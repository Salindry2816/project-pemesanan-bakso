<?php

namespace Database\Factories;

use App\Models\Menu;
use App\Models\MenuCategory;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Menu>
 */
class MenuFactory extends Factory
{
    public function definition(): array
    {
        return [
            'category_id' => MenuCategory::factory(),
            'name' => 'Bakso '.fake()->word(),
            'description' => fake()->sentence(),
            'price' => fake()->randomElement([15000, 17000, 18000, 20000, 22000]),
            'photo_path' => null,
            'is_available' => true,
            'sort_order' => fake()->numberBetween(1, 20),
        ];
    }
}
