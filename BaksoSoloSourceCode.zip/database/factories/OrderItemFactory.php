<?php

namespace Database\Factories;

use App\Models\Menu;
use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<OrderItem>
 */
class OrderItemFactory extends Factory
{
    public function definition(): array
    {
        $price = fake()->randomElement([17000, 18000, 22000]);
        $qty = fake()->numberBetween(1, 3);

        return [
            'order_id' => Order::factory(),
            'menu_id' => Menu::factory(),
            'name_snapshot' => 'Bakso Komplit',
            'price_snapshot' => $price,
            'qty' => $qty,
            'item_note' => null,
            'line_total' => $price * $qty,
        ];
    }
}
