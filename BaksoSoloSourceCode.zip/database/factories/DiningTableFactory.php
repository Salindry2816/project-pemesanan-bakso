<?php

namespace Database\Factories;

use App\Enums\TableType;
use App\Models\DiningTable;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<DiningTable>
 */
class DiningTableFactory extends Factory
{
    public function definition(): array
    {
        return [
            'code' => '2'.strtoupper(fake()->unique()->randomLetter()),
            'floor' => 2,
            'type' => TableType::Fixed,
            'capacity' => null,
            'is_active' => true,
        ];
    }

    public function freeTable(): static
    {
        return $this->state(fn () => [
            'code' => 'BEBAS',
            'floor' => 2,
            'type' => TableType::Free,
            'capacity' => 22,
            'is_active' => true,
        ]);
    }
}
