<?php

namespace Database\Factories;

use App\Models\BusinessProfile;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<BusinessProfile>
 */
class BusinessProfileFactory extends Factory
{
    public function definition(): array
    {
        return [
            'name' => 'Bakso Solo',
            'tagline' => 'Warung Bu Susi',
            'description' => 'Bakso Solo merupakan usaha kuliner milik Ibu Susi yang berlokasi di Kantin M, Lantai 2, Universitas Negeri Jakarta (UNJ).',
            'location' => 'Kantin M, Lantai 2, Universitas Negeri Jakarta (UNJ)',
            'phone' => '085215355501',
            'whatsapp' => '085215355501',
            'open_time' => '08.00',
            'close_time' => '17.00',
            'logo_path' => null,
            'qris_image_path' => null,
        ];
    }
}
