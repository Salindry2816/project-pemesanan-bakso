<?php

namespace Database\Factories;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Order;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Order>
 */
class OrderFactory extends Factory
{
    public function definition(): array
    {
        $subtotal = fake()->randomElement([17000, 18000, 22000, 35000, 40000]);

        return [
            'order_number' => now()->format('Ymd').'-'.str_pad((string) fake()->unique()->numberBetween(1, 9999), 4, '0', STR_PAD_LEFT),
            'customer_id' => Customer::factory(),
            'type' => OrderType::DineIn,
            'table_id' => DiningTable::factory(),
            'location_note' => null,
            'note' => null,
            'subtotal' => $subtotal,
            'total' => $subtotal,
            'payment_method' => PaymentMethod::Cash,
            'payment_status' => PaymentStatus::BelumBayar,
            'status' => OrderStatus::Diterima,
            'paid_at' => null,
        ];
    }
}
