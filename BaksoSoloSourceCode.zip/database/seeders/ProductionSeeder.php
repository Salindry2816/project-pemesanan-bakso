<?php

namespace Database\Seeders;

use App\Enums\TableType;
use App\Models\BusinessProfile;
use App\Models\DiningTable;
use App\Models\MenuCategory;
use App\Models\User;
use App\Support\TableCode;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;
use RuntimeException;

/**
 * ProductionSeeder dijalankan manual sekali saat setup awal
 * (contoh: `php artisan db:seed --force` di Railway), bukan di setiap deploy.
 * Seeder ini idempotent dan tidak menimpa data yang sudah ada di database.
 */
class ProductionSeeder extends Seeder
{
    public function run(): void
    {
        $adminUsername = trim((string) env('ADMIN_USERNAME', ''));
        $adminPassword = (string) env('ADMIN_PASSWORD', '');

        if ($adminUsername === '' || $adminPassword === '') {
            throw new RuntimeException(
                'ADMIN_USERNAME dan ADMIN_PASSWORD wajib diisi di environment sebelum menjalankan ProductionSeeder.'
            );
        }

        // 1. Admin user (buat hanya jika username belum ada; jangan timpa password/name jika sudah ada)
        User::firstOrCreate(
            ['username' => $adminUsername],
            [
                'name' => 'Ibu Susi (Admin)',
                'password' => Hash::make($adminPassword),
            ]
        );

        // 2. Coded tables 2A–2G (floor 2, type fixed) + 1 Free table ('BEBAS', capacity 22)
        // Gunakan firstOrCreate berdasarkan code agar tidak menimpa is_active/capacity yang sudah diubah admin.
        foreach (TableCode::range(2, 7) as $code) {
            DiningTable::firstOrCreate(
                ['code' => $code],
                [
                    'floor' => 2,
                    'type' => TableType::Fixed,
                    'capacity' => null,
                    'is_active' => true,
                ]
            );
        }

        DiningTable::firstOrCreate(
            ['code' => 'BEBAS'],
            [
                'floor' => 2,
                'type' => TableType::Free,
                'capacity' => 22,
                'is_active' => true,
            ]
        );

        // 3. Initial menu categories: Bakso, Paket, Minuman (jangan timpa sort_order yang sudah ada)
        $categories = [
            ['name' => 'Bakso', 'sort_order' => 1],
            ['name' => 'Paket', 'sort_order' => 2],
            ['name' => 'Minuman', 'sort_order' => 3],
        ];

        foreach ($categories as $category) {
            MenuCategory::firstOrCreate(
                ['name' => $category['name']],
                ['sort_order' => $category['sort_order']]
            );
        }

        // 4. Business profile (satu baris id = 1; jangan timpa jika sudah ada)
        BusinessProfile::firstOrCreate(
            ['id' => 1],
            [
                'name' => 'Bakso Solo',
                'tagline' => 'Warung Bu Susi',
                'description' => 'Bakso Solo merupakan usaha kuliner milik Ibu Susi yang berlokasi di Kantin M, Lantai 2, Universitas Negeri Jakarta (UNJ). Lokasinya yang dekat dengan tempat tinggal menjadi salah satu alasan Ibu Susi menjalankan usaha ini. Bakso Solo menyediakan beragam pilihan bakso yang dapat dinikmati oleh mahasiswa dan pengunjung di sekitar kampus.',
                'location' => 'Kantin M, Lantai 2, Universitas Negeri Jakarta (UNJ)',
                'phone' => '085215355501',
                'whatsapp' => '085215355501',
                'open_time' => '08.00',
                'close_time' => '17.00',
            ]
        );
    }
}
