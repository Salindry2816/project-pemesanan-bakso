<?php

namespace Database\Seeders;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderStatusLog;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class DemoSeeder extends Seeder
{
    public function run(): void
    {
        if (app()->environment('production')) {
            throw new RuntimeException('DemoSeeder tidak boleh dijalankan di environment production.');
        }

        $this->call(WarungCatalogSeeder::class);

        $menus = Menu::whereIn('name', ['Bakso + Indomie', 'Bakso Urat', 'Bakso Komplit'])
            ->get()
            ->keyBy('name');

        // Sample customers
        $customer1 = Customer::updateOrCreate(
            ['phone' => '6281234560001'],
            ['name' => 'Rizky Pratama']
        );
        $customer2 = Customer::updateOrCreate(
            ['phone' => '6281234560002'],
            ['name' => 'Siti Aisyah']
        );
        $customer3 = Customer::updateOrCreate(
            ['phone' => '6281234560003'],
            ['name' => 'Budi Santoso']
        );

        $table2A = DiningTable::where('code', '2A')->first();
        $table2B = DiningTable::where('code', '2B')->first();
        $table2C = DiningTable::where('code', '2C')->first();
        $admin = User::first();

        $datePrefix = now()->format('Ymd');

        $sampleOrders = [
            [
                'order_number' => "{$datePrefix}-0010",
                'customer' => $customer3,
                'table' => $table2C,
                'menu' => $menus['Bakso + Indomie'],
                'qty' => 1,
                'item_note' => null,
                'note' => null,
                'payment_method' => PaymentMethod::Qris,
                'payment_status' => PaymentStatus::BelumBayar,
                'status' => OrderStatus::Diterima,
            ],
            [
                'order_number' => "{$datePrefix}-0011",
                'customer' => $customer2,
                'table' => $table2B,
                'menu' => $menus['Bakso Urat'],
                'qty' => 1,
                'item_note' => null,
                'note' => null,
                'payment_method' => PaymentMethod::Cash,
                'payment_status' => PaymentStatus::BelumBayar,
                'status' => OrderStatus::Disiapkan,
            ],
            [
                'order_number' => "{$datePrefix}-0012",
                'customer' => $customer1,
                'table' => $table2A,
                'menu' => $menus['Bakso Komplit'],
                'qty' => 1,
                'item_note' => 'tanpa kecap',
                'note' => 'tanpa kecap, tambah bawang',
                'payment_method' => PaymentMethod::Qris,
                'payment_status' => PaymentStatus::BelumBayar,
                'status' => OrderStatus::Diproses,
            ],
        ];

        foreach ($sampleOrders as $sample) {
            /** @var Menu $menu */
            $menu = $sample['menu'];
            $lineTotal = $menu->price * $sample['qty'];

            $order = Order::updateOrCreate(
                ['order_number' => $sample['order_number']],
                [
                    'customer_id' => $sample['customer']->id,
                    'type' => OrderType::DineIn,
                    'table_id' => $sample['table']?->id,
                    'location_note' => null,
                    'note' => $sample['note'],
                    'subtotal' => $lineTotal,
                    'total' => $lineTotal,
                    'payment_method' => $sample['payment_method'],
                    'payment_status' => $sample['payment_status'],
                    'status' => $sample['status'],
                ]
            );

            OrderItem::updateOrCreate(
                [
                    'order_id' => $order->id,
                    'name_snapshot' => $menu->name,
                ],
                [
                    'menu_id' => $menu->id,
                    'price_snapshot' => $menu->price,
                    'qty' => $sample['qty'],
                    'item_note' => $sample['item_note'],
                    'line_total' => $lineTotal,
                ]
            );

            OrderStatusLog::firstOrCreate(
                [
                    'order_id' => $order->id,
                    'status' => $sample['status'],
                ],
                [
                    'changed_by' => $admin?->id,
                    'created_at' => now(),
                ]
            );
        }

        // Keep today's daily order sequence at least at #0012 so subsequent orders
        // created via OrderService do not collide with seeded demo orders.
        DB::table('order_sequences')->upsert(
            [
                'seq_date' => now()->toDateString(),
                'last_number' => 12,
            ],
            ['seq_date'],
            ['last_number' => DB::raw('GREATEST(last_number, 12)')]
        );
    }
}
