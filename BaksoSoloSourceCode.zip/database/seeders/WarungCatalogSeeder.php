<?php

namespace Database\Seeders;

use App\Models\BusinessProfile;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Support\MediaStorage;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Storage;

/**
 * WarungCatalogSeeder mengisi katalog menu asli Warung Bu Susi (12 item),
 * foto menu, logo usaha, dan gambar QRIS dari resources/assets/warung.
 * Idempotent dan aman dijalankan di environment mana pun.
 */
class WarungCatalogSeeder extends Seeder
{
    public function run(): void
    {
        $disk = Storage::disk(MediaStorage::disk());

        $categories = [
            'Bakso' => MenuCategory::firstOrCreate(['name' => 'Bakso'], ['sort_order' => 1]),
            'Paket' => MenuCategory::firstOrCreate(['name' => 'Paket'], ['sort_order' => 2]),
            'Minuman' => MenuCategory::firstOrCreate(['name' => 'Minuman'], ['sort_order' => 3]),
            'Tambahan' => MenuCategory::firstOrCreate(['name' => 'Tambahan'], ['sort_order' => 4]),
        ];

        // Copy logo & QRIS into media disk and attach to BusinessProfile if not set yet.
        $logoTarget = 'logos/logo-bakso-ibu-susi.jpg';
        $qrisTarget = 'qris/qris-bu-susi.png';

        $this->copyAssetIfMissing($disk, resource_path('assets/warung/branding/logo-bakso-ibu-susi.jpg'), $logoTarget);
        $this->copyAssetIfMissing($disk, resource_path('assets/warung/branding/qris-bu-susi.png'), $qrisTarget);

        $profile = BusinessProfile::find(1);
        if ($profile) {
            $updates = [];
            if (blank($profile->logo_path) && $disk->exists($logoTarget)) {
                $updates['logo_path'] = $logoTarget;
            }
            if (blank($profile->qris_image_path) && $disk->exists($qrisTarget)) {
                $updates['qris_image_path'] = $qrisTarget;
            }
            if ($updates !== []) {
                $profile->update($updates);
            }
        }

        // Rename legacy demo placeholder menu so local databases stay at 12 clean items.
        $legacyKeju = Menu::where('name', 'Bakso Keju')->first();
        if ($legacyKeju && ! Menu::where('name', 'Bakso Keju + Keju')->exists()) {
            $legacyKeju->update(['name' => 'Bakso Keju + Keju']);
        }

        $menusData = [
            [
                'category' => 'Bakso',
                'name' => 'Bakso Komplit',
                'description' => '(tahu • urat • telur)',
                'price' => 18000,
                'asset' => 'bakso-komplit.jpg',
                'sort_order' => 1,
            ],
            [
                'category' => 'Bakso',
                'name' => 'Bakso Urat',
                'description' => '(bakso urat besar)',
                'price' => 17000,
                'asset' => 'bakso-urat.jpg',
                'sort_order' => 2,
            ],
            [
                'category' => 'Bakso',
                'name' => 'Bakso Urat Dalam',
                'description' => '(bakso urat isian dalam)',
                'price' => 18000,
                'asset' => null,
                'sort_order' => 3,
            ],
            [
                'category' => 'Bakso',
                'name' => 'Bakso Mercon',
                'description' => '(pedas cabai rawit)',
                'price' => 22000,
                'asset' => 'bakso-mercon.jpg',
                'sort_order' => 4,
            ],
            [
                'category' => 'Bakso',
                'name' => 'Bakso Tahu',
                'description' => '(bakso + tahu isi)',
                'price' => 17000,
                'asset' => 'bakso-tahu.jpg',
                'sort_order' => 5,
            ],
            [
                'category' => 'Bakso',
                'name' => 'Bakso Keju + Keju',
                'description' => '(isian keju lumer)',
                'price' => 22000,
                'asset' => 'bakso-keju.jpg',
                'sort_order' => 6,
            ],
            [
                'category' => 'Bakso',
                'name' => 'Bakso Keju + Urat',
                'description' => '(bakso keju + bakso urat)',
                'price' => 20000,
                'asset' => null,
                'sort_order' => 7,
            ],
            [
                'category' => 'Bakso',
                'name' => 'Bakso Keju + Telor',
                'description' => '(bakso keju + bakso telur)',
                'price' => 22000,
                'asset' => 'bakso-telur.jpg',
                'sort_order' => 8,
            ],
            [
                'category' => 'Paket',
                'name' => 'Bakso + Indomie',
                'description' => '(bakso + mie instan)',
                'price' => 22000,
                'asset' => 'bakso-indomie.jpg',
                'sort_order' => 9,
            ],
            [
                'category' => 'Minuman',
                'name' => 'Es Teh / Teh Anget',
                'description' => '(pilihan es atau hangat)',
                'price' => 5000,
                'asset' => null,
                'sort_order' => 10,
            ],
            [
                'category' => 'Minuman',
                'name' => 'Es Jeruk / Jeruk Anget',
                'description' => '(pilihan es atau hangat)',
                'price' => 6000,
                'asset' => null,
                'sort_order' => 11,
            ],
            [
                'category' => 'Tambahan',
                'name' => 'Nasi Putih',
                'description' => '(porsi nasi putih hangat)',
                'price' => 5000,
                'asset' => null,
                'sort_order' => 12,
            ],
        ];

        foreach ($menusData as $item) {
            $photoPath = null;
            if ($item['asset'] !== null) {
                $target = 'menus/' . $item['asset'];
                $this->copyAssetIfMissing($disk, resource_path('assets/warung/menus/' . $item['asset']), $target);
                if ($disk->exists($target)) {
                    $photoPath = $target;
                }
            }

            $existing = Menu::where('name', $item['name'])->first();
            $resolvedPhotoPath = $existing && filled($existing->photo_path)
                ? $existing->photo_path
                : $photoPath;

            Menu::updateOrCreate(
                ['name' => $item['name']],
                [
                    'category_id' => $categories[$item['category']]->id,
                    'description' => $item['description'],
                    'price' => $item['price'],
                    'photo_path' => $resolvedPhotoPath,
                    'is_available' => $existing ? $existing->is_available : true,
                    'sort_order' => $item['sort_order'],
                ]
            );
        }
    }

    private function copyAssetIfMissing(\Illuminate\Contracts\Filesystem\Filesystem $disk, string $sourcePath, string $targetPath): void
    {
        if (! is_file($sourcePath) || $disk->exists($targetPath)) {
            return;
        }

        $contents = file_get_contents($sourcePath);
        if ($contents !== false) {
            $disk->put($targetPath, $contents);
        }
    }
}
