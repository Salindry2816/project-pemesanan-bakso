<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->string('order_number')->unique();
            $table->foreignId('customer_id')->constrained('customers')->restrictOnDelete();
            $table->enum('type', ['dine_in', 'take_away']);
            $table->foreignId('table_id')->nullable()->constrained('tables')->nullOnDelete();
            $table->string('location_note')->nullable();
            $table->text('note')->nullable();
            $table->unsignedInteger('subtotal');
            $table->unsignedInteger('total');
            $table->enum('payment_method', ['cash', 'qris']);
            $table->enum('payment_status', ['belum_bayar', 'lunas'])->default('belum_bayar');
            $table->enum('status', ['diterima', 'diproses', 'disiapkan', 'siap', 'selesai', 'dibatalkan'])->default('diterima');
            $table->timestamp('paid_at')->nullable();
            $table->timestamps();

            $table->index(['status', 'created_at']);
            $table->index(['table_id', 'status']);
            $table->index('customer_id');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
