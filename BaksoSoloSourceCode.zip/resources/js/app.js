import './bootstrap';
import Chart from 'chart.js/auto';

window.Chart = Chart;

window.playOrderChime = function () {
    try {
        if (localStorage.getItem('bakso_admin_muted') === '1') {
            return;
        }
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        if (!AudioCtx) {
            return;
        }
        const ctx = new AudioCtx();
        const notes = [587.33, 880.0, 1174.66]; // D5 -> A5 -> D6 warm bell chime
        const now = ctx.currentTime;

        notes.forEach((freq, idx) => {
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(freq, now + idx * 0.11);

            gain.gain.setValueAtTime(0.001, now + idx * 0.11);
            gain.gain.exponentialRampToValueAtTime(0.16, now + idx * 0.11 + 0.02);
            gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.11 + 0.45);

            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.start(now + idx * 0.11);
            osc.stop(now + idx * 0.11 + 0.46);
        });
    } catch {
        // Ignore audio autoplay blocks cleanly
    }
};
