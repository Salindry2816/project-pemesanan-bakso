@props([
    'variant' => 'primary',
    'type' => 'button',
    'disabled' => false,
    'fullWidth' => false,
])

@php
    $isDisabled = (bool) $disabled || $attributes->has('disabled');

    $baseClasses = 'inline-flex items-center justify-center gap-2 min-h-[52px] px-6 rounded-[12px] font-heading text-sm md:text-[15px] font-semibold transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-offset-2 select-none';

    $variantClasses = match (true) {
        $isDisabled => 'bg-asset text-[#9CA3AF] cursor-not-allowed pointer-events-none',
        $variant === 'green' => 'bg-green-dark text-white hover:opacity-95 focus:ring-green-dark cursor-pointer',
        $variant === 'outline' => 'bg-white text-text-body border-[1.5px] border-border-input hover:bg-cream focus:ring-maroon cursor-pointer',
        default => 'bg-primary-button text-white hover:bg-primary-button-hover focus:ring-primary-button cursor-pointer',
    };

    $widthClass = $fullWidth ? 'w-full' : '';
@endphp

<button
    type="{{ $type }}"
    @if ($isDisabled) disabled aria-disabled="true" @endif
    {{ $attributes->merge(['class' => trim("{$baseClasses} {$variantClasses} {$widthClass}")]) }}
>
    {{ $slot }}
</button>
