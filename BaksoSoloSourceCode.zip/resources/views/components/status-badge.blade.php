@props([
    'status',
])

@php
    use App\Enums\OrderStatus;

    $resolvedStatus = $status instanceof OrderStatus
        ? $status
        : OrderStatus::from((string) $status);
@endphp

<span
    style="background-color: {{ $resolvedStatus->badgeColor() }};"
    {{ $attributes->merge([
        'class' => 'inline-flex items-center justify-center min-w-[72px] md:min-w-[88px] h-6 px-3 rounded-pill text-white font-sub text-[10px] font-bold tracking-wide',
    ]) }}
>
    {{ $resolvedStatus->label() }}
</span>
