@props([
    'show' => false,
    'title' => '',
    'maxWidth' => 'md',
    'closeAction' => null,
])

@php
    $maxWidthClass = match ($maxWidth) {
        'sm' => 'max-w-sm',
        'lg' => 'max-w-lg',
        'xl' => 'max-w-xl',
        default => 'max-w-md',
    };
@endphp

@if ($show)
    <div
        class="fixed inset-0 z-50 flex items-center justify-center px-4 py-6 overflow-y-auto"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modal-title"
    >
        {{-- Backdrop --}}
        <div
            class="fixed inset-0 bg-text-primary/50 transition-opacity"
            @if ($closeAction)
                wire:click="{{ $closeAction }}"
            @endif
            aria-hidden="true"
        ></div>

        {{-- Modal Panel --}}
        <div class="relative z-10 w-full {{ $maxWidthClass }} bg-white border border-border-card rounded-[20px] shadow-card p-6">
            @if ($title !== '' || $closeAction)
                <div class="flex items-center justify-between gap-4 pb-4 mb-4 border-b border-border-card">
                    <h2 id="modal-title" class="font-heading text-lg font-semibold text-text-primary">
                        {{ $title }}
                    </h2>

                    @if ($closeAction)
                        <button
                            type="button"
                            wire:click="{{ $closeAction }}"
                            class="inline-flex items-center justify-center w-11 h-11 -mr-2 rounded-[12px] text-text-muted hover:text-text-primary hover:bg-cream transition-colors cursor-pointer"
                            aria-label="Tutup modal"
                        >
                            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <line x1="18" y1="6" x2="6" y2="18"/>
                                <line x1="6" y1="6" x2="18" y2="18"/>
                            </svg>
                        </button>
                    @endif
                </div>
            @endif

            <div>
                {{ $slot }}
            </div>

            @isset($footer)
                <div class="mt-6 pt-4 border-t border-border-card flex items-center justify-end gap-3">
                    {{ $footer }}
                </div>
            @endisset
        </div>
    </div>
@endif
