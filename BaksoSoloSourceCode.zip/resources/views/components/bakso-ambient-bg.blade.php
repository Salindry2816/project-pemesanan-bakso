{{-- Ambient 2D Culinary Background Layer for Customer & Admin Pages --}}
<div class="pointer-events-none fixed inset-0 overflow-hidden z-0 select-none" aria-hidden="true">
    {{-- Soft warm gradients --}}
    <div class="absolute -top-24 -right-20 w-64 h-64 sm:w-80 sm:h-80 md:w-[440px] md:h-[440px] rounded-full bg-accent-yellow/15 blur-3xl"></div>
    <div class="absolute top-1/3 -left-24 w-56 h-56 sm:w-72 sm:h-72 md:w-96 md:h-96 rounded-full bg-terracotta/12 blur-3xl"></div>
    <div class="absolute -bottom-20 right-1/4 w-60 h-60 sm:w-72 sm:h-72 rounded-full bg-beige/40 blur-3xl"></div>

    {{-- Subtle culinary dot motif --}}
    <div
        class="absolute inset-0 opacity-[0.2]"
        style="background-image: radial-gradient(#D7B996 1px, transparent 1px); background-size: 26px 26px;"
    ></div>

    {{-- Floating 2D Scallion / Meatball Accents (Visible on Mobile & Desktop) --}}
    <svg class="block absolute top-20 left-2 sm:top-24 sm:left-8 w-10 h-10 sm:w-16 sm:h-16 text-terracotta/25 animate-float-slow" viewBox="0 0 64 64" fill="none">
        <circle cx="24" cy="24" r="10" stroke="currentColor" stroke-width="4"/>
        <circle cx="44" cy="40" r="6" fill="currentColor" opacity="0.5"/>
    </svg>

    <svg class="block absolute top-28 right-3 sm:top-32 sm:right-12 w-12 h-12 sm:w-20 sm:h-20 text-green-mid/25 animate-float-slow" style="animation-delay: 1.5s" viewBox="0 0 80 80" fill="none">
        <path d="M18 46 C18 26, 44 18, 58 28 C54 48, 36 58, 18 46 Z" fill="currentColor"/>
        <path d="M22 44 C34 38, 46 34, 54 30" stroke="#FFFBEA" stroke-width="2.5" stroke-linecap="round"/>
    </svg>

    {{-- Floating Mini Meatball & Spice Accent (Mobile Mid-Left) --}}
    <svg class="block sm:hidden absolute bottom-44 left-3 w-12 h-12 text-maroon/20 animate-float-slow" style="animation-delay: 0.8s" viewBox="0 0 64 64" fill="none">
        <circle cx="24" cy="34" r="11" fill="currentColor"/>
        <circle cx="44" cy="22" r="7" fill="currentColor" opacity="0.7"/>
    </svg>

    {{-- 2D Animated Bakso Bowl with Rising Steam (Bottom-Right Corner, Mobile & Desktop) --}}
    <div class="block absolute bottom-20 right-2 sm:bottom-6 sm:right-6 md:bottom-8 md:right-10 opacity-30 sm:opacity-35">
        <x-bakso-bowl-illustration sizeClass="w-24 h-24 sm:w-32 sm:h-32 md:w-44 md:h-44" steamColor="#B85C3C" />
    </div>

    {{-- Smaller 2D Animated Bakso Bowl on Bottom-Left (Desktop & Tablet) --}}
    <div class="hidden md:block absolute bottom-12 left-8 opacity-25">
        <x-bakso-bowl-illustration sizeClass="w-28 h-28" steamColor="#782A25" />
    </div>
</div>
