@props([
    'label' => null,
    'name' => null,
    'id' => null,
    'error' => null,
    'required' => false,
])

@php
    $inputId = $id ?? $name ?? 'select-' . \Illuminate\Support\Str::random(6);
    $resolvedError = $error ?? ($name && isset($errors) ? $errors->first($name) : null);
@endphp

<div class="w-full">
    @if ($label)
        <label
            for="{{ $inputId }}"
            class="block font-sub text-xs font-bold text-text-body mb-1.5"
        >
            {{ $label }}
            @if ($required)
                <span class="text-primary-button" aria-hidden="true">*</span>
            @endif
        </label>
    @endif

    <div class="relative">
        <select
            id="{{ $inputId }}"
            @if ($name) name="{{ $name }}" @endif
            @if ($required) required @endif
            @if ($resolvedError) aria-invalid="true" aria-describedby="{{ $inputId }}-error" @endif
            {{ $attributes->merge([
                'class' => 'w-full min-h-[48px] pl-4 pr-10 py-2.5 bg-white border rounded-[12px] font-body text-[13px] text-text-primary appearance-none focus:outline-none focus:ring-2 transition-colors cursor-pointer ' . ($resolvedError ? 'border-primary-button focus:ring-primary-button/30' : 'border-border-input focus:border-maroon focus:ring-maroon/20'),
            ]) }}
        >
            {{ $slot }}
        </select>

        <span class="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3.5 text-text-muted" aria-hidden="true">
            <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="6 9 12 15 18 9"/>
            </svg>
        </span>
    </div>

    @if ($resolvedError)
        <p id="{{ $inputId }}-error" class="mt-1.5 font-body text-xs text-primary-button" role="alert">
            {{ $resolvedError }}
        </p>
    @endif
</div>
