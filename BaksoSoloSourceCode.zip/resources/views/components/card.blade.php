@props([
    'padding' => 'p-5 md:p-6',
    'radius' => 'rounded-[18px] md:rounded-[20px]',
])

<div {{ $attributes->merge([
    'class' => trim("bg-white border border-border-card shadow-card {$radius} {$padding}"),
]) }}>
    {{ $slot }}
</div>
