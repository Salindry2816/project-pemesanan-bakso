@props([
    'name' => null,
    'id' => null,
    'label' => null,
    'accept' => null,
    'error' => null,
    'required' => false,
    'hint' => null,
])

@php
    $inputId = $id ?? $name ?? 'file-input-' . uniqid();
    $errorMessage = $error ?? ($name && isset($errors) ? $errors->first($name) : null);
@endphp

<div class="w-full space-y-1.5" x-data="{ fileName: '' }">
    @if ($label)
        <label for="{{ $inputId }}" class="block font-sub text-xs md:text-[13px] font-bold text-text-primary">
            {{ $label }}
            @if ($required)
                <span class="text-primary-button" aria-hidden="true">*</span>
            @endif
        </label>
    @endif

    <div>
        <label
            for="{{ $inputId }}"
            tabindex="0"
            @keydown.enter.prevent="$refs.fileInput.click()"
            @keydown.space.prevent="$refs.fileInput.click()"
            class="flex items-center gap-3 p-1.5 rounded-[12px] bg-white border border-border-card hover:bg-cream/40 transition-colors cursor-pointer focus:outline-none focus:ring-2 focus:ring-maroon/20 focus:border-maroon focus-within:ring-2 focus-within:ring-maroon/20 focus-within:border-maroon {{ $errorMessage ? 'border-primary-button ring-1 ring-primary-button/20' : '' }}"
        >
            <input
                x-ref="fileInput"
                id="{{ $inputId }}"
                type="file"
                @if ($name) name="{{ $name }}" @endif
                @if ($accept) accept="{{ $accept }}" @endif
                @change="fileName = $event.target.files[0] ? $event.target.files[0].name : ''"
                class="sr-only"
                {{ $attributes }}
            />

            <span class="inline-flex items-center justify-center min-h-[36px] px-3.5 rounded-[8px] bg-cream border border-border-card font-sub text-xs font-bold text-maroon hover:bg-nav-active-bg transition-colors shrink-0 select-none">
                Pilih File
            </span>

            <span
                class="font-body text-xs text-text-muted truncate min-w-0 flex-1 pr-2 select-none"
                x-text="fileName ? fileName : 'Belum ada file dipilih'"
            >
                Belum ada file dipilih
            </span>
        </label>
    </div>

    @if ($hint)
        <p class="font-body text-[11px] text-text-muted">{{ $hint }}</p>
    @endif

    @if ($errorMessage)
        <p class="font-body text-xs text-primary-button" role="alert">
            {{ $errorMessage }}
        </p>
    @endif
</div>
