@props([
    'title' => 'Dashboard',
    'activeMenu' => null,
])

@php
    $adminUsername = auth()->user()?->username ?? 'admin';
    $adminInitial = strtoupper(substr($adminUsername, 0, 1));
    $dashboardUrl = route('admin.dashboard');
    $hasMenusRoute = true;
    $hasCategoriesRoute = true;
    $hasTablesRoute = true;
    $hasProfileRoute = true;
    $hasQrRoute = true;
    $hasLogoutRoute = true;

    try {
        $businessProfile = \App\Models\BusinessProfile::query()->find(1);
    } catch (\Throwable) {
        $businessProfile = null;
    }
    $businessLogoUrl = \App\Support\MediaStorage::url($businessProfile?->logo_path);
    $businessName = $businessProfile?->name ?? 'Bakso Solo';
    $businessTagline = $businessProfile?->tagline ?? 'Warung Bu Susi';

    $resolvedActiveMenu = $activeMenu ?? match (true) {
        request()->routeIs('admin.reports*') => 'laporan',
        request()->routeIs('admin.menus*') => 'menu',
        request()->routeIs('admin.categories*') => 'kategori',
        request()->routeIs('admin.tables*') => 'meja',
        request()->routeIs('admin.profile*') => 'profil',
        request()->routeIs('admin.password*') => 'password',
        request()->routeIs('admin.qr*') => 'qr',
        default => 'pesanan',
    };
@endphp

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title }} – Admin {{ config('app.name', 'Bakso Solo') }}</title>
    @include('partials.head-assets')
</head>
<body
    x-data="{ mobileMenuOpen: false }"
    @keydown.window.escape="mobileMenuOpen = false"
    class="relative bg-cream text-text-primary font-body antialiased min-h-screen flex"
>
    <x-bakso-ambient-bg />
    {{-- Desktop Left Sidebar (240px width per W-Penjual_02-Dashboard.svg) --}}
    <aside class="hidden md:flex md:flex-col md:w-[240px] md:fixed md:inset-y-0 bg-white border-r border-border-card z-30">
        {{-- Logo Header --}}
        <div class="px-6 pt-5 pb-6 flex items-center gap-2.5">
            <div class="w-10 h-10 rounded-full bg-asset flex items-center justify-center font-sub text-[11px] font-semibold text-[#6B6B6B] shrink-0 overflow-hidden">
                @if ($businessLogoUrl)
                    <img src="{{ $businessLogoUrl }}" alt="Logo {{ $businessName }}" class="w-full h-full object-cover">
                @else
                    LOGO
                @endif
            </div>
            <div class="min-w-0">
                <p class="font-heading text-[17px] font-bold text-maroon leading-tight truncate">{{ $businessName }}</p>
                <p class="font-sub text-[11px] text-text-muted leading-tight truncate">{{ $businessTagline }}</p>
            </div>
        </div>

        {{-- Grouped Navigation Links --}}
        <nav class="flex-1 px-4 pt-2 pb-4 space-y-5 overflow-y-auto" aria-label="Menu Admin">
            {{-- Group: Operasional --}}
            <div class="space-y-1">
                <p class="px-4 font-sub text-[11px] font-bold uppercase tracking-wider text-text-muted/80">Operasional</p>
                <a
                    href="{{ $dashboardUrl }}"
                    class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'pesanan' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                >
                    <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <rect x="5" y="4" width="14" height="17" rx="3"/>
                        <path d="M9 4V3h6v1M9 11h6M9 15h4"/>
                    </svg>
                    <span>Pesanan</span>
                </a>
                <a
                    href="{{ route('admin.reports') }}"
                    class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'laporan' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                >
                    <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M3 3v18h18"/>
                        <path d="M7 14l4-4 4 3 5-6"/>
                    </svg>
                    <span>Laporan</span>
                </a>
            </div>

            {{-- Group: Katalog --}}
            <div class="space-y-1">
                <p class="px-4 font-sub text-[11px] font-bold uppercase tracking-wider text-text-muted/80">Katalog</p>

                @if ($hasMenusRoute)
                    <a
                        href="{{ route('admin.menus') }}"
                        class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'menu' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <rect x="4" y="4" width="6" height="6" rx="1.5"/>
                            <rect x="14" y="4" width="6" height="6" rx="1.5"/>
                            <rect x="4" y="14" width="6" height="6" rx="1.5"/>
                            <rect x="14" y="14" width="6" height="6" rx="1.5"/>
                        </svg>
                        <span>Menu</span>
                    </a>
                @else
                    <span
                        aria-disabled="true"
                        class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm font-semibold text-text-muted/50 cursor-not-allowed select-none"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <rect x="4" y="4" width="6" height="6" rx="1.5"/>
                            <rect x="14" y="4" width="6" height="6" rx="1.5"/>
                            <rect x="4" y="14" width="6" height="6" rx="1.5"/>
                            <rect x="14" y="14" width="6" height="6" rx="1.5"/>
                        </svg>
                        <span>Menu</span>
                    </span>
                @endif

                @if ($hasCategoriesRoute)
                    <a
                        href="{{ route('admin.categories') }}"
                        class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'kategori' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M4 6h16M4 12h16M4 18h10"/>
                        </svg>
                        <span>Kategori</span>
                    </a>
                @else
                    <span
                        aria-disabled="true"
                        class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm font-semibold text-text-muted/50 cursor-not-allowed select-none"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M4 6h16M4 12h16M4 18h10"/>
                        </svg>
                        <span>Kategori</span>
                    </span>
                @endif
            </div>

            {{-- Group: Pengaturan --}}
            <div class="space-y-1">
                <p class="px-4 font-sub text-[11px] font-bold uppercase tracking-wider text-text-muted/80">Pengaturan</p>

                @if ($hasTablesRoute)
                    <a
                        href="{{ route('admin.tables') }}"
                        class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'meja' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <rect x="3" y="5" width="18" height="14" rx="2"/>
                            <path d="M3 10h18M9 19v2M15 19v2"/>
                        </svg>
                        <span>Meja</span>
                    </a>
                @else
                    <span
                        aria-disabled="true"
                        class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm font-semibold text-text-muted/50 cursor-not-allowed select-none"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <rect x="3" y="5" width="18" height="14" rx="2"/>
                            <path d="M3 10h18M9 19v2M15 19v2"/>
                        </svg>
                        <span>Meja</span>
                    </span>
                @endif

                @if ($hasProfileRoute)
                    <a
                        href="{{ route('admin.profile') }}"
                        class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'profil' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <circle cx="12" cy="8" r="4"/>
                            <path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>
                        </svg>
                        <span>Profil Usaha</span>
                    </a>
                @else
                    <span
                        aria-disabled="true"
                        class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm font-semibold text-text-muted/50 cursor-not-allowed select-none"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <circle cx="12" cy="8" r="4"/>
                            <path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>
                        </svg>
                        <span>Profil Usaha</span>
                    </span>
                @endif

                @if ($hasQrRoute)
                    <a
                        href="{{ route('admin.qr') }}"
                        class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'qr' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <rect x="3" y="3" width="7" height="7" rx="1"/>
                            <rect x="14" y="3" width="7" height="7" rx="1"/>
                            <rect x="3" y="14" width="7" height="7" rx="1"/>
                            <path d="M14 14h3v3h-3zM18 18h3v3h-3zM18 14h3M14 18v3"/>
                        </svg>
                        <span>Cetak QR</span>
                    </a>
                @else
                    <span
                        aria-disabled="true"
                        class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm font-semibold text-text-muted/50 cursor-not-allowed select-none"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <rect x="3" y="3" width="7" height="7" rx="1"/>
                            <rect x="14" y="3" width="7" height="7" rx="1"/>
                            <rect x="3" y="14" width="7" height="7" rx="1"/>
                            <path d="M14 14h3v3h-3zM18 18h3v3h-3zM18 14h3M14 18v3"/>
                        </svg>
                        <span>Cetak QR</span>
                    </span>
                @endif

                <a
                    href="{{ route('admin.password') }}"
                    class="flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'password' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                >
                    <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <rect x="3" y="11" width="18" height="11" rx="2"/>
                        <path d="M7 11V7a5 5 0 0110 0v4"/>
                    </svg>
                    <span>Ganti Password</span>
                </a>
            </div>
        </nav>

        {{-- Logout Button in Sidebar Footer --}}
        @if ($hasLogoutRoute)
            <div class="p-4 border-t border-border-card">
                <form method="POST" action="{{ route('admin.logout') }}">
                    @csrf
                    <button
                        type="submit"
                        class="w-full flex items-center gap-3 px-4 min-h-[44px] rounded-[12px] font-sub text-sm font-semibold text-text-body hover:bg-nav-active-bg hover:text-primary-button transition-colors cursor-pointer"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/>
                            <polyline points="16 17 21 12 16 7"/>
                            <line x1="21" y1="12" x2="9" y2="12"/>
                        </svg>
                        <span>Keluar</span>
                    </button>
                </form>
            </div>
        @endif
    </aside>

    {{-- Main Column --}}
    <div class="relative z-10 flex-1 min-w-0 w-full flex flex-col md:pl-[240px] min-h-screen">
        {{-- Desktop Topbar (72px height per W-Penjual_02-Dashboard.svg) --}}
        <header class="hidden md:flex items-center justify-between h-[72px] px-10 bg-white border-b border-border-card sticky top-0 z-20">
            <h1 class="font-heading text-xl font-semibold text-text-primary">{{ $title }}</h1>

            <div class="flex items-center gap-3.5">
                <livewire:admin.order-notification-bell wire:key="admin-bell-desktop" />

                <span class="font-sub text-[13px] font-semibold text-text-body">{{ $adminUsername }}</span>
                <div class="w-9 h-9 rounded-full bg-maroon text-white flex items-center justify-center font-heading text-sm font-bold">
                    {{ $adminInitial }}
                </div>
            </div>
        </header>

        {{-- Mobile Header (with Hamburger Drawer Trigger + Notification Bell) --}}
        <header class="md:hidden sticky top-0 z-20 bg-cream/95 backdrop-blur-xs border-b border-border-card/70 flex items-center justify-between gap-2 px-4 py-3">
            <div class="flex items-center gap-2 min-w-0">
                <button
                    type="button"
                    @click="mobileMenuOpen = true"
                    class="inline-flex items-center justify-center min-w-[42px] min-h-[42px] rounded-[12px] border border-border-card bg-white text-text-primary hover:bg-cream transition-colors cursor-pointer shrink-0"
                    aria-label="Buka menu admin"
                >
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <line x1="3" y1="6" x2="21" y2="6"/>
                        <line x1="3" y1="12" x2="21" y2="12"/>
                        <line x1="3" y1="18" x2="21" y2="18"/>
                    </svg>
                </button>

                @if ($businessLogoUrl)
                    <div class="w-8 h-8 rounded-full overflow-hidden shrink-0 border border-border-card bg-white">
                        <img src="{{ $businessLogoUrl }}" alt="Logo {{ $businessName }}" class="w-full h-full object-cover">
                    </div>
                @endif
                <h1 class="font-heading text-base font-semibold text-text-primary truncate">{{ $title }}</h1>
            </div>

            <div class="flex items-center gap-2 shrink-0">
                <livewire:admin.order-notification-bell wire:key="admin-bell-mobile" />

                @if ($hasLogoutRoute)
                    <form method="POST" action="{{ route('admin.logout') }}">
                        @csrf
                        <button
                            type="submit"
                            class="inline-flex items-center justify-center min-w-[42px] min-h-[42px] px-3 rounded-[10px] font-sub text-xs font-bold text-maroon hover:bg-nav-active-bg transition-colors cursor-pointer"
                        >
                            Keluar
                        </button>
                    </form>
                @endif
            </div>
        </header>

        {{-- Mobile Slide-Over Admin Menu Drawer --}}
        <div
            x-show="mobileMenuOpen"
            x-cloak
            class="md:hidden fixed inset-0 z-50 flex"
            role="dialog"
            aria-modal="true"
            aria-label="Menu Navigasi Admin"
        >
            <div
                x-show="mobileMenuOpen"
                x-transition.opacity
                @click="mobileMenuOpen = false"
                class="fixed inset-0 bg-black/50 backdrop-blur-xs"
            ></div>

            <div
                x-show="mobileMenuOpen"
                x-transition:enter="transition ease-out duration-200 transform"
                x-transition:enter-start="-translate-x-full"
                x-transition:enter-end="translate-x-0"
                x-transition:leave="transition ease-in duration-150 transform"
                x-transition:leave-start="translate-x-0"
                x-transition:leave-end="-translate-x-full"
                class="relative w-72 max-w-[85vw] bg-white h-full shadow-2xl border-r border-border-card flex flex-col z-10"
            >
                <div class="px-5 py-4 border-b border-border-card flex items-center justify-between gap-2">
                    <div class="flex items-center gap-2.5 min-w-0">
                        <div class="w-9 h-9 rounded-full bg-asset flex items-center justify-center font-sub text-[10px] font-semibold text-[#6B6B6B] shrink-0 overflow-hidden border border-border-card">
                            @if ($businessLogoUrl)
                                <img src="{{ $businessLogoUrl }}" alt="Logo {{ $businessName }}" class="w-full h-full object-cover">
                            @else
                                LOGO
                            @endif
                        </div>
                        <div class="min-w-0">
                            <p class="font-heading text-sm font-bold text-maroon leading-tight truncate">{{ $businessName }}</p>
                            <p class="font-sub text-[11px] text-text-muted leading-tight truncate">{{ $adminUsername }}</p>
                        </div>
                    </div>

                    <button
                        type="button"
                        @click="mobileMenuOpen = false"
                        class="inline-flex items-center justify-center min-w-[38px] min-h-[38px] rounded-[10px] text-text-muted hover:bg-cream hover:text-text-primary cursor-pointer"
                        aria-label="Tutup menu admin"
                    >
                        ✕
                    </button>
                </div>

                <nav class="flex-1 px-4 py-4 space-y-5 overflow-y-auto" aria-label="Menu Lengkap Admin">
                    <div class="space-y-1">
                        <p class="px-3 font-sub text-[11px] font-bold uppercase tracking-wider text-text-muted/80">Operasional</p>
                        <a
                            href="{{ $dashboardUrl }}"
                            @click="mobileMenuOpen = false"
                            class="flex items-center gap-3 px-3 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'pesanan' && ! request()->routeIs('admin.orders.index') ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                        >
                            <span>Dashboard Pesanan</span>
                        </a>
                        <a
                            href="{{ route('admin.orders.index') }}"
                            @click="mobileMenuOpen = false"
                            class="flex items-center gap-3 px-3 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ request()->routeIs('admin.orders.index') ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                        >
                            <span>Semua Pesanan</span>
                        </a>
                        <a
                            href="{{ route('admin.reports') }}"
                            @click="mobileMenuOpen = false"
                            class="flex items-center gap-3 px-3 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'laporan' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                        >
                            <span>Laporan Penjualan</span>
                        </a>
                    </div>

                    <div class="space-y-1">
                        <p class="px-3 font-sub text-[11px] font-bold uppercase tracking-wider text-text-muted/80">Katalog</p>
                        <a
                            href="{{ route('admin.menus') }}"
                            @click="mobileMenuOpen = false"
                            class="flex items-center gap-3 px-3 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'menu' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                        >
                            <span>Menu</span>
                        </a>
                        <a
                            href="{{ route('admin.categories') }}"
                            @click="mobileMenuOpen = false"
                            class="flex items-center gap-3 px-3 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'kategori' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                        >
                            <span>Kategori</span>
                        </a>
                    </div>

                    <div class="space-y-1">
                        <p class="px-3 font-sub text-[11px] font-bold uppercase tracking-wider text-text-muted/80">Pengaturan</p>
                        <a
                            href="{{ route('admin.tables') }}"
                            @click="mobileMenuOpen = false"
                            class="flex items-center gap-3 px-3 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'meja' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                        >
                            <span>Meja</span>
                        </a>
                        <a
                            href="{{ route('admin.profile') }}"
                            @click="mobileMenuOpen = false"
                            class="flex items-center gap-3 px-3 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'profil' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                        >
                            <span>Profil Usaha</span>
                        </a>
                        <a
                            href="{{ route('admin.qr') }}"
                            @click="mobileMenuOpen = false"
                            class="flex items-center gap-3 px-3 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'qr' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                        >
                            <span>Cetak QR</span>
                        </a>
                        <a
                            href="{{ route('admin.password') }}"
                            @click="mobileMenuOpen = false"
                            class="flex items-center gap-3 px-3 min-h-[44px] rounded-[12px] font-sub text-sm transition-colors {{ $resolvedActiveMenu === 'password' ? 'bg-nav-active-bg text-primary-button font-bold' : 'text-text-muted font-semibold hover:bg-cream' }}"
                        >
                            <span>Ganti Password</span>
                        </a>
                    </div>
                </nav>

                @if ($hasLogoutRoute)
                    <div class="p-4 border-t border-border-card">
                        <form method="POST" action="{{ route('admin.logout') }}">
                            @csrf
                            <button
                                type="submit"
                                class="w-full flex items-center justify-center gap-2 min-h-[44px] rounded-[12px] bg-primary-button/10 text-primary-button font-sub text-sm font-bold hover:bg-primary-button hover:text-white transition-colors cursor-pointer"
                            >
                                <span>Keluar</span>
                            </button>
                        </form>
                    </div>
                @endif
            </div>
        </div>

        {{-- Page Content --}}
        <main class="flex-1 w-full min-w-0 px-4 sm:px-6 py-4 md:px-10 md:py-8 pb-[calc(7.5rem+env(safe-area-inset-bottom,0px))] md:pb-10">
            {{ $slot }}
        </main>

        {{-- Mobile Bottom Navigation --}}
        <nav
            aria-label="Navigasi Bawah Admin"
            class="md:hidden fixed bottom-0 inset-x-0 z-30 bg-white border-t border-border-card shadow-[0_-2px_0_0_#EFE6D2] pb-[env(safe-area-inset-bottom,0px)]"
        >
            <div class="grid grid-cols-4 h-[76px]">
                <a
                    href="{{ $dashboardUrl }}"
                    class="flex flex-col items-center justify-center gap-1 min-h-[44px] {{ $resolvedActiveMenu === 'pesanan' ? 'text-primary-button font-bold' : 'text-text-muted font-semibold' }}"
                >
                    <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <rect x="5" y="4" width="14" height="17" rx="3"/>
                        <path d="M9 4V3h6v1M9 11h6M9 15h4"/>
                    </svg>
                    <span class="font-sub text-[10px]">Pesanan</span>
                </a>

                <a
                    href="{{ route('admin.reports') }}"
                    class="flex flex-col items-center justify-center gap-1 min-h-[44px] {{ $resolvedActiveMenu === 'laporan' ? 'text-primary-button font-bold' : 'text-text-muted font-semibold' }}"
                >
                    <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M3 3v18h18"/>
                        <path d="M7 14l4-4 4 3 5-6"/>
                    </svg>
                    <span class="font-sub text-[10px]">Laporan</span>
                </a>

                @if ($hasMenusRoute)
                    <a
                        href="{{ route('admin.menus') }}"
                        class="flex flex-col items-center justify-center gap-1 min-h-[44px] {{ in_array($resolvedActiveMenu, ['menu', 'kategori'], true) ? 'text-primary-button font-bold' : 'text-text-muted font-semibold' }}"
                    >
                        <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <rect x="4" y="4" width="6" height="6" rx="1.5"/>
                            <rect x="14" y="4" width="6" height="6" rx="1.5"/>
                            <rect x="4" y="14" width="6" height="6" rx="1.5"/>
                            <rect x="14" y="14" width="6" height="6" rx="1.5"/>
                        </svg>
                        <span class="font-sub text-[10px]">Menu</span>
                    </a>
                @else
                    <span
                        aria-disabled="true"
                        class="flex flex-col items-center justify-center gap-1 min-h-[44px] text-text-muted/50 cursor-not-allowed select-none"
                    >
                        <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <rect x="4" y="4" width="6" height="6" rx="1.5"/>
                            <rect x="14" y="4" width="6" height="6" rx="1.5"/>
                            <rect x="4" y="14" width="6" height="6" rx="1.5"/>
                            <rect x="14" y="14" width="6" height="6" rx="1.5"/>
                        </svg>
                        <span class="font-sub text-[10px] font-semibold">Menu</span>
                    </span>
                @endif

                @if ($hasProfileRoute)
                    <a
                        href="{{ route('admin.profile') }}"
                        class="flex flex-col items-center justify-center gap-1 min-h-[44px] {{ $resolvedActiveMenu === 'profil' ? 'text-primary-button font-bold' : 'text-text-muted font-semibold' }}"
                    >
                        <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <circle cx="12" cy="8" r="4"/>
                            <path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>
                        </svg>
                        <span class="font-sub text-[10px]">Profil</span>
                    </a>
                @else
                    <span
                        aria-disabled="true"
                        class="flex flex-col items-center justify-center gap-1 min-h-[44px] text-text-muted/50 cursor-not-allowed select-none"
                    >
                        <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <circle cx="12" cy="8" r="4"/>
                            <path d="M4 21c1-4 4-6 8-6s7 2 8 6"/>
                        </svg>
                        <span class="font-sub text-[10px] font-semibold">Profil</span>
                    </span>
                @endif
            </div>
        </nav>
    </div>
</body>
</html>
