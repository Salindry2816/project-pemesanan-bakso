@props([
    'title' => null,
    'activeNav' => null,
    'showNav' => true,
])

@php
    try {
        $businessProfile = \App\Models\BusinessProfile::query()->find(1);
    } catch (\Throwable) {
        $businessProfile = null;
    }
    $businessLogoUrl = \App\Support\MediaStorage::url($businessProfile?->logo_path);
    $businessName = $businessProfile?->name ?? 'Bakso Solo';
    $businessTagline = $businessProfile?->tagline ?? 'Warung Bu Susi';

    $customerId = session('customer_id');
    $customer = null;
    if ($customerId) {
        try {
            $customer = \App\Models\Customer::query()->find($customerId);
        } catch (\Throwable) {
            $customer = null;
        }
    }

    $orderType = session('order_type');
    $tableId = session('table_id');
    $tableBadge = null;
    if ($orderType === 'take_away') {
        $tableBadge = 'Bungkus';
    } elseif ($orderType === 'dine_in' && $tableId) {
        try {
            $tableModel = \App\Models\DiningTable::query()->find($tableId);
            $tableBadge = $tableModel ? ($tableModel->code === 'BEBAS' ? 'Meja Bebas' : 'Meja ' . $tableModel->code) : null;
        } catch (\Throwable) {
            $tableBadge = null;
        }
    }

    $cart = session('cart', []);
    $cartItemCount = 0;
    if (is_array($cart)) {
        foreach ($cart as $item) {
            $cartItemCount += (int) ($item['qty'] ?? 0);
        }
    }

    $homeUrl = $customer ? route('customer.table') : route('customer.phone');
    $menuUrl = route('customer.menu');
    $cartUrl = route('customer.cart');
    $ordersUrl = route('customer.orders');
    $profileUrl = route('customer.profile');
    $resetUrl = route('customer.reset');

    $resolvedActiveNav = $activeNav ?? match (true) {
        request()->routeIs('customer.menu*') => 'menu',
        request()->routeIs('customer.cart*', 'customer.confirm*') => 'keranjang',
        request()->routeIs('customer.orders*', 'customer.order.*') => 'pesanan',
        request()->routeIs('customer.profile*') => 'profil',
        default => 'beranda',
    };
@endphp

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ? "{$title} – " . $businessName : "{$businessName} – {$businessTagline}" }}</title>
    @include('partials.head-assets')
    @livewireStyles
</head>
<body class="relative bg-cream text-text-primary font-body antialiased min-h-screen flex flex-col selection:bg-maroon selection:text-white">
    <x-bakso-ambient-bg />

    {{-- Desktop Top Navbar (1440px reference) --}}
    <header class="hidden md:block bg-white border-b border-border-card sticky top-0 z-30 shadow-xs">
        <div class="max-w-6xl mx-auto px-8 h-[72px] flex items-center justify-between gap-6">
            <a href="{{ $homeUrl }}" class="flex items-center gap-3 min-h-[44px]">
                <div class="w-11 h-11 rounded-full bg-asset flex items-center justify-center font-sub text-[11px] font-semibold text-[#6B6B6B] shrink-0 overflow-hidden border border-border-card">
                    @if ($businessLogoUrl)
                        <img src="{{ $businessLogoUrl }}" alt="Logo {{ $businessName }}" class="w-full h-full object-cover">
                    @else
                        LOGO
                    @endif
                </div>
                <div>
                    <p class="font-heading text-lg font-bold text-maroon leading-tight">{{ $businessName }}</p>
                    <p class="font-sub text-[11px] text-text-muted leading-tight">{{ $businessTagline }}</p>
                </div>
            </a>

            @if ($showNav)
                <nav class="flex items-center gap-8" aria-label="Navigasi Utama Pembeli">
                    <a
                        href="{{ $homeUrl }}"
                        class="relative inline-flex items-center min-h-[44px] font-sub text-[15px] transition-colors {{ $resolvedActiveNav === 'beranda' ? 'font-bold text-primary-button' : 'font-semibold text-text-muted hover:text-text-primary' }}"
                    >
                        Beranda
                        @if ($resolvedActiveNav === 'beranda')
                            <span class="absolute bottom-0 left-0 right-0 h-[3px] rounded-full bg-primary-button"></span>
                        @endif
                    </a>

                    <a
                        href="{{ $menuUrl }}"
                        class="relative inline-flex items-center min-h-[44px] font-sub text-[15px] transition-colors {{ $resolvedActiveNav === 'menu' ? 'font-bold text-primary-button' : 'font-semibold text-text-muted hover:text-text-primary' }}"
                    >
                        Menu
                        @if ($resolvedActiveNav === 'menu')
                            <span class="absolute bottom-0 left-0 right-0 h-[3px] rounded-full bg-primary-button"></span>
                        @endif
                    </a>

                    <a
                        href="{{ $ordersUrl }}"
                        class="relative inline-flex items-center min-h-[44px] font-sub text-[15px] transition-colors {{ $resolvedActiveNav === 'pesanan' ? 'font-bold text-primary-button' : 'font-semibold text-text-muted hover:text-text-primary' }}"
                    >
                        Pesanan
                        @if ($resolvedActiveNav === 'pesanan')
                            <span class="absolute bottom-0 left-0 right-0 h-[3px] rounded-full bg-primary-button"></span>
                        @endif
                    </a>

                    <a
                        href="{{ $profileUrl }}"
                        class="relative inline-flex items-center min-h-[44px] font-sub text-[15px] transition-colors {{ $resolvedActiveNav === 'profil' ? 'font-bold text-primary-button' : 'font-semibold text-text-muted hover:text-text-primary' }}"
                    >
                        Profil
                        @if ($resolvedActiveNav === 'profil')
                            <span class="absolute bottom-0 left-0 right-0 h-[3px] rounded-full bg-primary-button"></span>
                        @endif
                    </a>
                </nav>
            @endif

            <div class="flex items-center gap-4">
                @if ($customer)
                    <div class="flex items-center gap-2 px-3 py-1.5 rounded-[12px] bg-cream/70 border border-border-card text-xs">
                        @if ($tableBadge)
                            <span class="px-2 py-0.5 rounded-pill bg-maroon text-white font-sub font-bold text-[11px]">
                                {{ $tableBadge }}
                            </span>
                            <a href="{{ route('customer.table') }}" class="text-maroon hover:underline font-sub font-semibold text-[11px]" title="Ganti meja">
                                Ganti meja
                            </a>
                        @endif
                        <span class="font-sub font-semibold text-text-body">
                            {{ str_starts_with($customer->phone, '62') ? '0' . substr($customer->phone, 2) : $customer->phone }}
                        </span>
                        <form method="POST" action="{{ $resetUrl }}" class="inline">
                            @csrf
                            <button
                                type="submit"
                                class="text-primary-button hover:underline font-sub font-bold text-[11px] ml-1 cursor-pointer"
                                title="Ganti nomor atau meja"
                            >
                                (Ganti)
                            </button>
                        </form>
                    </div>
                @endif

                @if ($showNav)
                    <a
                        href="{{ $cartUrl }}"
                        class="relative inline-flex items-center justify-center min-w-[44px] min-h-[44px] px-3 rounded-[12px] border border-border-card text-maroon hover:bg-cream transition-colors cursor-pointer"
                        title="Keranjang Pesanan"
                        aria-label="Keranjang Pesanan"
                    >
                        <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>
                            <line x1="3" y1="6" x2="21" y2="6"/>
                            <path d="M16 10a4 4 0 0 1-8 0"/>
                        </svg>
                        <livewire:customer.cart-badge position="desktop" wire:key="header-cart-badge" />
                    </a>
                @endif
            </div>
        </div>
    </header>

    {{-- Mobile Top Header (393px reference) --}}
    <header class="md:hidden bg-white border-b border-border-card sticky top-0 z-30 shadow-xs">
        <div class="px-4 py-3 flex items-center justify-between gap-3">
            <a href="{{ $homeUrl }}" class="flex items-center gap-2.5 min-w-0 min-h-[44px]">
                <div class="w-9 h-9 rounded-full bg-asset flex items-center justify-center font-sub text-[10px] font-semibold text-[#6B6B6B] shrink-0 overflow-hidden border border-border-card">
                    @if ($businessLogoUrl)
                        <img src="{{ $businessLogoUrl }}" alt="Logo {{ $businessName }}" class="w-full h-full object-cover">
                    @else
                        LOGO
                    @endif
                </div>
                <div class="min-w-0">
                    <p class="font-heading text-base font-bold text-maroon leading-tight truncate">{{ $businessName }}</p>
                    <p class="font-sub text-[10px] text-text-muted leading-tight truncate">{{ $businessTagline }}</p>
                </div>
            </a>

            <div class="flex items-center gap-2 shrink-0">
                @if ($tableBadge)
                    <div class="flex items-center gap-1">
                        <span class="inline-flex items-center px-2 py-0.5 rounded-pill bg-maroon text-white font-sub text-[11px] font-bold shadow-xs">
                            {{ $tableBadge }}
                        </span>
                        <a href="{{ route('customer.table') }}" class="text-maroon hover:underline font-sub font-semibold text-[10px]" title="Ganti meja">
                            Ganti
                        </a>
                    </div>
                @endif

                @if ($customer)
                    <form method="POST" action="{{ $resetUrl }}" class="inline">
                        @csrf
                        <button
                            type="submit"
                            class="inline-flex items-center justify-center min-h-[36px] px-2 rounded-[8px] border border-border-card text-primary-button hover:bg-cream text-[11px] font-sub font-bold cursor-pointer"
                            title="Ganti nomor atau meja"
                        >
                            (Ganti)
                        </button>
                    </form>
                @endif

                <a
                    href="{{ $profileUrl }}"
                    class="inline-flex items-center justify-center min-w-[38px] min-h-[38px] rounded-[10px] border border-border-card text-text-muted hover:text-maroon hover:bg-cream/60 transition-colors"
                    title="Tentang Warung"
                    aria-label="Tentang Warung"
                >
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <circle cx="12" cy="12" r="10"/>
                        <path d="M12 16v-4M12 8h.01"/>
                    </svg>
                </a>
            </div>
        </div>
    </header>

    {{-- Main Content Area (Mobile-first, comfortable width on desktop) --}}
    <main class="relative z-10 flex-1 w-full max-w-md md:max-w-5xl mx-auto px-4 md:px-8 py-5 md:py-8 {{ $showNav ? 'pb-[calc(6rem+env(safe-area-inset-bottom,0px))] md:pb-12' : 'pb-8' }}">
        {{-- Flash Notifications --}}
        @if (session()->has('status') || session()->has('success'))
            <div role="alert" class="mb-5 p-4 rounded-[12px] bg-green-dark/10 border border-green-dark/30 text-green-dark font-sub text-xs md:text-sm font-semibold flex items-center gap-2">
                <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/></svg>
                <span>{{ session('status') ?? session('success') }}</span>
            </div>
        @endif

        @if (session()->has('error'))
            <div role="alert" class="mb-5 p-4 rounded-[12px] bg-primary-button/10 border border-primary-button/30 text-primary-button font-sub text-xs md:text-sm font-semibold flex items-center gap-2">
                <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                <span>{{ session('error') }}</span>
            </div>
        @endif

        {{ $slot }}
    </main>

    @if ($showNav)
        {{-- Mobile Bottom Navigation (393px reference) --}}
        <nav
            aria-label="Navigasi Bawah Pembeli"
            class="md:hidden fixed bottom-0 inset-x-0 z-30 bg-white border-t border-border-card shadow-[0_-2px_0_0_#EFE6D2] pb-[env(safe-area-inset-bottom,0px)]"
        >
            <div class="max-w-md mx-auto grid grid-cols-5 h-[68px]">
                {{-- Beranda --}}
                <a
                    href="{{ $homeUrl }}"
                    class="flex flex-col items-center justify-center gap-1 min-h-[44px] transition-colors cursor-pointer {{ $resolvedActiveNav === 'beranda' ? 'text-primary-button font-bold' : 'text-text-muted hover:text-text-primary font-semibold' }}"
                >
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                        <polyline points="9 22 9 12 15 12 15 22"/>
                    </svg>
                    <span class="font-sub text-[10px]">Beranda</span>
                </a>

                {{-- Menu --}}
                <a
                    href="{{ $menuUrl }}"
                    class="flex flex-col items-center justify-center gap-1 min-h-[44px] transition-colors cursor-pointer {{ $resolvedActiveNav === 'menu' ? 'text-primary-button font-bold' : 'text-text-muted hover:text-text-primary font-semibold' }}"
                >
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <rect x="3" y="3" width="7" height="7"/>
                        <rect x="14" y="3" width="7" height="7"/>
                        <rect x="14" y="14" width="7" height="7"/>
                        <rect x="3" y="14" width="7" height="7"/>
                    </svg>
                    <span class="font-sub text-[10px]">Menu</span>
                </a>

                {{-- Keranjang --}}
                <a
                    href="{{ $cartUrl }}"
                    class="relative flex flex-col items-center justify-center gap-1 min-h-[44px] transition-colors cursor-pointer {{ $resolvedActiveNav === 'keranjang' ? 'text-primary-button font-bold' : 'text-text-muted hover:text-text-primary font-semibold' }}"
                >
                    <div class="relative">
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>
                            <line x1="3" y1="6" x2="21" y2="6"/>
                            <path d="M16 10a4 4 0 0 1-8 0"/>
                        </svg>
                        <livewire:customer.cart-badge position="mobile" wire:key="bottom-cart-badge" />
                    </div>
                    <span class="font-sub text-[10px]">Keranjang</span>
                </a>

                {{-- Pesanan --}}
                <a
                    href="{{ $ordersUrl }}"
                    class="flex flex-col items-center justify-center gap-1 min-h-[44px] transition-colors cursor-pointer {{ $resolvedActiveNav === 'pesanan' ? 'text-primary-button font-bold' : 'text-text-muted hover:text-text-primary font-semibold' }}"
                >
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/>
                        <rect x="9" y="3" width="6" height="4" rx="1"/>
                        <path d="M9 12h6M9 16h4"/>
                    </svg>
                    <span class="font-sub text-[10px]">Pesanan</span>
                </a>

                {{-- Profil --}}
                <a
                    href="{{ $profileUrl }}"
                    class="flex flex-col items-center justify-center gap-1 min-h-[44px] transition-colors cursor-pointer {{ $resolvedActiveNav === 'profil' ? 'text-primary-button font-bold' : 'text-text-muted hover:text-text-primary font-semibold' }}"
                >
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <circle cx="12" cy="12" r="10"/>
                        <path d="M12 16v-4M12 8h.01"/>
                    </svg>
                    <span class="font-sub text-[10px]">Profil</span>
                </a>
            </div>
        </nav>
    @endif

    @livewireScripts
</body>
</html>
