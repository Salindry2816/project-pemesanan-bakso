@props([
    'title' => 'Login Admin',
])

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{{ $title }} – {{ config('app.name', 'Bakso Solo') }}</title>
    @include('partials.head-assets')
</head>
<body class="relative bg-cream text-text-primary font-body antialiased min-h-screen flex flex-col justify-between selection:bg-maroon selection:text-white">
    <x-bakso-ambient-bg />

    <main class="relative z-10 flex-1 flex flex-col items-center justify-center px-4 sm:px-6 py-8 md:py-12">
        {{ $slot }}
    </main>
</body>
</html>
