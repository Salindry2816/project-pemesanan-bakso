@props([
    'sizeClass' => 'w-32 h-32',
    'steamColor' => '#B85C3C',
])

<svg
    {{ $attributes->merge(['class' => $sizeClass]) }}
    viewBox="0 0 180 180"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
>
    {{-- Rising Hot Steam (3 gentle animated wisps) --}}
    <g stroke="{{ $steamColor }}" stroke-width="3.5" stroke-linecap="round">
        <path
            class="animate-steam-1"
            d="M62 62 C55 48, 69 38, 61 24"
            opacity="0.7"
        />
        <path
            class="animate-steam-2"
            d="M90 56 C83 40, 98 30, 89 14"
            opacity="0.8"
        />
        <path
            class="animate-steam-3"
            d="M118 62 C112 48, 126 38, 118 24"
            opacity="0.7"
        />
    </g>

    {{-- Bowl + Ingredients --}}
    <g class="animate-bowl-bob">
        {{-- Subtle table shadow --}}
        <ellipse cx="90" cy="154" rx="52" ry="8" fill="#782A25" opacity="0.14"/>

        {{-- Noodles & Broth surface --}}
        <ellipse cx="90" cy="96" rx="58" ry="18" fill="#F6DFB0"/>
        <ellipse cx="90" cy="96" rx="52" ry="14" fill="#E8B93A" opacity="0.55"/>

        {{-- Golden noodle strands --}}
        <path d="M52 96 C62 90, 74 102, 86 95 C98 88, 112 102, 126 95" stroke="#D99B26" stroke-width="2.5" stroke-linecap="round"/>
        <path d="M58 100 C70 95, 82 105, 96 99 C108 94, 118 101, 124 98" stroke="#E0A15A" stroke-width="2.2" stroke-linecap="round"/>

        {{-- Green bok choy / sawi leaves --}}
        <path d="M46 93 C44 82, 56 76, 65 86 C60 93, 52 96, 46 93 Z" fill="#5A9158"/>
        <path d="M122 86 C130 77, 140 84, 134 94 C128 96, 122 92, 122 86 Z" fill="#064E34"/>

        {{-- Meatballs (Bakso Besar & Kecil) --}}
        <circle cx="72" cy="88" r="13" fill="#B88A6E"/>
        <circle cx="69" cy="84" r="3" fill="#D5B29A" opacity="0.6"/>
        <circle cx="104" cy="86" r="15" fill="#A6765B"/>
        <circle cx="100" cy="81" r="3.5" fill="#CCA38B" opacity="0.55"/>
        <circle cx="88" cy="94" r="11" fill="#C49679"/>

        {{-- Scallion / bawang goreng accents --}}
        <circle cx="80" cy="84" r="2.2" fill="#5A9158"/>
        <circle cx="92" cy="82" r="2" fill="#782A25" opacity="0.7"/>
        <circle cx="115" cy="94" r="2.2" fill="#5A9158"/>

        {{-- Ceramic Bowl Body --}}
        <path d="M28 96 C28 134, 54 148, 90 148 C126 148, 152 134, 152 96 Z" fill="#FFFDF7" stroke="#EADFCB" stroke-width="2.5"/>
        {{-- Bowl Rim & Maroon Accent Stripe --}}
        <path d="M30 98 C55 110, 125 110, 150 98" stroke="#782A25" stroke-width="4" stroke-linecap="round"/>
        <path d="M44 114 C68 122, 112 122, 136 114" stroke="#C62828" stroke-width="2" stroke-linecap="round" opacity="0.55"/>
        {{-- Bowl Base --}}
        <path d="M68 147 L112 147 L107 153 L73 153 Z" fill="#EADFCB"/>
    </g>
</svg>
