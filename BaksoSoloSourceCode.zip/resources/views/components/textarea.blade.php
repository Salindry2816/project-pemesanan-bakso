@props([
    'label' => null,
    'name' => null,
    'id' => null,
    'placeholder' => '',
    'rows' => 3,
    'error' => null,
    'required' => false,
])

@php
    $inputId = $id ?? $name ?? 'textarea-' . \Illuminate\Support\Str::random(6);
    $resolvedError = $error ?? ($name && isset($errors) ? $errors->first($name) : null);
@endphp

<div class="w-full">
    @if ($label)
        <label
            for="{{ $inputId }}"
            class="block font-sub text-xs font-bold text-text-body mb-1.5"
        >
            {{ $label }}
            @if ($required)
                <span class="text-primary-button" aria-hidden="true">*</span>
            @endif
        </label>
    @endif

    <textarea
        id="{{ $inputId }}"
        @if ($name) name="{{ $name }}" @endif
        rows="{{ $rows }}"
        placeholder="{{ $placeholder }}"
        @if ($required) required @endif
        @if ($resolvedError) aria-invalid="true" aria-describedby="{{ $inputId }}-error" @endif
        {{ $attributes->merge([
            'class' => 'w-full px-4 py-3 bg-white border rounded-[12px] font-body text-[13px] text-text-primary placeholder:text-[#9CA3AF] focus:outline-none focus:ring-2 transition-colors ' . ($resolvedError ? 'border-primary-button focus:ring-primary-button/30' : 'border-border-input focus:border-maroon focus:ring-maroon/20'),
        ]) }}
    >{{ $slot }}</textarea>

    @if ($resolvedError)
        <p id="{{ $inputId }}-error" class="mt-1.5 font-body text-xs text-primary-button" role="alert">
            {{ $resolvedError }}
        </p>
    @endif
</div>
