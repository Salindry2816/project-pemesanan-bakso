@props([
    'label' => null,
    'name' => null,
    'id' => null,
    'type' => 'text',
    'error' => null,
    'togglePassword' => false,
    'prefix' => null,
])

@php
    $inputId = $id ?? $name ?? 'input-' . uniqid();
    $errorMessage = $error ?? ($name && isset($errors) ? $errors->first($name) : null);
    $isPasswordToggle = $togglePassword || $type === 'password';
@endphp

<div class="w-full space-y-1.5" @if ($isPasswordToggle) x-data="{ showPassword: false }" @endif>
    @if ($label)
        <label for="{{ $inputId }}" class="block font-sub text-xs md:text-[13px] font-bold text-text-primary">
            {{ $label }}
        </label>
    @endif

    <div class="relative flex items-center">
        @if ($prefix)
            <div class="absolute inset-y-0 left-0 flex items-center pl-3.5 pointer-events-none text-text-body font-sub text-sm font-semibold">
                {{ $prefix }}
            </div>
        @endif

        <input
            id="{{ $inputId }}"
            @if ($name) name="{{ $name }}" @endif
            @if ($isPasswordToggle)
                :type="showPassword ? 'text' : 'password'"
            @else
                type="{{ $type }}"
            @endif
            {{ $attributes->merge([
                'class' => trim(
                    'w-full min-h-[48px] md:min-h-[52px] rounded-[12px] bg-white border px-4 font-sub text-sm font-medium text-text-primary placeholder:text-text-muted focus:outline-none focus:ring-2 transition-colors ' .
                    ($prefix ? 'pl-14 ' : '') .
                    (($isPasswordToggle || isset($icon)) ? 'pr-12 ' : '') .
                    ($errorMessage ? 'border-primary-button focus:ring-primary-button/30' : 'border-border-input focus:border-maroon focus:ring-maroon/20')
                ),
            ]) }}
        >

        @if (isset($icon))
            <div class="absolute inset-y-0 right-0 flex items-center pr-3 text-text-body">
                {{ $icon }}
            </div>
        @elseif ($isPasswordToggle)
            <button
                type="button"
                @click="showPassword = !showPassword"
                class="absolute inset-y-0 right-0 flex items-center justify-center min-w-[44px] min-h-[44px] px-3 text-text-body hover:text-text-primary focus:outline-none cursor-pointer"
                :aria-label="showPassword ? 'Sembunyikan password' : 'Tampilkan password'"
            >
                <svg x-show="!showPassword" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/>
                    <circle cx="12" cy="12" r="3"/>
                </svg>
                <svg x-show="showPassword" style="display: none;" class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M17.94 17.94A10.07 10.07 0 0112 20c-6 0-10-8-10-8a18.45 18.45 0 015.06-5.94M9.9 4.24A9.12 9.12 0 0112 4c6 0 10 8 10 8a18.5 18.5 0 01-2.16 3.19m-6.72-1.07a3 3 0 11-4.24-4.24"/>
                    <line x1="1" y1="1" x2="23" y2="23"/>
                </svg>
            </button>
        @endif
    </div>

    @if ($errorMessage)
        <p class="font-body text-xs text-primary-button mt-1" role="alert">
            {{ $errorMessage }}
        </p>
    @endif
</div>
