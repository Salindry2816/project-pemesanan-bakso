<x-layouts.customer title="Selamat Datang" activeNav="beranda">
    <div class="max-w-md mx-auto py-6 space-y-6 text-center">
        {{-- Brand Logo Header --}}
        <div class="flex items-center justify-center gap-3">
            <div class="w-12 h-12 rounded-full bg-asset flex items-center justify-center font-sub text-xs font-semibold text-[#6B6B6B]">
                LOGO
            </div>
            <div class="text-left">
                <h1 class="font-heading text-xl font-bold text-maroon leading-tight">Bakso Solo</h1>
                <p class="font-sub text-xs text-text-muted leading-tight">Warung Bu Susi</p>
            </div>
        </div>

        <x-card class="space-y-4 text-center">
            <h2 class="font-heading text-lg font-semibold text-text-primary">
                Selamat Datang di Bakso Solo
            </h2>
            <p class="font-body text-sm text-text-body leading-relaxed">
                Kantin M, Lantai 2, Universitas Negeri Jakarta (UNJ). Alur pemesanan pembeli akan diaktifkan pada Tahap 3.
            </p>
            <div class="pt-2">
                <x-button variant="green" :disabled="true" :fullWidth="true">
                    Mulai Pesan (Segera Hadir)
                </x-button>
            </div>
        </x-card>
    </div>
</x-layouts.customer>
