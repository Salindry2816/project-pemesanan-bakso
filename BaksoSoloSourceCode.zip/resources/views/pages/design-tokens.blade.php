<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Design System Tokens – {{ config('app.name', 'Bakso Solo') }}</title>
    @include('partials.head-assets')
</head>
<body class="bg-cream text-text-primary font-body antialiased min-h-screen py-10 px-6 md:px-16">
    <div class="max-w-7xl mx-auto space-y-10">
        <header>
            <h1 class="font-heading text-4xl font-bold text-text-primary">Design System</h1>
            <p class="font-body text-sm text-text-muted mt-1">
                Bakso Solo – Warung Bu Susi &bull; Kantin M, Lantai 2, UNJ &bull; Kelompok 3 (Environment: {{ app()->environment() }})
            </p>
        </header>

        {{-- Section: Warna --}}
        <section class="space-y-4">
            <div>
                <h2 class="font-heading text-xl font-bold text-maroon">Warna</h2>
                <hr class="border-border-input mt-2">
            </div>

            @php
                $swatches = [
                    ['name' => 'color/maroon', 'class' => 'bg-maroon', 'hex' => '#782A25'],
                    ['name' => 'color/primary-button', 'class' => 'bg-primary-button', 'hex' => '#C62828'],
                    ['name' => 'color/cream', 'class' => 'bg-cream', 'hex' => '#FFFBEA'],
                    ['name' => 'color/green-dark', 'class' => 'bg-green-dark', 'hex' => '#064E34'],
                    ['name' => 'color/beige', 'class' => 'bg-beige', 'hex' => '#EBCEB3'],
                    ['name' => 'color/green-mid', 'class' => 'bg-green-mid', 'hex' => '#5A9158'],
                    ['name' => 'color/terracotta', 'class' => 'bg-terracotta', 'hex' => '#B85C3C'],
                    ['name' => 'color/accent-yellow', 'class' => 'bg-accent-yellow', 'hex' => '#E8B93A'],
                    ['name' => 'color/selected', 'class' => 'bg-selected', 'hex' => '#E0A15A'],
                    ['name' => 'status/diterima', 'class' => 'bg-status-diterima', 'hex' => '#2F8FE0'],
                    ['name' => 'status/diproses', 'class' => 'bg-status-diproses', 'hex' => '#064E34'],
                    ['name' => 'status/disiapkan', 'class' => 'bg-status-disiapkan', 'hex' => '#E8A21A'],
                    ['name' => 'status/siap', 'class' => 'bg-status-siap', 'hex' => '#5A9158'],
                    ['name' => 'status/selesai', 'class' => 'bg-status-selesai', 'hex' => '#6B7280'],
                    ['name' => 'status/dibatalkan', 'class' => 'bg-status-dibatalkan', 'hex' => '#C62828'],
                    ['name' => 'color/asset', 'class' => 'bg-asset', 'hex' => '#D9D9D9'],
                ];
            @endphp

            <div class="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-4">
                @foreach ($swatches as $swatch)
                    <div class="bg-white border border-border-card rounded-lg p-2.5 shadow-card">
                        <div class="h-16 rounded-sm border border-border-input {{ $swatch['class'] }}"></div>
                        <p class="font-sub text-xs font-bold text-text-primary mt-2.5 truncate">{{ $swatch['name'] }}</p>
                        <p class="font-body text-xs text-text-muted">{{ $swatch['hex'] }}</p>
                    </div>
                @endforeach
            </div>
        </section>

        {{-- Section: Tipografi --}}
        <section class="space-y-4">
            <div>
                <h2 class="font-heading text-xl font-bold text-maroon">Tipografi</h2>
                <hr class="border-border-input mt-2">
            </div>

            <x-card class="space-y-6">
                <div>
                    <p class="font-heading text-[28px] font-bold text-text-primary leading-tight">
                        Judul dan Heading – Poppins Bold 28
                    </p>
                    <p class="font-sub text-xs font-semibold text-text-muted mt-1">
                        Poppins 600 / 700 &bull; judul, heading, harga, tombol
                    </p>
                </div>

                <div>
                    <p class="font-sub text-lg font-bold text-text-primary">
                        Sub Judul – Nunito Bold 18
                    </p>
                    <p class="font-sub text-xs font-semibold text-text-muted mt-1">
                        Nunito 600 / 700 &bull; sub judul, nama menu, chip, label
                    </p>
                </div>

                <div>
                    <p class="font-body text-sm text-text-body">
                        Teks isi – Nunito Sans Regular 14. Bakso Solo adalah usaha kuliner milik Ibu Susi yang berlokasi di Kantin M, Lantai 2, Universitas Negeri Jakarta (UNJ).
                    </p>
                    <p class="font-sub text-xs font-semibold text-text-muted mt-1">
                        Nunito Sans 400 / 600 &bull; teks isi, deskripsi
                    </p>
                </div>
            </x-card>
        </section>

        {{-- Section: Komponen Dasar --}}
        <section class="space-y-4">
            <div>
                <h2 class="font-heading text-xl font-bold text-maroon">Komponen Dasar</h2>
                <hr class="border-border-input mt-2">
            </div>

            <x-card class="space-y-6">
                <div class="flex flex-wrap items-center gap-4">
                    <x-button variant="primary">Simpan Meja</x-button>
                    <x-button variant="green">Masuk</x-button>
                    <x-button variant="outline">Lihat Denah Meja</x-button>
                    <x-button :disabled="true">Nonaktif</x-button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-2xl">
                    <x-input label="Username" name="demo_username" placeholder="Masukkan username" />
                    <x-input label="Password" name="demo_password" type="password" placeholder="••••••••" :togglePassword="true" />
                </div>

                <div class="flex flex-wrap items-center gap-3">
                    @foreach (\App\Enums\OrderStatus::cases() as $status)
                        <x-status-badge :status="$status" />
                    @endforeach
                </div>
            </x-card>
        </section>
    </div>
</body>
</html>
