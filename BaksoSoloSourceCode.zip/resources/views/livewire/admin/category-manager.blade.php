<div class="w-full min-w-0 space-y-6">
    {{-- Page Header --}}
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h2 class="font-heading text-lg md:text-xl font-bold text-maroon">Kelola Kategori Menu</h2>
            <p class="font-body text-sm text-text-muted mt-0.5">
                Atur daftar kategori dan urutan tampilnya di halaman menu pembeli.
            </p>
        </div>

        <a
            href="{{ route('admin.menus') }}"
            class="inline-flex items-center justify-center min-h-[44px] px-4 rounded-[12px] border border-border-input bg-white font-sub text-xs font-bold text-text-body hover:bg-cream transition-colors self-start sm:self-auto"
        >
            &larr; Kembali ke Menu
        </a>
    </div>

    {{-- Feedback Alerts --}}
    @if ($statusMessage)
        <div
            role="status"
            class="px-4 py-3 rounded-[14px] bg-green-dark/10 border border-green-dark/30 text-green-dark font-sub text-sm font-semibold flex items-center justify-between gap-3"
        >
            <span>{{ $statusMessage }}</span>
            <button
                type="button"
                wire:click="$set('statusMessage', null)"
                class="text-xs font-bold underline cursor-pointer"
            >
                Tutup
            </button>
        </div>
    @endif

    @if ($errorMessage)
        <div
            role="alert"
            class="px-4 py-3 rounded-[14px] bg-primary-button/10 border border-primary-button/30 text-primary-button font-sub text-sm font-semibold flex items-center justify-between gap-3"
        >
            <span>{{ $errorMessage }}</span>
            <button
                type="button"
                wire:click="$set('errorMessage', null)"
                class="text-xs font-bold underline cursor-pointer"
            >
                Tutup
            </button>
        </div>
    @endif

    {{-- Add Category Card --}}
    <x-card padding="p-5 md:p-6">
        <form wire:submit="createCategory" class="space-y-4">
            <h3 class="font-heading text-base font-semibold text-text-primary">Tambah Kategori Baru</h3>

            <div class="flex flex-col sm:flex-row sm:items-start gap-3">
                <div class="flex-1">
                    <x-input
                        name="newName"
                        label="Nama Kategori"
                        placeholder="Contoh: Bakso, Paket, Minuman, Camilan"
                        wire:model="newName"
                        maxlength="50"
                        :error="$errors->first('newName')"
                    />
                </div>

                <div class="sm:pt-[26px]">
                    <x-button type="submit" variant="primary" :fullWidth="false" class="w-full sm:w-auto px-6">
                        + Tambah Kategori
                    </x-button>
                </div>
            </div>
        </form>
    </x-card>

    {{-- Category List Card --}}
    <x-card padding="p-5 md:p-6">
        <div class="mb-4">
            <h3 class="font-heading text-base font-semibold text-text-primary">
                Daftar Kategori ({{ $categories->count() }})
            </h3>
            <p class="font-sub text-xs text-text-muted mt-0.5">Urutan atas tampil lebih dulu pada menu pemesanan pembeli.</p>
        </div>

        @if ($categories->isEmpty())
            <div class="py-10 text-center">
                <p class="font-heading text-base font-semibold text-text-primary">Belum Ada Kategori</p>
                <p class="font-body text-sm text-text-muted mt-1">
                    Tambahkan kategori pertama melalui formulir di atas.
                </p>
            </div>
        @else
            <div class="divide-y divide-border-card">
                @foreach ($categories as $index => $category)
                    @php
                        $isFirst = $index === 0;
                        $isLast = $index === $categories->count() - 1;
                        $isEditing = $editingId === $category->id;
                    @endphp

                    <div
                        wire:key="category-row-{{ $category->id }}"
                        class="py-4 first:pt-1 last:pb-1 flex flex-col sm:flex-row sm:items-center justify-between gap-3"
                    >
                        @if ($isEditing)
                            {{-- Inline Edit Form --}}
                            <form wire:submit="updateCategory" class="flex-1 flex flex-col sm:flex-row sm:items-start gap-3">
                                <div class="flex-1">
                                    <x-input
                                        name="editingName"
                                        placeholder="Nama kategori"
                                        wire:model="editingName"
                                        maxlength="50"
                                        :error="$errors->first('editingName')"
                                    />
                                </div>
                                <div class="flex items-center gap-2">
                                    <x-button type="submit" variant="green" :fullWidth="false" class="px-4 !min-h-[44px]">
                                        Simpan
                                    </x-button>
                                    <x-button
                                        type="button"
                                        variant="outline"
                                        :fullWidth="false"
                                        wire:click="cancelEdit"
                                        class="px-4 !min-h-[44px]"
                                    >
                                        Batal
                                    </x-button>
                                </div>
                            </form>
                        @else
                            {{-- Category Info --}}
                            <div class="flex items-center gap-3 min-w-0">
                                <span class="inline-flex items-center justify-center w-8 h-8 rounded-full bg-cream border border-border-card font-sub text-xs font-bold text-maroon shrink-0">
                                    {{ $index + 1 }}
                                </span>
                                <div class="min-w-0">
                                    <p class="font-heading text-base font-semibold text-text-primary truncate">
                                        {{ $category->name }}
                                    </p>
                                    <p class="font-body text-xs text-text-muted">
                                        {{ $category->menus_count }} menu terdaftar
                                    </p>
                                </div>
                            </div>

                            {{-- Action Buttons --}}
                            <div class="flex items-center gap-2 self-end sm:self-auto">
                                {{-- Move Up --}}
                                <button
                                    type="button"
                                    wire:click="moveUp({{ $category->id }})"
                                    @disabled($isFirst)
                                    title="Geser ke atas"
                                    aria-label="Geser {{ $category->name }} ke atas"
                                    class="inline-flex items-center justify-center w-11 h-11 rounded-[12px] border border-border-input bg-white text-text-body hover:bg-cream disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
                                >
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <polyline points="18 15 12 9 6 15"/>
                                    </svg>
                                </button>

                                {{-- Move Down --}}
                                <button
                                    type="button"
                                    wire:click="moveDown({{ $category->id }})"
                                    @disabled($isLast)
                                    title="Geser ke bawah"
                                    aria-label="Geser {{ $category->name }} ke bawah"
                                    class="inline-flex items-center justify-center w-11 h-11 rounded-[12px] border border-border-input bg-white text-text-body hover:bg-cream disabled:opacity-40 disabled:cursor-not-allowed transition-colors cursor-pointer"
                                >
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <polyline points="6 9 12 15 18 9"/>
                                    </svg>
                                </button>

                                {{-- Edit --}}
                                <button
                                    type="button"
                                    wire:click="startEdit({{ $category->id }})"
                                    class="inline-flex items-center justify-center min-h-[44px] px-3.5 rounded-[12px] border border-border-input bg-white font-sub text-xs font-bold text-text-body hover:bg-cream transition-colors cursor-pointer"
                                >
                                    Ubah
                                </button>

                                {{-- Delete --}}
                                <button
                                    type="button"
                                    wire:click="confirmDelete({{ $category->id }})"
                                    class="inline-flex items-center justify-center min-h-[44px] px-3.5 rounded-[12px] border border-primary-button/30 bg-primary-button/5 font-sub text-xs font-bold text-primary-button hover:bg-primary-button hover:text-white transition-colors cursor-pointer"
                                >
                                    Hapus
                                </button>
                            </div>
                        @endif
                    </div>
                @endforeach
            </div>
        @endif
    </x-card>

    {{-- Delete Confirmation Modal --}}
    <x-modal
        :show="$deletingId !== null"
        title="Hapus Kategori?"
        maxWidth="sm"
        closeAction="cancelDelete"
    >
        <p class="font-body text-sm text-text-body">
            Apakah Anda yakin ingin menghapus kategori
            <strong class="font-semibold text-text-primary">"{{ $deletingName }}"</strong>?
            Kategori yang masih memiliki menu tidak dapat dihapus.
        </p>

        <x-slot:footer>
            <x-button
                type="button"
                variant="outline"
                :fullWidth="false"
                wire:click="cancelDelete"
                class="px-4 !min-h-[44px]"
            >
                Batal
            </x-button>
            <x-button
                type="button"
                variant="primary"
                :fullWidth="false"
                wire:click="deleteCategory"
                class="px-4 !min-h-[44px]"
            >
                Ya, Hapus
            </x-button>
        </x-slot:footer>
    </x-modal>
</div>
