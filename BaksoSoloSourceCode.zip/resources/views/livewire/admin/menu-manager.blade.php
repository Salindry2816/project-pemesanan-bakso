<div class="w-full min-w-0 space-y-6">
    {{-- Page Header --}}
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div class="min-w-0">
            <h2 class="font-heading text-lg md:text-xl font-bold text-maroon">Kelola Menu</h2>
            <p class="font-body text-sm text-text-muted mt-0.5">
                Atur daftar menu, harga, foto, dan status ketersediaan untuk pembeli.
            </p>
        </div>

        <div class="grid grid-cols-2 sm:flex sm:flex-wrap items-center gap-2.5 w-full sm:w-auto">
            <a
                href="{{ route('admin.categories') }}"
                class="inline-flex items-center justify-center min-h-[44px] px-4 rounded-[12px] border border-border-input bg-white font-sub text-xs font-bold text-text-body hover:bg-cream transition-colors text-center"
            >
                Kelola Kategori
            </a>

            <x-button
                type="button"
                variant="primary"
                :fullWidth="false"
                wire:click="openCreateModal"
                class="w-full sm:w-auto px-5 !min-h-[44px]"
            >
                + Tambah Menu
            </x-button>
        </div>
    </div>

    {{-- Feedback Alerts --}}
    @if ($statusMessage)
        <div
            role="status"
            class="px-4 py-3 rounded-[14px] bg-green-dark/10 border border-green-dark/30 text-green-dark font-sub text-sm font-semibold flex items-center justify-between gap-3"
        >
            <span>{{ $statusMessage }}</span>
            <button
                type="button"
                wire:click="$set('statusMessage', null)"
                class="text-xs font-bold underline cursor-pointer"
            >
                Tutup
            </button>
        </div>
    @endif

    @if ($errorMessage)
        <div
            role="alert"
            class="px-4 py-3 rounded-[14px] bg-primary-button/10 border border-primary-button/30 text-primary-button font-sub text-sm font-semibold flex items-center justify-between gap-3"
        >
            <span>{{ $errorMessage }}</span>
            <button
                type="button"
                wire:click="$set('errorMessage', null)"
                class="text-xs font-bold underline cursor-pointer"
            >
                Tutup
            </button>
        </div>
    @endif

    {{-- Category Filter Chips --}}
    <div class="flex items-center gap-2 overflow-x-auto pb-1 max-w-full" role="tablist" aria-label="Filter Kategori">
        <button
            type="button"
            wire:click="filterByCategory(null)"
            class="inline-flex items-center justify-center min-h-[40px] px-4 rounded-pill font-sub text-xs font-bold transition-colors shrink-0 cursor-pointer {{ $selectedCategoryId === null ? 'bg-primary-button text-white' : 'bg-white border border-border-input text-text-body hover:bg-cream' }}"
        >
            Semua
        </button>

        @foreach ($categories as $category)
            <button
                type="button"
                wire:key="chip-cat-{{ $category->id }}"
                wire:click="filterByCategory({{ $category->id }})"
                class="inline-flex items-center justify-center min-h-[40px] px-4 rounded-pill font-sub text-xs font-bold transition-colors shrink-0 cursor-pointer {{ $selectedCategoryId === $category->id ? 'bg-primary-button text-white' : 'bg-white border border-border-input text-text-body hover:bg-cream' }}"
            >
                {{ $category->name }}
            </button>
        @endforeach
    </div>

    {{-- Menu List --}}
    @if ($menus->isEmpty())
        <x-card padding="p-8 md:p-12">
            <div class="text-center max-w-md mx-auto">
                <p class="font-heading text-base font-semibold text-text-primary">
                    Belum ada menu. Tambahkan menu pertama.
                </p>
                <p class="font-body text-sm text-text-muted mt-1">
                    Klik tombol "+ Tambah Menu" di atas untuk mulai mengisi daftar menu warung.
                </p>
            </div>
        </x-card>
    @else
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            @foreach ($menus as $menu)
                @php
                    $photoUrl = \App\Support\MediaStorage::url($menu->photo_path);
                    $formattedPrice = 'Rp ' . number_format($menu->price, 0, ',', '.');
                @endphp

                <x-card wire:key="menu-card-{{ $menu->id }}" padding="p-4">
                    <div class="flex gap-3 sm:gap-4">
                        {{-- Photo / Placeholder --}}
                        <div class="w-20 h-20 sm:w-24 sm:h-24 rounded-[12px] overflow-hidden bg-asset shrink-0 flex items-center justify-center border border-border-card">
                            @if ($photoUrl)
                                <img
                                    src="{{ $photoUrl }}"
                                    alt="{{ $menu->name }}"
                                    class="w-full h-full object-cover"
                                    loading="lazy"
                                >
                            @else
                                <span class="font-sub text-[10px] font-bold text-[#6B6B6B] text-center px-2">
                                    FOTO MENU
                                </span>
                            @endif
                        </div>

                        {{-- Details --}}
                        <div class="flex-1 min-w-0 flex flex-col justify-between">
                            <div>
                                <div class="flex items-start justify-between gap-2">
                                    <h3 class="font-heading text-sm sm:text-base font-semibold text-text-primary line-clamp-2">
                                        {{ $menu->name }}
                                    </h3>
                                    <span class="inline-flex items-center px-2.5 py-0.5 rounded-pill bg-cream border border-border-card font-sub text-[11px] font-bold text-maroon shrink-0">
                                        {{ $menu->category?->name ?? '-' }}
                                    </span>
                                </div>

                                @if ($menu->description)
                                    <p class="font-body text-xs text-text-muted mt-1 line-clamp-2">
                                        {{ $menu->description }}
                                    </p>
                                @endif
                            </div>

                            <p class="font-heading text-sm font-bold text-maroon mt-2">
                                {{ $formattedPrice }}
                            </p>
                        </div>
                    </div>

                    {{-- Action Footer --}}
                    <div class="mt-4 pt-3 border-t border-border-card flex flex-wrap items-center justify-between gap-2">
                        {{-- Quick Availability Toggle --}}
                        <button
                            type="button"
                            wire:click="toggleAvailability({{ $menu->id }})"
                            class="inline-flex items-center gap-2 min-h-[44px] px-3.5 rounded-[12px] font-sub text-xs font-bold transition-colors cursor-pointer {{ $menu->is_available ? 'bg-green-dark/10 text-green-dark border border-green-dark/30 hover:bg-green-dark/20' : 'bg-asset/60 text-text-muted border border-border-input hover:bg-asset' }}"
                        >
                            <span class="w-2.5 h-2.5 rounded-full {{ $menu->is_available ? 'bg-green-dark' : 'bg-text-muted' }}"></span>
                            <span>{{ $menu->is_available ? 'Tersedia' : 'Tidak tersedia' }}</span>
                        </button>

                        <div class="flex items-center gap-2">
                            <button
                                type="button"
                                wire:click="openEditModal({{ $menu->id }})"
                                class="inline-flex items-center justify-center min-h-[44px] px-3.5 rounded-[12px] border border-border-input bg-white font-sub text-xs font-bold text-text-body hover:bg-cream transition-colors cursor-pointer"
                            >
                                Ubah
                            </button>

                            <button
                                type="button"
                                wire:click="confirmDelete({{ $menu->id }})"
                                class="inline-flex items-center justify-center min-h-[44px] px-3.5 rounded-[12px] border border-primary-button/30 bg-primary-button/5 font-sub text-xs font-bold text-primary-button hover:bg-primary-button hover:text-white transition-colors cursor-pointer"
                            >
                                Hapus
                            </button>
                        </div>
                    </div>
                </x-card>
            @endforeach
        </div>
    @endif

    {{-- Create / Edit Menu Modal --}}
    <x-modal
        :show="$showFormModal"
        :title="$editingId ? 'Ubah Menu' : 'Tambah Menu Baru'"
        maxWidth="lg"
        closeAction="closeFormModal"
    >
        <form wire:submit="saveMenu" class="space-y-4">
            <x-input
                name="name"
                label="Nama Menu"
                placeholder="Contoh: Bakso Komplit"
                wire:model="name"
                maxlength="100"
                :required="true"
                :error="$errors->first('name')"
            />

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <x-select
                    name="categoryId"
                    label="Kategori"
                    wire:model="categoryId"
                    :required="true"
                    :error="$errors->first('categoryId')"
                >
                    <option value="">-- Pilih Kategori --</option>
                    @foreach ($categories as $category)
                        <option value="{{ $category->id }}">{{ $category->name }}</option>
                    @endforeach
                </x-select>

                <x-input
                    name="price"
                    type="number"
                    step="1"
                    min="1"
                    max="1000000"
                    label="Harga (Rupiah)"
                    placeholder="Contoh: 18000"
                    wire:model="price"
                    :required="true"
                    :error="$errors->first('price')"
                />
            </div>

            <x-textarea
                name="description"
                label="Deskripsi (Opsional)"
                placeholder="Contoh: Bakso halus, bakso urat, tahu, mie, dan pangsit"
                rows="3"
                maxlength="255"
                wire:model="description"
                :error="$errors->first('description')"
            />

            {{-- Photo Upload & Preview --}}
            <div class="space-y-2">
                <label class="block font-sub text-xs font-bold text-text-body">
                    Foto Menu (Opsional, JPG/PNG/WebP maks. 2 MB)
                </label>

                @php
                    $previewUrl = null;
                    if ($photo instanceof \Illuminate\Http\UploadedFile && method_exists($photo, 'isPreviewable') && $photo->isPreviewable()) {
                        try {
                            $previewUrl = $photo->temporaryUrl();
                        } catch (\Throwable) {
                            $previewUrl = null;
                        }
                    } elseif (! $removeExistingPhoto && $existingPhotoPath) {
                        $previewUrl = \App\Support\MediaStorage::url($existingPhotoPath);
                    }
                @endphp

                <div class="flex flex-col sm:flex-row sm:items-center gap-4">
                    <div class="w-20 h-20 rounded-[12px] overflow-hidden bg-asset border border-border-card flex items-center justify-center shrink-0">
                        @if ($previewUrl)
                            <img src="{{ $previewUrl }}" alt="Preview Foto Menu" class="w-full h-full object-cover">
                        @else
                            <span class="font-sub text-[10px] font-bold text-[#6B6B6B] text-center px-1">
                                FOTO
                            </span>
                        @endif
                    </div>

                    <div class="flex-1 min-w-0 space-y-2">
                        <x-file-input
                            wire:model="photo"
                            name="photo"
                            accept=".jpg,.jpeg,.png,.webp"
                        />

                        <div wire:loading wire:target="photo" class="font-sub text-xs text-maroon font-semibold flex items-center gap-1.5">
                            <svg class="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24" fill="none"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
                            <span>Mengunggah foto...</span>
                        </div>

                        @if ($photo || ($existingPhotoPath && ! $removeExistingPhoto))
                            <button
                                type="button"
                                wire:click="removePhoto"
                                class="inline-flex items-center font-sub text-xs font-bold text-primary-button hover:underline cursor-pointer"
                            >
                                Hapus Foto
                            </button>
                        @endif
                    </div>
                </div>

                @if ($errors->has('photo'))
                    <p class="font-body text-xs text-primary-button" role="alert">
                        {{ $errors->first('photo') }}
                    </p>
                @endif
            </div>

            {{-- Availability Checkbox --}}
            <label class="flex items-center gap-3 pt-1 cursor-pointer select-none">
                <input
                    type="checkbox"
                    wire:model="isAvailable"
                    class="w-5 h-5 rounded border-border-input text-green-dark focus:ring-green-dark"
                >
                <span class="font-sub text-sm font-semibold text-text-primary">
                    Menu tersedia untuk dipesan
                </span>
            </label>

            <div class="pt-4 border-t border-border-card flex items-center justify-end gap-3">
                <x-button
                    type="button"
                    variant="outline"
                    :fullWidth="false"
                    wire:click="closeFormModal"
                    class="px-4 !min-h-[44px]"
                >
                    Batal
                </x-button>
                <x-button
                    type="submit"
                    variant="primary"
                    :fullWidth="false"
                    class="px-5 !min-h-[44px]"
                >
                    {{ $editingId ? 'Simpan Perubahan' : 'Simpan Menu' }}
                </x-button>
            </div>
        </form>
    </x-modal>

    {{-- Delete Confirmation Modal --}}
    <x-modal
        :show="$deletingId !== null"
        title="Hapus Menu?"
        maxWidth="sm"
        closeAction="cancelDelete"
    >
        <p class="font-body text-sm text-text-body">
            Apakah Anda yakin ingin menghapus menu
            <strong class="font-semibold text-text-primary">"{{ $deletingName }}"</strong>?
            Riwayat pesanan lama tetap tersimpan dengan aman.
        </p>

        <x-slot:footer>
            <x-button
                type="button"
                variant="outline"
                :fullWidth="false"
                wire:click="cancelDelete"
                class="px-4 !min-h-[44px]"
            >
                Batal
            </x-button>
            <x-button
                type="button"
                variant="primary"
                :fullWidth="false"
                wire:click="deleteMenu"
                class="px-4 !min-h-[44px]"
            >
                Ya, Hapus
            </x-button>
        </x-slot:footer>
    </x-modal>
</div>
