<div class="space-y-6 pb-8">
    <div class="flex flex-wrap items-center justify-between gap-3">
        <div>
            <a
                href="{{ route('admin.dashboard') }}"
                class="inline-flex items-center gap-1.5 text-maroon hover:underline font-sub text-xs font-semibold min-h-[36px]"
            >
                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
                Kembali ke Dashboard
            </a>
            <h1 class="font-heading text-2xl md:text-3xl font-bold text-text-primary mt-1">
                Pesanan {{ $order->display_number }}
            </h1>
            <p class="font-sub text-xs text-text-muted">
                {{ $order->order_number }} · Dibuat {{ $order->created_at?->format('d M Y, H:i') }}
            </p>
        </div>

        <div class="flex flex-wrap items-center gap-2">
            <span class="inline-flex items-center px-3 py-1.5 rounded-pill font-sub text-xs font-bold {{ $order->status->badgeClass() }}">
                {{ $order->status->label() }}
            </span>
            <span class="inline-flex items-center px-3 py-1.5 rounded-pill font-sub text-xs font-bold {{ $order->payment_status->value === 'lunas' ? 'bg-green-dark text-white' : 'bg-cream text-text-primary border border-border-card' }}">
                {{ $order->payment_status->label() }}
            </span>
        </div>
    </div>

    @if ($statusMessage)
        <div role="alert" class="p-4 rounded-[12px] bg-green-dark/10 border border-green-dark/30 text-green-dark font-sub text-xs md:text-sm font-semibold">
            {{ $statusMessage }}
        </div>
    @endif

    @if ($errorMessage)
        <div role="alert" class="p-4 rounded-[12px] bg-status-dibatalkan/10 border border-status-dibatalkan/30 text-status-dibatalkan font-sub text-xs md:text-sm font-semibold">
            {{ $errorMessage }}
        </div>
    @endif

    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {{-- Left Column: Items & Info --}}
        <div class="lg:col-span-7 space-y-6">
            <x-card padding="p-5 md:p-6" radius="rounded-[16px]" class="space-y-4">
                <h2 class="font-heading text-base font-bold text-text-primary">
                    Informasi Pelanggan &amp; Meja
                </h2>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs md:text-sm">
                    <div>
                        <p class="font-sub text-[11px] font-bold uppercase tracking-wider text-text-muted">No. Handphone</p>
                        <p class="font-sub font-semibold text-text-primary mt-0.5">
                            {{ $order->customer?->phone ?? '-' }}
                        </p>
                    </div>
                    <div>
                        <p class="font-sub text-[11px] font-bold uppercase tracking-wider text-text-muted">Tipe &amp; Lokasi</p>
                        <p class="font-sub font-semibold text-text-primary mt-0.5">
                            @if ($order->type->value === 'take_away')
                                Bungkus (Take Away)
                            @elseif ($order->table)
                                Lantai {{ $order->table->floor }} · Meja {{ $order->table->code }}
                                @if ($order->location_note)
                                    ({{ $order->location_note }})
                                @endif
                            @endif
                        </p>
                    </div>
                </div>

                @if ($order->note)
                    <div class="p-3 rounded-[10px] bg-cream/60 border border-border-card text-xs">
                        <span class="font-sub font-bold text-text-muted">Catatan Pesanan:</span>
                        <span class="font-body text-text-primary ml-1">{{ $order->note }}</span>
                    </div>
                @endif
            </x-card>

            <x-card padding="p-5 md:p-6" radius="rounded-[16px]" class="space-y-4">
                <h2 class="font-heading text-base font-bold text-text-primary">
                    Item Pesanan
                </h2>

                <div class="divide-y divide-border-card/60">
                    @foreach ($order->items as $item)
                        <div class="py-3 first:pt-0 last:pb-0 flex items-start justify-between gap-3">
                            <div class="min-w-0">
                                <p class="font-heading font-semibold text-sm text-text-primary">
                                    {{ $item->name_snapshot }}
                                </p>
                                <p class="font-body text-xs text-text-muted">
                                    {{ $item->qty }}x @ Rp {{ number_format($item->price_snapshot, 0, ',', '.') }}
                                </p>
                                @if ($item->item_note)
                                    <p class="font-body text-xs text-text-muted italic mt-0.5">
                                        Catatan: {{ $item->item_note }}
                                    </p>
                                @endif
                            </div>
                            <p class="font-heading font-bold text-sm text-text-primary shrink-0">
                                Rp {{ number_format($item->line_total, 0, ',', '.') }}
                            </p>
                        </div>
                    @endforeach
                </div>

                <div class="pt-3 border-t border-border-card flex items-center justify-between">
                    <span class="font-sub text-xs uppercase tracking-wider font-bold text-text-muted">Total</span>
                    <span class="font-heading text-xl font-bold text-primary-button">
                        Rp {{ number_format($order->total, 0, ',', '.') }}
                    </span>
                </div>
            </x-card>
        </div>

        {{-- Right Column: Payment, Actions & Logs --}}
        <div class="lg:col-span-5 space-y-6">
            <x-card padding="p-5 md:p-6" radius="rounded-[16px]" class="space-y-4">
                <div class="flex items-center justify-between">
                    <h2 class="font-heading text-base font-bold text-text-primary">
                        Pembayaran
                    </h2>
                    <span class="font-sub text-xs font-bold text-text-muted">
                        {{ $order->payment_method->label() }}
                    </span>
                </div>

                @if ($order->payment_status->value === 'lunas')
                    <div class="p-3.5 rounded-[12px] bg-green-dark/10 border border-green-dark/30 text-green-dark font-sub text-xs font-semibold">
                        Lunas{{ $order->paid_at ? ' pada '.$order->paid_at->format('d M Y, H:i') : '' }}
                    </div>
                @else
                    <p class="font-body text-xs text-text-muted">
                        Pesanan belum ditandai lunas. Konfirmasi pembayaran sebelum menyelesaikan pesanan.
                    </p>
                    @if ($order->status !== \App\Enums\OrderStatus::Dibatalkan)
                        <button
                            type="button"
                            wire:click="markAsPaid"
                            wire:loading.attr="disabled"
                            class="w-full min-h-[44px] px-4 rounded-[12px] bg-green-dark text-white font-sub text-sm font-bold hover:opacity-90 transition-opacity cursor-pointer"
                        >
                            Tandai Lunas
                        </button>
                    @endif
                @endif
            </x-card>

            <x-card padding="p-5 md:p-6" radius="rounded-[16px]" class="space-y-4">
                <h2 class="font-heading text-base font-bold text-text-primary">
                    Aksi Status Pesanan
                </h2>

                @if ($nextStatus)
                    @php
                        $blockedByUnpaid = $nextStatus === \App\Enums\OrderStatus::Selesai && $order->payment_status->value !== 'lunas';
                    @endphp
                    <button
                        type="button"
                        wire:click="transitionStatus('{{ $order->status->value }}', '{{ $nextStatus->value }}')"
                        wire:loading.attr="disabled"
                        class="w-full min-h-[46px] px-4 rounded-[12px] bg-primary-button text-white font-sub text-sm font-bold hover:opacity-90 transition-opacity cursor-pointer"
                    >
                        Ubah ke {{ $nextStatus->label() }}
                    </button>
                    @if ($blockedByUnpaid)
                        <p class="font-body text-xs text-status-dibatalkan">
                            Pesanan harus berstatus Lunas terlebih dahulu sebelum dapat diselesaikan.
                        </p>
                    @endif
                @else
                    <p class="font-sub text-xs text-text-muted">
                        Pesanan sudah berada pada status akhir ({{ $order->status->label() }}).
                    </p>
                @endif

                @if ($canCancel)
                    <button
                        type="button"
                        wire:click="transitionStatus('{{ $order->status->value }}', '{{ \App\Enums\OrderStatus::Dibatalkan->value }}')"
                        wire:confirm="Yakin ingin membatalkan pesanan {{ $order->display_number }}?"
                        wire:loading.attr="disabled"
                        class="w-full min-h-[44px] px-4 rounded-[12px] border border-status-dibatalkan text-status-dibatalkan font-sub text-sm font-bold hover:bg-status-dibatalkan/10 transition-colors cursor-pointer"
                    >
                        Batalkan Pesanan
                    </button>
                @endif
            </x-card>

            <x-card padding="p-5 md:p-6" radius="rounded-[16px]" class="space-y-3">
                <h2 class="font-heading text-base font-bold text-text-primary">
                    Riwayat Status
                </h2>

                <div class="space-y-2.5">
                    @foreach ($order->statusLogs as $log)
                        <div class="flex items-center justify-between gap-3 text-xs border-b border-border-card/50 pb-2 last:border-b-0 last:pb-0">
                            <div>
                                <p class="font-sub font-bold text-text-primary">{{ $log->status->label() }}</p>
                                <p class="font-body text-[11px] text-text-muted">
                                    Oleh: {{ $log->changedByUser?->username ?? 'Sistem' }}
                                </p>
                            </div>
                            <span class="font-sub text-[11px] text-text-muted shrink-0">
                                {{ $log->created_at?->format('d M, H:i') }}
                            </span>
                        </div>
                    @endforeach
                </div>
            </x-card>
        </div>
    </div>
</div>
