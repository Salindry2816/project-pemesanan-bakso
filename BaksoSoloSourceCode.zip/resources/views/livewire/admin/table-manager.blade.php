<div class="w-full min-w-0 space-y-6">
    {{-- Page Header --}}
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h2 class="font-heading text-lg md:text-xl font-bold text-maroon">Kelola Meja</h2>
            <p class="font-body text-sm text-text-muted mt-0.5">
                Atur meja berkode per lantai serta pantau status keterisian meja saat ini.
            </p>
        </div>

        <a
            href="{{ route('admin.profile') }}"
            class="inline-flex items-center justify-center min-h-[44px] px-4 rounded-[12px] border border-border-input bg-white font-sub text-xs font-bold text-text-body hover:bg-cream transition-colors self-start sm:self-auto"
        >
            &larr; Kembali ke Profil Usaha
        </a>
    </div>

    {{-- Feedback Alerts --}}
    @if ($statusMessage)
        <div
            role="status"
            class="px-4 py-3 rounded-[14px] bg-green-dark/10 border border-green-dark/30 text-green-dark font-sub text-sm font-semibold flex items-center justify-between gap-3"
        >
            <span>{{ $statusMessage }}</span>
            <button
                type="button"
                wire:click="$set('statusMessage', null)"
                class="text-xs font-bold underline cursor-pointer"
            >
                Tutup
            </button>
        </div>
    @endif

    @if ($errorMessage)
        <div
            role="alert"
            class="px-4 py-3 rounded-[14px] bg-primary-button/10 border border-primary-button/30 text-primary-button font-sub text-sm font-semibold flex items-center justify-between gap-3"
        >
            <span>{{ $errorMessage }}</span>
            <button
                type="button"
                wire:click="$set('errorMessage', null)"
                class="text-xs font-bold underline cursor-pointer"
            >
                Tutup
            </button>
        </div>
    @endif

    {{-- Free Seating ("Meja Bebas") Locked Card --}}
    @if ($freeTable)
        <x-card padding="p-5 md:p-6">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div class="flex items-start gap-4">
                    <div class="px-3.5 py-2 rounded-[12px] bg-green-mid text-white font-heading text-sm font-bold shrink-0">
                        {{ $freeTable->code }}
                    </div>
                    <div>
                        <div class="flex flex-wrap items-center gap-2">
                            <h3 class="font-heading text-base font-semibold text-text-primary">
                                Area Meja Bebas (Lantai {{ $freeTable->floor }})
                            </h3>
                            <span class="inline-flex items-center px-2.5 py-0.5 rounded-pill bg-green-dark text-white font-sub text-[11px] font-bold">
                                Selalu Tersedia
                            </span>
                        </div>
                        <p class="font-body text-xs text-text-muted mt-1">
                            Area duduk bersama tanpa kode (kapasitas informasi: {{ $freeTable->capacity ?? 22 }} kursi). Pembeli wajib mengisi patokan lokasi saat memilih opsi ini.
                        </p>
                    </div>
                </div>

                <div class="flex items-center gap-2 self-end sm:self-auto shrink-0">
                    <span class="inline-flex items-center gap-1.5 min-h-[40px] px-3.5 rounded-[12px] bg-cream border border-border-card font-sub text-xs font-bold text-maroon select-none">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <rect x="5" y="11" width="14" height="10" rx="2"/>
                            <path d="M8 11V7a4 4 0 018 0v4"/>
                        </svg>
                        <span>Aktif (Terkunci)</span>
                    </span>
                </div>
            </div>
        </x-card>
    @endif

    {{-- Add New Coded Table Form --}}
    <x-card padding="p-5 md:p-6">
        <form wire:submit="createTable" class="space-y-4">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <h3 class="font-heading text-base font-semibold text-text-primary">Tambah Meja Berkode</h3>

                @if ($nextCodePreview)
                    <span class="font-sub text-xs font-semibold text-text-body">
                        Kode meja berikutnya:
                        <strong class="inline-flex items-center px-2.5 py-0.5 rounded-pill bg-cream border border-border-card text-maroon font-bold">
                            {{ $nextCodePreview }}
                        </strong>
                    </span>
                @else
                    <span class="font-sub text-xs font-bold text-primary-button">
                        Kode meja untuk lantai ini sudah penuh (A-Z)
                    </span>
                @endif
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 items-start">
                <x-select
                    name="selectedFloor"
                    label="Pilih Lantai"
                    wire:model.live="selectedFloor"
                    :required="true"
                    :error="$errors->first('selectedFloor')"
                >
                    @foreach (range(\App\Support\TableCode::MIN_FLOOR, \App\Support\TableCode::MAX_FLOOR) as $floorNumber)
                        <option value="{{ $floorNumber }}">
                            Lantai {{ $floorNumber }}{{ $floorNumber === 2 ? ' (Lokasi Warung)' : '' }}
                        </option>
                    @endforeach
                </x-select>

                <x-input
                    name="capacity"
                    type="number"
                    min="1"
                    max="50"
                    step="1"
                    label="Kapasitas Kursi (Opsional)"
                    placeholder="Contoh: 4"
                    wire:model="capacity"
                    :error="$errors->first('capacity')"
                />

                <div class="sm:pt-[26px]">
                    <x-button
                        type="submit"
                        variant="primary"
                        :disabled="$nextCodePreview === null"
                    >
                        + Tambah Meja {{ $nextCodePreview ?? '' }}
                    </x-button>
                </div>
            </div>
        </form>
    </x-card>

    {{-- Coded Tables Grouped by Floor --}}
    @forelse ($tablesByFloor as $floor => $tables)
        <x-card padding="p-5 md:p-6">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
                <h3 class="font-heading text-base font-semibold text-text-primary">
                    Meja Berkode — Lantai {{ $floor }} ({{ $tables->count() }} meja)
                </h3>
                <div class="flex items-center gap-3 font-sub text-xs font-semibold">
                    <span class="inline-flex items-center gap-1.5 text-green-dark">
                        <span class="w-2.5 h-2.5 rounded-full bg-green-dark"></span>
                        Tersedia
                    </span>
                    <span class="inline-flex items-center gap-1.5 text-primary-button">
                        <span class="w-2.5 h-2.5 rounded-full bg-primary-button"></span>
                        Terisi
                    </span>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                @foreach ($tables as $table)
                    @php
                        $isOccupied = (bool) $table->is_currently_occupied;
                        $hasOrderHistory = $table->orders_count > 0;
                    @endphp

                    <div
                        wire:key="table-card-{{ $table->id }}"
                        class="p-4 rounded-[16px] border {{ $table->is_active ? 'bg-white border-border-card' : 'bg-cream/60 border-border-input opacity-80' }} flex flex-col justify-between gap-4"
                    >
                        <div class="flex items-start justify-between gap-3">
                            <div class="flex items-center gap-3">
                                <div class="w-12 h-12 rounded-[12px] flex items-center justify-center font-heading text-base font-bold text-white shrink-0 {{ ! $table->is_active ? 'bg-text-muted' : ($isOccupied ? 'bg-table-terisi' : 'bg-table-tersedia') }}">
                                    {{ $table->code }}
                                </div>
                                <div>
                                    <p class="font-heading text-sm font-semibold text-text-primary">
                                        Meja {{ $table->code }}
                                    </p>
                                    <p class="font-body text-xs text-text-muted">
                                        {{ $table->capacity ? $table->capacity . ' kursi' : 'Kapasitas tidak diatur' }}
                                    </p>
                                </div>
                            </div>

                            {{-- Occupancy Badge --}}
                            <span class="inline-flex items-center px-2.5 py-1 rounded-pill font-sub text-[11px] font-bold text-white shadow-sm {{ $isOccupied ? 'bg-table-terisi' : 'bg-table-tersedia' }}">
                                {{ $isOccupied ? 'Terisi' : 'Tersedia' }}
                            </span>
                        </div>

                        <div class="pt-3 border-t border-border-card flex items-center justify-between gap-2">
                            {{-- Toggle Active --}}
                            <button
                                type="button"
                                wire:click="toggleActive({{ $table->id }})"
                                class="inline-flex items-center gap-2 min-h-[44px] px-3.5 rounded-[12px] font-sub text-xs font-bold transition-colors cursor-pointer {{ $table->is_active ? 'bg-green-dark/10 text-green-dark border border-green-dark/30 hover:bg-green-dark/20' : 'bg-asset/70 text-text-muted border border-border-input hover:bg-asset' }}"
                            >
                                <span class="w-2.5 h-2.5 rounded-full {{ $table->is_active ? 'bg-green-dark' : 'bg-text-muted' }}"></span>
                                <span>{{ $table->is_active ? 'Aktif' : 'Nonaktif' }}</span>
                            </button>

                            {{-- Delete Button (only if never used in orders; otherwise server also protects) --}}
                            @if (! $hasOrderHistory)
                                <button
                                    type="button"
                                    wire:click="confirmDelete({{ $table->id }})"
                                    class="inline-flex items-center justify-center min-h-[44px] px-3.5 rounded-[12px] border border-primary-button/30 bg-primary-button/5 font-sub text-xs font-bold text-primary-button hover:bg-primary-button hover:text-white transition-colors cursor-pointer"
                                >
                                    Hapus
                                </button>
                            @else
                                <span
                                    class="font-body text-[11px] text-text-muted px-2"
                                    title="Meja pernah digunakan dalam {{ $table->orders_count }} pesanan"
                                >
                                    {{ $table->orders_count }} riwayat pesanan
                                </span>
                            @endif
                        </div>
                    </div>
                @endforeach
            </div>
        </x-card>
    @empty
        <x-card padding="p-8 text-center">
            <p class="font-heading text-base font-semibold text-text-primary">Belum Ada Meja Berkode</p>
            <p class="font-body text-sm text-text-muted mt-1">
                Tambahkan meja berkode melalui formulir di atas.
            </p>
        </x-card>
    @endforelse

    {{-- Delete Confirmation Modal --}}
    <x-modal
        :show="$deletingId !== null"
        title="Hapus Meja?"
        maxWidth="sm"
        closeAction="cancelDelete"
    >
        <p class="font-body text-sm text-text-body">
            Apakah Anda yakin ingin menghapus meja
            <strong class="font-semibold text-text-primary">"{{ $deletingCode }}"</strong>?
        </p>

        <x-slot:footer>
            <x-button
                type="button"
                variant="outline"
                :fullWidth="false"
                wire:click="cancelDelete"
                class="px-4 !min-h-[44px]"
            >
                Batal
            </x-button>
            <x-button
                type="button"
                variant="primary"
                :fullWidth="false"
                wire:click="deleteTable"
                class="px-4 !min-h-[44px]"
            >
                Ya, Hapus
            </x-button>
        </x-slot:footer>
    </x-modal>
</div>
