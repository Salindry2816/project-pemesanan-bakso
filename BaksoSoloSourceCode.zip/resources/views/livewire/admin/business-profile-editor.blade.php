<div class="space-y-6">
    {{-- Page Header --}}
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h2 class="font-heading text-2xl font-bold text-text-primary">Profil Usaha</h2>
            <p class="font-sub text-sm text-text-muted mt-0.5">Kelola informasi warung, jam operasional, kontak, dan QRIS pembayaran.</p>
        </div>
    </div>

    {{-- System / Missing Profile Alert --}}
    @if ($profileMissingError)
        <div class="p-4 rounded-[12px] bg-red-50 border border-primary-button/30 text-primary-button font-sub text-sm font-semibold flex items-center gap-3" role="alert">
            <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8" x2="12" y2="12"/>
                <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <span>{{ $profileMissingError }}</span>
        </div>
    @endif

    {{-- Feedback Alerts --}}
    @if ($statusMessage)
        <div
            x-data="{ show: true }"
            x-show="show"
            x-init="setTimeout(() => show = false, 4000)"
            class="p-4 rounded-[12px] bg-green-50 border border-status-selesai/30 text-status-selesai font-sub text-sm font-semibold flex items-center justify-between gap-3 transition-opacity"
            role="status"
        >
            <div class="flex items-center gap-2.5">
                <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M20 6L9 17l-5-5"/>
                </svg>
                <span>{{ $statusMessage }}</span>
            </div>
            <button type="button" @click="show = false" class="text-status-selesai/70 hover:text-status-selesai" aria-label="Tutup pesan">
                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
        </div>
    @endif

    @if ($errorMessage)
        <div class="p-4 rounded-[12px] bg-red-50 border border-primary-button/30 text-primary-button font-sub text-sm font-semibold flex items-center gap-3" role="alert">
            <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                <circle cx="12" cy="12" r="10"/>
                <line x1="12" y1="8" x2="12" y2="12"/>
                <line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            <span>{{ $errorMessage }}</span>
        </div>
    @endif

    {{-- Bagian: Pengaturan Warung --}}
    <x-card class="space-y-4">
        <div>
            <h3 class="font-heading text-base font-bold text-text-primary">Pengaturan Warung</h3>
            <p class="font-sub text-xs text-text-muted mt-0.5">Akses cepat ke pengaturan operasional terkait meja, kategori, dan pencetakan QR.</p>
        </div>

        <div class="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
            <a
                href="{{ route('admin.tables') }}"
                class="flex items-start gap-3 p-3.5 rounded-[12px] border border-border-card bg-cream/40 hover:bg-cream transition-colors group"
            >
                <div class="w-9 h-9 rounded-[10px] bg-white border border-border-card flex items-center justify-center text-maroon shrink-0 group-hover:scale-105 transition-transform">
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <rect x="3" y="5" width="18" height="14" rx="2"/>
                        <path d="M3 10h18M9 19v2M15 19v2"/>
                    </svg>
                </div>
                <div class="min-w-0">
                    <p class="font-sub text-sm font-bold text-text-primary group-hover:text-maroon transition-colors">Kelola Meja</p>
                    <p class="font-body text-xs text-text-muted mt-0.5">Atur meja berkode dan meja bebas</p>
                </div>
            </a>

            <a
                href="{{ route('admin.categories') }}"
                class="flex items-start gap-3 p-3.5 rounded-[12px] border border-border-card bg-cream/40 hover:bg-cream transition-colors group"
            >
                <div class="w-9 h-9 rounded-[10px] bg-white border border-border-card flex items-center justify-center text-maroon shrink-0 group-hover:scale-105 transition-transform">
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M4 6h16M4 12h16M4 18h10"/>
                    </svg>
                </div>
                <div class="min-w-0">
                    <p class="font-sub text-sm font-bold text-text-primary group-hover:text-maroon transition-colors">Kelola Kategori</p>
                    <p class="font-body text-xs text-text-muted mt-0.5">Atur kategori & urutan menu</p>
                </div>
            </a>

            <a
                href="{{ route('admin.qr') }}"
                class="flex items-start gap-3 p-3.5 rounded-[12px] border border-border-card bg-cream/40 hover:bg-cream transition-colors group"
            >
                <div class="w-9 h-9 rounded-[10px] bg-white border border-border-card flex items-center justify-center text-maroon shrink-0 group-hover:scale-105 transition-transform">
                    <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <rect x="3" y="3" width="7" height="7" rx="1"/>
                        <rect x="14" y="3" width="7" height="7" rx="1"/>
                        <rect x="3" y="14" width="7" height="7" rx="1"/>
                        <path d="M14 14h3v3h-3zM18 18h3v3h-3zM18 14h3M14 18v3"/>
                    </svg>
                </div>
                <div class="min-w-0">
                    <p class="font-sub text-sm font-bold text-text-primary group-hover:text-maroon transition-colors">Cetak QR</p>
                    <p class="font-body text-xs text-text-muted mt-0.5">Lembar cetak QR untuk meja</p>
                </div>
            </a>
        </div>
    </x-card>

    {{-- Main Form: Business Profile & Media --}}
    @if (! $profileMissingError)
        <form wire:submit.prevent="saveProfile" class="space-y-6">
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {{-- Left 2 Columns: Text Data --}}
                <div class="lg:col-span-2 space-y-6">
                    {{-- Card: Informasi Warung --}}
                    <x-card class="space-y-4">
                        <div class="border-b border-border-card pb-3">
                            <h3 class="font-heading text-base font-bold text-text-primary">Informasi Warung</h3>
                            <p class="font-sub text-xs text-text-muted mt-0.5">Identitas usaha yang ditampilkan kepada pembeli pada halaman pemesanan.</p>
                        </div>

                        <div class="space-y-4 pt-1">
                            <div>
                                <x-input
                                    label="Nama Warung"
                                    name="name"
                                    wire:model="name"
                                    placeholder="contoh: Bakso Solo"
                                    required
                                />
                            </div>

                            <div>
                                <x-input
                                    label="Tagline / Subjudul"
                                    name="tagline"
                                    wire:model="tagline"
                                    placeholder="contoh: Warung Bu Susi"
                                />
                            </div>

                            <div>
                                <x-textarea
                                    label="Deskripsi Warung"
                                    name="description"
                                    wire:model="description"
                                    rows="4"
                                    placeholder="Ceritakan profil singkat warung Anda..."
                                />
                            </div>

                            <div>
                                <x-input
                                    label="Lokasi / Alamat"
                                    name="location"
                                    wire:model="location"
                                    placeholder="contoh: Kantin M, Lantai 2, Universitas Negeri Jakarta (UNJ)"
                                />
                            </div>
                        </div>
                    </x-card>

                    {{-- Card: Jam Operasional & Kontak --}}
                    <x-card class="space-y-4">
                        <div class="border-b border-border-card pb-3">
                            <h3 class="font-heading text-base font-bold text-text-primary">Kontak & Jam Operasional</h3>
                            <p class="font-sub text-xs text-text-muted mt-0.5">Nomor kontak pemesanan dan jadwal operasional harian.</p>
                        </div>

                        <div class="space-y-4 pt-1">
                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div>
                                    <x-input
                                        label="Nomor Telepon"
                                        name="phone"
                                        wire:model="phone"
                                        placeholder="085215355501"
                                    />
                                    <p class="mt-1 font-body text-[11px] text-text-muted">Nomor telepon aktif Indonesia (otomatis dinormalisasi ke format 628...)</p>
                                </div>

                                <div>
                                    <x-input
                                        label="Nomor WhatsApp"
                                        name="whatsapp"
                                        wire:model="whatsapp"
                                        placeholder="085215355501"
                                    />
                                    <p class="mt-1 font-body text-[11px] text-text-muted">Dipakai untuk tombol hubungi penjual via WhatsApp</p>
                                </div>
                            </div>

                            <div>
                                <label class="block font-sub text-xs md:text-[13px] font-bold text-text-primary mb-1.5">
                                    Jam Operasional
                                    <span class="text-primary-button" aria-hidden="true">*</span>
                                </label>
                                <div class="grid grid-cols-2 gap-4">
                                    <div>
                                        <x-input
                                            name="open_time"
                                            wire:model="open_time"
                                            placeholder="08.00"
                                            prefix="Buka:"
                                            required
                                        />
                                    </div>
                                    <div>
                                        <x-input
                                            name="close_time"
                                            wire:model="close_time"
                                            placeholder="17.00"
                                            prefix="Tutup:"
                                            required
                                        />
                                    </div>
                                </div>
                                <p class="mt-1.5 font-body text-[11px] text-text-muted">Format 24 jam dengan titik (contoh: 08.00 - 17.00). Jam buka dan tutup tidak boleh sama.</p>
                            </div>
                        </div>
                    </x-card>
                </div>

                {{-- Right Column: Media (Logo & QRIS) --}}
                <div class="space-y-6">
                    {{-- Card: Logo Warung --}}
                    <x-card class="space-y-4">
                        <div class="border-b border-border-card pb-3">
                            <h3 class="font-heading text-base font-bold text-text-primary">Logo Warung</h3>
                            <p class="font-sub text-xs text-text-muted mt-0.5">Logo yang tampil di header dan struk.</p>
                        </div>

                        <div class="space-y-3 pt-1">
                            {{-- Logo Preview --}}
                            <div class="flex items-center gap-4">
                                <div class="w-20 h-20 rounded-full border border-border-card bg-asset flex items-center justify-center overflow-hidden shrink-0">
                                    @if ($logo && method_exists($logo, 'temporaryUrl'))
                                        <img src="{{ $logo->temporaryUrl() }}" alt="Preview Logo Baru" class="w-full h-full object-cover">
                                    @elseif ($existingLogoUrl)
                                        <img src="{{ $existingLogoUrl }}" alt="Logo Warung" class="w-full h-full object-cover">
                                    @else
                                        <span class="font-sub text-xs font-bold text-text-muted">LOGO</span>
                                    @endif
                                </div>

                                <div class="min-w-0 space-y-1">
                                    @if ($existingLogoPath)
                                        <button
                                            type="button"
                                            wire:click="removeLogo"
                                            wire:loading.attr="disabled"
                                            class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-[8px] bg-red-50 text-primary-button hover:bg-red-100 font-sub text-xs font-semibold transition-colors cursor-pointer"
                                        >
                                            <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                                            <span>Hapus Logo</span>
                                        </button>
                                    @endif
                                    <p class="font-body text-[11px] text-text-muted leading-tight">JPG, PNG, atau WebP. Maks 2 MB (otomatis resize maks 800px).</p>
                                </div>
                            </div>

                            {{-- File Input --}}
                            <div>
                                <x-file-input
                                    wire:model="logo"
                                    name="logo"
                                    accept=".jpg,.jpeg,.png,.webp"
                                    hint="JPG, PNG, atau WebP. Maksimal 2 MB (otomatis disesuaikan maksimal 800px)."
                                />
                                <div wire:loading wire:target="logo" class="mt-1 font-body text-xs text-maroon flex items-center gap-1.5">
                                    <svg class="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24" fill="none"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
                                    <span>Mengunggah logo...</span>
                                </div>
                            </div>
                        </div>
                    </x-card>

                    {{-- Card: QRIS Pembayaran --}}
                    <x-card class="space-y-4">
                        <div class="border-b border-border-card pb-3">
                            <h3 class="font-heading text-base font-bold text-text-primary">QRIS Pembayaran</h3>
                            <p class="font-sub text-xs text-text-muted mt-0.5">Gambar QRIS resmi untuk pembayaran digital pembeli.</p>
                        </div>

                        <div class="space-y-3 pt-1">
                            {{-- QRIS Preview --}}
                            <div class="flex flex-col items-center justify-center p-3 rounded-[12px] border border-border-card bg-cream/30 min-h-[160px]">
                                @if ($qris && method_exists($qris, 'temporaryUrl'))
                                    <img src="{{ $qris->temporaryUrl() }}" alt="Preview QRIS Baru" class="max-h-48 max-w-full rounded-[8px] object-contain shadow-sm">
                                @elseif ($existingQrisUrl)
                                    <img src="{{ $existingQrisUrl }}" alt="QRIS Pembayaran Warung" class="max-h-48 max-w-full rounded-[8px] object-contain shadow-sm">
                                @else
                                    <div class="flex flex-col items-center justify-center text-text-muted py-6">
                                        <svg class="w-12 h-12 stroke-1 text-text-muted/60 mb-2" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                            <rect x="3" y="3" width="7" height="7" rx="1"/>
                                            <rect x="14" y="3" width="7" height="7" rx="1"/>
                                            <rect x="3" y="14" width="7" height="7" rx="1"/>
                                            <path d="M14 14h3v3h-3zM18 18h3v3h-3zM18 14h3M14 18v3"/>
                                        </svg>
                                        <span class="font-sub text-xs font-semibold">Belum ada gambar QRIS</span>
                                        <span class="font-body text-[11px] text-text-muted mt-0.5">Unggah gambar QRIS statis warung Anda</span>
                                    </div>
                                @endif
                            </div>

                            @if ($existingQrisPath)
                                <div class="flex justify-end">
                                    <button
                                        type="button"
                                        wire:click="removeQris"
                                        wire:loading.attr="disabled"
                                        class="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-[8px] bg-red-50 text-primary-button hover:bg-red-100 font-sub text-xs font-semibold transition-colors cursor-pointer"
                                    >
                                        <svg class="w-3.5 h-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 6h18M19 6v14a2 2 0 01-2 2H7a2 2 0 01-2-2V6m3 0V4a2 2 0 012-2h4a2 2 0 012 2v2"/></svg>
                                        <span>Hapus Gambar QRIS</span>
                                    </button>
                                </div>
                            @endif

                            {{-- File Input --}}
                            <div>
                                <x-file-input
                                    wire:model="qris"
                                    name="qris"
                                    accept=".png,.jpg,.jpeg,.webp"
                                    hint="PNG, JPG, atau WebP (maks 2 MB). Disimpan jernih tanpa resize agar presisi dipindai."
                                />
                                <div wire:loading wire:target="qris" class="mt-1 font-body text-xs text-maroon flex items-center gap-1.5">
                                    <svg class="animate-spin h-3.5 w-3.5" viewBox="0 0 24 24" fill="none"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
                                    <span>Mengunggah gambar QRIS...</span>
                                </div>
                            </div>
                        </div>
                    </x-card>
                </div>
            </div>

            {{-- Submit Action --}}
            <div class="flex items-center justify-end gap-3 pt-4 border-t border-border-card">
                <x-button
                    type="submit"
                    variant="primary"
                    wire:loading.attr="disabled"
                    wire:target="saveProfile, logo, qris"
                    class="min-w-[180px]"
                >
                    <span wire:loading.remove wire:target="saveProfile">Simpan Perubahan</span>
                    <span wire:loading wire:target="saveProfile" class="inline-flex items-center gap-2">
                        <svg class="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
                        <span>Menyimpan...</span>
                    </span>
                </x-button>
            </div>
        </form>
    @endif
</div>
