@php
    try {
        $businessProfile = \App\Models\BusinessProfile::query()->find(1);
    } catch (\Throwable) {
        $businessProfile = null;
    }
    $businessLogoUrl = \App\Support\MediaStorage::url($businessProfile?->logo_path);
    $businessName = $businessProfile?->name ?? 'Bakso Solo';
    $businessTagline = $businessProfile?->tagline ?? 'Warung Bu Susi';
@endphp

<div class="w-full max-w-md md:max-w-4xl mx-auto">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10 items-center">
        {{-- Desktop Left Hero Panel (Matches Customer Landing Split Layout) --}}
        <div class="hidden md:flex relative overflow-hidden flex-col justify-between gap-6 p-8 rounded-[24px] border border-maroon/20 shadow-card text-white min-h-[450px] bg-maroon">
            <img
                src="/images/hero-bakso.jpg"
                alt=""
                aria-hidden="true"
                class="absolute inset-0 w-full h-full object-cover opacity-35 scale-105"
            />
            <div
                class="absolute inset-0"
                style="background: linear-gradient(135deg, rgba(61, 18, 16, 0.92), rgba(120, 42, 37, 0.86), rgba(42, 13, 11, 0.95));"
            ></div>

            <div class="relative z-10 flex items-center gap-4">
                <div class="w-16 h-16 rounded-full bg-white flex items-center justify-center font-sub text-xs font-bold text-[#6B6B6B] overflow-hidden border-2 border-accent-yellow/80 shadow-md shrink-0">
                    @if ($businessLogoUrl)
                        <img src="{{ $businessLogoUrl }}" alt="Logo {{ $businessName }}" class="w-full h-full object-cover">
                    @else
                        LOGO
                    @endif
                </div>
                <div>
                    <span class="inline-block px-2.5 py-0.5 rounded-pill bg-white/15 text-accent-yellow font-sub text-[10px] font-bold uppercase tracking-wider mb-1">
                        Portal Penjual
                    </span>
                    <h2 class="font-heading text-2xl font-bold text-cream leading-tight">{{ $businessName }}</h2>
                    <p class="font-sub text-xs font-semibold text-cream/80">{{ $businessTagline }}</p>
                </div>
            </div>

            <div class="relative z-10 flex items-center justify-between gap-4 my-1">
                <p class="font-body text-sm text-cream/90 leading-relaxed">
                    Kelola pesanan masuk secara real-time, konfirmasi pembayaran Cash &amp; QRIS, atur menu, hingga pantau grafik laporan penjualan harian dan bulanan.
                </p>
                <div class="shrink-0">
                    <x-bakso-bowl-illustration sizeClass="w-28 h-28" steamColor="#FFFBEA" />
                </div>
            </div>

            <div class="relative z-10 space-y-3 pt-4 border-t border-white/15">
                <div class="flex items-center gap-3 text-xs font-sub font-semibold text-cream/95">
                    <span class="w-7 h-7 rounded-full bg-white/15 text-accent-yellow flex items-center justify-center shrink-0">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
                    </span>
                    <span>Notifikasi lonceng &amp; suara otomatis pesanan baru</span>
                </div>
                <div class="flex items-center gap-3 text-xs font-sub font-semibold text-cream/95">
                    <span class="w-7 h-7 rounded-full bg-white/15 text-accent-yellow flex items-center justify-center shrink-0">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="M7 14l4-4 4 3 5-6"/></svg>
                    </span>
                    <span>Laporan penjualan otomatis, grafik &amp; menu terlaris</span>
                </div>
                <div class="flex items-center gap-3 text-xs font-sub font-semibold text-cream/95">
                    <span class="w-7 h-7 rounded-full bg-white/15 text-accent-yellow flex items-center justify-center shrink-0">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/></svg>
                    </span>
                    <span>Kelola meja lantai 1–4, katalog menu &amp; cetak QR</span>
                </div>
            </div>
        </div>

        {{-- Login Card (Mobile & Desktop Right Column) --}}
        <div class="w-full max-w-md mx-auto rounded-[24px] bg-white border border-border-card shadow-card overflow-hidden">
            {{-- Mobile Warm Photo Hero Header --}}
            <div class="md:hidden relative px-6 pt-6 pb-5 text-center text-white bg-maroon overflow-hidden">
                <img
                    src="/images/hero-bakso.jpg"
                    alt=""
                    aria-hidden="true"
                    class="absolute inset-0 w-full h-full object-cover opacity-35"
                />
                <div
                    class="absolute inset-0"
                    style="background: linear-gradient(180deg, rgba(42, 13, 11, 0.85), rgba(120, 42, 37, 0.8), rgba(74, 23, 20, 0.95));"
                ></div>
                <div class="relative z-10 flex flex-col items-center">
                    <div class="flex items-center justify-center gap-3 mb-2">
                        <div class="w-12 h-12 rounded-full bg-white flex items-center justify-center font-sub text-[10px] font-bold text-[#6B6B6B] overflow-hidden border-2 border-accent-yellow shadow-md shrink-0">
                            @if ($businessLogoUrl)
                                <img src="{{ $businessLogoUrl }}" alt="Logo {{ $businessName }}" class="w-full h-full object-cover">
                            @else
                                LOGO
                            @endif
                        </div>
                        <x-bakso-bowl-illustration sizeClass="w-14 h-14" steamColor="#FFFBEA" />
                    </div>
                    <p class="font-heading text-lg font-bold text-cream leading-tight">{{ $businessName }}</p>
                    <p class="font-sub text-[11px] font-semibold text-accent-yellow mt-0.5">{{ $businessTagline }}</p>
                </div>
            </div>

            <div class="p-6 md:p-8">
                <div class="text-center md:text-left mb-6">
                    <h1 class="font-heading text-xl md:text-[22px] font-bold text-text-primary">Login Admin</h1>
                    <p class="font-body text-xs md:text-[13px] text-text-muted mt-1.5 leading-relaxed">
                        Masukkan username dan password<br class="hidden md:inline"> untuk masuk ke dashboard.
                    </p>
                </div>

                <form wire:submit="authenticate" class="space-y-5" novalidate>
                    <x-input
                        label="Username"
                        name="username"
                        id="username"
                        wire:model="username"
                        autocomplete="username"
                        placeholder="Masukkan username"
                        :error="$errors->first('username')"
                    />

                    <x-input
                        label="Password"
                        name="password"
                        id="password"
                        type="password"
                        wire:model="password"
                        autocomplete="current-password"
                        placeholder="•••••••••"
                        :togglePassword="true"
                        :error="$errors->first('password')"
                    />

                    <div class="pt-2">
                        <x-button type="submit" variant="primary" :fullWidth="true" wire:loading.attr="disabled">
                            <span wire:loading.remove wire:target="authenticate">Masuk</span>
                            <span wire:loading wire:target="authenticate">Memproses...</span>
                        </x-button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
