<div class="space-y-6 md:space-y-8">
    {{-- Live Automatic Summary Highlights (Hari Ini & Bulan Ini) --}}
    <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-3.5 md:gap-5">
        <x-card padding="p-4 md:p-5" radius="rounded-[16px]" class="flex items-center gap-3.5">
            <div class="w-11 h-11 rounded-[12px] bg-green-dark/15 text-green-dark flex items-center justify-center shrink-0">
                <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <line x1="12" y1="1" x2="12" y2="23"/>
                    <path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>
                </svg>
            </div>
            <div class="min-w-0">
                <p class="font-sub text-xs font-semibold text-text-muted">Pendapatan Hari Ini</p>
                <p class="font-heading text-xl md:text-2xl font-bold text-text-primary leading-tight">
                    Rp {{ number_format($todayRevenue, 0, ',', '.') }}
                </p>
                <p class="font-body text-[11px] text-green-dark font-semibold mt-0.5">{{ $todayTransactions }} transaksi lunas</p>
            </div>
        </x-card>

        <x-card padding="p-4 md:p-5" radius="rounded-[16px]" class="flex items-center gap-3.5">
            <div class="w-11 h-11 rounded-[12px] bg-maroon/12 text-maroon flex items-center justify-center shrink-0">
                <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <rect x="3" y="4" width="18" height="18" rx="2"/>
                    <line x1="16" y1="2" x2="16" y2="6"/>
                    <line x1="8" y1="2" x2="8" y2="6"/>
                    <line x1="3" y1="10" x2="21" y2="10"/>
                </svg>
            </div>
            <div class="min-w-0">
                <p class="font-sub text-xs font-semibold text-text-muted">Pendapatan Bulan Ini</p>
                <p class="font-heading text-xl md:text-2xl font-bold text-text-primary leading-tight">
                    Rp {{ number_format($thisMonthRevenue, 0, ',', '.') }}
                </p>
                <p class="font-body text-[11px] text-maroon font-semibold mt-0.5">{{ $thisMonthTransactions }} transaksi lunas</p>
            </div>
        </x-card>

        <x-card padding="p-4 md:p-5" radius="rounded-[16px]" class="flex items-center gap-3.5">
            <div class="w-11 h-11 rounded-[12px] bg-status-diterima/15 text-status-diterima flex items-center justify-center shrink-0">
                <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <rect x="5" y="4" width="14" height="17" rx="3"/>
                    <path d="M9 4V3h6v1M9 11h6M9 15h4"/>
                </svg>
            </div>
            <div class="min-w-0">
                <p class="font-sub text-xs font-semibold text-text-muted">Total Pesanan (Periode)</p>
                <p class="font-heading text-xl md:text-2xl font-bold text-text-primary leading-tight">{{ $totalOrdersCount }}</p>
                <p class="font-body text-[11px] text-text-muted mt-0.5">
                    {{ $paidTransactionsCount }} lunas &bull; {{ $unpaidOrdersCount }} belum bayar &bull; {{ $cancelledOrdersCount }} batal
                </p>
            </div>
        </x-card>

        <x-card padding="p-4 md:p-5" radius="rounded-[16px]" class="flex items-center gap-3.5">
            <div class="w-11 h-11 rounded-[12px] bg-accent-yellow/20 text-[#9A6E0A] flex items-center justify-center shrink-0">
                <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M3 3v18h18"/>
                    <path d="M7 14l4-4 4 3 5-6"/>
                </svg>
            </div>
            <div class="min-w-0">
                <p class="font-sub text-xs font-semibold text-text-muted">Rata-rata / Transaksi</p>
                <p class="font-heading text-xl md:text-2xl font-bold text-text-primary leading-tight">
                    Rp {{ number_format($averageOrderValue, 0, ',', '.') }}
                </p>
                <p class="font-body text-[11px] text-text-muted mt-0.5">
                    Cash: {{ $paymentBreakdown['cash']['count'] }} &bull; QRIS: {{ $paymentBreakdown['qris']['count'] }}
                </p>
            </div>
        </x-card>
    </div>

    {{-- Filter Controls + Export CSV --}}
    <x-card padding="p-4 md:p-5" radius="rounded-[16px]">
        <div class="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div class="flex flex-wrap items-center gap-2">
                <button
                    type="button"
                    wire:click="setPeriodMode('daily')"
                    class="min-h-[42px] px-4 rounded-[10px] font-sub text-xs md:text-sm font-bold transition-colors cursor-pointer {{ $periodMode === 'daily' ? 'bg-maroon text-white' : 'bg-cream text-text-body border border-border-card hover:bg-beige/40' }}"
                >
                    Rekap Harian
                </button>
                <button
                    type="button"
                    wire:click="setPeriodMode('monthly')"
                    class="min-h-[42px] px-4 rounded-[10px] font-sub text-xs md:text-sm font-bold transition-colors cursor-pointer {{ $periodMode === 'monthly' ? 'bg-maroon text-white' : 'bg-cream text-text-body border border-border-card hover:bg-beige/40' }}"
                >
                    Rekap Bulanan
                </button>
            </div>

            <div class="flex flex-wrap items-center gap-3">
                @if ($periodMode === 'daily')
                    <label class="flex items-center gap-2 font-sub text-xs font-semibold text-text-body">
                        <span>Bulan:</span>
                        <input
                            type="month"
                            wire:model.live="selectedMonth"
                            class="min-h-[42px] px-3 rounded-[10px] border border-border-input bg-white font-sub text-xs md:text-sm text-text-primary outline-none focus:border-maroon"
                        />
                    </label>
                @else
                    <label class="flex items-center gap-2 font-sub text-xs font-semibold text-text-body">
                        <span>Tahun:</span>
                        <select
                            wire:model.live="selectedYear"
                            class="min-h-[42px] px-3 rounded-[10px] border border-border-input bg-white font-sub text-xs md:text-sm text-text-primary outline-none focus:border-maroon"
                        >
                            @foreach ($yearOptions as $yearOption)
                                <option value="{{ $yearOption }}">{{ $yearOption }}</option>
                            @endforeach
                        </select>
                    </label>
                @endif

                <button
                    type="button"
                    wire:click="exportCsv"
                    class="inline-flex items-center gap-2 min-h-[42px] px-4 rounded-[10px] bg-green-dark text-white hover:bg-green-dark/90 font-sub text-xs md:text-sm font-bold transition-colors cursor-pointer"
                >
                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg>
                    <span>Export CSV</span>
                </button>
            </div>
        </div>
    </x-card>

    {{-- Main Grid: Sales Chart (Left 7 cols) + Top Selling Menus (Right 5 cols) --}}
    <div class="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {{-- Sales Chart --}}
        <x-card padding="p-5 md:p-6" radius="rounded-[18px]" class="lg:col-span-7 space-y-4">
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div>
                    <h2 class="font-heading text-base md:text-lg font-bold text-text-primary">
                        Grafik Penjualan
                    </h2>
                    <p class="font-sub text-xs text-text-muted">{{ $periodLabel }}</p>
                </div>
                <div class="px-3 py-1.5 rounded-[10px] bg-cream border border-border-card text-right">
                    <p class="font-sub text-[10px] text-text-muted">Omzet Periode</p>
                    <p class="font-heading text-sm font-bold text-maroon">
                        Rp {{ number_format($totalRevenue, 0, ',', '.') }}
                    </p>
                </div>
            </div>

            <div
                wire:ignore
                x-data="{
                    renderChart(payload) {
                        const canvas = this.$refs.canvas;
                        if (!canvas || typeof window.Chart === 'undefined') return;
                        const existing = window.Chart.getChart(canvas);
                        if (existing) {
                            existing.destroy();
                        }
                        new window.Chart(canvas.getContext('2d'), {
                            type: 'bar',
                            data: {
                                labels: payload.labels,
                                datasets: [{
                                    label: 'Pendapatan (Rp)',
                                    data: payload.revenues,
                                    backgroundColor: '#782A25',
                                    hoverBackgroundColor: '#C62828',
                                    borderRadius: 6,
                                    maxBarThickness: 32,
                                }]
                            },
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: { display: false },
                                    tooltip: {
                                        callbacks: {
                                            label: (ctx) => {
                                                const idx = ctx.dataIndex;
                                                const val = Number(ctx.parsed.y || 0).toLocaleString('id-ID');
                                                const tx = payload.counts[idx] ?? 0;
                                                return `Rp ${val} (${tx} transaksi)`;
                                            }
                                        }
                                    }
                                },
                                scales: {
                                    y: {
                                        beginAtZero: true,
                                        ticks: {
                                            callback: (val) => 'Rp ' + Number(val).toLocaleString('id-ID')
                                        },
                                        grid: { color: '#F1E8D4' }
                                    },
                                    x: {
                                        grid: { display: false }
                                    }
                                }
                            }
                        });
                    }
                }"
                x-init="renderChart(@js(['labels' => $chartLabels, 'revenues' => $chartRevenues, 'counts' => $chartCounts]))"
                x-on:sales-chart-updated.window="renderChart($event.detail[0] ?? $event.detail)"
                class="relative h-72 w-full"
            >
                <canvas x-ref="canvas" aria-label="Grafik Penjualan Bakso Solo"></canvas>
            </div>

            {{-- Cash vs QRIS Mini Breakdown --}}
            <div class="grid grid-cols-2 gap-3 pt-2 border-t border-border-card">
                <div class="p-3 rounded-[12px] bg-cream/70 border border-border-card">
                    <p class="font-sub text-[11px] font-bold text-text-muted">Pembayaran Cash</p>
                    <p class="font-heading text-sm md:text-base font-bold text-text-primary mt-0.5">
                        Rp {{ number_format($paymentBreakdown['cash']['revenue'], 0, ',', '.') }}
                    </p>
                    <p class="font-body text-[11px] text-text-muted">{{ $paymentBreakdown['cash']['count'] }} transaksi</p>
                </div>
                <div class="p-3 rounded-[12px] bg-cream/70 border border-border-card">
                    <p class="font-sub text-[11px] font-bold text-text-muted">Pembayaran QRIS</p>
                    <p class="font-heading text-sm md:text-base font-bold text-text-primary mt-0.5">
                        Rp {{ number_format($paymentBreakdown['qris']['revenue'], 0, ',', '.') }}
                    </p>
                    <p class="font-body text-[11px] text-text-muted">{{ $paymentBreakdown['qris']['count'] }} transaksi</p>
                </div>
            </div>
        </x-card>

        {{-- Top Selling Menus --}}
        <x-card padding="p-5 md:p-6" radius="rounded-[18px]" class="lg:col-span-5 space-y-4">
            <div>
                <h2 class="font-heading text-base md:text-lg font-bold text-text-primary">
                    Menu Paling Laris
                </h2>
                <p class="font-sub text-xs text-text-muted">Berdasarkan porsi terjual dari pesanan lunas</p>
            </div>

            @if (count($topMenus) === 0)
                <div class="py-10 text-center rounded-[14px] bg-cream/60 border border-dashed border-border-card">
                    <p class="font-sub text-xs text-text-muted">
                        Belum ada transaksi lunas pada periode ini.
                    </p>
                </div>
            @else
                <div class="space-y-3.5">
                    @foreach ($topMenus as $index => $menu)
                        <div class="space-y-1.5">
                            <div class="flex items-center justify-between gap-3">
                                <div class="flex items-center gap-2.5 min-w-0">
                                    <span class="w-6 h-6 rounded-full flex items-center justify-center font-heading text-xs font-bold shrink-0 {{ $index === 0 ? 'bg-accent-yellow text-text-primary' : ($index <= 2 ? 'bg-maroon text-white' : 'bg-cream border border-border-card text-text-body') }}">
                                        {{ $index + 1 }}
                                    </span>
                                    <span class="font-sub text-xs md:text-sm font-bold text-text-primary truncate">
                                        {{ $menu['menu_name'] }}
                                    </span>
                                </div>
                                <div class="text-right shrink-0">
                                    <span class="font-heading text-xs md:text-sm font-bold text-maroon">{{ $menu['total_qty'] }} porsi</span>
                                    <span class="block font-body text-[11px] text-text-muted">
                                        Rp {{ number_format($menu['total_revenue'], 0, ',', '.') }}
                                    </span>
                                </div>
                            </div>
                            <div class="w-full h-2 rounded-full bg-cream overflow-hidden border border-border-card/60">
                                <div
                                    class="h-full rounded-full {{ $index === 0 ? 'bg-primary-button' : 'bg-maroon/75' }}"
                                    style="width: {{ max(6, $menu['percent']) }}%"
                                ></div>
                            </div>
                        </div>
                    @endforeach
                </div>
            @endif
        </x-card>
    </div>

    {{-- Detailed Period Breakdown Table --}}
    <x-card padding="p-5 md:p-6" radius="rounded-[18px]" class="space-y-4">
        <div class="flex items-center justify-between">
            <div>
                <h2 class="font-heading text-base md:text-lg font-bold text-text-primary">
                    Rincian {{ $periodMode === 'daily' ? 'Harian' : 'Bulanan' }}
                </h2>
                <p class="font-sub text-xs text-text-muted">{{ $periodLabel }}</p>
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="border-b border-border-card text-text-muted font-sub text-xs uppercase">
                        <th class="py-2.5 pr-4">Periode</th>
                        <th class="py-2.5 px-4 text-right">Transaksi Lunas</th>
                        <th class="py-2.5 pl-4 text-right">Total Pendapatan</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-border-card/70 font-sub text-xs md:text-sm">
                    @php
                        $nonZeroRows = array_values(array_filter($rows, fn ($r) => $r['count'] > 0 || $r['revenue'] > 0));
                        $displayRows = count($nonZeroRows) > 0 ? $nonZeroRows : array_slice($rows, 0, 7);
                    @endphp
                    @foreach ($displayRows as $row)
                        <tr class="hover:bg-cream/50">
                            <td class="py-2.5 pr-4 font-semibold text-text-primary">{{ $row['label'] }}</td>
                            <td class="py-2.5 px-4 text-right text-text-body">{{ $row['count'] }}</td>
                            <td class="py-2.5 pl-4 text-right font-bold text-maroon">
                                Rp {{ number_format($row['revenue'], 0, ',', '.') }}
                            </td>
                        </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr class="border-t-2 border-border-card font-heading text-xs md:text-sm font-bold text-text-primary bg-cream/60">
                        <td class="py-3 pr-4">Total Periode</td>
                        <td class="py-3 px-4 text-right">{{ $paidTransactionsCount }}</td>
                        <td class="py-3 pl-4 text-right text-maroon">
                            Rp {{ number_format($totalRevenue, 0, ',', '.') }}
                        </td>
                    </tr>
                </tfoot>
            </table>
        </div>
    </x-card>
</div>
