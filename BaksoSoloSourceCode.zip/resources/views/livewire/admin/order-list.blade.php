<div class="space-y-6">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
            <a
                href="{{ route('admin.dashboard') }}"
                class="inline-flex items-center gap-1.5 text-maroon hover:underline font-sub text-xs font-semibold min-h-[36px]"
            >
                &larr; Kembali ke Dashboard
            </a>
            <h1 class="font-heading text-2xl font-bold text-text-primary mt-1">
                Semua Pesanan
            </h1>
            <p class="font-body text-xs md:text-sm text-text-muted">
                Cari dan filter riwayat seluruh pesanan berdasarkan status dan tanggal.
            </p>
        </div>
    </div>

    {{-- Filter Bar --}}
    <x-card padding="p-4 md:p-5" radius="rounded-[16px]" class="space-y-4">
        <div class="flex flex-wrap items-center gap-2">
            @foreach ([
                'semua' => 'Semua',
                'aktif' => 'Aktif',
                'diterima' => 'Diterima',
                'diproses' => 'Diproses',
                'disiapkan' => 'Disiapkan',
                'siap' => 'Siap Diantar',
                'selesai' => 'Selesai',
                'dibatalkan' => 'Dibatalkan',
            ] as $key => $label)
                <button
                    type="button"
                    wire:click="setFilter('{{ $key }}')"
                    class="min-h-[38px] px-3.5 rounded-pill font-sub text-xs font-bold transition-colors cursor-pointer {{ $statusFilter === $key ? 'bg-maroon text-white' : 'bg-cream text-text-muted border border-border-card hover:text-text-primary' }}"
                >
                    {{ $label }}
                </button>
            @endforeach
        </div>

        <div class="grid grid-cols-1 md:grid-cols-12 gap-3 items-end">
            <div class="md:col-span-5">
                <label for="order-search" class="block font-sub text-xs font-semibold text-text-muted mb-1">
                    Cari Nomor Pesanan, HP, atau Meja
                </label>
                <input
                    id="order-search"
                    type="search"
                    wire:model.live.debounce.300ms="search"
                    placeholder="Contoh: 0012, 08123456..., atau 2A"
                    class="w-full min-h-[42px] px-3.5 rounded-[12px] bg-white border border-border-card font-body text-xs md:text-sm text-text-primary placeholder-text-muted/60 focus:outline-none focus:ring-2 focus:ring-maroon/20 focus:border-maroon"
                />
            </div>

            <div class="md:col-span-3">
                <label for="date-from" class="block font-sub text-xs font-semibold text-text-muted mb-1">
                    Dari Tanggal
                </label>
                <input
                    id="date-from"
                    type="date"
                    wire:model.live="dateFrom"
                    class="w-full min-h-[42px] px-3.5 rounded-[12px] bg-white border border-border-card font-body text-xs md:text-sm text-text-primary focus:outline-none focus:ring-2 focus:ring-maroon/20 focus:border-maroon"
                />
            </div>

            <div class="md:col-span-3">
                <label for="date-to" class="block font-sub text-xs font-semibold text-text-muted mb-1">
                    Sampai Tanggal
                </label>
                <input
                    id="date-to"
                    type="date"
                    wire:model.live="dateTo"
                    class="w-full min-h-[42px] px-3.5 rounded-[12px] bg-white border border-border-card font-body text-xs md:text-sm text-text-primary focus:outline-none focus:ring-2 focus:ring-maroon/20 focus:border-maroon"
                />
            </div>

            <div class="md:col-span-1">
                <button
                    type="button"
                    wire:click="resetFilters"
                    class="w-full min-h-[42px] px-3 rounded-[12px] border border-border-card bg-white font-sub text-xs font-bold text-text-muted hover:text-text-primary hover:bg-cream transition-colors cursor-pointer"
                >
                    Reset
                </button>
            </div>
        </div>
    </x-card>

    {{-- Orders Table / Cards --}}
    @if ($orders->isEmpty())
        <x-card padding="p-6 md:p-8" radius="rounded-[16px]" class="text-center space-y-2">
            <p class="font-heading text-base font-bold text-text-primary">
                Tidak ada pesanan ditemukan
            </p>
            <p class="font-body text-xs md:text-sm text-text-muted">
                Coba ubah filter status, rentang tanggal, atau kata kunci pencarian.
            </p>
        </x-card>
    @else
        <div class="space-y-3">
            @foreach ($orders as $order)
                <a
                    href="{{ route('admin.orders.show', $order) }}"
                    wire:key="admin-all-order-{{ $order->id }}"
                    class="block p-4 md:p-5 rounded-[16px] bg-white border border-border-card shadow-sm hover:border-maroon/50 transition-colors"
                >
                    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                        <div class="space-y-1">
                            <div class="flex items-center gap-2 flex-wrap">
                                <span class="font-heading text-base md:text-lg font-bold text-text-primary">
                                    {{ $order->display_number }}
                                </span>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-pill font-sub text-[11px] font-bold {{ $order->status->badgeClass() }}">
                                    {{ $order->status->label() }}
                                </span>
                                <span class="inline-flex items-center px-2.5 py-0.5 rounded-pill font-sub text-[11px] font-bold {{ $order->payment_status->value === 'lunas' ? 'bg-green-dark text-white' : 'bg-cream text-text-primary border border-border-card' }}">
                                    {{ $order->payment_status->label() }}
                                </span>
                            </div>
                            <p class="font-sub text-xs text-text-muted">
                                {{ $order->created_at?->format('d M Y, H:i') }}
                                · {{ $order->customer?->phone ?? '-' }}
                                ·
                                @if ($order->type->value === 'take_away')
                                    Take Away
                                @elseif ($order->table)
                                    Meja {{ $order->table->code }}
                                @endif
                            </p>
                        </div>

                        <div class="flex items-center justify-between sm:justify-end gap-4">
                            <div class="text-left sm:text-right">
                                <p class="font-sub text-[11px] text-text-muted">
                                    {{ $order->items->sum('qty') }} porsi · {{ $order->payment_method->label() }}
                                </p>
                                <p class="font-heading text-base font-bold text-primary-button">
                                    Rp {{ number_format($order->total, 0, ',', '.') }}
                                </p>
                            </div>
                            <span class="font-sub text-xs font-bold text-maroon">
                                Detail &rarr;
                            </span>
                        </div>
                    </div>
                </a>
            @endforeach
        </div>

        <div class="pt-2">
            {{ $orders->links() }}
        </div>
    @endif
</div>
