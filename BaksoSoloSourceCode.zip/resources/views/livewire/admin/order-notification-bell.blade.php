<div
    wire:poll.5s.visible="checkOrders"
    x-data="{
        open: false,
        muted: false,
        toast: null,
        toastTimer: null,
        init() {
            try {
                this.muted = localStorage.getItem('bakso_admin_muted') === '1';
            } catch {}
        },
        toggleMute() {
            this.muted = !this.muted;
            try {
                localStorage.setItem('bakso_admin_muted', this.muted ? '1' : '0');
            } catch {}
        },
        testChime() {
            if (typeof window.playOrderChime === 'function') {
                window.playOrderChime();
            }
        },
        handleNewOrder(payload) {
            if (!payload || !payload.id) return;
            if (window.__baksoLastNotifiedOrderId === payload.id) return;
            window.__baksoLastNotifiedOrderId = payload.id;

            if (typeof window.playOrderChime === 'function') {
                window.playOrderChime();
            }

            this.toast = payload;
            clearTimeout(this.toastTimer);
            this.toastTimer = setTimeout(() => {
                this.toast = null;
            }, 8000);
        }
    }"
    x-on:new-order-alert.window="handleNewOrder($event.detail[0] ?? $event.detail)"
    class="relative"
>
    {{-- Bell Icon Button --}}
    <button
        type="button"
        @click="open = !open"
        @click.outside="open = false"
        class="relative inline-flex items-center justify-center min-w-[42px] min-h-[42px] rounded-[12px] border border-border-card bg-white text-text-body hover:bg-cream hover:text-maroon transition-colors cursor-pointer"
        aria-label="Notifikasi Pesanan Baru"
        title="Notifikasi Pesanan Baru"
    >
        <svg class="w-5 h-5 {{ $pendingCount > 0 ? 'text-primary-button' : '' }}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
            <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>

        @if ($pendingCount > 0)
            <span class="absolute -top-1.5 -right-1.5 min-w-[20px] h-5 px-1.5 rounded-full bg-primary-button text-white font-heading text-[11px] font-bold flex items-center justify-center shadow-xs">
                {{ $pendingCount > 99 ? '99+' : $pendingCount }}
            </span>
        @endif
    </button>

    {{-- Notification Dropdown --}}
    <div
        x-show="open"
        x-cloak
        x-transition
        class="absolute right-0 mt-2 w-80 max-w-[calc(100vw-2rem)] rounded-[16px] bg-white border border-border-card shadow-xl z-50 overflow-hidden"
    >
        <div class="px-4 py-3 bg-cream/70 border-b border-border-card flex items-center justify-between gap-2">
            <div>
                <p class="font-heading text-sm font-bold text-text-primary">Pesanan Baru</p>
                <p class="font-body text-[11px] text-text-muted">{{ $pendingCount }} menunggu konfirmasi</p>
            </div>
            <div class="flex items-center gap-1.5">
                <button
                    type="button"
                    @click="testChime()"
                    class="px-2 py-1 rounded-[8px] border border-border-card bg-white text-[11px] font-sub font-semibold text-maroon hover:bg-cream cursor-pointer"
                    title="Tes suara notifikasi"
                >
                    Tes Suara
                </button>
                <button
                    type="button"
                    @click="toggleMute()"
                    class="px-2 py-1 rounded-[8px] border border-border-card bg-white text-[11px] font-sub font-semibold cursor-pointer"
                    :class="muted ? 'text-primary-button' : 'text-green-dark'"
                >
                    <span x-text="muted ? 'Mute' : 'Suara Aktif'"></span>
                </button>
            </div>
        </div>

        <div class="max-h-72 overflow-y-auto divide-y divide-border-card/70">
            @forelse ($recentOrders as $item)
                <a
                    href="{{ $item['url'] }}"
                    class="flex items-center justify-between gap-3 px-4 py-3 hover:bg-cream/60 transition-colors"
                >
                    <div class="min-w-0">
                        <p class="font-heading text-xs font-bold text-maroon truncate">
                            Pesanan {{ $item['display_number'] }}
                        </p>
                        <p class="font-body text-[11px] text-text-muted truncate">
                            {{ $item['location'] }} &bull; {{ $item['time'] }}
                        </p>
                    </div>
                    <span class="font-sub text-xs font-bold text-text-primary shrink-0">
                        {{ $item['total_formatted'] }}
                    </span>
                </a>
            @empty
                <div class="px-4 py-6 text-center">
                    <p class="font-sub text-xs text-text-muted">Belum ada pesanan baru masuk.</p>
                </div>
            @endforelse
        </div>

        <a
            href="{{ route('admin.orders.index', ['status' => 'diterima']) }}"
            class="block text-center py-2.5 bg-cream/50 border-t border-border-card font-sub text-xs font-bold text-maroon hover:bg-cream transition-colors"
        >
            Lihat Semua Pesanan &rarr;
        </a>
    </div>

    {{-- Floating Popup Toast on New Order --}}
    <template x-if="toast">
        <div
            role="status"
            aria-live="polite"
            class="fixed top-4 right-4 z-[60] w-80 max-w-[calc(100vw-2rem)] p-4 rounded-[16px] bg-white border-2 border-primary-button shadow-2xl flex items-start gap-3"
        >
            <div class="w-9 h-9 rounded-full bg-primary-button/15 text-primary-button flex items-center justify-center shrink-0">
                <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>
            </div>
            <div class="min-w-0 flex-1">
                <p class="font-heading text-xs font-bold text-primary-button">Pesanan Baru Masuk!</p>
                <p class="font-sub text-xs font-bold text-text-primary mt-0.5" x-text="`Pesanan ${toast.display_number} • ${toast.location}`"></p>
                <p class="font-body text-[11px] text-text-muted" x-text="`${toast.total_formatted} (${toast.time})`"></p>
                <a
                    :href="toast.url"
                    class="inline-block mt-2 font-sub text-[11px] font-bold text-maroon hover:underline"
                >
                    Buka Detail Pesanan &rarr;
                </a>
            </div>
            <button
                type="button"
                @click="toast = null"
                class="text-text-muted hover:text-text-primary text-xs font-bold p-1 cursor-pointer"
                aria-label="Tutup notifikasi"
            >
                ✕
            </button>
        </div>
    </template>
</div>
