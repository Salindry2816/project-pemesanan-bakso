<div wire:poll.5s.visible class="space-y-6 md:space-y-8">
    {{-- 4 Stat Cards --}}
    <div class="grid grid-cols-2 lg:grid-cols-4 gap-3.5 md:gap-5">
        {{-- Stat 1: Pesanan Baru --}}
        <x-card padding="p-3.5 md:p-5" radius="rounded-[14px] md:rounded-[16px]" class="flex items-center gap-3 md:gap-4">
            <div class="w-9 h-9 md:w-12 md:h-12 rounded-[8px] md:rounded-[12px] bg-status-diterima/15 text-status-diterima flex items-center justify-center shrink-0">
                <svg class="w-5 h-5 md:w-6 md:h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <rect x="5" y="4" width="14" height="17" rx="3"/>
                    <path d="M9 4V3h6v1M9 11h6M9 15h4"/>
                </svg>
            </div>
            <div class="min-w-0">
                <p class="font-sub text-[11px] md:text-[13px] font-semibold text-[#9CA3AF] truncate">Pesanan Baru</p>
                <p class="font-heading text-[22px] md:text-[32px] font-bold text-text-primary leading-tight">{{ $pesananBaruCount }}</p>
            </div>
        </x-card>

        {{-- Stat 2: Dalam Proses --}}
        <x-card padding="p-3.5 md:p-5" radius="rounded-[14px] md:rounded-[16px]" class="flex items-center gap-3 md:gap-4">
            <div class="w-9 h-9 md:w-12 md:h-12 rounded-[8px] md:rounded-[12px] bg-green-dark/15 text-green-dark flex items-center justify-center shrink-0">
                <svg class="w-5 h-5 md:w-6 md:h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <circle cx="12" cy="12" r="9"/>
                    <path d="M12 7v5l3 2"/>
                </svg>
            </div>
            <div class="min-w-0">
                <p class="font-sub text-[11px] md:text-[13px] font-semibold text-[#9CA3AF] truncate">Dalam Proses</p>
                <p class="font-heading text-[22px] md:text-[32px] font-bold text-text-primary leading-tight">{{ $dalamProsesCount }}</p>
            </div>
        </x-card>

        {{-- Stat 3: Siap Diantar --}}
        <x-card padding="p-3.5 md:p-5" radius="rounded-[14px] md:rounded-[16px]" class="flex items-center gap-3 md:gap-4">
            <div class="w-9 h-9 md:w-12 md:h-12 rounded-[8px] md:rounded-[12px] bg-primary-button/15 text-primary-button flex items-center justify-center shrink-0">
                <svg class="w-5 h-5 md:w-6 md:h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <rect x="5" y="4" width="14" height="17" rx="3"/>
                    <path d="M9 4V3h6v1M9 11h6M9 15h4"/>
                </svg>
            </div>
            <div class="min-w-0">
                <p class="font-sub text-[11px] md:text-[13px] font-semibold text-[#9CA3AF] truncate">Siap Diantar</p>
                <p class="font-heading text-[22px] md:text-[32px] font-bold text-text-primary leading-tight">{{ $siapDiantarCount }}</p>
            </div>
        </x-card>

        {{-- Stat 4: Selesai Hari Ini --}}
        <x-card padding="p-3.5 md:p-5" radius="rounded-[14px] md:rounded-[16px]" class="flex items-center gap-3 md:gap-4">
            <div class="w-9 h-9 md:w-12 md:h-12 rounded-[8px] md:rounded-[12px] bg-green-dark/15 text-green-dark flex items-center justify-center shrink-0">
                <svg class="w-5 h-5 md:w-6 md:h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                    <path d="M5 12l5 5 9-10"/>
                </svg>
            </div>
            <div class="min-w-0">
                <p class="font-sub text-[11px] md:text-[13px] font-semibold text-[#9CA3AF] truncate">Selesai Hari Ini</p>
                <p class="font-heading text-[22px] md:text-[32px] font-bold text-text-primary leading-tight">{{ $selesaiHariIniCount }}</p>
            </div>
        </x-card>
    </div>

    {{-- Filter & Search --}}
    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div class="flex flex-wrap items-center gap-2">
            @foreach ([
                'aktif' => 'Aktif',
                'semua' => 'Semua',
                'diterima' => 'Diterima',
                'diproses' => 'Diproses',
                'disiapkan' => 'Disiapkan',
                'siap' => 'Siap Diantar',
                'selesai' => 'Selesai',
                'dibatalkan' => 'Dibatalkan',
            ] as $key => $label)
                <button
                    type="button"
                    wire:click="setFilter('{{ $key }}')"
                    class="min-h-[38px] px-3.5 rounded-pill font-sub text-xs font-bold transition-colors cursor-pointer {{ $statusFilter === $key ? 'bg-maroon text-white' : 'bg-white text-text-muted border border-border-card hover:text-text-primary' }}"
                >
                    {{ $label }}
                </button>
            @endforeach
        </div>

        <div class="flex items-center gap-3 w-full lg:w-auto">
            <input
                type="search"
                wire:model.live.debounce.300ms="search"
                placeholder="Cari nomor, HP, atau meja..."
                aria-label="Cari pesanan"
                class="w-full lg:w-64 min-h-[42px] px-3.5 rounded-[12px] bg-white border border-border-card font-body text-xs md:text-sm text-text-primary placeholder-text-muted/60 focus:outline-none focus:ring-2 focus:ring-maroon/20 focus:border-maroon"
            />
            <a
                href="{{ route('admin.orders.index') }}"
                class="inline-flex items-center justify-center min-h-[42px] px-4 rounded-[12px] bg-white border border-border-card font-sub text-xs font-bold text-maroon hover:bg-cream transition-colors shrink-0"
            >
                Semua Pesanan
            </a>
        </div>
    </div>

    {{-- Orders List --}}
    @if ($orders->isEmpty())
        <x-card padding="p-6 md:p-8" radius="rounded-[16px]" class="text-center space-y-2">
            <p class="font-heading text-base font-bold text-text-primary">
                Belum ada pesanan
            </p>
            <p class="font-body text-xs md:text-sm text-text-muted">
                Tidak ada pesanan yang cocok dengan filter saat ini.
            </p>
        </x-card>
    @else
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            @foreach ($orders as $order)
                <a
                    href="{{ route('admin.orders.show', $order) }}"
                    wire:key="admin-order-{{ $order->id }}"
                    class="block p-5 rounded-[16px] bg-white border border-border-card shadow-sm hover:border-maroon/50 transition-colors space-y-3"
                >
                    <div class="flex items-start justify-between gap-3">
                        <div>
                            <p class="font-heading text-base md:text-lg font-bold text-text-primary">
                                {{ $order->display_number }}
                            </p>
                            <p class="font-sub text-xs text-text-muted">
                                {{ $order->created_at?->format('d M Y, H:i') }} · {{ $order->customer?->phone ?? '-' }}
                            </p>
                        </div>

                        <div class="flex flex-wrap items-center justify-end gap-1.5">
                            <span class="inline-flex items-center px-2.5 py-1 rounded-pill font-sub text-[11px] font-bold {{ $order->status->badgeClass() }}">
                                {{ $order->status->label() }}
                            </span>
                            <span class="inline-flex items-center px-2.5 py-1 rounded-pill font-sub text-[11px] font-bold {{ $order->payment_status->value === 'lunas' ? 'bg-green-dark text-white' : 'bg-cream text-text-primary border border-border-card' }}">
                                {{ $order->payment_status->label() }}
                            </span>
                        </div>
                    </div>

                    <div class="text-xs font-sub text-text-muted flex flex-wrap items-center gap-2">
                        <span class="px-2 py-0.5 rounded-[6px] bg-cream text-text-primary font-semibold">
                            @if ($order->type->value === 'take_away')
                                Bungkus (Take Away)
                            @elseif ($order->table)
                                Meja {{ $order->table->code }}
                            @endif
                        </span>
                        <span>{{ $order->payment_method->label() }}</span>
                        <span>· {{ $order->items->sum('qty') }} item</span>
                    </div>

                    <div class="pt-2 border-t border-border-card/60 flex items-center justify-between gap-3">
                        <p class="font-heading text-sm md:text-base font-bold text-primary-button">
                            Rp {{ number_format($order->total, 0, ',', '.') }}
                        </p>
                        <span class="font-sub text-xs text-text-muted">
                            {{ $order->items->take(2)->map(fn ($i) => $i->qty.'x '.$i->name_snapshot)->implode(', ') }}
                        </span>
                    </div>
                </a>
            @endforeach
        </div>
    @endif
</div>
