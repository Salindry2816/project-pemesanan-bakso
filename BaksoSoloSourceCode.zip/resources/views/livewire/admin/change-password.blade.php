<div class="max-w-xl space-y-6">
    <div>
        <h1 class="font-heading text-2xl font-bold text-text-primary">
            Ganti Password Admin
        </h1>
        <p class="font-body text-xs md:text-sm text-text-muted mt-1">
            Perbarui kata sandi akun penjual. Gunakan minimal 8 karakter yang kuat.
        </p>
    </div>

    @if ($statusMessage)
        <div role="status" class="p-4 rounded-[12px] bg-green-dark/10 border border-green-dark/30 text-green-dark font-sub text-xs md:text-sm font-semibold">
            {{ $statusMessage }}
        </div>
    @endif

    <x-card padding="p-5 md:p-6" radius="rounded-[16px]">
        <form wire:submit="updatePassword" class="space-y-4">
            <div>
                <label for="current-password" class="block font-sub text-xs font-bold text-text-primary mb-1.5">
                    Password Saat Ini
                </label>
                <input
                    id="current-password"
                    type="password"
                    wire:model="currentPassword"
                    autocomplete="current-password"
                    class="w-full min-h-[44px] px-3.5 rounded-[12px] bg-white border border-border-card font-body text-sm text-text-primary focus:outline-none focus:ring-2 focus:ring-maroon/20 focus:border-maroon"
                />
                @error('currentPassword')
                    <p class="mt-1 font-sub text-xs text-status-dibatalkan font-medium">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="new-password" class="block font-sub text-xs font-bold text-text-primary mb-1.5">
                    Password Baru
                </label>
                <input
                    id="new-password"
                    type="password"
                    wire:model="newPassword"
                    autocomplete="new-password"
                    class="w-full min-h-[44px] px-3.5 rounded-[12px] bg-white border border-border-card font-body text-sm text-text-primary focus:outline-none focus:ring-2 focus:ring-maroon/20 focus:border-maroon"
                />
                @error('newPassword')
                    <p class="mt-1 font-sub text-xs text-status-dibatalkan font-medium">{{ $message }}</p>
                @enderror
            </div>

            <div>
                <label for="new-password-confirmation" class="block font-sub text-xs font-bold text-text-primary mb-1.5">
                    Konfirmasi Password Baru
                </label>
                <input
                    id="new-password-confirmation"
                    type="password"
                    wire:model="newPasswordConfirmation"
                    autocomplete="new-password"
                    class="w-full min-h-[44px] px-3.5 rounded-[12px] bg-white border border-border-card font-body text-sm text-text-primary focus:outline-none focus:ring-2 focus:ring-maroon/20 focus:border-maroon"
                />
                @error('newPasswordConfirmation')
                    <p class="mt-1 font-sub text-xs text-status-dibatalkan font-medium">{{ $message }}</p>
                @enderror
            </div>

            <div class="pt-2">
                <button
                    type="submit"
                    wire:loading.attr="disabled"
                    class="min-h-[48px] px-6 rounded-[12px] bg-primary-button text-white font-sub text-sm font-bold hover:opacity-90 disabled:opacity-60 transition-opacity cursor-pointer"
                >
                    <span wire:loading.remove wire:target="updatePassword">Simpan Password Baru</span>
                    <span wire:loading wire:target="updatePassword">Menyimpan...</span>
                </button>
            </div>
        </form>
    </x-card>
</div>
