<div class="w-full max-w-5xl mx-auto py-2 md:py-6 space-y-5">
    {{-- Error Banner / Alert --}}
    @if ($errorMessage)
        <div
            role="alert"
            class="p-4 rounded-[14px] bg-primary-button/10 border border-primary-button/30 text-primary-button font-sub text-xs md:text-sm font-semibold flex items-center justify-between gap-3 shadow-xs"
        >
            <div class="flex items-center gap-2.5">
                <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                <span>{{ $errorMessage }}</span>
            </div>
            <button
                type="button"
                wire:click="$set('errorMessage', null)"
                class="text-primary-button hover:opacity-70 p-1 cursor-pointer"
                aria-label="Tutup pemberitahuan"
            >
                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
            </button>
        </div>
    @endif

    {{-- Page Header --}}
    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
            <h1 class="font-heading text-2xl md:text-3xl font-bold text-text-primary">
                Menu Bakso
            </h1>
            <p class="font-body text-xs md:text-sm text-text-muted mt-0.5">
                Pilih menu lezat khas Solo untuk pesananmu.
            </p>
        </div>

        @if ($tableBadge)
            <div class="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-[12px] bg-white border border-border-card shadow-xs self-start sm:self-auto">
                <span class="font-sub text-xs text-text-muted">Pesanan:</span>
                <span class="font-heading font-bold text-xs md:text-sm text-maroon">{{ $tableBadge }}</span>
                <span class="text-text-muted/40">&bull;</span>
                <a
                    href="{{ route('customer.table') }}"
                    class="font-sub text-xs font-bold text-primary-button hover:underline cursor-pointer"
                    title="Ganti meja atau opsi bungkus"
                >
                    Ganti meja
                </a>
            </div>
        @endif
    </div>

    {{-- Category Filter Chips (Semua + categories with at least 1 menu) --}}
    <div class="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none" role="tablist" aria-label="Kategori Menu">
        <button
            type="button"
            wire:click="selectCategory(null)"
            role="tab"
            aria-selected="{{ $selectedCategoryId === null ? 'true' : 'false' }}"
            class="min-h-[38px] px-4 rounded-full font-sub text-xs md:text-sm font-bold transition-all cursor-pointer shrink-0 {{ $selectedCategoryId === null ? 'bg-primary-button text-white shadow-xs' : 'bg-white border border-border-card text-text-primary hover:bg-cream/60' }}"
        >
            Semua
        </button>

        @foreach ($categories as $cat)
            <button
                type="button"
                wire:key="category-chip-{{ $cat->id }}"
                wire:click="selectCategory({{ $cat->id }})"
                role="tab"
                aria-selected="{{ $selectedCategoryId === $cat->id ? 'true' : 'false' }}"
                class="min-h-[38px] px-4 rounded-full font-sub text-xs md:text-sm font-bold transition-all cursor-pointer shrink-0 {{ $selectedCategoryId === $cat->id ? 'bg-primary-button text-white shadow-xs' : 'bg-white border border-border-card text-text-primary hover:bg-cream/60' }}"
            >
                {{ $cat->name }}
            </button>
        @endforeach
    </div>

    {{-- Menu Grid --}}
    @if ($menus->isEmpty())
        <div class="p-8 md:p-12 rounded-[20px] bg-white border border-border-card shadow-card text-center my-6">
            <p class="font-sub text-sm md:text-base text-text-muted">
                {{ $selectedCategoryId === null ? 'Menu belum tersedia.' : 'Belum ada menu di kategori ini.' }}
            </p>
        </div>
    @else
        <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3 md:gap-5">
            @foreach ($menus as $m)
                @php
                    $isAvailable = (bool) $m->is_available;
                    $qtyInCart = isset($cartLines[$m->id]) ? (int) $cartLines[$m->id]['qty'] : 0;
                    $photoUrl = $m->photo_path ? \App\Support\MediaStorage::url($m->photo_path) : null;
                @endphp

                <div
                    wire:key="menu-card-{{ $m->id }}"
                    class="rounded-[16px] border border-border-card shadow-card overflow-hidden flex flex-col justify-between transition-all {{ $isAvailable ? 'bg-white hover:border-maroon/40' : 'bg-white/80 opacity-75' }}"
                >
                    <div>
                        {{-- Photo Section --}}
                        <div class="aspect-[4/3] rounded-[12px] bg-[#D9D9D9] overflow-hidden relative m-2 border border-border-card/40">
                            @if ($photoUrl)
                                <img
                                    src="{{ $photoUrl }}"
                                    alt="{{ $m->name }}"
                                    loading="lazy"
                                    class="w-full h-full object-cover {{ $isAvailable ? '' : 'grayscale' }}"
                                />
                            @else
                                <div class="w-full h-full flex items-center justify-center font-sub text-[11px] font-semibold text-[#6B6B6B]">
                                    FOTO MENU
                                </div>
                            @endif

                            @if (! $isAvailable)
                                <div class="absolute inset-0 bg-black/30 flex items-center justify-center">
                                    <span class="px-2.5 py-1 rounded-pill bg-[#C62828] text-white font-sub text-[11px] font-bold shadow-xs">
                                        Habis
                                    </span>
                                </div>
                            @endif
                        </div>

                        {{-- Info Section --}}
                        <div class="px-2.5 pt-1">
                            <h2 class="font-heading text-xs md:text-sm font-bold text-text-primary leading-snug line-clamp-2">
                                {{ $m->name }}
                            </h2>

                            @if (! empty(trim((string) $m->description)))
                                <p class="font-body text-[10px] md:text-xs text-text-muted line-clamp-2 mt-0.5 leading-tight">
                                    {{ $m->description }}
                                </p>
                            @endif
                        </div>
                    </div>

                    {{-- Price & Action Bar --}}
                    <div class="flex items-center justify-between p-2.5 pt-2 mt-1">
                        <span class="font-heading font-bold text-xs md:text-sm text-maroon">
                            Rp {{ number_format($m->price, 0, ',', '.') }}
                        </span>

                        @if (! $isAvailable)
                            <button
                                type="button"
                                disabled
                                aria-label="{{ $m->name }} habis"
                                class="w-11 h-11 rounded-full bg-gray-200 text-gray-400 flex items-center justify-center cursor-not-allowed opacity-60"
                            >
                                <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 5v14M5 12h14"/></svg>
                            </button>
                        @elseif ($qtyInCart === 0)
                            <button
                                type="button"
                                wire:click="addToCart({{ $m->id }})"
                                wire:loading.attr="disabled"
                                aria-label="Tambah {{ $m->name }} ke keranjang"
                                class="w-11 h-11 rounded-full bg-maroon hover:bg-maroon/90 text-white flex items-center justify-center shadow-xs cursor-pointer transition-transform active:scale-95 disabled:opacity-50"
                            >
                                <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
                            </button>
                        @else
                            <div class="inline-flex items-center gap-1.5 p-1 rounded-full bg-cream border border-border-card">
                                <button
                                    type="button"
                                    wire:click="decrementQty({{ $m->id }})"
                                    wire:loading.attr="disabled"
                                    aria-label="Kurangi {{ $m->name }}"
                                    class="w-9 h-9 rounded-full flex items-center justify-center bg-white text-maroon border border-border-card hover:bg-cream transition-colors cursor-pointer disabled:opacity-50"
                                >
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14"/></svg>
                                </button>

                                <span class="font-heading font-bold text-xs md:text-sm text-maroon min-w-[20px] text-center">
                                    {{ $qtyInCart }}
                                </span>

                                <button
                                    type="button"
                                    wire:click="incrementQty({{ $m->id }})"
                                    wire:loading.attr="disabled"
                                    @disabled($qtyInCart >= 20)
                                    aria-label="Tambah {{ $m->name }}"
                                    class="w-9 h-9 rounded-full flex items-center justify-center bg-maroon text-white hover:bg-maroon/90 transition-colors cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                                >
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
                                </button>
                            </div>
                        @endif
                    </div>
                </div>
            @endforeach
        </div>
    @endif

    {{-- Floating Cart Bar (Sticky bottom above mobile nav, sticky floating on desktop) --}}
    @if ($cartCount > 0)
        <div class="fixed bottom-[84px] md:bottom-8 left-0 right-0 z-40 px-4 pointer-events-none">
            <div class="max-w-md md:max-w-2xl mx-auto pointer-events-auto">
                <div class="flex items-center justify-between p-3.5 md:p-4 rounded-[16px] bg-maroon text-white shadow-xl border border-maroon/20">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-full bg-white/15 flex items-center justify-center font-heading font-bold text-sm">
                            {{ $cartCount }}
                        </div>
                        <div>
                            <p class="font-sub text-[11px] text-white/80 uppercase font-semibold">Total Pesanan</p>
                            <p class="font-heading text-base md:text-lg font-bold">
                                Rp {{ number_format($cartSummary->total, 0, ',', '.') }}
                            </p>
                        </div>
                    </div>

                    <a
                        href="{{ route('customer.cart') }}"
                        class="inline-flex items-center justify-center min-h-[44px] px-5 rounded-[12px] bg-white text-maroon hover:bg-cream font-sub text-xs md:text-sm font-bold shadow-xs transition-colors cursor-pointer"
                    >
                        <span>Lihat Keranjang</span>
                        <span class="ml-1">&rarr;</span>
                    </a>
                </div>
            </div>
        </div>
    @endif
</div>
