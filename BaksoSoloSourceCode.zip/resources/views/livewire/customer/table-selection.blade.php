<div class="w-full max-w-4xl mx-auto py-2 md:py-6">
    {{-- Header --}}
    <div class="mb-6">
        <h1 class="font-heading text-2xl md:text-3xl font-bold text-text-primary">
            Pilih Meja
        </h1>
        <p class="font-body text-xs md:text-sm text-text-muted mt-1">
            Pilih nomor meja dan lantai tempat kamu duduk, atau pilih opsi bungkus.
        </p>
    </div>

    {{-- Error Alert --}}
    @error('table')
        <div role="alert" class="mb-5 p-4 rounded-[12px] bg-primary-button/10 border border-primary-button/30 text-primary-button font-sub text-xs md:text-sm font-semibold flex items-center gap-2">
            <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            <span>{{ $message }}</span>
        </div>
    @enderror

    {{-- Order Type Switcher (Dine In vs Take Away) --}}
    <div class="grid grid-cols-2 gap-3 mb-6">
        <button
            type="button"
            wire:click="$set('orderType', 'dine_in')"
            class="flex items-center justify-center gap-2.5 min-h-[52px] px-4 rounded-[14px] border-2 font-sub text-xs md:text-sm font-bold transition-all cursor-pointer {{ $orderType === 'dine_in' ? 'bg-cream border-maroon text-maroon shadow-xs' : 'bg-white border-border-card text-text-muted hover:border-maroon/40' }}"
        >
            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 2v7c0 1.1.9 2 2 2h4a2 2 0 0 0 2-2V2M7 2v20M21 15V2v0a5 5 0 0 0-5 5v6c0 1.1.9 2 2 2h3Zm0 0v7"/></svg>
            <span>Makan di Tempat</span>
        </button>

        <button
            type="button"
            wire:click="selectTakeAway"
            class="flex items-center justify-center gap-2.5 min-h-[52px] px-4 rounded-[14px] border-2 font-sub text-xs md:text-sm font-bold transition-all cursor-pointer {{ $orderType === 'take_away' ? 'bg-cream border-maroon text-maroon shadow-xs' : 'bg-white border-border-card text-text-muted hover:border-maroon/40' }}"
        >
            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
            <span>Bungkus (Take Away)</span>
        </button>
    </div>

    @if ($orderType === 'take_away')
        {{-- Take Away Banner Card --}}
        <div class="p-6 md:p-8 rounded-[20px] bg-white border border-border-card shadow-card mb-6">
            <div class="flex items-start gap-4">
                <div class="w-12 h-12 rounded-full bg-cream border border-border-card flex items-center justify-center text-maroon shrink-0">
                    <svg class="w-6 h-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/></svg>
                </div>
                <div>
                    <h3 class="font-heading text-lg font-bold text-text-primary">Pesanan Dibungkus (Take Away)</h3>
                    <p class="font-body text-xs md:text-sm text-text-body mt-1 leading-relaxed">
                        Pesananmu akan dibungkus rapi dan dapat langsung diambil di etalase Warung Bu Susi (Kantin M Lt. 2 UNJ) saat status pesanan siap.
                    </p>
                </div>
            </div>
        </div>
    @else
        {{-- Dine In Floor Tabs & Tables --}}
        <div class="space-y-6">
            {{-- Floor Tabs (Only floors with active tables) --}}
            @if (count($availableFloors) > 1)
                <div class="flex items-center gap-2 overflow-x-auto pb-1" role="tablist">
                    @foreach ($availableFloors as $floor)
                        <button
                            type="button"
                            wire:click="selectFloor({{ $floor }})"
                            role="tab"
                            aria-selected="{{ $selectedFloor === $floor ? 'true' : 'false' }}"
                            class="min-h-[44px] px-5 rounded-[12px] font-sub text-xs md:text-sm font-bold transition-all cursor-pointer shrink-0 {{ $selectedFloor === $floor ? 'bg-primary-button text-white shadow-xs' : 'bg-white border border-border-card text-text-primary hover:bg-cream/60' }}"
                        >
                            Lantai {{ $floor }}{{ $floor === 2 ? ' (Lokasi Warung)' : '' }}
                        </button>
                    @endforeach
                </div>
            @endif

            {{-- Coded Tables Grid --}}
            <div class="p-5 md:p-7 rounded-[20px] bg-white border border-border-card shadow-card">
                <div class="flex items-center justify-between mb-4">
                    <h2 class="font-heading text-base md:text-lg font-bold text-text-primary">
                        Meja Berkode — Lantai {{ $selectedFloor }}
                    </h2>

                    {{-- Legenda Status --}}
                    <div class="flex items-center gap-3 font-sub text-[11px] md:text-xs">
                        <span class="inline-flex items-center gap-1.5 text-green-dark">
                            <span class="w-2.5 h-2.5 rounded-full bg-green-dark"></span>
                            Tersedia
                        </span>
                        <span class="inline-flex items-center gap-1.5 text-primary-button">
                            <span class="w-2.5 h-2.5 rounded-full bg-primary-button"></span>
                            Terisi
                        </span>
                        <span class="inline-flex items-center gap-1.5 text-table-dipilih font-bold">
                            <span class="w-2.5 h-2.5 rounded-full bg-table-dipilih"></span>
                            Dipilih
                        </span>
                    </div>
                </div>

                @if ($tables->isEmpty())
                    <div class="text-center py-8 text-text-muted">
                        <p class="font-sub text-sm">Tidak ada meja berkode aktif di Lantai {{ $selectedFloor }}.</p>
                    </div>
                @else
                    <div class="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-5 gap-3 md:gap-4">
                        @foreach ($tables as $t)
                            @php
                                $isOccupied = $t->isOccupied($currentCustomerId);
                                $isSelected = $selectedTableId === $t->id;
                            @endphp

                            <button
                                type="button"
                                wire:key="table-btn-{{ $t->id }}"
                                wire:click="selectTable({{ $t->id }})"
                                @disabled($isOccupied)
                                class="relative p-3.5 rounded-[16px] border-2 flex flex-col items-center justify-center min-h-[92px] transition-all text-center {{ $isSelected ? 'bg-[#FBE9D0] border-table-dipilih ring-2 ring-table-dipilih/30 shadow-xs cursor-pointer' : ($isOccupied ? 'bg-[#FBE3E3] border-table-terisi/40 opacity-80 cursor-not-allowed' : 'bg-white border-border-card hover:border-maroon/50 cursor-pointer') }}"
                            >
                                <span class="font-heading text-lg md:text-xl font-bold {{ $isSelected ? 'text-maroon' : ($isOccupied ? 'text-table-terisi' : 'text-text-primary') }}">
                                    {{ $t->code }}
                                </span>

                                <span class="font-sub text-[11px] mt-0.5 {{ $isSelected ? 'text-maroon font-bold' : ($isOccupied ? 'text-table-terisi' : 'text-text-muted') }}">
                                    {{ $t->capacity ? $t->capacity . ' kursi' : 'Bebas' }}
                                </span>

                                {{-- Badge status --}}
                                <span class="inline-block mt-1 px-2 py-0.5 rounded-pill font-sub text-[10px] font-bold {{ $isSelected ? 'bg-table-dipilih text-white' : ($isOccupied ? 'bg-table-terisi text-white' : 'bg-green-dark/10 text-green-dark') }}">
                                    {{ $isSelected ? 'Dipilih' : ($isOccupied ? 'Terisi' : 'Tersedia') }}
                                </span>
                            </button>
                        @endforeach
                    </div>
                @endif
            </div>

            {{-- Free Table ("Meja Bebas") Option --}}
            @if ($freeTable)
                @php
                    $isFreeSelected = $selectedTableId === $freeTable->id;
                @endphp

                <div class="p-5 md:p-6 rounded-[20px] bg-white border border-border-card shadow-card transition-all {{ $isFreeSelected ? 'ring-2 ring-table-dipilih/40 border-table-dipilih' : '' }}">
                    <div class="flex items-start justify-between gap-4">
                        <div class="flex items-start gap-3.5">
                            <div class="w-11 h-11 rounded-[12px] bg-cream border border-border-card flex items-center justify-center font-heading font-bold text-maroon text-base shrink-0">
                                BEBAS
                            </div>
                            <div>
                                <h3 class="font-heading text-base font-bold text-text-primary">
                                    Meja Bebas ({{ $freeTable->capacity ?? '22' }})
                                </h3>
                                <p class="font-body text-xs text-text-muted mt-0.5">
                                    Pilih opsi ini jika kamu duduk di luar deretan meja bernomor (contoh: di area bangku bebas atau depan tenant lain).
                                </p>
                            </div>
                        </div>

                        <button
                            type="button"
                            wire:click="selectTable({{ $freeTable->id }})"
                            class="min-h-[44px] px-4 rounded-[12px] font-sub text-xs font-bold transition-all cursor-pointer shrink-0 {{ $isFreeSelected ? 'bg-table-dipilih text-white shadow-xs' : 'bg-cream border border-border-card text-maroon hover:bg-cream/70' }}"
                        >
                            {{ $isFreeSelected ? 'Dipilih' : 'Pilih Meja Bebas' }}
                        </button>
                    </div>

                    {{-- Location Note Input for Free Table --}}
                    @if ($isFreeSelected)
                        <div class="mt-4 pt-4 border-t border-border-card space-y-2">
                            <label for="location-note" class="block font-sub text-xs md:text-[13px] font-bold text-text-primary">
                                Patokan Lokasi Duduk <span class="text-primary-button" aria-hidden="true">*</span>
                            </label>
                            <input
                                id="location-note"
                                type="text"
                                wire:model="locationNote"
                                placeholder="Contoh: Depan kasir kantin, baju biru, dekat tiang (3–100 karakter)"
                                maxlength="100"
                                class="w-full min-h-[48px] px-4 rounded-[12px] bg-white border {{ $errors->has('locationNote') ? 'border-primary-button ring-1 ring-primary-button/30' : 'border-border-input focus:border-maroon focus:ring-2 focus:ring-maroon/20' }} font-sub text-xs md:text-sm text-text-primary outline-none"
                            />
                            <p class="font-body text-[11px] text-text-muted">
                                Bantu kami mengantarkan pesanan ke tempatmu dengan patokan lokasi yang jelas.
                            </p>
                            @error('locationNote')
                                <p class="font-body text-xs text-primary-button" role="alert">
                                    {{ $message }}
                                </p>
                            @enderror
                        </div>
                    @endif
                </div>
            @endif
        </div>
    @endif

    {{-- Action Buttons --}}
    <div class="mt-8 space-y-3">
        <x-button
            type="button"
            wire:click="submit"
            variant="primary"
            class="w-full justify-center min-h-[52px] text-sm md:text-base font-bold shadow-sm"
        >
            <span wire:loading.remove wire:target="submit">
                {{ $orderType === 'take_away' ? 'Lanjutkan Pesanan (Bungkus)' : 'Simpan Meja' }} &rarr;
            </span>
            <span wire:loading wire:target="submit" class="inline-flex items-center gap-2">
                <svg class="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
                <span>Menyimpan...</span>
            </span>
        </x-button>

        <div class="flex items-center justify-center">
            <span class="font-sub text-xs text-text-muted">atau</span>
        </div>

        <button
            type="button"
            id="btn-lihat-denah"
            wire:click="toggleFloorMap"
            class="w-full flex items-center justify-center gap-2 min-h-[48px] px-4 rounded-[12px] bg-white border border-border-card text-text-body hover:bg-cream/50 transition-colors font-sub text-xs md:text-sm font-semibold cursor-pointer shadow-xs focus:ring-2 focus:ring-maroon focus:outline-none"
        >
            <svg class="w-4 h-4 text-maroon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18M9 21V9"/></svg>
            <span>Lihat Denah Meja (Lantai 2)</span>
        </button>
    </div>

    {{-- Floor 2 Map Modal (Per Figma Layout Meja Pelanggan di Lantai 2) --}}
    @if ($showFloorMap)
        <div
            x-data
            x-init="$el.focus()"
            tabindex="-1"
            @keydown.window.escape="$wire.closeFloorMap(); $nextTick(() => document.getElementById('btn-lihat-denah')?.focus())"
            class="fixed inset-0 z-50 overflow-y-auto bg-black/60 flex items-center justify-center p-4 backdrop-blur-xs outline-none"
            role="dialog"
            aria-modal="true"
            aria-labelledby="floor-map-title"
        >
            <div class="relative w-full max-w-3xl rounded-[24px] bg-white border border-border-card shadow-2xl p-6 md:p-8 space-y-5">
                {{-- Modal Header --}}
                <div class="flex items-center justify-between">
                    <div>
                        <h2 id="floor-map-title" class="font-heading text-lg md:text-xl font-bold text-text-primary">
                            Layout Meja Pelanggan di Lantai 2
                        </h2>
                        <p class="font-body text-xs text-text-muted mt-0.5">
                            Kantin M Lantai 2 UNJ — Warung Bakso Solo Bu Susi
                        </p>
                    </div>

                    <button
                        type="button"
                        wire:click="closeFloorMap"
                        @click="$nextTick(() => document.getElementById('btn-lihat-denah')?.focus())"
                        class="w-9 h-9 rounded-full bg-cream border border-border-card flex items-center justify-center text-text-muted hover:text-maroon transition-colors cursor-pointer"
                        aria-label="Tutup Denah"
                    >
                        <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
                    </button>
                </div>

                {{-- Map Panel (Green Mid Background per Figma) --}}
                <div class="rounded-[20px] bg-[#5A9158] p-4 md:p-6 text-white space-y-6 overflow-x-auto shadow-inner">
                    {{-- Row 1: Tenants Order (Tangga, Tenant 1, 2, 3, Bakso Solo, Tenant 5, 6, Kamar Mandi, Tangga Turunan — NO Tenant 4!) --}}
                    <div>
                        <p class="font-sub text-[11px] font-bold text-white/90 mb-2.5 uppercase tracking-wider">
                            Deretan Tenant Kantin
                        </p>
                        <div class="grid grid-cols-9 gap-1.5 md:gap-2 min-w-[620px]">
                            {{-- 1. Tangga --}}
                            <div class="h-24 md:h-28 rounded-[12px] bg-[#2F3F27] text-white flex flex-col items-center justify-center p-1 text-center border border-white/20">
                                <span class="font-heading text-[10px] md:text-xs font-bold leading-tight">TANGGA</span>
                            </div>

                            {{-- 2. Tenant 1 --}}
                            <div class="h-24 md:h-28 rounded-[12px] bg-[#EBCEB3] text-[#1C1B1F] flex flex-col items-center justify-center p-1 text-center border border-white/20">
                                <span class="font-heading text-[10px] md:text-xs font-bold leading-tight">TENANT 1</span>
                            </div>

                            {{-- 3. Tenant 2 --}}
                            <div class="h-24 md:h-28 rounded-[12px] bg-[#AE8884] text-white flex flex-col items-center justify-center p-1 text-center border border-white/20">
                                <span class="font-heading text-[10px] md:text-xs font-bold leading-tight">TENANT 2</span>
                            </div>

                            {{-- 4. Tenant 3 --}}
                            <div class="h-24 md:h-28 rounded-[12px] bg-[#A07F5F] text-white flex flex-col items-center justify-center p-1 text-center border border-white/20">
                                <span class="font-heading text-[10px] md:text-xs font-bold leading-tight">TENANT 3</span>
                            </div>

                            {{-- 5. Bakso Solo (Warung Bu Susi - Highlight) --}}
                            <div class="h-24 md:h-28 rounded-[12px] bg-white text-green-dark flex flex-col items-center justify-center p-1 text-center ring-2 ring-maroon shadow-md">
                                <span class="font-heading text-[11px] md:text-xs font-bold leading-tight text-maroon">BAKSO SOLO</span>
                                <span class="font-sub text-[9px] text-green-dark font-semibold mt-0.5">Bu Susi</span>
                            </div>

                            {{-- 6. Tenant 5 --}}
                            <div class="h-24 md:h-28 rounded-[12px] bg-[#D4967E] text-white flex flex-col items-center justify-center p-1 text-center border border-white/20">
                                <span class="font-heading text-[10px] md:text-xs font-bold leading-tight">TENANT 5</span>
                            </div>

                            {{-- 7. Tenant 6 --}}
                            <div class="h-24 md:h-28 rounded-[12px] bg-[#D77744] text-white flex flex-col items-center justify-center p-1 text-center border border-white/20">
                                <span class="font-heading text-[10px] md:text-xs font-bold leading-tight">TENANT 6</span>
                            </div>

                            {{-- 8. Kamar Mandi --}}
                            <div class="h-24 md:h-28 rounded-[12px] bg-[#7A1519] text-white flex flex-col items-center justify-center p-1 text-center border border-white/20">
                                <span class="font-heading text-[9px] md:text-[11px] font-bold leading-tight">KAMAR MANDI</span>
                            </div>

                            {{-- 9. Tangga Turunan --}}
                            <div class="h-24 md:h-28 rounded-[12px] bg-[#064E34] text-white flex flex-col items-center justify-center p-1 text-center border border-white/20">
                                <span class="font-heading text-[9px] md:text-[11px] font-bold leading-tight">TANGGA TURUNAN</span>
                            </div>
                        </div>
                    </div>

                    {{-- Row 2: Coded Tables (2A - 2G) & Meja Bebas --}}
                    <div>
                        <div class="flex items-center justify-between mb-2.5">
                            <p class="font-sub text-[11px] font-bold text-white/90 uppercase tracking-wider">
                                Posisi Meja Pelanggan
                            </p>
                            <span class="font-sub text-[10px] text-white/80">
                                Klik meja tersedia untuk memilih langsung
                            </span>
                        </div>

                        <div class="flex items-center gap-2.5 md:gap-3 overflow-x-auto pb-1 min-w-[620px]">
                            @foreach ($floor2Tables as $ft)
                                @php
                                    $isOccupied = $ft->isOccupied($currentCustomerId);
                                    $isSelected = $selectedTableId === $ft->id;
                                @endphp

                                <button
                                    type="button"
                                    wire:key="map-table-{{ $ft->id }}"
                                    wire:click="selectTable({{ $ft->id }})"
                                    @disabled($isOccupied)
                                    class="w-14 h-28 md:w-16 md:h-32 rounded-[16px] flex flex-col items-center justify-between p-2.5 border-2 transition-all {{ $isSelected ? 'bg-[#FBE9D0] border-table-dipilih ring-2 ring-table-dipilih text-maroon cursor-pointer' : ($isOccupied ? 'bg-[#FBE3E3] border-table-terisi text-table-terisi cursor-not-allowed opacity-80' : 'bg-white border-white text-green-dark hover:scale-105 cursor-pointer shadow-sm') }}"
                                >
                                    <span class="font-heading text-sm md:text-base font-bold">{{ $ft->code }}</span>
                                    <span class="font-sub text-[9px] uppercase font-bold px-1.5 py-0.5 rounded-full {{ $isSelected ? 'bg-table-dipilih text-white' : ($isOccupied ? 'bg-table-terisi text-white' : 'bg-green-dark text-white') }}">
                                        {{ $isSelected ? 'Dipilih' : ($isOccupied ? 'Terisi' : 'Ada') }}
                                    </span>
                                </button>
                            @endforeach

                            {{-- Meja Bebas Box --}}
                            @if ($freeTable)
                                @php
                                    $isFreeMapSelected = $selectedTableId === $freeTable->id;
                                @endphp
                                <button
                                    type="button"
                                    wire:click="selectTable({{ $freeTable->id }})"
                                    class="h-28 md:h-32 px-4 rounded-[16px] border-2 flex flex-col items-center justify-center gap-1 transition-all {{ $isFreeMapSelected ? 'bg-[#FBE9D0] border-table-dipilih text-maroon ring-2 ring-table-dipilih cursor-pointer' : 'bg-white border-white text-green-dark hover:scale-105 cursor-pointer shadow-sm' }}"
                                >
                                    <span class="font-heading text-xs md:text-sm font-bold text-center">Meja Bebas ({{ $freeTable->capacity ?? '22' }})</span>
                                    <span class="mt-1 px-2 py-0.5 rounded-pill font-sub text-[9px] font-bold {{ $isFreeMapSelected ? 'bg-table-dipilih text-white' : 'bg-green-dark text-white' }}">
                                        {{ $isFreeMapSelected ? 'Dipilih' : 'Pilih' }}
                                    </span>
                                </button>
                            @endif
                        </div>
                    </div>
                </div>

                {{-- Modal Footer --}}
                <div class="flex items-center justify-between pt-2">
                    <div class="flex items-center gap-3 font-sub text-xs">
                        <span class="inline-flex items-center gap-1 text-green-dark font-semibold">
                            <span class="w-2.5 h-2.5 rounded-full bg-green-dark"></span> Tersedia
                        </span>
                        <span class="inline-flex items-center gap-1 text-table-terisi font-semibold">
                            <span class="w-2.5 h-2.5 rounded-full bg-table-terisi"></span> Terisi
                        </span>
                        <span class="inline-flex items-center gap-1 text-table-dipilih font-bold">
                            <span class="w-2.5 h-2.5 rounded-full bg-table-dipilih"></span> Dipilih
                        </span>
                    </div>

                    <x-button
                        type="button"
                        wire:click="closeFloorMap"
                        @click="$nextTick(() => document.getElementById('btn-lihat-denah')?.focus())"
                        variant="primary"
                        class="min-h-[44px] px-6 text-xs md:text-sm"
                    >
                        Tutup Denah
                    </x-button>
                </div>
            </div>
        </div>
    @endif
</div>
