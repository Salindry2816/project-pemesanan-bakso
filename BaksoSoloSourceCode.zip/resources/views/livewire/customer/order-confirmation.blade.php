<div class="max-w-4xl mx-auto px-4 sm:px-6 py-6 md:py-8 space-y-6">
    <!-- Breadcrumb / Back Link -->
    <div class="flex items-center justify-between">
        <a
            href="{{ route('customer.cart') }}"
            class="inline-flex items-center gap-1.5 text-xs md:text-sm font-sub font-semibold text-text-muted hover:text-maroon transition-colors min-h-[44px]"
        >
            <span>&larr;</span>
            <span>Kembali ke Keranjang</span>
        </a>

        @if ($maskedPhone)
            <div class="inline-flex items-center gap-1.5 text-xs font-sub text-text-muted">
                <span>Pemesan:</span>
                <strong class="text-text-primary font-bold">{{ $maskedPhone }}</strong>
            </div>
        @endif
    </div>

    <!-- Page Title -->
    <div>
        <h1 class="font-heading text-2xl md:text-3xl font-bold text-text-primary">
            Konfirmasi Pesanan
        </h1>
        <p class="font-body text-xs md:text-sm text-text-muted mt-1">
            Periksa kembali detail pesanan sebelum melanjutkan ke pembayaran.
        </p>
    </div>

    <!-- Flash / Error Message Alert -->
    @if ($errorMessage)
        <div
            role="alert"
            class="p-4 rounded-[12px] bg-red-50 border border-red-200 text-status-dibatalkan text-xs md:text-sm font-sub font-medium flex items-center justify-between gap-3"
        >
            <div class="flex items-center gap-2">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                <span>{{ $errorMessage }}</span>
            </div>
            <button
                type="button"
                wire:click="$set('errorMessage', null)"
                class="min-h-[44px] min-w-[44px] inline-flex items-center justify-center text-status-dibatalkan hover:opacity-75 cursor-pointer"
                aria-label="Tutup pesan error"
            >
                &times;
            </button>
        </div>
    @endif

    <div class="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        <!-- Left Column: Type, Location, Note -->
        <div class="md:col-span-7 space-y-6">
            <!-- Tipe Pesanan Section -->
            <div class="p-5 md:p-6 rounded-[20px] bg-white border border-border-card shadow-sm space-y-4">
                <div class="flex items-center justify-between">
                    <h2 class="font-heading text-base font-bold text-text-primary">
                        Tipe Pesanan
                    </h2>
                    <a
                        href="{{ route('customer.table') }}"
                        class="text-maroon hover:underline font-sub text-xs font-semibold min-h-[44px] inline-flex items-center"
                    >
                        Ubah
                    </a>
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <div
                        class="p-4 rounded-[14px] border-2 flex flex-col justify-center min-h-[64px] {{ $orderType === 'dine_in' ? 'border-primary-button bg-cream' : 'border-border-card bg-white opacity-60' }}"
                    >
                        <p class="font-sub text-sm font-bold {{ $orderType === 'dine_in' ? 'text-primary-button' : 'text-text-muted' }}">
                            Makan di Tempat
                        </p>
                        <p class="font-sub text-xs {{ $orderType === 'dine_in' ? 'text-primary-button/80' : 'text-text-muted' }}">
                            (Dine-in)
                        </p>
                    </div>

                    <div
                        class="p-4 rounded-[14px] border-2 flex flex-col justify-center min-h-[64px] {{ $orderType === 'take_away' ? 'border-primary-button bg-cream' : 'border-border-card bg-white opacity-60' }}"
                    >
                        <p class="font-sub text-sm font-bold {{ $orderType === 'take_away' ? 'text-primary-button' : 'text-text-muted' }}">
                            Bungkus
                        </p>
                        <p class="font-sub text-xs {{ $orderType === 'take_away' ? 'text-primary-button/80' : 'text-text-muted' }}">
                            (Take Away)
                        </p>
                    </div>
                </div>
            </div>

            <!-- Lokasi Meja Section -->
            <div class="p-5 md:p-6 rounded-[20px] bg-white border border-border-card shadow-sm space-y-3">
                <div class="flex items-center justify-between">
                    <h2 class="font-heading text-base font-bold text-text-primary">
                        Lokasi Meja
                    </h2>
                    <a
                        href="{{ route('customer.table') }}"
                        class="text-maroon hover:underline font-sub text-xs font-semibold min-h-[44px] inline-flex items-center"
                    >
                        Ubah
                    </a>
                </div>

                <div class="flex items-center gap-3 p-3.5 rounded-[12px] bg-cream/50 border border-border-card">
                    <div class="w-10 h-10 rounded-full bg-cream border border-border-card flex items-center justify-center text-maroon flex-shrink-0">
                        <svg class="w-5 h-5 text-primary-button" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M12 21s-7-6-7-11a7 7 0 0114 0c0 5-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>
                        </svg>
                    </div>
                    <div class="min-w-0">
                        @if ($orderType === 'take_away')
                            <p class="font-sub text-sm font-bold text-text-primary">
                                Pesanan Dibungkus (Take Away)
                            </p>
                            <p class="font-body text-xs text-text-muted">
                                Ambil langsung di meja kasir warung.
                            </p>
                        @elseif ($table)
                            <p class="font-sub text-sm font-bold text-text-primary">
                                Lantai {{ $table->floor }} · Meja {{ $table->code }}
                            </p>
                            @if ($locationNote)
                                <p class="font-body text-xs text-text-muted truncate">
                                    Patokan: {{ $locationNote }}
                                </p>
                            @endif
                        @endif
                    </div>
                </div>
            </div>

            <!-- Catatan Pesanan Section -->
            <div class="p-5 md:p-6 rounded-[20px] bg-white border border-border-card shadow-sm space-y-3">
                <h2 class="font-heading text-base font-bold text-text-primary">
                    Catatan Pesanan
                </h2>
                <div>
                    <textarea
                        rows="3"
                        maxlength="200"
                        wire:model.blur="orderNote"
                        placeholder="Contoh: tanpa kecap, tambah bawang"
                        class="w-full p-3 rounded-[12px] border border-border-card text-xs md:text-sm font-body text-text-primary placeholder-text-muted/60 focus:outline-none focus:ring-2 focus:ring-maroon/20 focus:border-maroon"
                        aria-label="Catatan pesanan"
                    ></textarea>
                </div>
                <div class="flex items-center justify-between text-[11px] font-sub text-text-muted">
                    <span>
                        @error('orderNote')
                            <span class="text-status-dibatalkan font-medium">{{ $message }}</span>
                        @else
                            <span>Catatan umum untuk seluruh pesanan (opsional)</span>
                        @enderror
                    </span>
                    <span>
                        {{ mb_strlen($orderNote) }}/200
                    </span>
                </div>
            </div>
        </div>

        <!-- Right Column: Order Details & Total -->
        <div class="md:col-span-5 space-y-6">
            <div class="rounded-[20px] bg-white border border-border-card shadow-sm divide-y divide-border-card/60 overflow-hidden">
                <!-- Header -->
                <div class="p-4 md:p-5 bg-cream/40 flex items-center justify-between">
                    <h2 class="font-heading text-base font-bold text-text-primary">
                        Detail Pesanan
                    </h2>
                    <a
                        href="{{ route('customer.cart') }}"
                        class="text-maroon hover:underline font-sub text-xs font-semibold min-h-[44px] inline-flex items-center"
                    >
                        Ubah
                    </a>
                </div>

                <!-- Lines List -->
                <div class="p-4 md:p-5 space-y-4 max-h-[360px] overflow-y-auto divide-y divide-border-card/40">
                    @foreach ($summary->validLines as $line)
                        @php
                            $menu = $line['menu'];
                            $photoUrl = $menu->photo_path ? \App\Support\MediaStorage::url($menu->photo_path) : null;
                        @endphp
                        <div
                            wire:key="confirm-line-{{ $line['menu_id'] }}"
                            class="pt-3 first:pt-0 space-y-1.5"
                        >
                            <div class="flex items-start justify-between gap-3">
                                <div class="flex items-start gap-2.5 min-w-0">
                                    @if ($photoUrl)
                                        <img
                                            src="{{ $photoUrl }}"
                                            alt="{{ $menu->name }}"
                                            loading="lazy"
                                            class="w-11 h-11 rounded-[10px] object-cover bg-cream border border-border-card/60 flex-shrink-0"
                                        />
                                    @else
                                        <div class="w-11 h-11 rounded-[10px] bg-cream border border-border-card/60 flex items-center justify-center text-maroon flex-shrink-0">
                                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.8">
                                                <rect x="4" y="8" width="16" height="12" rx="3"/><path d="M8 8V6a4 4 0 018 0v2"/>
                                            </svg>
                                        </div>
                                    @endif
                                    <div class="min-w-0">
                                        <p class="font-heading font-semibold text-xs md:text-sm text-text-primary truncate">
                                            {{ $menu->name }}
                                        </p>
                                        <p class="font-body text-[11px] text-text-muted">
                                            {{ $line['qty'] }}x @ Rp {{ number_format($line['unit_price'], 0, ',', '.') }}
                                        </p>
                                    </div>
                                </div>

                                <div class="text-right flex-shrink-0">
                                    <p class="font-heading font-bold text-xs md:text-sm text-text-primary">
                                        Rp {{ number_format($line['line_total'], 0, ',', '.') }}
                                    </p>
                                </div>
                            </div>

                            @if (! empty($line['item_note']))
                                <p class="font-body text-[11px] text-text-muted italic bg-cream/40 px-2.5 py-1 rounded-[6px]">
                                    Catatan: {{ $line['item_note'] }}
                                </p>
                            @endif
                        </div>
                    @endforeach
                </div>

                <!-- Total and Payment Action -->
                <div class="p-4 md:p-5 bg-cream/30 space-y-4">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="font-sub text-xs uppercase tracking-wider font-bold text-text-muted">
                                Total Pembayaran
                            </p>
                            <p class="font-heading text-xl md:text-2xl font-bold text-primary-button">
                                Rp {{ number_format($summary->total, 0, ',', '.') }}
                            </p>
                        </div>
                        <span class="font-sub text-xs text-text-muted">
                            {{ count($summary->validLines) }} menu
                        </span>
                    </div>

                    <!-- Payment Method Selection -->
                    <div class="pt-2 space-y-3">
                        <p class="font-heading text-sm font-bold text-text-primary">
                            Metode Pembayaran
                        </p>

                        <div class="space-y-2.5">
                            <label
                                class="flex items-start gap-3 p-3.5 rounded-[14px] border-2 cursor-pointer transition-colors {{ $paymentMethod === 'cash' ? 'border-primary-button bg-cream' : 'border-border-card bg-white hover:border-maroon/40' }}"
                            >
                                <input
                                    type="radio"
                                    name="paymentMethod"
                                    value="cash"
                                    wire:model.live="paymentMethod"
                                    class="mt-1 accent-maroon"
                                />
                                <div class="min-w-0">
                                    <p class="font-sub text-sm font-bold text-text-primary">
                                        Bayar di Kasir (Tunai)
                                    </p>
                                    <p class="font-body text-xs text-text-muted">
                                        Lakukan pembayaran tunai langsung ke kasir warung.
                                    </p>
                                </div>
                            </label>

                            <label
                                class="flex items-start gap-3 p-3.5 rounded-[14px] border-2 transition-colors {{ $qrisAvailable ? ($paymentMethod === 'qris' ? 'border-primary-button bg-cream cursor-pointer' : 'border-border-card bg-white hover:border-maroon/40 cursor-pointer') : 'border-border-card bg-gray-100 opacity-60 cursor-not-allowed' }}"
                            >
                                <input
                                    type="radio"
                                    name="paymentMethod"
                                    value="qris"
                                    wire:model.live="paymentMethod"
                                    @disabled(! $qrisAvailable)
                                    class="mt-1 accent-maroon"
                                />
                                <div class="min-w-0">
                                    <p class="font-sub text-sm font-bold text-text-primary">
                                        QRIS
                                    </p>
                                    @if ($qrisAvailable)
                                        <p class="font-body text-xs text-text-muted">
                                            Scan kode QRIS warung setelah pesanan dibuat.
                                        </p>
                                    @else
                                        <p class="font-body text-xs text-status-dibatalkan">
                                            QRIS belum tersedia (kode QR belum diunggah penjual).
                                        </p>
                                    @endif
                                </div>
                            </label>
                        </div>

                        @error('paymentMethod')
                            <p class="font-sub text-xs text-status-dibatalkan font-medium">
                                {{ $message }}
                            </p>
                        @enderror

                        <button
                            type="button"
                            wire:click="openConfirmDialog"
                            wire:loading.attr="disabled"
                            class="flex items-center justify-center min-h-[52px] w-full px-6 rounded-[12px] bg-primary-button text-white font-sub text-sm md:text-base font-bold hover:opacity-90 disabled:opacity-60 transition-opacity cursor-pointer shadow-xs"
                        >
                            <span wire:loading.remove wire:target="openConfirmDialog">Buat Pesanan</span>
                            <span wire:loading wire:target="openConfirmDialog">Memeriksa...</span>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @if ($showConfirmDialog)
        <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="confirm-order-dialog-title"
            class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
        >
            <div class="w-full max-w-md rounded-[20px] bg-white border border-border-card shadow-lg p-6 space-y-5">
                <div class="space-y-2 text-center">
                    <h2 id="confirm-order-dialog-title" class="font-heading text-xl font-bold text-text-primary">
                        Kirim pesanan?
                    </h2>
                    <p class="font-body text-xs md:text-sm text-text-muted">
                        Pesanan senilai <strong class="text-text-primary">Rp {{ number_format($summary->total, 0, ',', '.') }}</strong>
                        dengan metode pembayaran <strong class="text-text-primary">{{ $paymentMethod === 'qris' ? 'QRIS' : 'Bayar di Kasir (Tunai)' }}</strong>
                        akan dikirim ke dapur.
                    </p>
                </div>

                <div class="flex flex-col sm:flex-row gap-3">
                    <button
                        type="button"
                        wire:click="cancelConfirmDialog"
                        wire:loading.attr="disabled"
                        wire:target="placeOrder"
                        class="flex-1 min-h-[48px] px-4 rounded-[12px] border border-border-card bg-white text-text-primary font-sub text-sm font-bold hover:bg-cream transition-colors cursor-pointer"
                    >
                        Tidak, Batalkan
                    </button>
                    <button
                        type="button"
                        wire:click="placeOrder"
                        wire:loading.attr="disabled"
                        wire:target="placeOrder"
                        class="flex-1 min-h-[48px] px-4 rounded-[12px] bg-primary-button text-white font-sub text-sm font-bold hover:opacity-90 disabled:opacity-60 transition-opacity cursor-pointer"
                    >
                        <span wire:loading.remove wire:target="placeOrder">Ya, Kirim Pesanan</span>
                        <span wire:loading wire:target="placeOrder">Mengirim...</span>
                    </button>
                </div>
            </div>
        </div>
    @endif
</div>
