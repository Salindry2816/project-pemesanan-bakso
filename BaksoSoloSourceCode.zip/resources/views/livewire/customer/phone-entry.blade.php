<div class="w-full max-w-4xl mx-auto py-4 md:py-10">
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12 items-center">
        {{-- Desktop Left Hero Column (Rich Photo Backdrop + Animated 2D Steam Bowl) --}}
        <div class="hidden md:flex relative overflow-hidden flex-col justify-between gap-6 p-8 rounded-[24px] border border-maroon/20 shadow-card text-white min-h-[430px] bg-maroon">
            <img
                src="/images/hero-bakso.jpg"
                alt=""
                aria-hidden="true"
                class="absolute inset-0 w-full h-full object-cover opacity-35 scale-105"
            />
            <div
                class="absolute inset-0"
                style="background: linear-gradient(135deg, rgba(61, 18, 16, 0.9), rgba(120, 42, 37, 0.85), rgba(42, 13, 11, 0.95));"
            ></div>

            <div class="relative z-10 flex items-center gap-4">
                <div class="w-16 h-16 rounded-full bg-white flex items-center justify-center font-sub text-base font-bold text-[#6B6B6B] overflow-hidden border-2 border-accent-yellow/80 shadow-md shrink-0">
                    @if ($businessLogoUrl)
                        <img src="{{ $businessLogoUrl }}" alt="Logo {{ $businessName }}" class="w-full h-full object-cover">
                    @else
                        LOGO
                    @endif
                </div>
                <div>
                    <h2 class="font-heading text-2xl font-bold text-cream leading-tight">{{ $businessName }}</h2>
                    <p class="font-sub text-sm font-semibold text-accent-yellow">{{ $businessTagline }}</p>
                </div>
            </div>

            <div class="relative z-10 flex items-center justify-between gap-4 my-1">
                <p class="font-body text-sm text-cream/90 leading-relaxed">
                    Pesan hidangan bakso hangat dan minuman segar langsung dari mejamu di Kantin M Lt. 2 UNJ. Cukup masukkan nomor handphone untuk mulai memilih meja dan menu favorit.
                </p>
                <div class="shrink-0">
                    <x-bakso-bowl-illustration sizeClass="w-28 h-28" steamColor="#FFFBEA" />
                </div>
            </div>

            <div class="relative z-10 space-y-3 pt-4 border-t border-white/15">
                <div class="flex items-center gap-3 text-xs font-sub font-semibold text-cream/95">
                    <span class="w-7 h-7 rounded-full bg-white/15 text-accent-yellow flex items-center justify-center shrink-0">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                    </span>
                    <span>Makan di tempat (Lantai 1–4 & Meja Bebas)</span>
                </div>
                <div class="flex items-center gap-3 text-xs font-sub font-semibold text-cream/95">
                    <span class="w-7 h-7 rounded-full bg-white/15 text-accent-yellow flex items-center justify-center shrink-0">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                    </span>
                    <span>Bungkus (Take Away) praktis tanpa antre</span>
                </div>
                <div class="flex items-center gap-3 text-xs font-sub font-semibold text-cream/95">
                    <span class="w-7 h-7 rounded-full bg-white/15 text-accent-yellow flex items-center justify-center shrink-0">
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="20 6 9 17 4 12"/></svg>
                    </span>
                    <span>Privasi aman, nomor hanya untuk identifikasi pesanan</span>
                </div>
            </div>
        </div>

        {{-- Phone Entry Form (Mobile & Desktop Right Column) --}}
        <div class="w-full max-w-md mx-auto rounded-[24px] bg-white border border-border-card shadow-card overflow-hidden">
            {{-- Mobile Warm Photo Hero Header (Inspired by Divine Coffee + 2D Animated Bowl) --}}
            <div class="md:hidden relative px-6 pt-6 pb-5 text-center text-white bg-maroon overflow-hidden">
                <img
                    src="/images/hero-bakso.jpg"
                    alt=""
                    aria-hidden="true"
                    class="absolute inset-0 w-full h-full object-cover opacity-35"
                />
                <div
                    class="absolute inset-0"
                    style="background: linear-gradient(180deg, rgba(42, 13, 11, 0.85), rgba(120, 42, 37, 0.8), rgba(74, 23, 20, 0.95));"
                ></div>
                <div class="relative z-10 flex flex-col items-center">
                    <div class="flex items-center justify-center gap-3 mb-2">
                        <div class="w-14 h-14 rounded-full bg-white flex items-center justify-center font-sub text-xs font-bold text-[#6B6B6B] overflow-hidden border-2 border-accent-yellow shadow-md shrink-0">
                            @if ($businessLogoUrl)
                                <img src="{{ $businessLogoUrl }}" alt="Logo {{ $businessName }}" class="w-full h-full object-cover">
                            @else
                                LOGO
                            @endif
                        </div>
                        <x-bakso-bowl-illustration sizeClass="w-16 h-16" steamColor="#FFFBEA" />
                    </div>
                    <h1 class="font-heading text-xl font-bold text-cream leading-tight">{{ $businessName }}</h1>
                    <p class="font-sub text-xs font-semibold text-accent-yellow mt-0.5">{{ $businessTagline }}</p>
                </div>
            </div>

            <div class="p-6 md:p-8">

            {{-- Title & Subtitle --}}
            <div class="text-center md:text-left mb-6">
                <h2 class="font-heading text-xl md:text-2xl font-bold text-text-primary">
                    Selamat Datang!
                </h2>
                <p class="font-body text-xs md:text-sm text-text-muted mt-1.5 leading-relaxed">
                    Masukkan nomor handphone kamu untuk melanjutkan pemesanan di {{ $businessName }}.
                </p>
            </div>

            {{-- Phone Form --}}
            <form wire:submit="submit" class="space-y-4">
                <div>
                    <label for="phone-input" class="block font-sub text-xs md:text-[13px] font-bold text-text-primary mb-1.5">
                        Nomor Handphone <span class="text-primary-button" aria-hidden="true">*</span>
                    </label>

                    <div class="relative flex items-center rounded-[12px] bg-white border {{ $errors->has('phone') ? 'border-primary-button ring-1 ring-primary-button/30' : 'border-border-input focus-within:border-maroon focus-within:ring-2 focus-within:ring-maroon/20' }} transition-all">
                        {{-- Phone Icon --}}
                        <div class="pl-3.5 pr-2 text-text-body pointer-events-none">
                            <svg class="w-5 h-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                <path d="M5 4h4l2 5-2.5 1.5a11 11 0 005 5L15 13l5 2v4a2 2 0 01-2 2A16 16 0 013 6a2 2 0 012-2z"/>
                            </svg>
                        </div>

                        {{-- +62 Prefix --}}
                        <span class="font-sub text-xs md:text-sm font-bold text-text-primary pr-2 select-none">
                            +62
                        </span>

                        {{-- Divider --}}
                        <span class="h-6 w-px bg-border-input mr-2.5" aria-hidden="true"></span>

                        {{-- Input Field --}}
                        <input
                            id="phone-input"
                            type="tel"
                            inputmode="numeric"
                            autocomplete="tel"
                            placeholder="812 3456 7890"
                            wire:model="phone"
                            x-data="{
                                sanitize() {
                                    let v = $el.value.replace(/[\s\-.\(\)]+/g, '');
                                    if (v.startsWith('+62')) v = v.slice(3);
                                    else if (v.startsWith('62') && v.length > 2) v = v.slice(2);
                                    else if (v.startsWith('0')) v = v.slice(1);
                                    if (v !== $el.value) {
                                        $el.value = v;
                                        $wire.phone = v;
                                    }
                                }
                            }"
                            x-on:input="sanitize()"
                            x-on:change="sanitize()"
                            class="w-full min-h-[52px] pr-4 font-sub text-sm md:text-base text-text-primary placeholder:text-text-muted/60 bg-transparent outline-none"
                            autofocus
                        />
                    </div>

                    @error('phone')
                        <p class="font-body text-xs text-primary-button mt-1.5" role="alert">
                            {{ $message }}
                        </p>
                    @enderror
                </div>

                {{-- Submit Button --}}
                <x-button
                    type="submit"
                    variant="green"
                    class="w-full justify-center text-sm md:text-base"
                >
                    <span wire:loading.remove wire:target="submit">Masuk &rarr;</span>
                    <span wire:loading wire:target="submit" class="inline-flex items-center gap-2">
                        <svg class="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"></path></svg>
                        <span>Memproses...</span>
                    </span>
                </x-button>

                {{-- Privacy Note (Per Figma) --}}
                <div class="flex items-start gap-2.5 pt-2 text-text-muted">
                    <svg class="w-5 h-5 text-text-body shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                        <path d="M9 12l2 2 4-4"/>
                    </svg>
                    <p class="font-body text-[11px] md:text-xs text-text-muted leading-relaxed">
                        Nomor handphone kamu akan digunakan untuk akses pemesanan dan notifikasi pesanan.
                    </p>
                </div>
            </form>
            </div>
        </div>
    </div>
</div>
