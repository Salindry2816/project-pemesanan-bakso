<div wire:poll.5s.visible class="space-y-6 pb-8">
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
            <h1 class="font-heading text-2xl md:text-3xl font-bold text-text-primary">
                Pesanan Saya
            </h1>
            <p class="font-body text-xs md:text-sm text-text-muted mt-1">
                Pantau status pesanan Anda secara langsung.
            </p>
        </div>

        <a
            href="{{ route('customer.menu') }}"
            class="inline-flex items-center justify-center min-h-[44px] px-4 rounded-[12px] bg-primary-button text-white font-sub text-xs md:text-sm font-bold hover:opacity-90 transition-opacity"
        >
            + Pesan Lagi
        </a>
    </div>

    @if ($orders->isEmpty())
        <div class="p-8 rounded-[20px] bg-white border border-border-card shadow-sm text-center space-y-3">
            <p class="font-heading text-base font-bold text-text-primary">
                Belum Ada Pesanan
            </p>
            <p class="font-body text-xs md:text-sm text-text-muted">
                Anda belum membuat pesanan dari nomor ini. Yuk pilih menu bakso favorit Anda!
            </p>
            <div class="pt-2">
                <a
                    href="{{ route('customer.menu') }}"
                    class="inline-flex items-center justify-center min-h-[44px] px-5 rounded-[12px] bg-primary-button text-white font-sub text-sm font-bold hover:opacity-90"
                >
                    Lihat Menu
                </a>
            </div>
        </div>
    @else
        <div class="space-y-4">
            @foreach ($orders as $order)
                <a
                    href="{{ route('customer.order.show', ['orderNumber' => $order->order_number]) }}"
                    wire:key="customer-order-{{ $order->id }}"
                    class="block p-5 rounded-[20px] bg-white border border-border-card shadow-sm hover:border-maroon/50 transition-colors space-y-3"
                >
                    <div class="flex items-start justify-between gap-3">
                        <div>
                            <p class="font-heading text-base md:text-lg font-bold text-text-primary">
                                {{ $order->display_number }}
                            </p>
                            <p class="font-sub text-[11px] text-text-muted">
                                {{ $order->created_at?->format('d M Y, H:i') }}
                            </p>
                        </div>

                        <div class="flex flex-wrap items-center justify-end gap-1.5">
                            <span class="inline-flex items-center px-2.5 py-1 rounded-pill font-sub text-[11px] font-bold {{ $order->status->badgeClass() }}">
                                {{ $order->status->label() }}
                            </span>
                            <span class="inline-flex items-center px-2.5 py-1 rounded-pill font-sub text-[11px] font-bold {{ $order->payment_status->value === 'lunas' ? 'bg-green-dark text-white' : 'bg-cream text-text-primary border border-border-card' }}">
                                {{ $order->payment_status->label() }}
                            </span>
                        </div>
                    </div>

                    <div class="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-border-card/60 text-xs">
                        <div class="font-sub text-text-muted">
                            @if ($order->type->value === 'take_away')
                                Bungkus (Take Away)
                            @elseif ($order->table)
                                Meja {{ $order->table->code }}
                            @endif
                            · {{ $order->items->sum('qty') }} porsi
                            · {{ $order->payment_method->label() }}
                        </div>
                        <p class="font-heading text-sm md:text-base font-bold text-primary-button">
                            Rp {{ number_format($order->total, 0, ',', '.') }}
                        </p>
                    </div>
                </a>
            @endforeach
        </div>
    @endif
</div>
