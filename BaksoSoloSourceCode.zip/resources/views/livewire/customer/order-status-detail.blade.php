<div wire:poll.5s.visible class="space-y-6 pb-8">
    <div class="flex items-center justify-between gap-3">
        <div>
            <a
                href="{{ route('customer.orders') }}"
                class="inline-flex items-center gap-1.5 text-maroon hover:underline font-sub text-xs font-semibold min-h-[36px]"
            >
                <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
                Semua Pesanan
            </a>
            <h1 class="font-heading text-2xl md:text-3xl font-bold text-text-primary mt-1">
                Pesanan {{ $order->display_number }}
            </h1>
            <p class="font-sub text-xs text-text-muted">
                Dibuat {{ $order->created_at?->format('d M Y, H:i') }}
            </p>
        </div>

        <span class="inline-flex items-center px-3 py-1.5 rounded-pill font-sub text-xs font-bold {{ $order->status->badgeClass() }}">
            {{ $order->status->label() }}
        </span>
    </div>

    @if ($errorMessage)
        <div role="alert" class="p-4 rounded-[12px] bg-red-50 border border-red-200 text-status-dibatalkan text-xs md:text-sm font-sub font-medium">
            {{ $errorMessage }}
        </div>
    @endif

    @if ($statusMessage)
        <div role="status" class="p-4 rounded-[12px] bg-green-dark/10 border border-green-dark/30 text-green-dark text-xs md:text-sm font-sub font-semibold">
            {{ $statusMessage }}
        </div>
    @endif

    <div class="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        <div class="md:col-span-7 space-y-6">
            {{-- Status Timeline --}}
            <div class="p-5 md:p-6 rounded-[20px] bg-white border border-border-card shadow-sm space-y-4">
                <h2 class="font-heading text-base font-bold text-text-primary">
                    Status Pesanan
                </h2>

                @if ($order->status === \App\Enums\OrderStatus::Dibatalkan)
                    @php
                        $cancelledAt = $logsByStatus[\App\Enums\OrderStatus::Dibatalkan->value] ?? null;
                        $reachedSteps = array_values(array_filter(
                            $steps,
                            static fn (\App\Enums\OrderStatus $s): bool => isset($logsByStatus[$s->value])
                        ));
                    @endphp

                    @if (count($reachedSteps) > 0)
                        <div class="relative pl-8 space-y-4">
                            <div class="absolute left-[13px] top-2 bottom-2 w-0.5 bg-border-card" aria-hidden="true"></div>
                            @foreach ($reachedSteps as $step)
                                @php
                                    $stepTime = $logsByStatus[$step->value] ?? null;
                                @endphp
                                <div class="relative flex items-center justify-between gap-3">
                                    <div class="absolute -left-8 w-7 h-7 rounded-full flex items-center justify-center text-xs font-sub font-bold bg-text-muted text-white shrink-0">
                                        ✓
                                    </div>
                                    <p class="font-sub text-sm font-semibold text-text-primary">
                                        {{ $step->customerTimelineLabel() }}
                                    </p>
                                    @if ($stepTime)
                                        <span class="font-sub text-xs text-text-muted shrink-0">
                                            {{ $stepTime->format('H:i') }}
                                        </span>
                                    @endif
                                </div>
                            @endforeach
                        </div>
                    @endif

                    <div class="p-4 rounded-[12px] bg-status-dibatalkan/10 border border-status-dibatalkan/30 text-status-dibatalkan space-y-1">
                        <div class="flex items-center justify-between gap-2">
                            <p class="font-sub text-sm font-bold">
                                Pesanan Dibatalkan
                            </p>
                            @if ($cancelledAt)
                                <span class="font-sub text-xs font-semibold">
                                    {{ $cancelledAt->format('d M Y, H:i') }}
                                </span>
                            @endif
                        </div>
                        <p class="font-body text-xs">
                            Pesanan ini telah dibatalkan dan tidak diproses lebih lanjut.
                        </p>
                    </div>
                @else
                    <div class="relative pl-8 space-y-4">
                        <div class="absolute left-[13px] top-3 bottom-3 w-0.5 bg-border-card" aria-hidden="true"></div>
                        @foreach ($steps as $index => $step)
                            @php
                                $reached = $currentStepIndex !== false && $index <= $currentStepIndex;
                                $isCurrent = $order->status === $step;
                                $stepTime = $reached ? ($logsByStatus[$step->value] ?? null) : null;
                            @endphp
                            <div class="relative flex items-center justify-between gap-3">
                                <div class="absolute -left-8 w-7 h-7 rounded-full flex items-center justify-center text-xs font-sub font-bold shrink-0 {{ $reached ? 'bg-primary-button text-white' : 'bg-cream text-text-muted border border-border-card' }}">
                                    @if ($reached)
                                        ✓
                                    @else
                                        {{ $index + 1 }}
                                    @endif
                                </div>
                                <div class="min-w-0">
                                    <p class="font-sub text-sm {{ $isCurrent ? 'font-bold text-primary-button' : ($reached ? 'font-semibold text-text-primary' : 'text-text-muted') }}">
                                        {{ $step->customerTimelineLabel() }}
                                    </p>
                                    @if (! $reached)
                                        <p class="font-sub text-[11px] text-text-muted">
                                            Belum
                                        </p>
                                    @endif
                                </div>
                                @if ($reached && $stepTime)
                                    <span class="font-sub text-xs font-semibold {{ $isCurrent ? 'text-primary-button' : 'text-text-muted' }} shrink-0">
                                        {{ $stepTime->format('H:i') }}
                                    </span>
                                @endif
                            </div>
                        @endforeach
                    </div>

                    @if ($order->status->isActive())
                        <div class="p-4 rounded-[12px] bg-cream/70 border border-border-card font-body text-xs md:text-sm text-text-primary">
                            Pesanan Anda sedang disiapkan oleh tim kami. Terima kasih sudah memesan!
                        </div>
                    @endif
                @endif
            </div>

            {{-- Payment Section --}}
            <div class="p-5 md:p-6 rounded-[20px] bg-white border border-border-card shadow-sm space-y-4">
                <div class="flex items-center justify-between">
                    <h2 class="font-heading text-base font-bold text-text-primary">
                        Pembayaran ({{ $order->payment_method->label() }})
                    </h2>
                    <span class="inline-flex items-center px-2.5 py-1 rounded-pill font-sub text-xs font-bold {{ $order->payment_status->value === 'lunas' ? 'bg-green-dark text-white' : 'bg-cream text-text-primary border border-border-card' }}">
                        {{ $order->payment_status->label() }}
                    </span>
                </div>

                @if ($order->payment_status->value === 'lunas')
                    <div class="p-4 rounded-[12px] bg-green-dark/10 border border-green-dark/30 text-green-dark font-sub text-xs md:text-sm font-semibold">
                        Pembayaran sudah diterima{{ $order->paid_at ? ' pada '.$order->paid_at->format('d M Y, H:i') : '' }}.
                    </div>
                @elseif ($order->payment_method->value === 'qris')
                    <div class="space-y-3 text-center">
                        <div class="p-3 rounded-[12px] bg-cream/60 border border-border-card font-sub text-xs md:text-sm font-semibold text-text-primary">
                            Menunggu konfirmasi penjual
                        </div>
                        @if ($qrisUrl)
                            <div class="inline-block p-3 bg-white rounded-[16px] border border-border-card shadow-xs">
                                <img
                                    src="{{ $qrisUrl }}"
                                    alt="Kode QRIS Pembayaran"
                                    class="w-56 h-56 object-contain mx-auto"
                                />
                            </div>
                            <p class="font-body text-xs text-text-muted">
                                Scan kode QRIS di atas sebesar <strong>Rp {{ number_format($order->total, 0, ',', '.') }}</strong>, lalu tunjukkan bukti ke kasir.
                            </p>
                        @endif
                    </div>
                @else
                    <div class="p-4 rounded-[12px] bg-cream/60 border border-border-card space-y-1">
                        <p class="font-sub text-sm font-bold text-text-primary">
                            Bayar di kasir
                        </p>
                        <p class="font-body text-xs text-text-muted">
                            Silakan bayar sebesar <strong>Rp {{ number_format($order->total, 0, ',', '.') }}</strong> di kasir dengan menyebutkan nomor <strong>{{ $order->display_number }}</strong>. Menunggu konfirmasi penjual.
                        </p>
                    </div>
                @endif
            </div>
        </div>

        {{-- Right Column: Order Summary --}}
        <div class="md:col-span-5 rounded-[20px] bg-white border border-border-card shadow-sm divide-y divide-border-card/60 overflow-hidden">
            <div class="p-4 md:p-5 bg-cream/40 space-y-1">
                <h2 class="font-heading text-base font-bold text-text-primary">
                    Rincian Pesanan
                </h2>
                <p class="font-sub text-xs text-text-muted">
                    @if ($order->type->value === 'take_away')
                        Bungkus (Take Away)
                    @elseif ($order->table)
                        Lantai {{ $order->table->floor }} · Meja {{ $order->table->code }}
                        @if ($order->location_note)
                            ({{ $order->location_note }})
                        @endif
                    @endif
                </p>
            </div>

            <div class="p-4 md:p-5 space-y-3">
                @foreach ($order->items as $item)
                    <div class="flex items-start justify-between gap-3 text-xs md:text-sm">
                        <div class="min-w-0">
                            <p class="font-heading font-semibold text-text-primary">
                                {{ $item->name_snapshot }}
                            </p>
                            <p class="font-body text-[11px] text-text-muted">
                                {{ $item->qty }}x @ Rp {{ number_format($item->price_snapshot, 0, ',', '.') }}
                            </p>
                            @if ($item->item_note)
                                <p class="font-body text-[11px] text-text-muted italic">
                                    Catatan: {{ $item->item_note }}
                                </p>
                            @endif
                        </div>
                        <p class="font-heading font-bold text-text-primary shrink-0">
                            Rp {{ number_format($item->line_total, 0, ',', '.') }}
                        </p>
                    </div>
                @endforeach

                @if ($order->note)
                    <div class="pt-2 border-t border-border-card/60">
                        <p class="font-sub text-[11px] font-bold text-text-muted">Catatan Pesanan:</p>
                        <p class="font-body text-xs text-text-primary">{{ $order->note }}</p>
                    </div>
                @endif
            </div>

            <div class="p-4 md:p-5 bg-cream/30 flex items-center justify-between">
                <span class="font-sub text-xs uppercase tracking-wider font-bold text-text-muted">Total</span>
                <span class="font-heading text-xl font-bold text-primary-button">
                    Rp {{ number_format($order->total, 0, ',', '.') }}
                </span>
            </div>

            @if ($order->status === \App\Enums\OrderStatus::Diterima)
                <div class="p-4 md:p-5 bg-white">
                    <button
                        type="button"
                        wire:click="openCancelDialog"
                        class="w-full min-h-[44px] px-4 rounded-[12px] border border-status-dibatalkan text-status-dibatalkan font-sub text-sm font-bold hover:bg-status-dibatalkan/10 transition-colors cursor-pointer"
                    >
                        Batalkan Pesanan
                    </button>
                </div>
            @endif
        </div>
    </div>

    @if ($showCancelDialog)
        <div
            role="dialog"
            aria-modal="true"
            aria-labelledby="cancel-order-dialog-title"
            class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
        >
            <div class="w-full max-w-md rounded-[20px] bg-white border border-border-card shadow-lg p-6 space-y-5">
                <div class="space-y-2 text-center">
                    <h2 id="cancel-order-dialog-title" class="font-heading text-xl font-bold text-text-primary">
                        Batalkan pesanan?
                    </h2>
                    <p class="font-body text-xs md:text-sm text-text-muted">
                        Pesanan <strong>{{ $order->display_number }}</strong> akan dibatalkan dan tidak dapat dikembalikan.
                    </p>
                </div>

                <div class="flex flex-col sm:flex-row gap-3">
                    <button
                        type="button"
                        wire:click="dismissCancelDialog"
                        wire:loading.attr="disabled"
                        wire:target="cancelOrder"
                        class="flex-1 min-h-[48px] px-4 rounded-[12px] border border-border-card bg-white text-text-primary font-sub text-sm font-bold hover:bg-cream transition-colors cursor-pointer"
                    >
                        Tidak, Kembali
                    </button>
                    <button
                        type="button"
                        wire:click="cancelOrder"
                        wire:loading.attr="disabled"
                        wire:target="cancelOrder"
                        class="flex-1 min-h-[48px] px-4 rounded-[12px] bg-status-dibatalkan text-white font-sub text-sm font-bold hover:opacity-90 disabled:opacity-60 transition-opacity cursor-pointer"
                    >
                        <span wire:loading.remove wire:target="cancelOrder">Ya, Batalkan Pesanan</span>
                        <span wire:loading wire:target="cancelOrder">Membatalkan...</span>
                    </button>
                </div>
            </div>
        </div>
    @endif
</div>
