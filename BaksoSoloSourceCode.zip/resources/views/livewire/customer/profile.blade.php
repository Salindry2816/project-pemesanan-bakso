<div class="w-full max-w-5xl mx-auto py-2 md:py-6 space-y-6">
    {{-- Hero Section: Logo, Nama Usaha, Tagline --}}
    <div class="flex flex-col items-center justify-center text-center py-4 md:py-8">
        {{-- Avatar Logo (96x96px matching Figma hero-logo) --}}
        <div class="w-24 h-24 rounded-full bg-asset border border-border-card shadow-xs flex items-center justify-center overflow-hidden mb-3">
            @if ($logoUrl)
                <img
                    src="{{ $logoUrl }}"
                    alt="Logo {{ $businessName }}"
                    class="w-full h-full object-cover"
                />
            @else
                <span class="font-sub text-xs md:text-sm font-semibold text-[#6B6B6B]">
                    LOGO
                </span>
            @endif
        </div>

        <h1 class="font-heading text-2xl md:text-3xl font-bold text-maroon">
            {{ $profile?->name ?? 'Bakso Solo' }}
        </h1>

        @if ($profile && ! empty(trim((string) $profile->tagline)))
            <p class="font-sub text-xs md:text-sm text-text-muted mt-1">
                {{ $profile->tagline }}
            </p>
        @endif
    </div>

    @if (! $profile)
        {{-- Empty State when BusinessProfile is not in DB --}}
        <div class="p-8 rounded-[20px] bg-white border border-border-card shadow-card text-center">
            <p class="font-sub text-sm text-text-muted">
                Profil usaha belum dikonfigurasi.
            </p>
        </div>
    @else
        {{-- Content Grid: Left Column (Tentang Kami), Right Column (Informasi Usaha & Kontak) --}}
        <div class="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
            {{-- Section Tentang Kami --}}
            @if (! empty(trim((string) $profile->description)))
                <div class="{{ empty(trim((string) $profile->location)) && empty(trim((string) $profile->phone)) && empty($normalizedWa) ? 'md:col-span-12' : 'md:col-span-7' }} p-6 md:p-8 rounded-[20px] bg-white border border-border-card shadow-card">
                    <h2 class="font-heading text-lg md:text-xl font-bold text-text-primary mb-3 md:mb-4">
                        Tentang Kami
                    </h2>
                    <p class="font-body text-xs md:text-sm text-text-body leading-relaxed whitespace-pre-line">
                        {{ $profile->description }}
                    </p>
                </div>
            @endif

            {{-- Section Informasi Usaha --}}
            @php
                $hasLocation = ! empty(trim((string) $profile->location));
                $hasPhone = ! empty(trim((string) $profile->phone));
                $hasHours = ! empty(trim((string) $profile->open_time)) || ! empty(trim((string) $profile->close_time));
                $hasInfo = $hasLocation || $hasPhone || $hasHours || $normalizedWa;
            @endphp

            @if ($hasInfo)
                <div class="{{ empty(trim((string) $profile->description)) ? 'md:col-span-12' : 'md:col-span-5' }} p-6 md:p-8 rounded-[20px] bg-white border border-border-card shadow-card space-y-6">
                    <h2 class="font-heading text-lg md:text-xl font-bold text-text-primary">
                        Informasi Usaha
                    </h2>

                    <div class="space-y-4">
                        {{-- Lokasi --}}
                        @if ($hasLocation)
                            <div class="flex items-start gap-3.5">
                                <div class="w-9 h-9 rounded-full bg-[#F6E3E1] flex items-center justify-center shrink-0 text-primary-button mt-0.5">
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <path d="M12 21s-7-6-7-11a7 7 0 0114 0c0 5-7 11-7 11z"/>
                                        <circle cx="12" cy="10" r="2.5"/>
                                    </svg>
                                </div>
                                <div class="min-w-0">
                                    <p class="font-sub font-bold text-xs text-text-primary">Lokasi</p>
                                    <p class="font-body text-xs md:text-sm text-text-body mt-0.5 leading-relaxed break-words">
                                        {{ $profile->location }}
                                    </p>
                                </div>
                            </div>
                        @endif

                        {{-- Kontak (Telepon) --}}
                        @if ($hasPhone)
                            <div class="flex items-start gap-3.5">
                                <div class="w-9 h-9 rounded-full bg-[#F6E3E1] flex items-center justify-center shrink-0 text-primary-button mt-0.5">
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>
                                    </svg>
                                </div>
                                <div class="min-w-0">
                                    <p class="font-sub font-bold text-xs text-text-primary">Kontak</p>
                                    <a
                                        href="tel:{{ preg_replace('/[^0-9+]/', '', (string) $profile->phone) }}"
                                        class="font-body text-xs md:text-sm text-text-body hover:text-maroon mt-0.5 inline-block"
                                    >
                                        {{ $profile->phone }}
                                    </a>
                                </div>
                            </div>
                        @endif

                        {{-- Jam Operasional --}}
                        @if ($hasHours)
                            <div class="flex items-start gap-3.5">
                                <div class="w-9 h-9 rounded-full bg-[#F6E3E1] flex items-center justify-center shrink-0 text-primary-button mt-0.5">
                                    <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <circle cx="12" cy="12" r="10"/>
                                        <polyline points="12 6 12 12 16 14"/>
                                    </svg>
                                </div>
                                <div class="min-w-0">
                                    <p class="font-sub font-bold text-xs text-text-primary">Jam Operasional</p>
                                    <p class="font-body text-xs md:text-sm text-text-body mt-0.5">
                                        {{ $profile->open_time ?? '08.00' }} - {{ $profile->close_time ?? '17.00' }}
                                    </p>
                                </div>
                            </div>
                        @endif
                    </div>

                    {{-- Tombol Hubungi via WhatsApp --}}
                    @if ($normalizedWa)
                        <div class="pt-2">
                            <a
                                href="https://wa.me/{{ $normalizedWa }}"
                                target="_blank"
                                rel="noopener noreferrer"
                                class="w-full flex items-center justify-center gap-2.5 min-h-[48px] md:min-h-[52px] px-6 rounded-[12px] bg-[#064E34] hover:bg-[#064E34]/90 text-white font-sub text-xs md:text-sm font-semibold shadow-xs transition-colors cursor-pointer"
                            >
                                <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                                    <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91C2.13 13.66 2.59 15.36 3.45 16.86L2.05 22L7.3 20.62C8.75 21.41 10.38 21.83 12.04 21.83C17.5 21.83 21.95 17.38 21.95 11.92C21.95 9.27 20.92 6.78 19.05 4.91C17.18 3.03 14.69 2 12.04 2M12.05 3.67C14.25 3.67 16.31 4.53 17.87 6.09C19.42 7.65 20.28 9.72 20.28 11.92C20.28 16.46 16.58 20.15 12.04 20.15C10.56 20.15 9.11 19.76 7.85 19.01L7.55 18.83L4.43 19.65L5.26 16.61L5.06 16.29C4.24 14.99 3.8 13.47 3.8 11.91C3.81 7.37 7.5 3.67 12.05 3.67M9.53 7.35C9.34 7.35 9.03 7.42 8.77 7.7C8.51 7.99 7.78 8.68 7.78 10.08C7.78 11.48 8.8 12.83 8.95 13.02C9.09 13.22 10.96 16.27 13.92 17.43C16.38 18.4 16.88 18.2 17.42 18.15C17.96 18.1 19.16 17.44 19.41 16.74C19.66 16.04 19.66 15.44 19.58 15.32C19.51 15.2 19.32 15.13 19.03 14.99C18.75 14.85 17.37 14.17 17.11 14.07C16.86 13.98 16.67 13.93 16.48 14.22C16.29 14.51 15.75 15.15 15.58 15.34C15.42 15.54 15.25 15.56 14.97 15.42C14.68 15.27 13.76 14.97 12.67 14C11.82 13.24 11.24 12.3 11.08 12.02C10.92 11.73 11.06 11.58 11.21 11.44C11.34 11.31 11.5 11.1 11.65 10.93C11.79 10.76 11.84 10.64 11.94 10.44C12.03 10.25 11.99 10.08 11.91 9.93C11.84 9.79 11.27 8.39 11.04 7.82C10.81 7.27 10.58 7.34 10.4 7.34L9.53 7.35Z"/>
                                </svg>
                                <span>Hubungi via WhatsApp</span>
                            </a>
                        </div>
                    @endif
                </div>
            @endif
        </div>
    @endif
</div>
