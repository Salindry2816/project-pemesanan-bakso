<div>
    @if ($count > 0)
        @if ($position === 'desktop')
            <span class="absolute -top-1.5 -right-1.5 inline-flex items-center justify-center min-w-[20px] h-5 px-1 rounded-pill bg-primary-button text-white font-sub text-[11px] font-bold shadow-xs">
                {{ $count }}
            </span>
        @else
            <span class="absolute -top-1.5 -right-2 inline-flex items-center justify-center min-w-[16px] h-4 px-1 rounded-pill bg-primary-button text-white font-sub text-[9px] font-bold">
                {{ $count }}
            </span>
        @endif
    @endif
</div>
