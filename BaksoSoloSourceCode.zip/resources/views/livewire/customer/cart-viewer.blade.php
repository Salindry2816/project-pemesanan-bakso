<div class="max-w-4xl mx-auto px-4 sm:px-6 py-6 md:py-8 space-y-6">
    <!-- Breadcrumb / Back Link -->
    <div class="flex items-center justify-between">
        <a
            href="{{ route('customer.menu') }}"
            class="inline-flex items-center gap-1.5 text-xs md:text-sm font-sub font-semibold text-text-muted hover:text-maroon transition-colors min-h-[44px]"
        >
            <span>&larr;</span>
            <span>Kembali ke Menu</span>
        </a>

        @if ($table || $orderType === 'take_away')
            <div class="inline-flex items-center gap-2 px-3 py-1.5 rounded-pill bg-white border border-border-card text-xs font-sub text-text-primary shadow-xs">
                <svg class="w-3.5 h-3.5 text-maroon flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 21s-7-6-7-11a7 7 0 0114 0c0 5-7 11-7 11z"/><circle cx="12" cy="10" r="2.5"/>
                </svg>
                <span>
                    @if ($orderType === 'take_away')
                        <strong>Bungkus (Take Away)</strong>
                    @elseif ($table)
                        <strong>Lantai {{ $table->floor }} &bull; Meja {{ $table->code }}</strong>
                        @if ($locationNote)
                            <span class="text-text-muted">({{ $locationNote }})</span>
                        @endif
                    @endif
                </span>
                <a
                    href="{{ route('customer.table') }}"
                    class="text-maroon hover:underline font-semibold ml-1"
                >
                    Ganti
                </a>
            </div>
        @endif
    </div>

    <!-- Page Title -->
    <div>
        <h1 class="font-heading text-2xl md:text-3xl font-bold text-text-primary">
            Keranjang Pesanan
        </h1>
        <p class="font-body text-xs md:text-sm text-text-muted mt-1">
            Periksa pesananmu dan tambahkan catatan khusus sebelum konfirmasi.
        </p>
    </div>

    <!-- Flash / Error Message Alert -->
    @if ($errorMessage)
        <div
            role="alert"
            class="p-4 rounded-[12px] bg-red-50 border border-red-200 text-status-dibatalkan text-xs md:text-sm font-sub font-medium flex items-center justify-between gap-3"
        >
            <div class="flex items-center gap-2">
                <svg class="w-5 h-5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                    <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
                </svg>
                <span>{{ $errorMessage }}</span>
            </div>
            <button
                type="button"
                wire:click="$set('errorMessage', null)"
                class="min-h-[44px] min-w-[44px] inline-flex items-center justify-center text-status-dibatalkan hover:opacity-75 cursor-pointer"
                aria-label="Tutup pesan error"
            >
                &times;
            </button>
        </div>
    @endif

    <!-- Problem Items Banner -->
    @if ($summary->hasProblems)
        <div
            role="alert"
            class="p-4 md:p-5 rounded-[16px] bg-amber-50 border border-amber-300 text-amber-900 text-xs md:text-sm font-sub space-y-3 shadow-xs"
        >
            <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div class="flex items-center gap-2">
                    <svg class="w-5 h-5 text-amber-700 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                    </svg>
                    <span class="font-bold text-sm md:text-base">Beberapa menu sudah tidak tersedia dan tidak dihitung</span>
                </div>
                <button
                    type="button"
                    wire:click="removeUnavailable"
                    wire:loading.attr="disabled"
                    wire:target="removeUnavailable"
                    class="min-h-[44px] px-4 py-2 rounded-pill bg-amber-700 text-white hover:bg-amber-800 text-xs font-bold transition-colors shadow-xs flex-shrink-0 cursor-pointer text-center"
                >
                    Hapus menu yang tidak tersedia
                </button>
            </div>
            <p class="text-[11px] md:text-xs text-amber-800">
                Menu yang habis atau telah dinonaktifkan tidak diikutsertakan dalam total pesanan. Hapus menu tersebut untuk melanjutkan.
            </p>
        </div>

        <!-- Problem Lines List -->
        <div class="space-y-3">
            <h2 class="font-heading text-xs uppercase tracking-wider font-bold text-text-muted">
                Menu Tidak Tersedia
            </h2>
            @foreach ($summary->problemLines as $problem)
                <div
                    wire:key="problem-line-{{ $problem['menu_id'] }}"
                    class="p-4 rounded-[16px] bg-gray-100/80 border border-dashed border-gray-300 flex flex-col sm:flex-row sm:items-center justify-between gap-3 opacity-75"
                >
                    <div class="flex items-center gap-3">
                        <div class="w-12 h-12 rounded-[10px] bg-gray-200 text-gray-500 flex items-center justify-center font-sub text-[10px] font-bold flex-shrink-0">
                            HABIS
                        </div>
                        <div>
                            <p class="font-heading font-semibold text-sm text-gray-700 line-through">
                                {{ $problem['menu'] ? $problem['menu']->name : 'Menu #' . $problem['menu_id'] }}
                            </p>
                            <p class="font-sub text-xs text-status-dibatalkan font-medium">
                                {{ $problem['reason'] }}
                            </p>
                        </div>
                    </div>
                    <div class="flex items-center justify-between sm:justify-end gap-4">
                        <span class="font-sub text-xs text-gray-500">
                            {{ $problem['qty'] }} porsi
                        </span>
                        <button
                            type="button"
                            wire:click="removeItem({{ $problem['menu_id'] }})"
                            wire:loading.attr="disabled"
                            wire:target="removeItem"
                            class="min-h-[44px] px-2 text-status-dibatalkan hover:underline font-sub text-xs font-semibold cursor-pointer"
                        >
                            Hapus
                        </button>
                    </div>
                </div>
            @endforeach
        </div>
    @endif

    <!-- Main Order Details Card -->
    <div class="rounded-[20px] bg-white border border-border-card shadow-sm divide-y divide-border-card/60 overflow-hidden">
        <!-- Header Card -->
        <div class="p-4 md:p-6 bg-cream/40 flex items-center justify-between">
            <h2 class="font-heading text-base md:text-lg font-bold text-text-primary">
                Detail Pesanan
            </h2>
            <span class="font-sub text-xs text-text-muted">
                {{ count($summary->validLines) }} jenis menu
            </span>
        </div>

        @if (empty($summary->validLines))
            <!-- Empty State inside Card -->
            <div class="p-8 md:p-12 text-center space-y-4">
                <div class="w-16 h-16 mx-auto rounded-full bg-cream flex items-center justify-center text-maroon">
                    <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.8">
                        <rect x="4" y="8" width="16" height="12" rx="3"/><path d="M8 8V6a4 4 0 018 0v2"/>
                    </svg>
                </div>
                <div>
                    <h3 class="font-heading text-lg md:text-xl font-bold text-text-primary">
                        Keranjang masih kosong.
                    </h3>
                    <p class="font-body text-xs md:text-sm text-text-muted mt-1">
                        Kamu belum memilih menu apa pun. Silakan lihat pilihan menu kami.
                    </p>
                </div>
                <div class="pt-2">
                    <a
                        href="{{ route('customer.menu') }}"
                        class="inline-flex items-center justify-center min-h-[44px] px-6 rounded-pill bg-primary-button text-white font-sub text-sm font-bold shadow-xs hover:bg-primary-button-hover transition-colors"
                    >
                        Lihat Menu
                    </a>
                </div>
            </div>
        @else
            <!-- List of Valid Items -->
            @foreach ($summary->validLines as $line)
                @php
                    $menu = $line['menu'];
                    $menuId = $line['menu_id'];
                    $qty = $line['qty'];
                    $photoUrl = $menu->photo_path ? \App\Support\MediaStorage::url($menu->photo_path) : null;
                @endphp
                <div
                    wire:key="cart-line-{{ $menuId }}"
                    class="p-4 md:p-6 space-y-3"
                >
                    <!-- Row 1: Thumbnail, Name, Unit Price, Line Total -->
                    <div class="flex items-start justify-between gap-3">
                        <div class="flex items-start gap-3 min-w-0">
                            @if ($photoUrl)
                                <img
                                    src="{{ $photoUrl }}"
                                    alt="{{ $menu->name }}"
                                    loading="lazy"
                                    class="w-14 h-14 md:w-16 md:h-16 rounded-[12px] object-cover bg-cream border border-border-card/60 flex-shrink-0"
                                />
                            @else
                                <div class="w-14 h-14 md:w-16 md:h-16 rounded-[12px] bg-cream border border-border-card/60 flex items-center justify-center text-maroon flex-shrink-0">
                                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="1.8">
                                        <rect x="4" y="8" width="16" height="12" rx="3"/><path d="M8 8V6a4 4 0 018 0v2"/>
                                    </svg>
                                </div>
                            @endif

                            <div class="min-w-0">
                                <h3 class="font-heading font-bold text-sm md:text-base text-text-primary truncate">
                                    {{ $menu->name }}
                                </h3>
                                <p class="font-body text-xs text-text-muted mt-0.5">
                                    Rp {{ number_format($line['unit_price'], 0, ',', '.') }} / porsi
                                </p>
                            </div>
                        </div>

                        <div class="text-right flex-shrink-0">
                            <span class="font-heading font-bold text-sm md:text-base text-text-primary">
                                Rp {{ number_format($line['line_total'], 0, ',', '.') }}
                            </span>
                        </div>
                    </div>

                    <!-- Row 2: Stepper & Delete Button -->
                    <div class="flex flex-wrap items-center justify-between gap-3 pt-1">
                        <!-- Stepper - [qty] + -->
                        <div class="inline-flex items-center rounded-[10px] border border-border-card bg-cream/40 p-0.5">
                            <button
                                type="button"
                                wire:click="decrementQty({{ $menuId }})"
                                wire:loading.attr="disabled"
                                wire:target="decrementQty,incrementQty,removeItem,updateQty"
                                @disabled($qty <= 1)
                                class="min-w-[40px] min-h-[40px] md:min-w-[36px] md:min-h-[36px] flex items-center justify-center rounded-[8px] text-text-primary hover:bg-white active:bg-cream disabled:opacity-40 disabled:cursor-not-allowed transition-colors font-bold text-sm cursor-pointer"
                                aria-label="Kurangi porsi {{ $menu->name }}"
                            >
                                &minus;
                            </button>
                            <span class="min-w-[36px] text-center font-heading font-bold text-xs md:text-sm text-text-primary">
                                {{ $qty }}
                            </span>
                            <button
                                type="button"
                                wire:click="incrementQty({{ $menuId }})"
                                wire:loading.attr="disabled"
                                wire:target="decrementQty,incrementQty,removeItem,updateQty"
                                @disabled($qty >= 20)
                                class="min-w-[40px] min-h-[40px] md:min-w-[36px] md:min-h-[36px] flex items-center justify-center rounded-[8px] text-text-primary hover:bg-white active:bg-cream disabled:opacity-40 disabled:cursor-not-allowed transition-colors font-bold text-sm cursor-pointer"
                                aria-label="Tambah porsi {{ $menu->name }}"
                            >
                                +
                            </button>
                        </div>

                        <!-- Delete button -->
                        <button
                            type="button"
                            wire:click="removeItem({{ $menuId }})"
                            wire:confirm="Hapus {{ $menu->name }} dari keranjang?"
                            wire:loading.attr="disabled"
                            wire:target="removeItem"
                            class="min-h-[44px] px-2 text-status-dibatalkan hover:underline font-sub text-xs md:text-sm font-semibold inline-flex items-center gap-1 cursor-pointer"
                        >
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"/>
                            </svg>
                            <span>Hapus</span>
                        </button>
                    </div>

                    <!-- Row 3: Per-item note input -->
                    <div class="pt-2">
                        <div class="relative">
                            <input
                                type="text"
                                maxlength="100"
                                wire:model.blur="notes.{{ $menuId }}"
                                placeholder="Contoh: tanpa kecap, kuah dipisah (opsional)"
                                class="w-full px-3 py-2 rounded-[10px] border border-border-card text-xs md:text-sm font-body text-text-primary placeholder-text-muted/60 focus:outline-none focus:ring-2 focus:ring-maroon/20 focus:border-maroon"
                                aria-label="Catatan untuk {{ $menu->name }}"
                            />
                        </div>
                        <div class="flex items-center justify-between text-[11px] font-sub mt-1 text-text-muted">
                            <span>
                                @error("notes.{$menuId}")
                                    <span class="text-status-dibatalkan font-medium">{{ $message }}</span>
                                @else
                                    <span>Catatan khusus untuk menu ini</span>
                                @enderror
                            </span>
                            <span>
                                {{ mb_strlen($notes[$menuId] ?? '') }}/100
                            </span>
                        </div>
                    </div>
                </div>
            @endforeach
        @endif

        <!-- Total and Actions Section -->
        <div class="p-4 md:p-6 bg-cream/30 space-y-4">
            <div class="flex items-center justify-between">
                <div>
                    <p class="font-sub text-xs uppercase tracking-wider font-bold text-text-muted">Total Pesanan</p>
                    <p class="font-heading text-xl md:text-2xl font-bold text-primary-button">
                        Rp {{ number_format($summary->total, 0, ',', '.') }}
                    </p>
                </div>
                <span class="font-sub text-xs text-text-muted">
                    {{ count($summary->validLines) }} jenis menu
                </span>
            </div>

            <div class="space-y-2 pt-2">
                @php
                    $canCheckout = ! empty($summary->validLines) && ! $summary->hasProblems;
                @endphp
                @if ($canCheckout)
                    <a
                        href="{{ route('customer.confirm') }}"
                        class="flex items-center justify-center min-h-[48px] w-full px-6 rounded-[12px] bg-primary-button text-white font-sub text-sm md:text-base font-bold shadow-xs hover:bg-primary-button-hover transition-colors"
                    >
                        Lanjut ke Konfirmasi
                    </a>
                @else
                    <button
                        type="button"
                        disabled
                        aria-disabled="true"
                        class="flex items-center justify-center min-h-[48px] w-full px-6 rounded-[12px] bg-gray-300 text-gray-500 font-sub text-sm md:text-base font-bold cursor-not-allowed select-none"
                    >
                        Lanjut ke Konfirmasi
                    </button>
                    @if ($summary->hasProblems)
                        <p class="font-sub text-[11px] md:text-xs text-status-dibatalkan font-medium text-center">
                            Hapus menu yang tidak tersedia terlebih dahulu
                        </p>
                    @endif
                @endif

                <a
                    href="{{ route('customer.menu') }}"
                    class="flex items-center justify-center min-h-[44px] w-full px-6 rounded-[12px] border border-border-card bg-white text-text-primary font-sub text-xs md:text-sm font-semibold hover:bg-cream transition-colors text-center"
                >
                    &larr; Tambah menu lagi
                </a>
            </div>
        </div>
    </div>
</div>
