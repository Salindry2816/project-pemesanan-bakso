<x-layouts.admin title="Cetak QR Meja" active-menu="qr">
    <style>
        @media print {
            /* Hide all navigation, sidebars, headers, and toolbars */
            aside,
            header,
            nav,
            .no-print {
                display: none !important;
            }

            body {
                background: #ffffff !important;
                margin: 0 !important;
                padding: 0 !important;
                color: #2D2D2D !important;
            }

            main {
                padding: 0 !important;
                margin: 0 !important;
            }

            /* Reset container padding */
            .flex-1.flex.flex-col.md\:pl-\[240px\] {
                padding-left: 0 !important;
            }

            @page {
                size: A6 portrait;
                margin: 0;
            }

            .print-poster-container {
                display: flex !important;
                align-items: center !important;
                justify-content: center !important;
                width: 100vw !important;
                height: 100vh !important;
                margin: 0 !important;
                padding: 0 !important;
            }

            .print-poster-card {
                width: 105mm !important;
                height: 148mm !important;
                max-width: 105mm !important;
                max-height: 148mm !important;
                box-shadow: none !important;
                border: none !important;
                border-radius: 0 !important;
                padding: 10mm 8mm !important;
                margin: 0 auto !important;
                page-break-inside: avoid !important;
                page-break-after: avoid !important;
            }
        }

        .qr-svg-wrapper svg {
            width: 100%;
            height: 100%;
            display: block;
        }
    </style>

    <div class="space-y-6">
        {{-- Screen Toolbar & Alerts (hidden during print) --}}
        <div class="no-print space-y-4">
            {{-- Breadcrumb & Actions --}}
            <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                <div>
                    <h2 class="font-heading text-2xl font-bold text-text-primary">Cetak QR Meja</h2>
                    <p class="font-sub text-sm text-text-muted mt-0.5">Lembar cetak QR code siap pakai untuk diletakkan di meja atau kasir warung.</p>
                </div>

                <div class="flex items-center gap-2.5">
                    <a
                        href="{{ route('admin.profile') }}"
                        class="inline-flex items-center justify-center gap-2 px-4 min-h-[44px] rounded-[12px] border border-border-card bg-white hover:bg-cream font-sub text-sm font-semibold text-text-body transition-colors"
                    >
                        <svg class="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>
                        <span>Kembali</span>
                    </a>

                    <x-button
                        type="button"
                        variant="primary"
                        onclick="window.print()"
                        class="gap-2"
                    >
                        <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                            <polyline points="6 9 6 2 18 2 18 9"/>
                            <path d="M6 18H4a2 2 0 01-2-2v-5a2 2 0 012-2h16a2 2 0 012 2v5a2 2 0 01-2 2h-2"/>
                            <rect x="6" y="14" width="12" height="8"/>
                        </svg>
                        <span>Cetak Poster (A6)</span>
                    </x-button>
                </div>
            </div>

            {{-- Missing Profile Warning --}}
            @if (! $profile)
                <div class="p-4 rounded-[12px] bg-red-50 border border-primary-button/30 text-primary-button font-sub text-sm font-semibold flex items-center gap-3" role="alert">
                    <svg class="w-5 h-5 shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <circle cx="12" cy="12" r="10"/>
                        <line x1="12" y1="8" x2="12" y2="12"/>
                        <line x1="12" y1="16" x2="12.01" y2="16"/>
                    </svg>
                    <span>Profil usaha belum dibuat. Jalankan seeder awal untuk mengisi profil usaha.</span>
                </div>
            @endif

            {{-- APP_URL Warning --}}
            @if ($showAppUrlWarning)
                <div class="p-4 rounded-[12px] bg-amber-50 border border-amber-300 text-amber-900 font-sub text-sm flex items-start gap-3" role="alert">
                    <svg class="w-5 h-5 text-amber-600 shrink-0 mt-0.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
                        <line x1="12" y1="9" x2="12" y2="13"/>
                        <line x1="12" y1="17" x2="12.01" y2="17"/>
                    </svg>
                    <div class="space-y-1">
                        <p class="font-bold">Ubah APP_URL ke domain final sebelum mencetak QR.</p>
                        <p class="font-body text-xs text-amber-800 leading-relaxed">
                            Nilai saat ini: <code class="px-1.5 py-0.5 rounded bg-amber-100 font-mono text-[11px] font-bold">{{ $targetUrl }}</code>.
                            Jika dicetak menggunakan localhost atau IP privat, pelanggan yang memindai QR lewat ponsel mereka tidak akan dapat mengakses aplikasi pemesanan.
                        </p>
                    </div>
                </div>
            @endif

            {{-- Target URL Info Box --}}
            <div class="p-3.5 rounded-[12px] bg-white border border-border-card flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 text-xs">
                <div class="flex items-center gap-2">
                    <span class="font-sub font-bold text-text-primary">URL Target QR:</span>
                    <a href="{{ $targetUrl }}" target="_blank" rel="noopener" class="font-mono text-primary-button hover:underline break-all">
                        {{ $targetUrl }}
                    </a>
                </div>
                <span class="font-body text-text-muted">Ukuran standar cetak: A6 Portrait (105 × 148 mm)</span>
            </div>
        </div>

        {{-- Printable Poster Sheet Container --}}
        <div class="print-poster-container flex justify-center py-4">
            <div class="print-poster-card w-full max-w-[390px] sm:w-[105mm] sm:h-[148mm] bg-white rounded-[20px] shadow-[0_4px_24px_rgba(45,45,45,0.08)] border border-border-card p-6 flex flex-col items-center justify-between text-center select-none">
                {{-- Header Warung --}}
                <div class="w-full space-y-1">
                    <div class="inline-flex items-center justify-center gap-1.5 px-3 py-1 rounded-full bg-cream/70 border border-border-card/60 text-maroon font-sub text-[11px] font-bold uppercase tracking-wider mb-1">
                        <span>Pesan Menu Online</span>
                    </div>

                    <h1 class="font-heading text-2xl font-bold text-maroon leading-tight">
                        {{ $profile?->name ?? 'Bakso Solo' }}
                    </h1>

                    @if ($profile?->tagline)
                        <p class="font-sub text-xs font-semibold text-text-body">
                            {{ $profile->tagline }}
                        </p>
                    @endif

                    @if ($profile?->location)
                        <p class="font-body text-[10px] text-text-muted leading-tight">
                            {{ $profile->location }}
                        </p>
                    @endif
                </div>

                {{-- Center QR Code --}}
                <div class="my-auto py-2 flex flex-col items-center">
                    <div class="qr-svg-wrapper w-[190px] h-[190px] sm:w-[60mm] sm:h-[60mm] p-2 bg-white rounded-[16px] border-2 border-maroon shadow-sm flex items-center justify-center">
                        {!! $qrSvg !!}
                    </div>

                    <div class="mt-3 space-y-0.5">
                        <p class="font-heading text-lg font-bold text-text-primary">
                            Scan untuk pesan
                        </p>
                        <p class="font-body text-[11px] text-text-muted max-w-[240px]">
                            Arahkan kamera ponsel Anda ke kode QR untuk memilih meja dan memesan menu.
                        </p>
                    </div>
                </div>

                {{-- Footer Info --}}
                <div class="w-full pt-2 border-t border-dashed border-border-card text-[10px] font-sub text-text-muted flex items-center justify-between px-1">
                    <span>
                        @if ($profile?->open_time && $profile?->close_time)
                            Buka: {{ $profile->open_time }} – {{ $profile->close_time }}
                        @else
                            Buka: 08.00 – 17.00
                        @endif
                    </span>
                    <span>Tanpa Aplikasi</span>
                </div>
            </div>
        </div>
    </div>
</x-layouts.admin>
