#!/usr/bin/env bash
set -e

mkdir -p storage/app/public/logos storage/app/public/menus storage/app/public/qris
mkdir -p storage/framework/cache/data storage/framework/sessions storage/framework/views storage/logs

rm -rf public/storage
php artisan storage:link

php artisan migrate --force

if [ -n "${ADMIN_USERNAME:-}" ] && [ -n "${ADMIN_PASSWORD:-}" ]; then
    php artisan db:seed --force
fi

if [ "${SEED_WARUNG_CATALOG:-false}" = "true" ]; then
    php artisan db:seed --class=WarungCatalogSeeder --force
fi

php artisan optimize:clear
php artisan config:cache
php artisan route:cache
php artisan view:cache

exec php artisan serve --host=0.0.0.0 --port="${PORT:-8080}"
