<?php

namespace Tests\Unit;

use App\Enums\OrderStatus;
use PHPUnit\Framework\TestCase;

class OrderStatusTest extends TestCase
{
    public function test_labels_and_badge_colors_match_design_system(): void
    {
        $this->assertSame('Diterima', OrderStatus::Diterima->label());
        $this->assertSame('#2F8FE0', OrderStatus::Diterima->badgeColor());

        $this->assertSame('Diproses', OrderStatus::Diproses->label());
        $this->assertSame('#064E34', OrderStatus::Diproses->badgeColor());

        $this->assertSame('Disiapkan', OrderStatus::Disiapkan->label());
        $this->assertSame('#E8A21A', OrderStatus::Disiapkan->badgeColor());

        $this->assertSame('Siap Diantar', OrderStatus::Siap->label());
        $this->assertSame('#5A9158', OrderStatus::Siap->badgeColor());

        $this->assertSame('Selesai', OrderStatus::Selesai->label());
        $this->assertSame('#6B7280', OrderStatus::Selesai->badgeColor());

        $this->assertSame('Dibatalkan', OrderStatus::Dibatalkan->label());
        $this->assertSame('#C62828', OrderStatus::Dibatalkan->badgeColor());
    }

    public function test_next_returns_sequential_step(): void
    {
        $this->assertSame(OrderStatus::Diproses, OrderStatus::Diterima->next());
        $this->assertSame(OrderStatus::Disiapkan, OrderStatus::Diproses->next());
        $this->assertSame(OrderStatus::Siap, OrderStatus::Disiapkan->next());
        $this->assertSame(OrderStatus::Selesai, OrderStatus::Siap->next());
        $this->assertNull(OrderStatus::Selesai->next());
        $this->assertNull(OrderStatus::Dibatalkan->next());
    }

    public function test_can_transition_to_allows_only_forward_single_step_or_cancel_before_selesai(): void
    {
        // Forward 1 step is valid
        $this->assertTrue(OrderStatus::Diterima->canTransitionTo(OrderStatus::Diproses));
        $this->assertTrue(OrderStatus::Diproses->canTransitionTo(OrderStatus::Disiapkan));
        $this->assertTrue(OrderStatus::Disiapkan->canTransitionTo(OrderStatus::Siap));
        $this->assertTrue(OrderStatus::Siap->canTransitionTo(OrderStatus::Selesai));

        // Skipping steps or going backwards is invalid
        $this->assertFalse(OrderStatus::Diterima->canTransitionTo(OrderStatus::Disiapkan));
        $this->assertFalse(OrderStatus::Diterima->canTransitionTo(OrderStatus::Selesai));
        $this->assertFalse(OrderStatus::Diproses->canTransitionTo(OrderStatus::Diterima));
        $this->assertFalse(OrderStatus::Selesai->canTransitionTo(OrderStatus::Siap));

        // Cancel is allowed from any status before selesai
        $this->assertTrue(OrderStatus::Diterima->canTransitionTo(OrderStatus::Dibatalkan));
        $this->assertTrue(OrderStatus::Diproses->canTransitionTo(OrderStatus::Dibatalkan));
        $this->assertTrue(OrderStatus::Disiapkan->canTransitionTo(OrderStatus::Dibatalkan));
        $this->assertTrue(OrderStatus::Siap->canTransitionTo(OrderStatus::Dibatalkan));

        // Cancel is NOT allowed from selesai or dibatalkan
        $this->assertFalse(OrderStatus::Selesai->canTransitionTo(OrderStatus::Dibatalkan));
        $this->assertFalse(OrderStatus::Dibatalkan->canTransitionTo(OrderStatus::Dibatalkan));
        $this->assertFalse(OrderStatus::Dibatalkan->canTransitionTo(OrderStatus::Diproses));
    }

    public function test_is_active_returns_true_only_for_non_terminal_statuses(): void
    {
        $this->assertTrue(OrderStatus::Diterima->isActive());
        $this->assertTrue(OrderStatus::Diproses->isActive());
        $this->assertTrue(OrderStatus::Disiapkan->isActive());
        $this->assertTrue(OrderStatus::Siap->isActive());

        $this->assertFalse(OrderStatus::Selesai->isActive());
        $this->assertFalse(OrderStatus::Dibatalkan->isActive());
    }
}
