<?php

namespace Tests\Unit;

use PHPUnit\Framework\TestCase as PhpUnitTestCase;
use RuntimeException;
use Tests\TestCase;

class TestDatabaseGuardTest extends PhpUnitTestCase
{
    public function test_database_guard_rejects_database_without_test_suffix(): void
    {
        $this->expectException(RuntimeException::class);
        $this->expectExceptionMessage('Test hanya boleh berjalan di database yang namanya berakhiran _test');

        TestCase::ensureTestingDatabaseName('umkm_bakso');
    }

    public function test_database_guard_allows_database_with_test_suffix(): void
    {
        TestCase::ensureTestingDatabaseName('umkm_bakso_test');

        $this->assertTrue(true);
    }
}
