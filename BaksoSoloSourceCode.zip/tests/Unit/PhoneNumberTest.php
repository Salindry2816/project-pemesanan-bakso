<?php

namespace Tests\Unit;

use App\Support\PhoneNumber;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;

class PhoneNumberTest extends TestCase
{
    public function test_normalizes_various_indonesian_phone_formats_to_628(): void
    {
        $this->assertSame('6281234567890', PhoneNumber::normalize('0812-3456-7890'));
        $this->assertSame('6281234567890', PhoneNumber::normalize('+62 812 3456 7890'));
        $this->assertSame('6281234567890', PhoneNumber::normalize('6281234567890'));
        $this->assertSame('6281234567890', PhoneNumber::normalize('81234567890'));
        $this->assertSame('6285711223344', PhoneNumber::normalize('(0857) 1122.3344'));
    }

    public function test_validates_indonesian_mobile_numbers(): void
    {
        $this->assertTrue(PhoneNumber::isValid('081234567890'));
        $this->assertTrue(PhoneNumber::isValid('+6281234567890'));
        $this->assertTrue(PhoneNumber::isValid('628991234567'));

        $this->assertFalse(PhoneNumber::isValid(''));
        $this->assertFalse(PhoneNumber::isValid('08123'));
        $this->assertFalse(PhoneNumber::isValid('0215551234'));
        $this->assertFalse(PhoneNumber::isValid('abc0812345678'));
    }

    public function test_normalize_or_fail_throws_validation_exception_for_invalid_number(): void
    {
        $this->expectException(ValidationException::class);

        PhoneNumber::normalizeOrFail('12345', 'whatsapp');
    }
}
