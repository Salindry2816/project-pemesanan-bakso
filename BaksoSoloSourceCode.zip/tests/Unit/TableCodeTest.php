<?php

namespace Tests\Unit;

use App\Enums\TableType;
use App\Support\TableCode;
use InvalidArgumentException;
use PHPUnit\Framework\TestCase;

class TableCodeTest extends TestCase
{
    public function test_generates_floor_2_codes_2a_to_2g(): void
    {
        $codes = TableCode::range(2, 7);

        $this->assertSame(['2A', '2B', '2C', '2D', '2E', '2F', '2G'], $codes);
    }

    public function test_generates_first_code_for_floor_3_as_3a(): void
    {
        $this->assertSame('3A', TableCode::fromIndex(3, 0));
        $this->assertSame('3A', TableCode::nextForFloor(3, []));
    }

    public function test_next_for_floor_ignores_free_table_records_and_other_floors(): void
    {
        $existing = [
            ['code' => 'BEBAS', 'type' => TableType::Free],
            (object) ['code' => 'BEBAS', 'type' => 'free'],
            'BEBAS',
            '3Z',
            '2A',
            '2B',
        ];

        $this->assertSame('2C', TableCode::nextForFloor(2, $existing));
        $this->assertSame('3A', TableCode::nextForFloor(3, ['BEBAS', '2A', '2G']));
    }

    public function test_rejects_invalid_floor_numbers(): void
    {
        $this->expectException(InvalidArgumentException::class);
        TableCode::fromIndex(5, 0);
    }
}
