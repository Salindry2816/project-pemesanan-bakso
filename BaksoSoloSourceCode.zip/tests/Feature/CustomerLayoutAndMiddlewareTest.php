<?php

namespace Tests\Feature;

use App\Models\BusinessProfile;
use App\Models\Customer;
use App\Models\DiningTable;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\Route;
use Tests\TestCase;

class CustomerLayoutAndMiddlewareTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        Route::middleware(['web', 'customer.identified'])->get('/_test-customer-protected', function () {
            return response('Protected Customer Area');
        });
    }

    public function test_unidentified_customer_is_redirected_to_phone_page(): void
    {
        $response = $this->get('/_test-customer-protected');

        $response->assertRedirect(url('/'));
        $response->assertSessionHas('error', 'Masukkan nomor handphone kamu untuk melanjutkan pemesanan di Bakso Solo.');
    }

    public function test_unidentified_json_request_receives_401_unauthorized(): void
    {
        $response = $this->getJson('/_test-customer-protected');

        $response->assertStatus(401);
        $response->assertJson([
            'message' => 'Masukkan nomor handphone kamu untuk melanjutkan pemesanan di Bakso Solo.',
        ]);
    }

    public function test_invalid_customer_id_in_session_clears_session_and_redirects(): void
    {
        $response = $this->withSession([
            'customer_id' => 999999, // Non-existent ID
            'order_type' => 'dine_in',
            'table_id' => 1,
            'cart' => [1 => ['qty' => 2]],
        ])->get('/_test-customer-protected');

        $response->assertRedirect(url('/'));
        $response->assertSessionHas('error', 'Sesi tidak valid. Silakan masukkan nomor handphone Anda kembali.');
        $response->assertSessionMissing('customer_id');
        $response->assertSessionMissing('order_type');
        $response->assertSessionMissing('cart');
    }

    public function test_identified_customer_can_access_protected_route(): void
    {
        $customer = Customer::factory()->create([
            'phone' => '628123456789',
        ]);

        $response = $this->withSession([
            'customer_id' => $customer->id,
        ])->get('/_test-customer-protected');

        $response->assertOk();
        $response->assertSee('Protected Customer Area');
    }

    public function test_customer_layout_renders_business_profile_and_fonts(): void
    {
        BusinessProfile::unguarded(fn () => BusinessProfile::factory()->create([
            'id' => 1,
            'name' => 'Bakso Solo Asli',
            'tagline' => 'Kantin M Lantai 2',
            'logo_path' => 'business/test-logo.webp',
        ]));

        $html = Blade::render('<x-layouts.customer title="Uji Coba">Konten Halaman Pembeli</x-layouts.customer>');

        $this->assertStringContainsString('Bakso Solo Asli', $html);
        $this->assertStringContainsString('Kantin M Lantai 2', $html);
        $this->assertStringContainsString('Konten Halaman Pembeli', $html);
        $this->assertStringContainsString('fonts.googleapis.com', $html);
        $this->assertStringContainsString('Poppins', $html);
        $this->assertStringContainsString('Nunito', $html);
    }

    public function test_customer_layout_renders_table_badge_and_customer_phone_when_session_present(): void
    {
        $customer = Customer::factory()->create(['phone' => '628123456789']);
        $table = DiningTable::factory()->create(['code' => '2A', 'floor' => 2]);

        session([
            'customer_id' => $customer->id,
            'order_type' => 'dine_in',
            'table_id' => $table->id,
            'cart' => [
                1 => ['qty' => 3],
            ],
        ]);

        $html = Blade::render('<x-layouts.customer>Konten</x-layouts.customer>');

        $this->assertStringContainsString('Meja 2A', $html);
        $this->assertStringContainsString('08123456789', $html);
        $this->assertStringContainsString('3', $html); // Cart count
    }

    public function test_customer_layout_renders_take_away_badge(): void
    {
        $customer = Customer::factory()->create(['phone' => '628123456789']);

        session([
            'customer_id' => $customer->id,
            'order_type' => 'take_away',
        ]);

        $html = Blade::render('<x-layouts.customer>Konten</x-layouts.customer>');

        $this->assertStringContainsString('Bungkus', $html);
    }

    public function test_customer_layout_renders_flash_messages(): void
    {
        session()->flash('status', 'Pilihan meja berhasil disimpan.');
        session()->flash('error', 'Meja sedang terisi.');

        $html = Blade::render('<x-layouts.customer>Konten</x-layouts.customer>');

        $this->assertStringContainsString('Pilihan meja berhasil disimpan.', $html);
        $this->assertStringContainsString('Meja sedang terisi.', $html);
    }
}
