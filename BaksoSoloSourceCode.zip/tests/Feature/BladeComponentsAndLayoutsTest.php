<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use Illuminate\Support\Facades\Blade;
use Tests\TestCase;

class BladeComponentsAndLayoutsTest extends TestCase
{
    public function test_home_placeholder_returns_200_and_includes_shared_google_fonts(): void
    {
        $response = $this->get('/');

        $response->assertStatus(200);
        $response->assertSee('Bakso Solo');
        $response->assertSee('Warung Bu Susi');
        $response->assertSee('fonts.googleapis.com');
        $response->assertSee('Poppins');
        $response->assertSee('Nunito');
    }

    public function test_button_component_renders_variants_and_disabled_state(): void
    {
        $primary = Blade::render('<x-button variant="primary">Simpan Meja</x-button>');
        $this->assertStringContainsString('bg-primary-button', $primary);
        $this->assertStringContainsString('hover:bg-primary-button-hover', $primary);
        $this->assertStringContainsString('min-h-[52px]', $primary);
        $this->assertStringContainsString('Simpan Meja', $primary);

        $green = Blade::render('<x-button variant="green">Masuk</x-button>');
        $this->assertStringContainsString('bg-green-dark', $green);

        $outline = Blade::render('<x-button variant="outline">Lihat Denah Meja</x-button>');
        $this->assertStringContainsString('border-border-input', $outline);

        $disabled = Blade::render('<x-button :disabled="true">Nonaktif</x-button>');
        $this->assertStringContainsString('disabled', $disabled);
        $this->assertStringContainsString('bg-asset', $disabled);
    }

    public function test_input_component_renders_label_error_icon_slot_and_password_toggle(): void
    {
        $withError = Blade::render(
            '<x-input label="Username" name="username" error="Username wajib diisi." />'
        );
        $this->assertStringContainsString('Username', $withError);
        $this->assertStringContainsString('Username wajib diisi.', $withError);
        $this->assertStringContainsString('border-primary-button', $withError);

        $withPasswordToggle = Blade::render(
            '<x-input label="Password" name="password" type="password" :togglePassword="true" />'
        );
        $this->assertStringContainsString('showPassword', $withPasswordToggle);
        $this->assertStringContainsString('Tampilkan password', $withPasswordToggle);

        $withIcon = Blade::render(
            '<x-input label="Cari" name="search"><x-slot:icon><span id="custom-icon">ICON</span></x-slot:icon></x-input>'
        );
        $this->assertStringContainsString('custom-icon', $withIcon);
    }

    public function test_card_component_renders_border_radius_and_shadow(): void
    {
        $html = Blade::render('<x-card>Isi Kartu</x-card>');

        $this->assertStringContainsString('bg-white', $html);
        $this->assertStringContainsString('border-border-card', $html);
        $this->assertStringContainsString('shadow-card', $html);
        $this->assertStringContainsString('Isi Kartu', $html);
    }

    public function test_status_badge_component_renders_all_order_status_enum_cases(): void
    {
        foreach (OrderStatus::cases() as $status) {
            $html = Blade::render('<x-status-badge :status="$status" />', ['status' => $status]);

            $this->assertStringContainsString($status->label(), $html);
            $this->assertStringContainsString($status->badgeColor(), $html);
        }
    }

    public function test_admin_and_guest_admin_layouts_render_properly(): void
    {
        $adminHtml = Blade::render('<x-layouts.admin title="Dashboard">Konten Admin</x-layouts.admin>');
        $this->assertStringContainsString('Konten Admin', $adminHtml);
        $this->assertStringContainsString('Pesanan', $adminHtml);
        $this->assertStringContainsString('Cetak QR', $adminHtml);
        $this->assertStringContainsString('fonts.googleapis.com', $adminHtml);

        $guestHtml = Blade::render('<x-layouts.guest-admin title="Login Admin">Form Login</x-layouts.guest-admin>');
        $this->assertStringContainsString('Form Login', $guestHtml);
        $this->assertStringContainsString('fonts.googleapis.com', $guestHtml);
    }
}
