<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Livewire\Admin\SalesReport;
use App\Models\Customer;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use Tests\TestCase;

class AdminSalesReportTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::factory()->create(['username' => 'admin_laporan']);
    }

    public function test_guest_is_redirected_from_sales_report_to_login(): void
    {
        $this->get(route('admin.reports'))
            ->assertRedirect(route('admin.login'));
    }

    public function test_sales_report_calculates_revenue_top_menus_and_excludes_cancelled_or_unpaid(): void
    {
        $customer = Customer::factory()->create(['phone' => '6281234560011']);
        $today = now();

        // 1. Paid Cash order (should count)
        $paidCash = Order::factory()->create([
            'order_number' => $today->format('Ymd').'-0001',
            'customer_id' => $customer->id,
            'type' => OrderType::TakeAway,
            'subtotal' => 40000,
            'total' => 40000,
            'payment_method' => PaymentMethod::Cash,
            'payment_status' => PaymentStatus::Lunas,
            'status' => OrderStatus::Selesai,
            'paid_at' => $today,
        ]);
        OrderItem::create([
            'order_id' => $paidCash->id,
            'name_snapshot' => 'Bakso Komplit',
            'price_snapshot' => 18000,
            'qty' => 2,
            'line_total' => 36000,
        ]);
        OrderItem::create([
            'order_id' => $paidCash->id,
            'name_snapshot' => 'Es Teh / Teh Anget',
            'price_snapshot' => 4000,
            'qty' => 1,
            'line_total' => 4000,
        ]);

        // 2. Paid QRIS order (should count)
        $paidQris = Order::factory()->create([
            'order_number' => $today->format('Ymd').'-0002',
            'customer_id' => $customer->id,
            'type' => OrderType::TakeAway,
            'subtotal' => 22000,
            'total' => 22000,
            'payment_method' => PaymentMethod::Qris,
            'payment_status' => PaymentStatus::Lunas,
            'status' => OrderStatus::Siap,
            'paid_at' => $today,
        ]);
        OrderItem::create([
            'order_id' => $paidQris->id,
            'name_snapshot' => 'Bakso Mercon',
            'price_snapshot' => 22000,
            'qty' => 1,
            'line_total' => 22000,
        ]);

        // 3. Unpaid order (excluded from revenue & top menus, counted in total orders)
        $unpaid = Order::factory()->create([
            'order_number' => $today->format('Ymd').'-0003',
            'customer_id' => $customer->id,
            'type' => OrderType::TakeAway,
            'subtotal' => 50000,
            'total' => 50000,
            'payment_method' => PaymentMethod::Cash,
            'payment_status' => PaymentStatus::BelumBayar,
            'status' => OrderStatus::Diterima,
            'paid_at' => null,
        ]);
        OrderItem::create([
            'order_id' => $unpaid->id,
            'name_snapshot' => 'Bakso Unpaid',
            'price_snapshot' => 50000,
            'qty' => 1,
            'line_total' => 50000,
        ]);

        // 4. Cancelled order even if marked lunas (excluded from revenue & top menus)
        $cancelled = Order::factory()->create([
            'order_number' => $today->format('Ymd').'-0004',
            'customer_id' => $customer->id,
            'type' => OrderType::TakeAway,
            'subtotal' => 99000,
            'total' => 99000,
            'payment_method' => PaymentMethod::Qris,
            'payment_status' => PaymentStatus::Lunas,
            'status' => OrderStatus::Dibatalkan,
            'paid_at' => $today,
        ]);
        OrderItem::create([
            'order_id' => $cancelled->id,
            'name_snapshot' => 'Bakso Batal',
            'price_snapshot' => 99000,
            'qty' => 1,
            'line_total' => 99000,
        ]);

        $this->actingAs($this->admin);

        $this->get(route('admin.reports'))
            ->assertOk()
            ->assertSee('Grafik Penjualan')
            ->assertSee('Menu Paling Laris')
            ->assertSee('Rp 62.000')
            ->assertSee('Bakso Komplit')
            ->assertSee('2 porsi')
            ->assertDontSee('Bakso Unpaid')
            ->assertDontSee('Bakso Batal');

        Livewire::test(SalesReport::class)
            ->assertViewHas('totalRevenue', 62000)
            ->assertViewHas('paidTransactionsCount', 2)
            ->assertViewHas('totalOrdersCount', 4)
            ->assertViewHas('cancelledOrdersCount', 1)
            ->assertViewHas('unpaidOrdersCount', 1)
            ->assertViewHas('averageOrderValue', 31000)
            ->assertDispatched('sales-chart-updated')
            ->call('setPeriodMode', 'monthly')
            ->assertSet('periodMode', 'monthly')
            ->assertViewHas('totalRevenue', 62000)
            ->assertDispatched('sales-chart-updated');
    }

    public function test_sales_report_exports_csv_and_neutralizes_formula_injection(): void
    {
        $customer = Customer::factory()->create(['phone' => '6281234560012']);
        $today = now();

        $order = Order::factory()->create([
            'order_number' => $today->format('Ymd').'-0005',
            'customer_id' => $customer->id,
            'type' => OrderType::TakeAway,
            'subtotal' => 18000,
            'total' => 18000,
            'payment_method' => PaymentMethod::Cash,
            'payment_status' => PaymentStatus::Lunas,
            'status' => OrderStatus::Selesai,
            'paid_at' => $today,
        ]);
        OrderItem::create([
            'order_id' => $order->id,
            'name_snapshot' => '=SUM(A1:A2)',
            'price_snapshot' => 18000,
            'qty' => 1,
            'line_total' => 18000,
        ]);

        $this->actingAs($this->admin);

        $response = Livewire::test(SalesReport::class)
            ->call('exportCsv');

        $response->assertFileDownloaded();
        $csvContent = $response->effects['download']['content'] ?? '';
        $decoded = base64_decode($csvContent, true);
        $body = $decoded !== false ? $decoded : '';

        $this->assertStringContainsString("'=SUM(A1:A2)", $body);
        $this->assertStringNotContainsString(",=SUM(A1:A2)", $body);
    }
}
