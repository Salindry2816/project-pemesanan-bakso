<?php

namespace Tests\Feature;

use App\Models\Menu;
use App\Models\MenuCategory;
use App\Services\CartService;
use App\Services\CartSummary;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Session\ArraySessionHandler;
use Illuminate\Session\Store;
use Illuminate\Support\Facades\DB;
use InvalidArgumentException;
use Tests\TestCase;

class CartServiceTest extends TestCase
{
    use RefreshDatabase;

    private MenuCategory $category;

    private Menu $menuBakso;

    private Menu $menuEsTeh;

    private CartService $cart;

    protected function setUp(): void
    {
        parent::setUp();
        $this->startSession();

        $this->category = MenuCategory::factory()->create([
            'name' => 'Makanan',
            'sort_order' => 1,
        ]);

        $this->menuBakso = Menu::factory()->create([
            'category_id' => $this->category->id,
            'name' => 'Bakso Urat Spesial',
            'price' => 20000,
            'is_available' => true,
        ]);

        $this->menuEsTeh = Menu::factory()->create([
            'category_id' => $this->category->id,
            'name' => 'Es Teh Manis',
            'price' => 5000,
            'is_available' => true,
        ]);

        $this->cart = app(CartService::class);
    }

    public function test_add_new_item_and_same_item_increments_quantity_up_to_20(): void
    {
        // 1. Initial add
        $qty = $this->cart->add($this->menuBakso->id, 3);
        $this->assertSame(3, $qty);
        $this->assertSame(3, $this->cart->count());
        $this->assertSame(1, $this->cart->distinctCount());
        $this->assertFalse($this->cart->isEmpty());

        // 2. Add same item increments
        $qty = $this->cart->add($this->menuBakso->id, 5);
        $this->assertSame(8, $qty);
        $this->assertSame(8, $this->cart->count());

        // 3. Add exceeding 20 throws exception
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Jumlah pesanan untuk menu ini maksimal 20 porsi.');
        $this->cart->add($this->menuBakso->id, 13); // 8 + 13 = 21 > 20
    }

    public function test_add_rejects_quantity_less_than_one(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Jumlah pesanan minimal 1 porsi.');

        $this->cart->add($this->menuBakso->id, 0);
    }

    public function test_add_rejects_quantity_above_twenty_in_single_add(): void
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Jumlah pesanan untuk satu menu maksimal 20 porsi.');

        $this->cart->add($this->menuBakso->id, 25);
    }

    public function test_set_quantity_valid_zero_negative_and_above_limit(): void
    {
        // 1. Set valid quantity on new item
        $this->cart->setQuantity($this->menuBakso->id, 7);
        $this->assertSame(7, $this->cart->count());

        // 2. Update quantity on existing item
        $this->cart->setQuantity($this->menuBakso->id, 12);
        $this->assertSame(12, $this->cart->count());

        // 3. Set to 0 removes item
        $this->cart->setQuantity($this->menuBakso->id, 0);
        $this->assertSame(0, $this->cart->count());
        $this->assertTrue($this->cart->isEmpty());

        // 4. Negative quantity rejected
        try {
            $this->cart->setQuantity($this->menuEsTeh->id, -2);
            $this->fail('Expected InvalidArgumentException for negative quantity.');
        } catch (InvalidArgumentException $e) {
            $this->assertSame('Jumlah pesanan tidak boleh negatif.', $e->getMessage());
        }

        // 5. Quantity above 20 rejected
        try {
            $this->cart->setQuantity($this->menuEsTeh->id, 21);
            $this->fail('Expected InvalidArgumentException for quantity above 20.');
        } catch (InvalidArgumentException $e) {
            $this->assertSame('Jumlah pesanan untuk satu menu maksimal 20 porsi.', $e->getMessage());
        }
    }

    public function test_remove_item_from_cart(): void
    {
        $this->cart->add($this->menuBakso->id, 2);
        $this->cart->add($this->menuEsTeh->id, 3);
        $this->assertSame(5, $this->cart->count());
        $this->assertSame(2, $this->cart->distinctCount());

        $this->cart->remove($this->menuBakso->id);

        $this->assertSame(3, $this->cart->count());
        $this->assertSame(1, $this->cart->distinctCount());
        $lines = $this->cart->lines();
        $this->assertArrayNotHasKey($this->menuBakso->id, $lines);
        $this->assertArrayHasKey($this->menuEsTeh->id, $lines);

        // Removing non-existent item is safe and idempotent
        $this->cart->remove(9999);
        $this->assertSame(3, $this->cart->count());
    }

    public function test_item_note_validation_trim_empty_and_max_100_chars(): void
    {
        $this->cart->add($this->menuBakso->id, 2);

        // 1. Valid note trimmed
        $this->cart->setItemNote($this->menuBakso->id, '  Jangan pakai seledri, kuah banyak  ');
        $lines = $this->cart->lines();
        $this->assertSame('Jangan pakai seledri, kuah banyak', $lines[$this->menuBakso->id]['item_note']);

        // 2. Whitespace only note normalized to null
        $this->cart->setItemNote($this->menuBakso->id, '   ');
        $lines = $this->cart->lines();
        $this->assertNull($lines[$this->menuBakso->id]['item_note']);

        // 3. Null note
        $this->cart->setItemNote($this->menuBakso->id, null);
        $lines = $this->cart->lines();
        $this->assertNull($lines[$this->menuBakso->id]['item_note']);

        // 4. Note exceeding 100 chars rejected
        $tooLong = str_repeat('a', 101);
        try {
            $this->cart->setItemNote($this->menuBakso->id, $tooLong);
            $this->fail('Expected InvalidArgumentException for note > 100 chars.');
        } catch (InvalidArgumentException $e) {
            $this->assertSame('Catatan menu maksimal 100 karakter.', $e->getMessage());
        }

        // 5. Setting note on menu not in cart rejected
        try {
            $this->cart->setItemNote(9999, 'Catatan menu');
            $this->fail('Expected InvalidArgumentException for non-existent cart item.');
        } catch (InvalidArgumentException $e) {
            $this->assertSame('Menu tidak ada di dalam keranjang.', $e->getMessage());
        }
    }

    public function test_max_30_distinct_menu_items_enforced(): void
    {
        $menus = Menu::factory()->count(31)->create([
            'category_id' => $this->category->id,
            'is_available' => true,
        ]);

        // Add 30 items
        for ($i = 0; $i < 30; $i++) {
            $this->cart->add($menus[$i]->id, 1);
        }

        $this->assertSame(30, $this->cart->distinctCount());

        // 31st item rejected
        try {
            $this->cart->add($menus[30]->id, 1);
            $this->fail('Expected InvalidArgumentException for 31st distinct item.');
        } catch (InvalidArgumentException $e) {
            $this->assertSame('Keranjang belanja maksimal berisi 30 jenis menu berbeda.', $e->getMessage());
        }

        // Adding more to an existing item in the 30 is still allowed
        $newQty = $this->cart->add($menus[0]->id, 2);
        $this->assertSame(3, $newQty);
        $this->assertSame(30, $this->cart->distinctCount());
    }

    public function test_unavailable_or_non_existent_menu_rejected_on_add(): void
    {
        $unavailable = Menu::factory()->create([
            'category_id' => $this->category->id,
            'name' => 'Menu Habis',
            'is_available' => false,
        ]);

        try {
            $this->cart->add($unavailable->id, 1);
            $this->fail('Expected InvalidArgumentException for unavailable menu.');
        } catch (InvalidArgumentException $e) {
            $this->assertSame('Menu Menu Habis sedang tidak tersedia.', $e->getMessage());
        }

        try {
            $this->cart->add(99999, 1);
            $this->fail('Expected InvalidArgumentException for missing menu.');
        } catch (InvalidArgumentException $e) {
            $this->assertSame('Menu tidak ditemukan.', $e->getMessage());
        }
    }

    public function test_deleted_menu_marked_as_problem_line_and_excluded_from_total(): void
    {
        $this->cart->add($this->menuBakso->id, 2); // 2 x 20.000 = 40.000
        $this->cart->add($this->menuEsTeh->id, 1); // 1 x 5.000 = 5.000

        // Delete Es Teh from database
        $this->menuEsTeh->delete();

        $summary = $this->cart->summary();
        $this->assertInstanceOf(CartSummary::class, $summary);
        $this->assertTrue($summary->hasProblems);
        $this->assertCount(1, $summary->validLines);
        $this->assertCount(1, $summary->problemLines);

        // Valid line is only Bakso
        $this->assertSame($this->menuBakso->id, $summary->validLines[0]['menu_id']);
        $this->assertSame(40000, $summary->validLines[0]['line_total']);

        // Problem line is Es Teh
        $this->assertSame($this->menuEsTeh->id, $summary->problemLines[0]['menu_id']);
        $this->assertNull($summary->problemLines[0]['menu']);
        $this->assertSame('Menu sudah tidak ada atau telah dihapus', $summary->problemLines[0]['reason']);

        // Total excludes the deleted item!
        $this->assertSame(40000, $summary->total);

        // Clean up problem lines explicitly
        $removed = $this->cart->removeUnavailable();
        $this->assertSame(1, $removed);

        $newSummary = $this->cart->summary();
        $this->assertFalse($newSummary->hasProblems);
        $this->assertCount(1, $newSummary->validLines);
        $this->assertCount(0, $newSummary->problemLines);
        $this->assertSame(40000, $newSummary->total);
    }

    public function test_unavailable_menu_marked_as_problem_line_and_excluded_from_total(): void
    {
        $this->cart->add($this->menuBakso->id, 2); // 40.000
        $this->cart->add($this->menuEsTeh->id, 2); // 10.000

        // Deactivate Es Teh in database
        $this->menuEsTeh->update(['is_available' => false]);

        $summary = $this->cart->summary();
        $this->assertTrue($summary->hasProblems);
        $this->assertSame(40000, $summary->total);
        $this->assertCount(1, $summary->problemLines);
        $this->assertSame("Menu {$this->menuEsTeh->name} sedang tidak tersedia", $summary->problemLines[0]['reason']);

        // Summary does NOT silently remove the item from session
        $this->assertSame(4, $this->cart->count());

        // Explicit removeUnavailable removes it
        $this->cart->removeUnavailable();
        $this->assertSame(2, $this->cart->count());
        $this->assertFalse($this->cart->summary()->hasProblems);
    }

    public function test_price_change_in_database_is_reflected_in_summary_proving_no_price_in_session(): void
    {
        $this->cart->add($this->menuBakso->id, 2);

        $summary1 = $this->cart->summary();
        $this->assertSame(20000, $summary1->validLines[0]['unit_price']);
        $this->assertSame(40000, $summary1->total);

        // Update price in database
        $this->menuBakso->update(['price' => 25000]);

        $summary2 = $this->cart->summary();
        $this->assertSame(25000, $summary2->validLines[0]['unit_price']);
        $this->assertSame(50000, $summary2->total);

        // Inspect raw session: NO price key exists in session!
        $sessionData = session('cart');
        $this->assertArrayNotHasKey('price', $sessionData[$this->menuBakso->id]);
        $this->assertArrayNotHasKey('unit_price', $sessionData[$this->menuBakso->id]);
        $this->assertArrayNotHasKey('line_total', $sessionData[$this->menuBakso->id]);
    }

    public function test_integer_total_calculated_correctly_for_multiple_lines(): void
    {
        $menuGorengan = Menu::factory()->create([
            'category_id' => $this->category->id,
            'price' => 2500,
            'is_available' => true,
        ]);

        $this->cart->add($this->menuBakso->id, 3); // 3 x 20.000 = 60.000
        $this->cart->add($this->menuEsTeh->id, 4); // 4 x 5.000 = 20.000
        $this->cart->add($menuGorengan->id, 6);   // 6 x 2.500 = 15.000

        $summary = $this->cart->summary();
        $this->assertSame(95000, $summary->total);
        $this->assertIsInt($summary->total);
    }

    public function test_summary_eager_loads_and_has_no_n_plus_one_queries(): void
    {
        $menus = Menu::factory()->count(10)->create([
            'category_id' => $this->category->id,
            'is_available' => true,
        ]);

        foreach ($menus as $m) {
            $this->cart->add($m->id, 1);
        }

        DB::flushQueryLog();
        DB::enableQueryLog();

        $summary = $this->cart->summary();

        $queries = DB::getQueryLog();
        DB::disableQueryLog();

        $this->assertCount(10, $summary->validLines);
        // Exactly 2 batch queries: 1 for menus whereIn, 1 for categories whereIn (independent of cart item count, no N+1!)
        $this->assertCount(2, $queries);
        $this->assertStringContainsString('menus', strtolower($queries[0]['query']));
        $this->assertStringContainsString('in (', strtolower($queries[0]['query']));
        $this->assertStringContainsString('menu_categories', strtolower($queries[1]['query']));
        $this->assertStringContainsString('in (', strtolower($queries[1]['query']));
    }

    public function test_corrupted_or_manipulated_session_data_is_safely_normalized(): void
    {
        // 1. Session is non-array string
        session(['cart' => 'invalid_cart_string']);
        $this->assertSame(0, $this->cart->count());
        $this->assertSame([], $this->cart->lines());
        $this->assertFalse($this->cart->summary()->hasProblems);

        // 2. Session contains malformed entries
        session(['cart' => [
            'bad_key' => ['qty' => 5],
            -10 => ['qty' => 2],
            $this->menuBakso->id => ['qty' => -5],
            $this->menuEsTeh->id => ['qty' => 'not_a_number'],
            99991 => 4, // scalar quantity should normalize to valid array
            99992 => [
                'qty' => 25, // should cap to 20
                'item_note' => str_repeat('z', 150), // should truncate to 100
            ],
        ]]);

        $lines = $this->cart->lines();
        $this->assertArrayNotHasKey('bad_key', $lines);
        $this->assertArrayNotHasKey(-10, $lines);
        $this->assertArrayNotHasKey($this->menuBakso->id, $lines);
        $this->assertArrayNotHasKey($this->menuEsTeh->id, $lines);

        $this->assertArrayHasKey(99991, $lines);
        $this->assertSame(4, $lines[99991]['qty']);
        $this->assertNull($lines[99991]['item_note']);

        $this->assertArrayHasKey(99992, $lines);
        $this->assertSame(20, $lines[99992]['qty']);
        $this->assertSame(100, mb_strlen($lines[99992]['item_note']));
    }

    public function test_clear_empties_cart_and_preserves_other_session_keys(): void
    {
        $this->cart->add($this->menuBakso->id, 2);

        session([
            'order_note' => 'Jangan pakai sambal',
            'table_id' => 5,
            'order_type' => 'dine_in',
            'customer_id' => 99,
            'location_note' => 'Dekat kasir',
        ]);

        $this->cart->clear();

        $this->assertTrue($this->cart->isEmpty());
        $this->assertSame(0, $this->cart->count());

        // All other keys are intact!
        $this->assertSame('Jangan pakai sambal', session('order_note'));
        $this->assertSame(5, session('table_id'));
        $this->assertSame('dine_in', session('order_type'));
        $this->assertSame(99, session('customer_id'));
        $this->assertSame('Dekat kasir', session('location_note'));
    }

    public function test_session_isolation_between_different_sessions(): void
    {
        $store1 = new Store('sess1', new ArraySessionHandler(120));
        $store1->start();
        $cart1 = new CartService($store1);

        $store2 = new Store('sess2', new ArraySessionHandler(120));
        $store2->start();
        $cart2 = new CartService($store2);

        $cart1->add($this->menuBakso->id, 2);
        $cart2->add($this->menuEsTeh->id, 5);

        $this->assertSame(2, $cart1->count());
        $this->assertSame(5, $cart2->count());

        $this->assertArrayHasKey($this->menuBakso->id, $cart1->lines());
        $this->assertArrayNotHasKey($this->menuEsTeh->id, $cart1->lines());

        $this->assertArrayHasKey($this->menuEsTeh->id, $cart2->lines());
        $this->assertArrayNotHasKey($this->menuBakso->id, $cart2->lines());
    }

    public function test_service_container_resolves_cart_service_scoped_instance(): void
    {
        $service1 = app(CartService::class);
        $service2 = app(CartService::class);

        $this->assertInstanceOf(CartService::class, $service1);
        $this->assertSame($service1, $service2);
    }

    public function test_http_request_sequence_persists_cart_across_requests_with_same_session_cookie(): void
    {
        \Illuminate\Support\Facades\Route::middleware('web')->group(function () {
            \Illuminate\Support\Facades\Route::post('/_test/http-cart/add', function () {
                $menuId = (int) request('menu_id');
                $qty = (int) request('qty', 1);
                $newQty = app(CartService::class)->add($menuId, $qty);

                return response()->json(['qty' => $newQty]);
            });

            \Illuminate\Support\Facades\Route::get('/_test/http-cart/count', function () {
                return response()->json(['count' => app(CartService::class)->count()]);
            });

            \Illuminate\Support\Facades\Route::post('/_test/http-cart/login-regenerate', function () {
                session()->regenerate();

                return response()->json(['regenerated' => true]);
            });
        });

        // (a) Request 1 adds item, Request 2 (same session cookie) reads same item
        $res1 = $this->post('/_test/http-cart/add', [
            'menu_id' => $this->menuBakso->id,
            'qty' => 3,
        ]);
        $res1->assertOk();
        $res1->assertJson(['qty' => 3]);

        $res2 = $this->get('/_test/http-cart/count');
        $res2->assertOk();
        $res2->assertJson(['count' => 3]);

        // (b) Cart remains intact after session()->regenerate()
        $resLogin = $this->post('/_test/http-cart/login-regenerate');
        $resLogin->assertOk();

        $resAfterRegenerate = $this->get('/_test/http-cart/count');
        $resAfterRegenerate->assertOk();
        $resAfterRegenerate->assertJson(['count' => 3]);

        // (c) Two different sessions do not see each other's cart
        // Reset cookies/session to simulate different customer browser
        $this->flushSession();
        $resOtherCustomer = $this->get('/_test/http-cart/count');
        $resOtherCustomer->assertOk();
        $resOtherCustomer->assertJson(['count' => 0]);
    }

    public function test_cart_service_functions_properly_inside_livewire_component(): void
    {
        // (d) Running inside Livewire component with pre-existing cart session
        session(['cart' => [
            $this->menuBakso->id => ['qty' => 2, 'item_note' => 'Tanpa micin'],
        ]]);

        $livewireClass = new class extends \Livewire\Component {
            public int $itemCount = 0;

            public function mount(CartService $cart): void
            {
                $this->itemCount = $cart->count();
            }

            public function addMore(int $menuId, CartService $cart): void
            {
                $cart->add($menuId, 3);
                $this->itemCount = $cart->count();
            }

            public function render(): string
            {
                return '<div>Item count: {{ $itemCount }}</div>';
            }
        };

        \Livewire\Livewire::test($livewireClass::class)
            ->assertSee('Item count: 2')
            ->call('addMore', $this->menuEsTeh->id)
            ->assertSee('Item count: 5');

        $this->assertSame(5, app(CartService::class)->count());
        $this->assertSame(2, app(CartService::class)->distinctCount());
    }
}
