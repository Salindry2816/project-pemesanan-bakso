<?php

namespace Tests\Feature;

use App\Support\MediaStorage;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Tests\TestCase;

class MediaStorageTest extends TestCase
{
    private array $tempFiles = [];

    protected function tearDown(): void
    {
        foreach ($this->tempFiles as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }

        parent::tearDown();
    }

    public function test_stores_and_resizes_image_proportionally_and_replaces_old_file(): void
    {
        Storage::fake('public');
        config(['filesystems.media_disk' => 'public']);

        $firstFile = $this->createPngUploadedFile(1600, 1200, 'original-name.png');
        $firstPath = MediaStorage::storeImage($firstFile, 'menus');

        Storage::disk('public')->assertExists($firstPath);
        $this->assertStringStartsWith('menus/', $firstPath);
        $this->assertStringNotContainsString('original-name', $firstPath);
        $this->assertMatchesRegularExpression('#^menus/[0-9a-hjkmnp-tv-z]{26}\.png$#', $firstPath);

        $storedBinary = Storage::disk('public')->get($firstPath);
        $info = getimagesizefromstring($storedBinary);
        $this->assertNotFalse($info);
        $this->assertSame(800, $info[0]);
        $this->assertSame(600, $info[1]);

        // Replace with a second image and verify old file is deleted
        $secondFile = $this->createPngUploadedFile(400, 300, 'second.png');
        $secondPath = MediaStorage::storeImage($secondFile, 'menus', oldPath: $firstPath);

        Storage::disk('public')->assertMissing($firstPath);
        Storage::disk('public')->assertExists($secondPath);

        $secondInfo = getimagesizefromstring(Storage::disk('public')->get($secondPath));
        $this->assertSame(400, $secondInfo[0]);
        $this->assertSame(300, $secondInfo[1]);
    }

    public function test_old_file_remains_intact_when_replacement_validation_or_storage_write_fails(): void
    {
        Storage::fake('public');
        config(['filesystems.media_disk' => 'public']);

        $initialFile = $this->createPngUploadedFile(400, 300, 'initial.png');
        $initialPath = MediaStorage::storeImage($initialFile, 'menus');
        Storage::disk('public')->assertExists($initialPath);

        // 1. Replacement fails validation (corrupt/non-image file) -> old file must remain intact
        $invalidReplacement = $this->createUploadedFileFromBytes('not-an-image', 'bad.jpg', 'image/jpeg');

        try {
            MediaStorage::storeImage($invalidReplacement, 'menus', oldPath: $initialPath);
            $this->fail('Expected ValidationException was not thrown.');
        } catch (ValidationException) {
            Storage::disk('public')->assertExists($initialPath);
        }

        // 2. Replacement fails when disk->put() returns false -> old file must not be deleted
        $validReplacement = $this->createPngUploadedFile(500, 400, 'replacement.png');
        $deletedPaths = [];

        $mockDisk = \Mockery::mock(\Illuminate\Contracts\Filesystem\Filesystem::class);
        $mockDisk->shouldReceive('put')->once()->andReturn(false);
        $mockDisk->shouldReceive('delete')->andReturnUsing(function (string $path) use (&$deletedPaths) {
            $deletedPaths[] = $path;

            return true;
        });

        Storage::shouldReceive('disk')->with('public')->andReturn($mockDisk);

        try {
            MediaStorage::storeImage($validReplacement, 'menus', oldPath: $initialPath);
            $this->fail('Expected ValidationException when disk->put() returns false.');
        } catch (ValidationException $e) {
            $this->assertArrayHasKey('photo', $e->errors());
            $this->assertEmpty($deletedPaths);
        }
    }

    public function test_preserves_png_alpha_transparency_on_resize(): void
    {
        Storage::fake('public');
        config(['filesystems.media_disk' => 'public']);

        $img = imagecreatetruecolor(1000, 1000);
        imagealphablending($img, false);
        imagesavealpha($img, true);
        $transparent = imagecolorallocatealpha($img, 0, 0, 0, 127);
        imagefilledrectangle($img, 0, 0, 1000, 1000, $transparent);

        ob_start();
        imagepng($img);
        $pngBytes = (string) ob_get_clean();

        $file = $this->createUploadedFileFromBytes($pngBytes, 'transparent.png', 'image/png');
        $path = MediaStorage::storeImage($file, 'logos');

        $storedBytes = Storage::disk('public')->get($path);
        $reloaded = imagecreatefromstring($storedBytes);
        $this->assertNotFalse($reloaded);
        $this->assertSame(800, imagesx($reloaded));
        $this->assertSame(800, imagesy($reloaded));

        $rgba = imagecolorsforindex($reloaded, imagecolorat($reloaded, 10, 10));
        $this->assertSame(127, $rgba['alpha']);
    }

    public function test_applies_exif_orientation_before_resize_and_strips_exif(): void
    {
        Storage::fake('public');
        config(['filesystems.media_disk' => 'public']);

        // Create a 1000x500 landscape JPEG with EXIF Orientation = 6 (90° CW -> should become 500x1000 portrait, then resized to 400x800)
        $jpegWithExif = $this->createJpegWithExifOrientation(1000, 500, 6);
        $file = $this->createUploadedFileFromBytes($jpegWithExif, 'rotated.jpg', 'image/jpeg');

        $path = MediaStorage::storeImage($file, 'menus');

        $storedBytes = Storage::disk('public')->get($path);
        $info = getimagesizefromstring($storedBytes);
        $this->assertNotFalse($info);

        // After applying Orientation=6 (becomes 500x1000) and resizing max 800px, dimensions must be 400x800
        $this->assertSame(400, $info[0]);
        $this->assertSame(800, $info[1]);

        // Verify EXIF header is stripped in the re-encoded JPEG
        $tmpCheck = tempnam(sys_get_temp_dir(), 'exif_check_');
        $this->tempFiles[] = $tmpCheck;
        file_put_contents($tmpCheck, $storedBytes);
        $exifAfter = @exif_read_data($tmpCheck);
        $this->assertFalse(isset($exifAfter['Orientation']));
    }

    public function test_rejects_non_image_file_with_jpg_extension(): void
    {
        Storage::fake('public');
        config(['filesystems.media_disk' => 'public']);

        $fakeJpg = $this->createUploadedFileFromBytes(
            "<?php echo 'malicious payload'; ?> not an image",
            'evil.jpg',
            'image/jpeg'
        );

        try {
            MediaStorage::storeImage($fakeJpg, 'menus');
            $this->fail('Expected ValidationException was not thrown for non-image payload.');
        } catch (ValidationException $e) {
            $this->assertArrayHasKey('photo', $e->errors());
            $this->assertStringContainsString('JPG, PNG, atau WebP', $e->errors()['photo'][0]);
        }
    }

    public function test_rejects_image_exceeding_maximum_pixel_dimensions(): void
    {
        Storage::fake('public');
        config(['filesystems.media_disk' => 'public']);

        // Minimal PNG header with width = 6001, height = 100 (IHDR chunk) so we don't even allocate huge memory in test
        $oversizedPng = $this->createMinimalPngHeader(6001, 100);
        $file = $this->createUploadedFileFromBytes($oversizedPng, 'huge.png', 'image/png');

        try {
            MediaStorage::storeImage($file, 'menus');
            $this->fail('Expected ValidationException was not thrown for oversized image.');
        } catch (ValidationException $e) {
            $this->assertArrayHasKey('photo', $e->errors());
            $this->assertStringContainsString('6000x6000', $e->errors()['photo'][0]);
        }
    }

    public function test_qris_image_is_not_resized_and_keeps_original_dimensions_and_format(): void
    {
        Storage::fake('public');
        config(['filesystems.media_disk' => 'public']);

        $qrisFile = $this->createPngUploadedFile(1240, 1754, 'qris-statis.png');
        $path = MediaStorage::storeQris($qrisFile, 'qris');

        Storage::disk('public')->assertExists($path);
        $this->assertStringEndsWith('.png', $path);

        $storedBytes = Storage::disk('public')->get($path);
        $info = getimagesizefromstring($storedBytes);
        $this->assertNotFalse($info);
        $this->assertSame(1240, $info[0]);
        $this->assertSame(1754, $info[1]);
        $this->assertSame(IMAGETYPE_PNG, $info[2]);
    }

    private function createPngUploadedFile(int $width, int $height, string $clientName): UploadedFile
    {
        $img = imagecreatetruecolor($width, $height);
        $red = imagecolorallocate($img, 198, 40, 40);
        imagefilledrectangle($img, 0, 0, $width, $height, $red);

        ob_start();
        imagepng($img);
        $bytes = (string) ob_get_clean();

        return $this->createUploadedFileFromBytes($bytes, $clientName, 'image/png');
    }

    private function createUploadedFileFromBytes(string $bytes, string $clientName, string $mime): UploadedFile
    {
        $tmpPath = tempnam(sys_get_temp_dir(), 'media_test_');
        $this->tempFiles[] = $tmpPath;
        file_put_contents($tmpPath, $bytes);

        return new UploadedFile($tmpPath, $clientName, $mime, null, true);
    }

    private function createJpegWithExifOrientation(int $width, int $height, int $orientation): string
    {
        $img = imagecreatetruecolor($width, $height);
        $green = imagecolorallocate($img, 6, 78, 52);
        imagefilledrectangle($img, 0, 0, $width, $height, $green);

        ob_start();
        imagejpeg($img, null, 90);
        $rawJpeg = (string) ob_get_clean();

        // Build minimal APP1 Exif segment (little-endian TIFF header + 1 IFD entry for Orientation 0x0112)
        $tiff = "II\x2A\x00\x08\x00\x00\x00" // Little-endian, magic 42, offset to IFD0 = 8
            ."\x01\x00" // 1 directory entry
            ."\x12\x01" // Tag 0x0112 (Orientation)
            ."\x03\x00" // Type 3 (SHORT)
            ."\x01\x00\x00\x00" // Count = 1
            .pack('v', $orientation)."\x00\x00" // Value
            ."\x00\x00\x00\x00"; // Next IFD offset = 0

        $app1Payload = "Exif\x00\x00".$tiff;
        $app1Segment = "\xFF\xE1".pack('n', strlen($app1Payload) + 2).$app1Payload;

        // Insert APP1 right after SOI (\xFF\xD8)
        return "\xFF\xD8".$app1Segment.substr($rawJpeg, 2);
    }

    private function createMinimalPngHeader(int $width, int $height): string
    {
        $ihdrData = pack('NNCCCCC', $width, $height, 8, 2, 0, 0, 0);
        $ihdrChunk = pack('N', 13).'IHDR'.$ihdrData.pack('N', crc32('IHDR'.$ihdrData));
        $iendChunk = pack('N', 0).'IEND'.pack('N', crc32('IEND'));

        return "\x89PNG\r\n\x1a\n".$ihdrChunk.$iendChunk;
    }
}
