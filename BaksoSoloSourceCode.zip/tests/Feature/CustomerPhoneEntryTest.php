<?php

namespace Tests\Feature;

use App\Livewire\Customer\PhoneEntry;
use App\Models\BusinessProfile;
use App\Models\Customer;
use App\Models\DiningTable;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Blade;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;
use Livewire\Livewire;
use Tests\TestCase;

class CustomerPhoneEntryTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();
        $this->startSession();
        RateLimiter::clear('phone-entry:fail:ip:127.0.0.1');
        RateLimiter::clear('phone-entry:success:ip:127.0.0.1');
    }

    public function test_phone_entry_page_renders_properly_with_figma_elements(): void
    {
        BusinessProfile::unguarded(fn () => BusinessProfile::factory()->create([
            'id' => 1,
            'name' => 'Bakso Solo Bu Susi',
            'tagline' => 'Kantin M Lt. 2 UNJ',
        ]));

        $response = $this->get(route('customer.phone'));

        $response->assertOk();
        $response->assertSee('Selamat Datang!');
        $response->assertSee('Bakso Solo Bu Susi');
        $response->assertSee('+62');
        $response->assertSee('Nomor Handphone');
        $response->assertSee('Masuk');
        $response->assertSee('Nomor handphone kamu akan digunakan untuk akses pemesanan');
    }

    public function test_customer_can_login_with_various_valid_indonesian_phone_formats(): void
    {
        // 1. Format 081234567890
        Livewire::test(PhoneEntry::class)
            ->set('phone', '081234567890')
            ->call('submit')
            ->assertHasNoErrors()
            ->assertRedirect(url('/pilih-meja'));

        $this->assertDatabaseHas('customers', [
            'phone' => '6281234567890',
        ]);

        $this->assertEquals(
            Customer::where('phone', '6281234567890')->value('id'),
            session('customer_id')
        );

        // Reset session customer_id to simulate new login attempt
        session()->forget('customer_id');

        // 2. Format with prefix +62
        Livewire::test(PhoneEntry::class)
            ->set('phone', '+6281299998888')
            ->call('submit')
            ->assertHasNoErrors();

        $this->assertDatabaseHas('customers', [
            'phone' => '6281299998888',
        ]);

        // Reset session customer_id to simulate new login attempt
        session()->forget('customer_id');

        // 3. Format starting with 8 directly (from UI +62 badge)
        Livewire::test(PhoneEntry::class)
            ->set('phone', '81277776666')
            ->call('submit')
            ->assertHasNoErrors();

        $this->assertDatabaseHas('customers', [
            'phone' => '6281277776666',
        ]);
    }

    public function test_empty_and_invalid_phone_numbers_are_rejected(): void
    {
        // Empty
        Livewire::test(PhoneEntry::class)
            ->set('phone', '   ')
            ->call('submit')
            ->assertHasErrors(['phone'])
            ->assertSee('Nomor handphone wajib diisi.');

        // Too short
        Livewire::test(PhoneEntry::class)
            ->set('phone', '08123')
            ->call('submit')
            ->assertHasErrors(['phone'])
            ->assertSee('Format nomor handphone tidak valid');

        // Landline / invalid operator prefix (021)
        Livewire::test(PhoneEntry::class)
            ->set('phone', '0217654321')
            ->call('submit')
            ->assertHasErrors(['phone'])
            ->assertSee('Format nomor handphone tidak valid');

        // Non-numeric
        Livewire::test(PhoneEntry::class)
            ->set('phone', '0812abcd3456')
            ->call('submit')
            ->assertHasErrors(['phone'])
            ->assertSee('Format nomor handphone tidak valid');
    }

    public function test_fifteen_different_valid_customers_from_same_ip_can_login_without_being_blocked(): void
    {
        for ($i = 1; $i <= 15; $i++) {
            session()->forget('customer_id');

            $validPhone = sprintf('0812%08d', $i);
            Livewire::test(PhoneEntry::class)
                ->set('phone', $validPhone)
                ->call('submit')
                ->assertHasNoErrors()
                ->assertRedirect(url('/pilih-meja'));

            $normalized = '62812' . sprintf('%08d', $i);
            $this->assertDatabaseHas('customers', ['phone' => $normalized]);
        }
    }

    public function test_eleven_failed_attempts_from_same_ip_are_blocked(): void
    {
        $component = Livewire::test(PhoneEntry::class);

        for ($i = 1; $i <= 10; $i++) {
            $component->set('phone', '021' . $i)
                ->call('submit')
                ->assertHasErrors(['phone']);
        }

        // 11th failed attempt must be blocked
        $component->set('phone', 'invalid-phone-11')
            ->call('submit')
            ->assertHasErrors(['phone'])
            ->assertSee('Terlalu banyak percobaan gagal dari perangkat ini.');
    }

    public function test_five_failed_attempts_for_same_phone_are_blocked_and_reset_on_success(): void
    {
        RateLimiter::clear('phone-entry:fail:phone:6281234567890');

        $component = Livewire::test(PhoneEntry::class);

        // 4 failed attempts with invalid format candidate
        for ($i = 0; $i < 4; $i++) {
            $component->set('phone', '081234567890-invalid')
                ->call('submit')
                ->assertHasErrors(['phone']);
        }

        // Now user enters valid phone format for that number -> success clears failure key
        $component->set('phone', '081234567890')
            ->call('submit')
            ->assertHasNoErrors();

        $this->assertEquals(0, RateLimiter::attempts('phone-entry:fail:phone:6281234567890'));

        // Reset session customer_id to test that failure count was indeed reset
        session()->forget('customer_id');

        // Can attempt with this phone without being immediately blocked
        Livewire::test(PhoneEntry::class)
            ->set('phone', '081234567890-invalid')
            ->call('submit')
            ->assertHasErrors(['phone'])
            ->assertDontSee('Terlalu banyak percobaan untuk nomor ini.');
    }

    public function test_different_phone_from_previous_session_resets_cart_and_table(): void
    {
        $customerA = Customer::factory()->create(['phone' => '6281211111111']);
        $customerB = Customer::factory()->create(['phone' => '6281222222222']);

        // Set previous session state for Customer A
        session([
            'customer_id' => $customerA->id,
            'order_type' => 'dine_in',
            'table_id' => 5,
            'location_note' => 'Dekat pintu',
            'cart' => [1 => ['qty' => 2]],
        ]);

        // Customer enters Customer B's phone number on phone entry
        Livewire::withQueryParams(['ganti' => 1])
            ->test(PhoneEntry::class)
            ->set('phone', $customerB->phone)
            ->call('submit')
            ->assertHasNoErrors();

        // Customer B has clean state (previous cart & table wiped)
        $this->assertEquals($customerB->id, session('customer_id'));
        $this->assertNull(session('order_type'));
        $this->assertNull(session('table_id'));
        $this->assertNull(session('location_note'));
        $this->assertNull(session('cart'));
    }

    public function test_same_phone_from_previous_session_preserves_cart_and_table(): void
    {
        $customerA = Customer::factory()->create(['phone' => '6281211111111']);

        // Set previous session state for Customer A
        session([
            'customer_id' => $customerA->id,
            'order_type' => 'dine_in',
            'table_id' => 5,
            'location_note' => 'Dekat pintu',
            'cart' => [1 => ['qty' => 2]],
        ]);

        // Customer enters same Customer A's phone number
        Livewire::withQueryParams(['ganti' => 1])
            ->test(PhoneEntry::class)
            ->set('phone', $customerA->phone)
            ->call('submit')
            ->assertHasNoErrors();

        // Customer A preserves existing cart and table
        $this->assertEquals($customerA->id, session('customer_id'));
        $this->assertEquals('dine_in', session('order_type'));
        $this->assertEquals(5, session('table_id'));
        $this->assertEquals('Dekat pintu', session('location_note'));
        $this->assertEquals([1 => ['qty' => 2]], session('cart'));
    }

    public function test_already_identified_customer_visiting_home_is_redirected_appropriately(): void
    {
        $customer = Customer::factory()->create(['phone' => '628123456789']);

        // 1. Without table -> redirected to /pilih-meja
        $response = $this->withSession([
            'customer_id' => $customer->id,
        ])->get(route('customer.phone'));

        $response->assertRedirect(url('/pilih-meja'));

        // 2. With table -> redirected to /menu
        $table = DiningTable::factory()->create(['code' => '2A', 'floor' => 2]);
        $response = $this->withSession([
            'customer_id' => $customer->id,
            'order_type' => 'dine_in',
            'table_id' => $table->id,
        ])->get(route('customer.phone'));

        $response->assertRedirect(url('/menu'));
    }

    public function test_ganti_nomor_endpoint_clears_customer_session_and_redirects(): void
    {
        $customer = Customer::factory()->create(['phone' => '628123456789']);

        $response = $this->withSession([
            'customer_id' => $customer->id,
            'order_type' => 'dine_in',
            'table_id' => 3,
            'cart' => [1 => ['qty' => 3]],
        ])->post(route('customer.reset'));

        $response->assertRedirect(route('customer.phone'));
        $response->assertSessionHas('status', 'Sesi telah direset. Silakan masukkan nomor handphone baru.');
        $response->assertSessionMissing('customer_id');
        $response->assertSessionMissing('order_type');
        $response->assertSessionMissing('table_id');
        $response->assertSessionMissing('cart');
    }

    public function test_customer_layout_renders_ganti_button_with_post_method_and_csrf(): void
    {
        $customer = Customer::factory()->create(['phone' => '628123456789']);

        session([
            'customer_id' => $customer->id,
        ]);

        $html = Blade::render('<x-layouts.customer>Konten</x-layouts.customer>');

        // Check that layout renders (Ganti) button with form POST to customer.reset
        $this->assertStringContainsString('(Ganti)', $html);
        $this->assertStringContainsString('method="POST"', $html);
        $this->assertStringContainsString(route('customer.reset'), $html);
    }
}
