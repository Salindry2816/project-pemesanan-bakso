<?php

namespace Tests\Feature;

use App\Enums\TableType;
use App\Livewire\Customer\OrderConfirmation;
use App\Models\BusinessProfile;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderStatusLog;
use App\Services\CartService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Livewire\Livewire;
use Tests\TestCase;

class CustomerOrderConfirmationTest extends TestCase
{
    use RefreshDatabase;

    private Customer $customer;

    private DiningTable $table;

    private MenuCategory $categoryMakanan;

    private MenuCategory $categoryMinuman;

    private Menu $menuBakso;

    private Menu $menuEsTeh;

    protected function setUp(): void
    {
        parent::setUp();
        $this->startSession();

        BusinessProfile::factory()->create([
            'name' => 'Bakso Solo Bu Susi',
            'tagline' => 'Kantin M Lt. 2 UNJ',
        ]);

        $this->customer = Customer::factory()->create([
            'phone' => '6281234567890',
            'name' => 'Budi Santoso',
        ]);

        $this->table = DiningTable::factory()->create([
            'code' => '2A',
            'floor' => 2,
            'capacity' => 4,
            'type' => TableType::Fixed,
            'is_active' => true,
        ]);

        $this->categoryMakanan = MenuCategory::factory()->create([
            'name' => 'Makanan',
            'sort_order' => 1,
        ]);

        $this->categoryMinuman = MenuCategory::factory()->create([
            'name' => 'Minuman',
            'sort_order' => 2,
        ]);

        $this->menuBakso = Menu::factory()->create([
            'category_id' => $this->categoryMakanan->id,
            'name' => 'Bakso Komplit',
            'description' => 'Bakso halus, urat, dan tahu.',
            'price' => 18000,
            'is_available' => true,
        ]);

        $this->menuEsTeh = Menu::factory()->create([
            'category_id' => $this->categoryMinuman->id,
            'name' => 'Es Teh Manis',
            'description' => 'Segar manis dingin.',
            'price' => 5000,
            'is_available' => true,
        ]);
    }

    private function actingAsCustomerSession(array $overrides = []): self
    {
        return $this->withSession(array_merge([
            'customer_id' => $this->customer->id,
            'order_type' => 'dine_in',
            'table_id' => $this->table->id,
            'location_note' => null,
        ], $overrides));
    }

    public function test_guest_without_phone_session_is_redirected_to_home(): void
    {
        $response = $this->get(route('customer.confirm'));

        $response->assertRedirect(route('customer.phone'));
        $response->assertSessionHas('error', 'Masukkan nomor handphone kamu untuk melanjutkan pemesanan di Bakso Solo.');
    }

    public function test_customer_without_table_session_is_redirected_to_table_selection(): void
    {
        $response = $this->withSession([
            'customer_id' => $this->customer->id,
        ])->get(route('customer.confirm'));

        $response->assertRedirect(route('customer.table'));
        $response->assertSessionHas('error', 'Silakan pilih meja atau bungkus terlebih dahulu.');
    }

    public function test_customer_with_empty_cart_is_redirected_to_menu_with_flash(): void
    {
        $this->actingAsCustomerSession();
        app(CartService::class)->clear();

        $response = $this->get(route('customer.confirm'));

        $response->assertRedirect(route('customer.menu'));
        $response->assertSessionHas('error', 'Keranjang belanja masih kosong. Silakan pilih menu terlebih dahulu.');
    }

    public function test_customer_with_problem_items_is_redirected_to_cart_with_flash(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);
        $cart->add($this->menuEsTeh->id, 1);

        // Deactivate one menu in cart
        $this->menuEsTeh->update(['is_available' => false]);

        $response = $this->get(route('customer.confirm'));

        $response->assertRedirect(route('customer.cart'));
        $response->assertSessionHas('error', 'Beberapa menu tidak tersedia, periksa keranjang.');
    }

    public function test_order_confirmation_renders_summary_from_database(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 2); // 2 x 18.000 = 36.000
        $cart->setItemNote($this->menuBakso->id, 'Tanpa seledri');
        $cart->add($this->menuEsTeh->id, 1);  // 1 x 5.000 = 5.000

        $component = Livewire::test(OrderConfirmation::class);

        $component->assertOk();
        $component->assertSee('Konfirmasi Pesanan');
        $component->assertSee('Lantai 2');
        $component->assertSee('Meja 2A');
        $component->assertSee('Bakso Komplit');
        $component->assertSee('2x @ Rp 18.000');
        $component->assertSee('Rp 36.000');
        $component->assertSee('Catatan: Tanpa seledri');
        $component->assertSee('Es Teh Manis');
        $component->assertSee('1x @ Rp 5.000');
        $component->assertSee('Rp 41.000'); // total 36.000 + 5.000
        $component->assertSee('0812-****-7890'); // masked phone
    }

    public function test_payment_button_is_disabled_and_no_orders_created(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);

        $initialOrdersCount = Order::query()->count();
        $initialOrderItemsCount = OrderItem::query()->count();
        $initialLogsCount = OrderStatusLog::query()->count();

        $component = Livewire::test(OrderConfirmation::class);

        $component->assertSee('Metode Pembayaran');
        $component->assertSee('Buat Pesanan');

        // Confirm database records are strictly untouched
        $this->assertSame($initialOrdersCount, Order::query()->count());
        $this->assertSame($initialOrderItemsCount, OrderItem::query()->count());
        $this->assertSame($initialLogsCount, OrderStatusLog::query()->count());
    }

    public function test_customer_can_save_order_note_and_validation_enforces_max_200_chars(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);

        $component = Livewire::test(OrderConfirmation::class);

        // 1. Valid note <= 200 chars
        $component->set('orderNote', 'Tolong jangan terlalu pedas, kecap dipisah.');
        $component->assertHasNoErrors();
        $this->assertSame('Tolong jangan terlalu pedas, kecap dipisah.', session('order_note'));

        // 2. Note > 200 chars is rejected with Indonesian message
        $tooLong = str_repeat('b', 201);
        $component->set('orderNote', $tooLong);
        $component->assertHasErrors(['orderNote']);
        $component->assertSee('Catatan pesanan maksimal 200 karakter.');

        // Session retains previously valid note
        $this->assertSame('Tolong jangan terlalu pedas, kecap dipisah.', session('order_note'));

        // 3. New component mount reloads saved note from session
        $component2 = Livewire::test(OrderConfirmation::class);
        $this->assertSame('Tolong jangan terlalu pedas, kecap dipisah.', $component2->get('orderNote'));
    }

    public function test_database_price_changes_are_reflected_live(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 2); // 2 x 18.000 = 36.000

        $component = Livewire::test(OrderConfirmation::class);
        $component->assertSee('Rp 36.000');

        // Admin updates price in DB
        $this->menuBakso->update(['price' => 20000]);

        // Render again: 2 x 20.000 = 40.000
        $component2 = Livewire::test(OrderConfirmation::class);
        $component2->assertSee('Rp 40.000');
        $component2->assertSee('2x @ Rp 20.000');
    }

    public function test_occupied_or_inactive_table_redirects_to_table_selection(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);

        // Table is deactivated
        $this->table->update(['is_active' => false]);

        $response = $this->get(route('customer.confirm'));
        $response->assertRedirect(route('customer.table'));
        $response->assertSessionHas('error', 'Meja yang kamu pilih sedang tidak aktif. Silakan pilih meja lain.');
    }

    public function test_no_n_plus_one_queries_on_order_confirmation(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();

        // 8 menus
        $menus = Menu::factory()->count(8)->create([
            'category_id' => $this->categoryMakanan->id,
            'is_available' => true,
        ]);

        foreach ($menus as $m) {
            $cart->add($m->id, 1);
        }

        DB::flushQueryLog();
        DB::enableQueryLog();

        Livewire::test(OrderConfirmation::class);

        $queries = DB::getQueryLog();
        DB::disableQueryLog();

        // Summary should execute a single Menu query (with category eager loaded)
        // rather than 1 query per item in cart.
        // Total queries for component mount + render + layout should not scale with cart size.
        $this->assertLessThanOrEqual(8, count($queries), 'Query count indicates an N+1 query issue.');
    }

    public function test_all_customer_layout_navigation_links_point_to_active_registered_routes(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);

        $response = $this->get(route('customer.confirm'));

        $response->assertOk();
        $response->assertSee(route('customer.table'));
        $response->assertSee(route('customer.menu'));
        $response->assertSee(route('customer.cart'));
        $response->assertSee(route('customer.profile'));
        $response->assertSee(route('customer.reset'));
    }

    public function test_no_route_has_calls_remain_in_views(): void
    {
        $viewsPath = resource_path('views');
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($viewsPath));
        $matches = [];

        /** @var \SplFileInfo $file */
        foreach ($files as $file) {
            if ($file->isDir() || ! str_ends_with($file->getFilename(), '.blade.php')) {
                continue;
            }

            $content = file_get_contents($file->getPathname());
            if (str_contains($content, 'Route::has')) {
                $relPath = str_replace('\\', '/', substr($file->getPathname(), strlen($viewsPath) + 1));
                $matches[] = $relPath;
            }
        }

        $this->assertEmpty($matches, 'Route::has was found in: ' . implode(', ', $matches));
    }

    public function test_user_texts_and_notes_are_properly_escaped_against_xss(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);
        $cart->setItemNote($this->menuBakso->id, '<script>alert("xss-item-note")</script>');
        session(['order_note' => '<script>alert("xss-order-note")</script>']);

        $response = $this->get(route('customer.confirm'));

        $response->assertOk();
        $response->assertDontSee('<script>alert("xss-item-note")</script>', false);
        $response->assertDontSee('<script>alert("xss-order-note")</script>', false);
        $response->assertSee('&lt;script&gt;alert(&quot;xss-item-note&quot;)&lt;/script&gt;', false);
    }

    public function test_checkout_token_is_generated_on_mount_and_locked(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);

        $component = Livewire::test(OrderConfirmation::class);
        $token = $component->get('checkoutToken');

        $this->assertGreaterThanOrEqual(40, strlen($token));

        $this->expectException(\Livewire\Features\SupportLockedProperties\CannotUpdateLockedPropertyException::class);
        $component->set('checkoutToken', 'tampered-token');
    }

    public function test_qris_option_is_disabled_when_qris_not_uploaded_and_selectable_when_uploaded(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);

        Livewire::test(OrderConfirmation::class)
            ->assertSee('Bayar di Kasir (Tunai)')
            ->assertSee('QRIS belum tersedia (kode QR belum diunggah penjual).')
            ->set('paymentMethod', 'qris')
            ->assertSet('paymentMethod', 'cash')
            ->assertHasErrors('paymentMethod');

        BusinessProfile::query()->update(['qris_image_path' => 'qris/sample.png']);

        Livewire::test(OrderConfirmation::class)
            ->assertSee('Scan kode QRIS warung setelah pesanan dibuat.')
            ->set('paymentMethod', 'qris')
            ->assertSet('paymentMethod', 'qris')
            ->assertHasNoErrors('paymentMethod');
    }

    public function test_clicking_buat_pesanan_opens_confirmation_dialog_and_tidak_batalkan_does_not_create_order(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);

        $component = Livewire::test(OrderConfirmation::class)
            ->assertSet('showConfirmDialog', false)
            ->call('openConfirmDialog')
            ->assertSet('showConfirmDialog', true)
            ->assertSee('Kirim pesanan?')
            ->assertSee('Ya, Kirim Pesanan')
            ->assertSee('Tidak, Batalkan');

        $this->assertSame(0, Order::query()->count());

        $component
            ->call('cancelConfirmDialog')
            ->assertSet('showConfirmDialog', false)
            ->assertDontSee('Kirim pesanan?');

        $this->assertSame(0, Order::query()->count());
        $this->assertFalse($cart->isEmpty());
    }

    public function test_confirming_ya_kirim_pesanan_creates_order_and_redirects_to_status(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 2);

        $component = Livewire::test(OrderConfirmation::class)
            ->call('openConfirmDialog')
            ->assertSet('showConfirmDialog', true)
            ->call('placeOrder')
            ->assertDispatched('cart-updated');

        $order = Order::query()->where('customer_id', $this->customer->id)->firstOrFail();
        $component->assertRedirect(route('customer.order.show', ['orderNumber' => $order->order_number]));
        $this->assertSame(1, Order::query()->count());
    }
}
