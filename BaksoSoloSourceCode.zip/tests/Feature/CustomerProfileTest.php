<?php

namespace Tests\Feature;

use App\Livewire\Customer\Profile;
use App\Models\BusinessProfile;
use App\Models\Customer;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use Tests\TestCase;

class CustomerProfileTest extends TestCase
{
    use RefreshDatabase;

    private Customer $customer;

    protected function setUp(): void
    {
        parent::setUp();
        $this->startSession();

        $this->customer = Customer::factory()->create([
            'phone' => '6281234567890',
        ]);
    }

    public function test_guest_without_phone_session_is_redirected_to_home(): void
    {
        $response = $this->get(route('customer.profile'));

        $response->assertRedirect(route('customer.phone'));
        $response->assertSessionHas('error', 'Masukkan nomor handphone kamu untuk melanjutkan pemesanan di Bakso Solo.');
    }

    public function test_identified_customer_without_selected_table_can_view_profile_page(): void
    {
        BusinessProfile::factory()->create([
            'name' => 'Bakso Solo Bu Susi',
            'tagline' => 'Kantin M Lt. 2 UNJ',
            'description' => 'Bakso Solo adalah usaha kuliner lezat khas Solo.',
            'location' => 'Kantin M, Lantai 2 (UNJ)',
            'phone' => '085215355501',
            'whatsapp' => '085215355501',
            'open_time' => '08.00',
            'close_time' => '17.00',
        ]);

        // Customer has NO table_id and NO order_type in session
        $response = $this->withSession(['customer_id' => $this->customer->id])
            ->get(route('customer.profile'));

        $response->assertOk();
        $response->assertSee('Bakso Solo Bu Susi');
        $response->assertSee('Kantin M Lt. 2 UNJ');
        $response->assertSee('Tentang Kami');
        $response->assertSee('Bakso Solo adalah usaha kuliner lezat khas Solo.');
        $response->assertSee('Informasi Usaha');
        $response->assertSee('Lokasi');
        $response->assertSee('Kantin M, Lantai 2 (UNJ)');
        $response->assertSee('Kontak');
        $response->assertSee('085215355501');
        $response->assertSee('href="tel:085215355501"', false);
        $response->assertSee('Jam Operasional');
        $response->assertSee('08.00 - 17.00');
        $response->assertSee('Hubungi via WhatsApp');
    }

    public function test_whatsapp_button_uses_normalized_number_and_safe_rel_attributes(): void
    {
        BusinessProfile::factory()->create([
            'whatsapp' => '0812-3456-7890',
        ]);

        $response = $this->withSession(['customer_id' => $this->customer->id])
            ->get(route('customer.profile'));

        $response->assertOk();
        $response->assertSee('https://wa.me/6281234567890', false);
        $response->assertSee('target="_blank"', false);
        $response->assertSee('rel="noopener noreferrer"', false);
    }

    public function test_empty_fields_are_hidden(): void
    {
        BusinessProfile::factory()->create([
            'name' => 'Warung Singkat',
            'tagline' => null,
            'description' => null,
            'location' => null,
            'phone' => null,
            'whatsapp' => null,
            'open_time' => '',
            'close_time' => '',
        ]);

        $response = $this->withSession(['customer_id' => $this->customer->id])
            ->get(route('customer.profile'));

        $response->assertOk();
        $response->assertSee('Warung Singkat');
        $response->assertDontSee('Tentang Kami');
        $response->assertDontSee('Lokasi');
        $response->assertDontSee('Kontak');
        $response->assertDontSee('Jam Operasional');
        $response->assertDontSee('Hubungi via WhatsApp');
    }

    public function test_missing_profile_in_database_does_not_throw_500(): void
    {
        BusinessProfile::query()->delete();

        $response = $this->withSession(['customer_id' => $this->customer->id])
            ->get(route('customer.profile'));

        $response->assertOk();
        $response->assertSee('Profil usaha belum dikonfigurasi.');
    }

    public function test_text_containing_html_is_properly_escaped(): void
    {
        BusinessProfile::factory()->create([
            'name' => '<script>alert("xss-name")</script>',
            'tagline' => '<img src=x onerror=alert(1)>',
            'description' => '<b>Tebal</b><script>alert("xss-desc")</script>',
            'location' => '<script>alert("xss-loc")</script>',
            'phone' => '<script>alert("xss-phone")</script>',
        ]);

        $response = $this->withSession(['customer_id' => $this->customer->id])
            ->get(route('customer.profile'));

        $response->assertOk();
        // Raw script tags MUST NOT appear unescaped
        $response->assertDontSee('<script>alert("xss-name")</script>', false);
        $response->assertDontSee('<img src=x onerror=alert(1)>', false);
        $response->assertDontSee('<script>alert("xss-desc")</script>', false);
        $response->assertDontSee('<script>alert("xss-loc")</script>', false);

        // Escaped HTML entities MUST appear
        $response->assertSee('&lt;script&gt;alert(&quot;xss-name&quot;)&lt;/script&gt;', false);
        $response->assertSee('&lt;b&gt;Tebal&lt;/b&gt;', false);
    }

    public function test_profile_nav_link_is_active_on_profile_page(): void
    {
        BusinessProfile::factory()->create([
            'name' => 'Bakso Solo',
        ]);

        $response = $this->withSession(['customer_id' => $this->customer->id])
            ->get(route('customer.profile'));

        $response->assertOk();
        // In customer layout, route('customer.profile') is active
        $response->assertSee(route('customer.profile'), false);
    }
}
