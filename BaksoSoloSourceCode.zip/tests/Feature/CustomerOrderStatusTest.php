<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Enums\TableType;
use App\Livewire\Customer\OrderConfirmation;
use App\Livewire\Customer\OrderHistory;
use App\Livewire\Customer\OrderStatusDetail;
use App\Models\BusinessProfile;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Models\Order;
use App\Services\CartService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Livewire\Features\SupportLockedProperties\CannotUpdateLockedPropertyException;
use Livewire\Livewire;
use Tests\TestCase;

class CustomerOrderStatusTest extends TestCase
{
    use RefreshDatabase;

    private Customer $customerA;

    private Customer $customerB;

    private DiningTable $table;

    private Menu $menu;

    protected function setUp(): void
    {
        parent::setUp();

        BusinessProfile::factory()->create([
            'id' => 1,
            'qris_image_path' => 'qris/warung-qris.png',
        ]);

        $this->customerA = Customer::factory()->create(['phone' => '6281234560001']);
        $this->customerB = Customer::factory()->create(['phone' => '6281234560002']);

        $this->table = DiningTable::factory()->create([
            'code' => '2A',
            'floor' => 2,
            'type' => TableType::Fixed,
            'is_active' => true,
        ]);

        $category = MenuCategory::factory()->create(['name' => 'Bakso']);
        $this->menu = Menu::factory()->create([
            'category_id' => $category->id,
            'name' => 'Bakso Komplit',
            'price' => 18000,
            'is_available' => true,
        ]);
    }

    public function test_guest_without_session_is_redirected_from_order_pages(): void
    {
        $order = Order::factory()->create([
            'order_number' => '20261113-0001',
            'customer_id' => $this->customerA->id,
            'table_id' => $this->table->id,
        ]);

        $this->get(route('customer.orders'))->assertRedirect(route('customer.phone'));
        $this->get(route('customer.order.show', ['orderNumber' => $order->order_number]))
            ->assertRedirect(route('customer.phone'));
    }

    public function test_customer_can_place_order_from_confirmation_and_table_session_is_preserved(): void
    {
        $this->withSession([
            'customer_id' => $this->customerA->id,
            'order_type' => 'dine_in',
            'table_id' => $this->table->id,
            'location_note' => null,
            'order_note' => 'Tanpa seledri',
        ]);

        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menu->id, 2);

        $component = Livewire::test(OrderConfirmation::class)
            ->set('paymentMethod', 'qris')
            ->call('placeOrder')
            ->assertDispatched('cart-updated');

        $order = Order::query()->where('customer_id', $this->customerA->id)->firstOrFail();

        $component->assertRedirect(route('customer.order.show', ['orderNumber' => $order->order_number]));

        $this->assertSame(36000, $order->total);
        $this->assertSame(PaymentMethod::Qris, $order->payment_method);
        $this->assertSame(PaymentStatus::BelumBayar, $order->payment_status);
        $this->assertSame(OrderStatus::Diterima, $order->status);
        $this->assertSame('Tanpa seledri', $order->note);
        $this->assertTrue($cart->isEmpty());
        $this->assertSame($this->table->id, session('table_id'));
        $this->assertNull(session('order_note'));

        // Re-submitting with the same checkoutToken is idempotent
        $component->call('placeOrder');
        $this->assertSame(1, Order::query()->where('customer_id', $this->customerA->id)->count());
    }

    public function test_order_history_only_displays_authenticated_customers_orders(): void
    {
        $orderA = Order::factory()->create([
            'order_number' => '20261113-0001',
            'customer_id' => $this->customerA->id,
            'table_id' => $this->table->id,
            'total' => 18000,
        ]);

        $orderB = Order::factory()->create([
            'order_number' => '20261113-0002',
            'customer_id' => $this->customerB->id,
            'table_id' => $this->table->id,
            'total' => 25000,
        ]);

        $this->withSession(['customer_id' => $this->customerA->id]);

        Livewire::test(OrderHistory::class)
            ->assertSee($orderA->display_number)
            ->assertDontSee($orderB->display_number);
    }

    public function test_order_status_detail_returns_identical_404_for_missing_and_other_customers_order(): void
    {
        $orderB = Order::factory()->create([
            'order_number' => '20261113-0099',
            'customer_id' => $this->customerB->id,
            'table_id' => $this->table->id,
        ]);

        $this->withSession(['customer_id' => $this->customerA->id]);

        $missingResponse = $this->get(route('customer.order.show', ['orderNumber' => '20261113-9999']));
        $otherCustomerResponse = $this->get(route('customer.order.show', ['orderNumber' => $orderB->order_number]));

        $missingResponse->assertNotFound();
        $otherCustomerResponse->assertNotFound();
    }

    public function test_order_status_detail_shows_qris_or_cash_instructions_and_no_cancel_action(): void
    {
        $qrisOrder = Order::factory()->create([
            'order_number' => '20261113-0010',
            'customer_id' => $this->customerA->id,
            'type' => OrderType::DineIn,
            'table_id' => $this->table->id,
            'payment_method' => PaymentMethod::Qris,
            'payment_status' => PaymentStatus::BelumBayar,
            'status' => OrderStatus::Diterima,
            'total' => 18000,
        ]);

        $cashOrder = Order::factory()->create([
            'order_number' => '20261113-0011',
            'customer_id' => $this->customerA->id,
            'type' => OrderType::TakeAway,
            'table_id' => null,
            'payment_method' => PaymentMethod::Cash,
            'payment_status' => PaymentStatus::BelumBayar,
            'status' => OrderStatus::Diproses,
            'total' => 18000,
        ]);

        $this->withSession(['customer_id' => $this->customerA->id]);

        $this->get(route('customer.order.show', ['orderNumber' => $qrisOrder->order_number]))
            ->assertOk()
            ->assertSee('Menunggu konfirmasi penjual')
            ->assertSee('qris/warung-qris.png')
            ->assertSee('Batalkan Pesanan');

        $this->get(route('customer.order.show', ['orderNumber' => $cashOrder->order_number]))
            ->assertOk()
            ->assertSee('Bayar di kasir')
            ->assertDontSee('Batalkan Pesanan');
    }

    public function test_locked_order_number_cannot_be_tampered_from_client(): void
    {
        $order = Order::factory()->create([
            'order_number' => '20261113-0012',
            'customer_id' => $this->customerA->id,
            'table_id' => $this->table->id,
        ]);

        $this->withSession(['customer_id' => $this->customerA->id]);

        $this->expectException(CannotUpdateLockedPropertyException::class);

        Livewire::test(OrderStatusDetail::class, ['orderNumber' => $order->order_number])
            ->set('orderNumber', '20261113-0001');
    }

    public function test_order_history_limits_to_20_hides_full_phone_and_avoids_n_plus_one(): void
    {
        for ($i = 1; $i <= 25; $i++) {
            Order::factory()->create([
                'order_number' => sprintf('20261113-%04d', $i),
                'customer_id' => $this->customerA->id,
                'table_id' => $this->table->id,
                'created_at' => now()->subMinutes(30 - $i),
            ]);
        }

        $this->withSession(['customer_id' => $this->customerA->id]);

        DB::flushQueryLog();
        DB::enableQueryLog();

        $component = Livewire::test(OrderHistory::class);

        $queries = DB::getQueryLog();
        DB::disableQueryLog();

        $component->assertOk();
        // Latest 20 (#0006 .. #0025) are shown; oldest 5 (#0001 .. #0005) are excluded
        $component->assertSee('#0025');
        $component->assertSee('#0006');
        $component->assertDontSee('#0005');
        $component->assertDontSee('#0001');

        // Full phone number must never appear
        $component->assertDontSee($this->customerA->phone);
        $component->assertDontSee('081234560001');

        // Orders + eager loaded tables + eager loaded items (+ session/customer queries <= 6 total)
        $this->assertLessThanOrEqual(8, count($queries));
    }

    public function test_order_status_timeline_shows_reached_timestamps_belum_for_unreached_and_info_box(): void
    {
        $order = Order::factory()->create([
            'order_number' => '20261113-0020',
            'customer_id' => $this->customerA->id,
            'table_id' => $this->table->id,
            'status' => OrderStatus::Diproses,
        ]);

        $order->statusLogs()->create([
            'status' => OrderStatus::Diterima,
            'created_at' => now()->setTime(10, 15),
        ]);
        $order->statusLogs()->create([
            'status' => OrderStatus::Diproses,
            'created_at' => now()->setTime(10, 22),
        ]);

        $this->withSession(['customer_id' => $this->customerA->id]);

        Livewire::test(OrderStatusDetail::class, ['orderNumber' => $order->order_number])
            ->assertOk()
            ->assertSee('Pesanan diterima')
            ->assertSee('10:15')
            ->assertSee('Sedang diproses')
            ->assertSee('10:22')
            ->assertSee('Sedang disiapkan')
            ->assertSee('Siap diambil')
            ->assertSee('Belum')
            ->assertSee('Pesanan Anda sedang disiapkan oleh tim kami. Terima kasih sudah memesan!');
    }

    public function test_cancelled_order_shows_reached_stages_and_cancellation_timestamp(): void
    {
        $order = Order::factory()->create([
            'order_number' => '20261113-0021',
            'customer_id' => $this->customerA->id,
            'table_id' => $this->table->id,
            'status' => OrderStatus::Dibatalkan,
        ]);

        $order->statusLogs()->create([
            'status' => OrderStatus::Diterima,
            'created_at' => now()->setTime(11, 5),
        ]);
        $order->statusLogs()->create([
            'status' => OrderStatus::Dibatalkan,
            'created_at' => now()->setTime(11, 10),
        ]);

        $this->withSession(['customer_id' => $this->customerA->id]);

        Livewire::test(OrderStatusDetail::class, ['orderNumber' => $order->order_number])
            ->assertOk()
            ->assertSee('Pesanan diterima')
            ->assertSee('11:05')
            ->assertSee('Pesanan Dibatalkan')
            ->assertSee('11:10')
            ->assertDontSee('Sedang disiapkan')
            ->assertDontSee('Pesanan Anda sedang disiapkan oleh tim kami. Terima kasih sudah memesan!');
    }

    public function test_customer_can_cancel_received_order_after_confirmation_and_frees_table_and_active_limit(): void
    {
        $orderService = app(\App\Services\OrderService::class);
        $created = [];
        for ($i = 1; $i <= 3; $i++) {
            $created[] = $orderService->createOrder(
                customerId: $this->customerA->id,
                orderType: OrderType::DineIn,
                tableId: $this->table->id,
                locationNote: null,
                orderNote: null,
                paymentMethod: PaymentMethod::Cash,
                cartLines: [$this->menu->id => ['menu_id' => $this->menu->id, 'qty' => 1, 'item_note' => null]],
                checkoutToken: \App\Services\OrderService::generateCheckoutToken(),
            );
        }

        $targetOrder = $created[0];
        $this->assertTrue($this->table->fresh()->isOccupied());

        $this->withSession(['customer_id' => $this->customerA->id]);

        Livewire::test(OrderStatusDetail::class, ['orderNumber' => $targetOrder->order_number])
            ->call('openCancelDialog')
            ->assertSet('showCancelDialog', true)
            ->assertSee('Batalkan pesanan?')
            ->call('cancelOrder')
            ->assertSet('showCancelDialog', false)
            ->assertSee('Pesanan berhasil dibatalkan.');

        $this->assertSame(OrderStatus::Dibatalkan, $targetOrder->fresh()->status);
        $this->assertDatabaseHas('order_status_logs', [
            'order_id' => $targetOrder->id,
            'status' => OrderStatus::Dibatalkan->value,
        ]);

        // Active order slot is freed: customerA can now place a new order (total active becomes 3 again)
        $newOrder = $orderService->createOrder(
            customerId: $this->customerA->id,
            orderType: OrderType::TakeAway,
            tableId: null,
            locationNote: null,
            orderNote: null,
            paymentMethod: PaymentMethod::Cash,
            cartLines: [$this->menu->id => ['menu_id' => $this->menu->id, 'qty' => 1, 'item_note' => null]],
            checkoutToken: \App\Services\OrderService::generateCheckoutToken(),
        );
        $this->assertSame(OrderStatus::Diterima, $newOrder->status);

        // Cancel remaining 2 dine-in orders on table 2A and verify table is no longer occupied
        $orderService->cancelOrderByCustomer($this->customerA->id, $created[1]->order_number);
        $orderService->cancelOrderByCustomer($this->customerA->id, $created[2]->order_number);
        $this->assertFalse($this->table->fresh()->isOccupied());
    }

    public function test_customer_cannot_cancel_order_that_is_no_longer_diterima(): void
    {
        $order = Order::factory()->create([
            'order_number' => '20261113-0030',
            'customer_id' => $this->customerA->id,
            'table_id' => $this->table->id,
            'status' => OrderStatus::Diproses,
        ]);

        $this->withSession(['customer_id' => $this->customerA->id]);

        Livewire::test(OrderStatusDetail::class, ['orderNumber' => $order->order_number])
            ->call('cancelOrder')
            ->assertSee('Pesanan tidak dapat dibatalkan karena sudah diproses atau diselesaikan.');

        $this->assertSame(OrderStatus::Diproses, $order->fresh()->status);
    }
}
