<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Enums\TableType;
use App\Exceptions\OrderCreationException;
use App\Models\BusinessProfile;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Models\Order;
use App\Services\CartService;
use App\Services\OrderService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Tests\TestCase;

class OrderServiceTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        BusinessProfile::factory()->create([
            'id' => 1,
            'qris_image_path' => null,
        ]);
    }

    public function test_creates_dine_in_order_with_snapshots_status_log_and_clears_cart(): void
    {
        $customer = Customer::factory()->create();
        $table = DiningTable::factory()->create(['code' => '2A', 'floor' => 2, 'type' => TableType::Fixed]);
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create([
            'category_id' => $category->id,
            'name' => 'Bakso Urat',
            'price' => 22000,
            'is_available' => true,
        ]);

        $cart = app(CartService::class);
        $cart->add($menu->id, 2);
        $cart->setItemNote($menu->id, 'Pedas sedang');

        $token = Str::random(32);
        $service = app(OrderService::class);

        $order = $service->createOrder(
            customerId: $customer->id,
            orderType: OrderType::DineIn,
            tableId: $table->id,
            locationNote: null,
            orderNote: '  Tanpa seledri  ',
            paymentMethod: PaymentMethod::Cash,
            cartLines: $cart->lines(),
            checkoutToken: $token,
            rateLimitIp: '127.0.0.1',
        );

        $this->assertSame(now()->format('Ymd').'-0001', $order->order_number);
        $this->assertSame($token, $order->checkout_token);
        $this->assertSame($customer->id, $order->customer_id);
        $this->assertSame(OrderType::DineIn, $order->type);
        $this->assertSame($table->id, $order->table_id);
        $this->assertSame('Tanpa seledri', $order->note);
        $this->assertSame(44000, $order->subtotal);
        $this->assertSame(44000, $order->total);
        $this->assertSame(PaymentMethod::Cash, $order->payment_method);
        $this->assertSame(PaymentStatus::BelumBayar, $order->payment_status);
        $this->assertSame(OrderStatus::Diterima, $order->status);

        $this->assertCount(1, $order->items);
        $item = $order->items->first();
        $this->assertSame($menu->id, $item->menu_id);
        $this->assertSame('Bakso Urat', $item->name_snapshot);
        $this->assertSame(22000, $item->price_snapshot);
        $this->assertSame(2, $item->qty);
        $this->assertSame('Pedas sedang', $item->item_note);
        $this->assertSame(44000, $item->line_total);

        $this->assertCount(1, $order->statusLogs);
        $this->assertSame(OrderStatus::Diterima, $order->statusLogs->first()->status);
        $this->assertNull($order->statusLogs->first()->changed_by);

        $this->assertTrue($cart->isEmpty());
    }

    public function test_same_customer_can_order_again_at_own_table_while_other_customer_is_rejected(): void
    {
        $customerA = Customer::factory()->create();
        $customerB = Customer::factory()->create();
        $table = DiningTable::factory()->create(['code' => '2B', 'floor' => 2, 'type' => TableType::Fixed]);
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);

        $service = app(OrderService::class);
        $lines = [$menu->id => ['qty' => 1, 'item_note' => null]];

        $first = $service->createOrder($customerA->id, OrderType::DineIn, $table->id, null, null, PaymentMethod::Cash, $lines, Str::random(32), clearCart: false);
        $second = $service->createOrder($customerA->id, OrderType::DineIn, $table->id, null, null, PaymentMethod::Cash, $lines, Str::random(32), clearCart: false);

        $this->assertSame(now()->format('Ymd').'-0001', $first->order_number);
        $this->assertSame(now()->format('Ymd').'-0002', $second->order_number);

        $this->expectException(OrderCreationException::class);
        $this->expectExceptionMessage('sudah terisi');

        $service->createOrder($customerB->id, OrderType::DineIn, $table->id, null, null, PaymentMethod::Cash, $lines, Str::random(32), clearCart: false);
    }

    public function test_free_table_requires_location_note_and_take_away_clears_table(): void
    {
        $customer = Customer::factory()->create();
        $freeTable = DiningTable::factory()->create(['code' => 'BEBAS', 'floor' => 1, 'type' => TableType::Free]);
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);
        $service = app(OrderService::class);
        $lines = [$menu->id => ['qty' => 1, 'item_note' => null]];

        $takeAway = $service->createOrder($customer->id, OrderType::TakeAway, $freeTable->id, 'ignored', null, PaymentMethod::Cash, $lines, Str::random(32), clearCart: false);
        $this->assertNull($takeAway->table_id);
        $this->assertNull($takeAway->location_note);

        $freeOrder = $service->createOrder($customer->id, OrderType::DineIn, $freeTable->id, '  Dekat jendela  ', null, PaymentMethod::Cash, $lines, Str::random(32), clearCart: false);
        $this->assertSame($freeTable->id, $freeOrder->table_id);
        $this->assertSame('Dekat jendela', $freeOrder->location_note);

        $this->expectException(OrderCreationException::class);
        $service->createOrder($customer->id, OrderType::DineIn, $freeTable->id, 'ab', null, PaymentMethod::Cash, $lines, Str::random(32), clearCart: false);
    }

    public function test_unavailable_menu_fails_and_preserves_cart_and_sequence(): void
    {
        $customer = Customer::factory()->create();
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000, 'is_available' => true]);

        $cart = app(CartService::class);
        $cart->add($menu->id, 2);

        $menu->update(['is_available' => false]);

        $service = app(OrderService::class);

        try {
            $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, $cart->lines(), Str::random(32));
            $this->fail('Expected OrderCreationException was not thrown.');
        } catch (OrderCreationException $e) {
            $this->assertStringContainsString('habis', $e->getMessage());
        }

        $this->assertSame(0, Order::query()->count());
        $this->assertSame(2, $cart->count());
    }

    public function test_active_order_limit_of_three_is_enforced_inside_transaction(): void
    {
        $customer = Customer::factory()->create();
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);
        $lines = [$menu->id => ['qty' => 1, 'item_note' => null]];
        $service = app(OrderService::class);

        $order1 = $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, $lines, Str::random(32), clearCart: false);
        $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, $lines, Str::random(32), clearCart: false);
        $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, $lines, Str::random(32), clearCart: false);

        try {
            $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, $lines, Str::random(32), clearCart: false);
            $this->fail('Expected active order limit exception.');
        } catch (OrderCreationException $e) {
            $this->assertStringContainsString('3 pesanan aktif', $e->getMessage());
        }

        $order1->update(['status' => OrderStatus::Selesai]);

        $order4 = $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, $lines, Str::random(32), clearCart: false);
        $this->assertSame(now()->format('Ymd').'-0004', $order4->order_number);
    }

    public function test_checkout_token_idempotency_returns_same_order_without_duplicating(): void
    {
        $customer = Customer::factory()->create();
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);
        $lines = [$menu->id => ['qty' => 1, 'item_note' => null]];
        $service = app(OrderService::class);
        $token = Str::random(32);

        $first = $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, $lines, $token, clearCart: false);
        $second = $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, $lines, $token, clearCart: false);

        $this->assertSame($first->id, $second->id);
        $this->assertSame(1, Order::query()->count());
    }

    public function test_checkout_token_belonging_to_other_customer_is_rejected_generically(): void
    {
        $customerA = Customer::factory()->create();
        $customerB = Customer::factory()->create();
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);
        $lines = [$menu->id => ['qty' => 1, 'item_note' => null]];
        $service = app(OrderService::class);
        $token = OrderService::generateCheckoutToken();

        $this->assertGreaterThanOrEqual(40, strlen($token));

        $orderA = $service->createOrder($customerA->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, $lines, $token, clearCart: false);

        try {
            $service->createOrder($customerB->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, $lines, $token, clearCart: false);
            $this->fail('Expected generic rejection for cross-customer checkout token.');
        } catch (OrderCreationException $e) {
            $this->assertSame('Permintaan checkout tidak valid. Silakan muat ulang halaman.', $e->getMessage());
            $this->assertStringNotContainsString($orderA->order_number, $e->getMessage());
            $this->assertStringNotContainsString((string) $orderA->id, $e->getMessage());
        }
    }

    public function test_generate_checkout_token_produces_strong_unique_tokens(): void
    {
        $token1 = OrderService::generateCheckoutToken();
        $token2 = OrderService::generateCheckoutToken();

        $this->assertSame(40, strlen($token1));
        $this->assertSame(40, strlen($token2));
        $this->assertNotSame($token1, $token2);
    }

    public function test_qris_rejected_when_qris_image_not_uploaded_and_allowed_when_present(): void
    {
        $customer = Customer::factory()->create();
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);
        $lines = [$menu->id => ['qty' => 1, 'item_note' => null]];
        $service = app(OrderService::class);

        try {
            $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Qris, $lines, Str::random(32), clearCart: false);
            $this->fail('Expected QRIS rejection.');
        } catch (OrderCreationException $e) {
            $this->assertStringContainsString('QRIS', $e->getMessage());
        }

        BusinessProfile::query()->update(['qris_image_path' => 'qris/merchant.png']);

        $order = $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Qris, $lines, Str::random(32), clearCart: false);
        $this->assertSame(PaymentMethod::Qris, $order->payment_method);
    }

    public function test_rate_limit_blocks_after_ten_failures_and_resets_on_success(): void
    {
        $customer = Customer::factory()->create();
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);
        $service = app(OrderService::class);
        $ip = '10.10.10.99';

        RateLimiter::clear("order-create:fail:customer:{$customer->id}");
        RateLimiter::clear("order-create:fail:ip:{$ip}");
        RateLimiter::clear("order-create:success:ip:{$ip}");

        for ($i = 0; $i < 10; $i++) {
            try {
                $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, [], Str::random(32), $ip, false);
            } catch (OrderCreationException) {
            }
        }

        try {
            $service->createOrder($customer->id, OrderType::TakeAway, null, null, null, PaymentMethod::Cash, [$menu->id => ['qty' => 1]], Str::random(32), $ip, false);
            $this->fail('Expected rate limit block.');
        } catch (OrderCreationException $e) {
            $this->assertStringContainsString('Terlalu banyak percobaan gagal', $e->getMessage());
        }
    }
}
