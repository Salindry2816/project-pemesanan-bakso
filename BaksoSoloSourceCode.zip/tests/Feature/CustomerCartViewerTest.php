<?php

namespace Tests\Feature;

use App\Enums\TableType;
use App\Livewire\Customer\CartViewer;
use App\Models\BusinessProfile;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Services\CartService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Route;
use Livewire\Livewire;
use Tests\TestCase;

class CustomerCartViewerTest extends TestCase
{
    use RefreshDatabase;

    private Customer $customer;

    private DiningTable $table;

    private MenuCategory $categoryMakanan;

    private MenuCategory $categoryMinuman;

    private Menu $menuBakso;

    private Menu $menuUrat;

    private Menu $menuEsTeh;

    protected function setUp(): void
    {
        parent::setUp();
        $this->startSession();

        BusinessProfile::factory()->create([
            'name' => 'Bakso Solo Bu Susi',
            'tagline' => 'Kantin M Lt. 2 UNJ',
        ]);

        $this->customer = Customer::factory()->create([
            'phone' => '6281234567890',
            'name' => 'Budi Santoso',
        ]);

        $this->table = DiningTable::factory()->create([
            'code' => '2A',
            'floor' => 2,
            'capacity' => 4,
            'type' => TableType::Fixed,
            'is_active' => true,
        ]);

        $this->categoryMakanan = MenuCategory::factory()->create([
            'name' => 'Makanan',
            'sort_order' => 1,
        ]);

        $this->categoryMinuman = MenuCategory::factory()->create([
            'name' => 'Minuman',
            'sort_order' => 2,
        ]);

        $this->menuBakso = Menu::factory()->create([
            'category_id' => $this->categoryMakanan->id,
            'name' => 'Bakso Komplit',
            'description' => 'Bakso halus, urat, dan tahu.',
            'price' => 18000,
            'is_available' => true,
        ]);

        $this->menuUrat = Menu::factory()->create([
            'category_id' => $this->categoryMakanan->id,
            'name' => 'Bakso Urat',
            'description' => 'Bakso urat sapi asli kenyal.',
            'price' => 17000,
            'is_available' => true,
        ]);

        $this->menuEsTeh = Menu::factory()->create([
            'category_id' => $this->categoryMinuman->id,
            'name' => 'Es Teh Manis',
            'description' => 'Segar manis dingin.',
            'price' => 5000,
            'is_available' => true,
        ]);
    }

    private function actingAsCustomerSession(array $overrides = []): self
    {
        return $this->withSession(array_merge([
            'customer_id' => $this->customer->id,
            'order_type' => 'dine_in',
            'table_id' => $this->table->id,
            'location_note' => null,
        ], $overrides));
    }

    public function test_guest_without_phone_session_is_redirected_to_home(): void
    {
        $response = $this->get(route('customer.cart'));

        $response->assertRedirect(route('customer.phone'));
        $response->assertSessionHas('error', 'Masukkan nomor handphone kamu untuk melanjutkan pemesanan di Bakso Solo.');
    }

    public function test_customer_without_table_session_is_redirected_to_table_selection(): void
    {
        $response = $this->withSession([
            'customer_id' => $this->customer->id,
        ])->get(route('customer.cart'));

        $response->assertRedirect(route('customer.table'));
        $response->assertSessionHas('error', 'Silakan pilih meja atau bungkus terlebih dahulu.');
    }

    public function test_cart_viewer_renders_empty_state_when_cart_is_empty(): void
    {
        $this->actingAsCustomerSession();
        app(CartService::class)->clear();

        $response = $this->get(route('customer.cart'));

        $response->assertOk();
        $response->assertSee('Keranjang masih kosong.');
        $response->assertSee('Lihat Menu');
        $response->assertSee(route('customer.menu'));
    }

    public function test_cart_viewer_renders_valid_cart_lines_and_total_from_database(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 2); // 2 x 18.000 = 36.000
        $cart->add($this->menuEsTeh->id, 1);  // 1 x 5.000 = 5.000

        $component = Livewire::test(CartViewer::class);

        $component->assertOk();
        $component->assertSee('Bakso Komplit');
        $component->assertSee('Rp 18.000 / porsi');
        $component->assertSee('Rp 36.000');
        $component->assertSee('Es Teh Manis');
        $component->assertSee('Rp 5.000 / porsi');
        $component->assertSee('Rp 41.000'); // total 36.000 + 5.000
        $component->assertSee('2 jenis menu');
    }

    public function test_customer_can_change_quantity_within_bounds(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);

        $component = Livewire::test(CartViewer::class);

        // 1. Increment from 1 to 2
        $component->call('incrementQty', $this->menuBakso->id);
        $component->assertDispatched('cart-updated');
        $this->assertSame(2, $cart->count());

        // 2. Decrement from 2 to 1
        $component->call('decrementQty', $this->menuBakso->id);
        $component->assertDispatched('cart-updated');
        $this->assertSame(1, $cart->count());

        // 3. Decrement at 1 does not decrement further (stays 1; removal requires removeItem)
        $component->call('decrementQty', $this->menuBakso->id);
        $this->assertSame(1, $cart->count());

        // 4. UpdateQty to 20 (max allowed)
        $component->call('updateQty', $this->menuBakso->id, 20);
        $this->assertSame(20, $cart->count());

        // 5. Incrementing at 20 is rejected with Indonesian message
        $component->call('incrementQty', $this->menuBakso->id);
        $component->assertSet('errorMessage', 'Jumlah pesanan untuk menu ini maksimal 20 porsi.');
        $this->assertSame(20, $cart->count());

        // 6. UpdateQty exceeding 20 is rejected
        $component->call('updateQty', $this->menuBakso->id, 21);
        $component->assertSet('errorMessage', 'Jumlah pesanan untuk menu ini maksimal 20 porsi.');
        $this->assertSame(20, $cart->count());

        // 7. UpdateQty with 0 removes the item
        $component->call('updateQty', $this->menuBakso->id, 0);
        $this->assertTrue($cart->isEmpty());
    }

    public function test_customer_can_remove_item_from_cart(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 2);
        $cart->add($this->menuEsTeh->id, 1);
        $cart->setItemNote($this->menuBakso->id, 'Tanpa kecap');

        $component = Livewire::test(CartViewer::class);
        $this->assertSame('Tanpa kecap', $component->get('notes')[$this->menuBakso->id] ?? null);

        // Remove Bakso
        $component->call('removeItem', $this->menuBakso->id);
        $component->assertDispatched('cart-updated');

        $this->assertFalse(isset($cart->lines()[$this->menuBakso->id]));
        $this->assertTrue(isset($cart->lines()[$this->menuEsTeh->id]));
        $this->assertArrayNotHasKey($this->menuBakso->id, $component->get('notes'));
    }

    public function test_customer_can_save_per_item_notes_and_validation_enforces_max_100_chars(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);

        $component = Livewire::test(CartViewer::class);

        // 1. Save valid note <= 100 characters
        $component->set('notes.' . $this->menuBakso->id, 'Kuah dipisah, banyakin sambal');
        $component->call('saveNote', $this->menuBakso->id);
        $component->assertHasNoErrors();
        $component->assertDispatched('cart-updated');

        $this->assertSame('Kuah dipisah, banyakin sambal', $cart->lines()[$this->menuBakso->id]['item_note']);

        // 2. Note > 100 characters is rejected with localized error
        $tooLong = str_repeat('a', 101);
        $component->set('notes.' . $this->menuBakso->id, $tooLong);
        $component->call('saveNote', $this->menuBakso->id);
        $component->assertHasErrors(["notes.{$this->menuBakso->id}"]);
        $component->assertSee('Catatan maksimal 100 karakter.');

        // Session note is not corrupted by the invalid entry
        $this->assertSame('Kuah dipisah, banyakin sambal', $cart->lines()[$this->menuBakso->id]['item_note']);
    }

    public function test_problem_lines_render_alert_banner_and_are_excluded_from_total(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1); // 18.000
        $cart->add($this->menuEsTeh->id, 2); // 2 x 5.000 = 10.000

        // Admin marks Es Teh as unavailable
        $this->menuEsTeh->update(['is_available' => false]);

        $component = Livewire::test(CartViewer::class);

        // Alert banner with role="alert"
        $component->assertSeeHtml('role="alert"');
        $component->assertSee('Beberapa menu sudah tidak tersedia dan tidak dihitung');
        $component->assertSee('Menu Es Teh Manis sedang tidak tersedia');
        $component->assertSee('Hapus menu yang tidak tersedia');

        // Total excludes Es Teh (only Bakso 18.000)
        $component->assertSee('Rp 18.000');
        $component->assertDontSee('Rp 28.000');
    }

    public function test_remove_unavailable_only_purges_problem_lines_leaving_valid_lines(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 2); // available
        $cart->add($this->menuEsTeh->id, 1); // will become unavailable

        $this->menuEsTeh->update(['is_available' => false]);

        $component = Livewire::test(CartViewer::class);
        $component->assertSee('Beberapa menu sudah tidak tersedia dan tidak dihitung');

        // Call removeUnavailable
        $component->call('removeUnavailable');
        $component->assertDispatched('cart-updated');

        // Es Teh is removed, Bakso remains
        $lines = $cart->lines();
        $this->assertTrue(isset($lines[$this->menuBakso->id]));
        $this->assertFalse(isset($lines[$this->menuEsTeh->id]));
        $this->assertSame(2, $cart->count());

        // Alert banner is now gone
        $component->assertDontSee('Beberapa menu sudah tidak tersedia dan tidak dihitung');
    }

    public function test_checkout_button_is_disabled_when_cart_is_empty_or_has_problems(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();

        // 1. When empty: button is disabled
        $component = Livewire::test(CartViewer::class);
        $component->assertSeeHtml('disabled');
        $component->assertSee('Lanjut ke Konfirmasi');

        // 2. When valid: button is active link
        $cart->add($this->menuBakso->id, 1);
        $component = Livewire::test(CartViewer::class);
        $component->assertSeeHtml('href="' . route('customer.confirm') . '"');

        // 3. When has problem: button is disabled with explanatory text
        $this->menuBakso->update(['is_available' => false]);
        $component = Livewire::test(CartViewer::class);
        $component->assertSeeHtml('disabled');
        $component->assertSee('Hapus menu yang tidak tersedia terlebih dahulu');
    }

    public function test_database_price_changes_are_reflected_live_without_session_prices(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 2); // 2 x 18.000 = 36.000

        $component = Livewire::test(CartViewer::class);
        $component->assertSee('Rp 36.000');

        // Verify session data does NOT store prices
        $rawSessionCart = session('cart');
        $this->assertArrayNotHasKey('price', $rawSessionCart[$this->menuBakso->id]);
        $this->assertArrayNotHasKey('unit_price', $rawSessionCart[$this->menuBakso->id]);
        $this->assertArrayNotHasKey('total', $rawSessionCart[$this->menuBakso->id]);

        // Admin updates price in database to 22.000
        $this->menuBakso->update(['price' => 22000]);

        // Next render automatically reflects 2 x 22.000 = 44.000
        $component = Livewire::test(CartViewer::class);
        $component->assertSee('Rp 44.000');
        $component->assertSee('Rp 22.000 / porsi');
    }

    public function test_cart_viewer_has_no_n_plus_one_queries(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();

        // Create 8 menu items and add to cart
        $menus = Menu::factory()->count(8)->create([
            'category_id' => $this->categoryMakanan->id,
            'is_available' => true,
        ]);

        foreach ($menus as $m) {
            $cart->add($m->id, 1);
        }

        DB::flushQueryLog();
        DB::enableQueryLog();

        Livewire::test(CartViewer::class);

        $queries = DB::getQueryLog();
        DB::disableQueryLog();

        // Summary should execute a single Menu query (with category eager loaded)
        // rather than 1 query per item in cart.
        // Total queries for component render should be very low (<= 5 queries).
        $this->assertLessThanOrEqual(5, count($queries), 'Query count indicates an N+1 query issue.');
    }

    public function test_tampered_or_invalid_menu_id_is_safely_rejected(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 1);

        $component = Livewire::test(CartViewer::class);

        // Invalid negative or zero menu_id
        $component->call('incrementQty', -1);
        $component->assertSet('errorMessage', 'Menu tidak ada di dalam keranjang.');

        $component->call('decrementQty', 0);
        $component->assertSet('errorMessage', 'Menu tidak ada di dalam keranjang.');

        $component->call('removeItem', 999999);
        $component->assertSet('errorMessage', 'Menu tidak ada di dalam keranjang.');

        $component->call('updateQty', 999999, 5);
        $component->assertSet('errorMessage', 'Menu tidak ada di dalam keranjang.');

        $component->call('saveNote', 999999);
        $component->assertSet('errorMessage', 'Menu tidak ada di dalam keranjang.');
    }

    public function test_note_and_menu_texts_with_html_are_escaped_against_xss(): void
    {
        $this->actingAsCustomerSession();

        $xssMenu = Menu::factory()->create([
            'category_id' => $this->categoryMakanan->id,
            'name' => '<script>alert("xss-menu")</script>',
            'price' => 15000,
            'is_available' => true,
        ]);

        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($xssMenu->id, 1);
        $cart->setItemNote($xssMenu->id, '<b onmouseover=alert("xss-note")>Catatan</b>');

        $response = $this->get(route('customer.cart'));

        $response->assertOk();
        $response->assertDontSee('<script>alert("xss-menu")</script>', false);
        $response->assertDontSee('<b onmouseover=alert("xss-note")>', false);
        $response->assertSee('&lt;script&gt;alert(&quot;xss-menu&quot;)&lt;/script&gt;', false);
    }

    public function test_cart_badge_updated_event_is_dispatched_on_cart_modifications(): void
    {
        $this->actingAsCustomerSession();
        $cart = app(CartService::class);
        $cart->clear();
        $cart->add($this->menuBakso->id, 2);

        $component = Livewire::test(CartViewer::class);

        $component->call('incrementQty', $this->menuBakso->id);
        $component->assertDispatched('cart-updated');

        $component->call('decrementQty', $this->menuBakso->id);
        $component->assertDispatched('cart-updated');

        $component->call('saveNote', $this->menuBakso->id);
        $component->assertDispatched('cart-updated');

        $component->call('removeItem', $this->menuBakso->id);
        $component->assertDispatched('cart-updated');
    }
}
