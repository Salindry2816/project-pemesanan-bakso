<?php

namespace Tests\Feature;

use Illuminate\Support\Facades\Route;
use Tests\TestCase;

class DesignTokensRouteTest extends TestCase
{
    public function test_tokens_page_is_not_accessible_outside_local_environment(): void
    {
        // In testing environment (APP_ENV=testing), app()->isLocal() is false
        $this->assertFalse(app()->isLocal());

        $response = $this->get('/_tokens');
        $response->assertNotFound();
    }

    public function test_tokens_view_renders_design_system_tokens(): void
    {
        $view = $this->view('pages.design-tokens');

        $view->assertSee('Design System');
        $view->assertSee('#782A25');
        $view->assertSee('#C62828');
        $view->assertSee('#FFFBEA');
        $view->assertSee('Poppins');
        $view->assertSee('Nunito');
    }

    public function test_theme_css_defines_table_state_color_tokens_and_build_contains_utilities(): void
    {
        $cssSource = file_get_contents(resource_path('css/app.css'));
        $this->assertStringContainsString('--color-table-tersedia: #064E34;', $cssSource);
        $this->assertStringContainsString('--color-table-terisi: #C62828;', $cssSource);
        $this->assertStringContainsString('--color-table-dipilih: #E0A15A;', $cssSource);

        $manifestPath = public_path('build/manifest.json');
        if (file_exists($manifestPath)) {
            $manifest = json_decode(file_get_contents($manifestPath), true);
            $cssFile = $manifest['resources/css/app.css']['file'] ?? null;
            if ($cssFile && file_exists(public_path('build/' . $cssFile))) {
                $builtCss = file_get_contents(public_path('build/' . $cssFile));
                $this->assertStringContainsString('.bg-table-tersedia', $builtCss);
                $this->assertStringContainsString('.bg-table-terisi', $builtCss);
            }
        }
    }

    public function test_all_custom_theme_token_classes_in_views_are_defined_in_theme_css(): void
    {
        $cssSource = file_get_contents(resource_path('css/app.css'));

        // Extract color tokens defined under @theme
        preg_match('/@theme\s*\{([^}]+)\}/s', $cssSource, $themeMatches);
        $this->assertNotEmpty($themeMatches, 'No @theme block found in resources/css/app.css');

        $definedTokens = [];
        foreach (explode("\n", $themeMatches[1]) as $line) {
            if (preg_match('/--color-([a-zA-Z0-9_-]+)\s*:/', $line, $m)) {
                $definedTokens[$m[1]] = true;
            }
        }

        $stdColors = [
            'white', 'black', 'transparent', 'current', 'inherit',
            'red', 'green', 'blue', 'yellow', 'amber', 'gray', 'slate', 'zinc',
            'neutral', 'stone', 'orange', 'emerald', 'teal', 'cyan', 'sky',
            'indigo', 'violet', 'purple', 'fuchsia', 'pink', 'rose',
        ];

        $stdUtilities = [
            'text' => [
                'xs', 'sm', 'base', 'lg', 'xl', '2xl', '3xl', '4xl', '5xl', '6xl', '7xl', '8xl', '9xl',
                'left', 'center', 'right', 'justify', 'start', 'end',
                'ellipsis', 'clip', 'wrap', 'nowrap', 'balance', 'pretty',
            ],
            'border' => [
                '0', '1', '2', '4', '8', 't', 'b', 'l', 'r', 'x', 'y', 't-0', 't-2', 't-4', 't-8',
                'b-0', 'b-2', 'b-4', 'b-8', 'l-0', 'l-2', 'l-4', 'l-8', 'r-0', 'r-2', 'r-4', 'r-8',
                'solid', 'dashed', 'dotted', 'double', 'hidden', 'none',
                'collapse', 'separate',
            ],
            'ring' => [
                '0', '1', '2', '3', '4', '8', 'inset',
            ],
            'bg' => [
                'auto', 'cover', 'contain', 'bottom', 'top', 'center', 'left', 'right',
                'repeat', 'no-repeat', 'repeat-x', 'repeat-y', 'repeat-round', 'repeat-space',
                'fixed', 'local', 'scroll', 'transparent',
            ],
        ];

        $viewsPath = resource_path('views');
        $files = new \RecursiveIteratorIterator(new \RecursiveDirectoryIterator($viewsPath));
        $undefined = [];

        /** @var \SplFileInfo $file */
        foreach ($files as $file) {
            if ($file->isDir() || ! str_ends_with($file->getFilename(), '.blade.php')) {
                continue;
            }

            $content = file_get_contents($file->getPathname());
            $relPath = str_replace('\\', '/', substr($file->getPathname(), strlen($viewsPath) + 1));

            // Extract all class="..." or class='...'
            preg_match_all('/class=(?:"([^"]*)"|\'([^\']*)\')/', $content, $matches, PREG_SET_ORDER);

            $classes = [];
            foreach ($matches as $match) {
                $raw = $match[1] ?: $match[2] ?: '';
                foreach (preg_split('/\s+/', $raw, -1, PREG_SPLIT_NO_EMPTY) as $cls) {
                    $classes[] = $cls;
                }
            }

            foreach ($classes as $cls) {
                // Strip quotes, brackets, ternary artifacts
                $cleaned = trim($cls, "\"'() \t\r\n");
                // Strip variants like hover:, focus:, md:, lg:, dark:, peer-checked:
                $cleaned = preg_replace('/^(?:[a-zA-Z0-9_-]+:)+/', '', $cleaned);
                // Strip opacity suffix like /80, /40
                $base = preg_replace('/\/(?:\d+|[a-zA-Z0-9_\.]+)$/', '', $cleaned);

                foreach (['bg-', 'text-', 'border-', 'ring-'] as $prefix) {
                    if (str_starts_with($base, $prefix)) {
                        $prop = substr($prefix, 0, -1);
                        $token = substr($base, strlen($prefix));

                        // Ignore arbitrary values like text-[12px] or bg-[#fff]
                        if (str_starts_with($token, '[') || in_array($token, $stdUtilities[$prop] ?? [], true)) {
                            continue;
                        }

                        // Check standard colors
                        $isStd = false;
                        foreach ($stdColors as $sc) {
                            if ($token === $sc || str_starts_with($token, $sc . '-')) {
                                $isStd = true;
                                break;
                            }
                        }
                        if ($isStd) {
                            continue;
                        }

                        // Must exist in defined tokens
                        if (! isset($definedTokens[$token])) {
                            $undefined[$relPath][] = "{$cls} (token: {$token})";
                        }
                    }
                }
            }
        }

        $this->assertEmpty(
            $undefined,
            "Found custom token classes in views without definitions in resources/css/app.css:\n" . json_encode($undefined, JSON_PRETTY_PRINT)
        );
    }
}
