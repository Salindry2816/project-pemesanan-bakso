<?php

namespace Tests\Feature;

use App\Livewire\Admin\ChangePassword;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Livewire\Livewire;
use Tests\TestCase;

class AdminChangePasswordTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::factory()->create([
            'username' => 'admin_test',
            'password' => 'old_password_123',
        ]);
    }

    public function test_guest_is_redirected_from_change_password_page(): void
    {
        $this->get(route('admin.password'))
            ->assertRedirect(route('admin.login'));
    }

    public function test_change_password_validates_current_length_confirmation_and_rejects_same_password(): void
    {
        $this->actingAs($this->admin);

        // Wrong current password
        Livewire::test(ChangePassword::class)
            ->set('currentPassword', 'wrong_pass')
            ->set('newPassword', 'new_password_123')
            ->set('newPasswordConfirmation', 'new_password_123')
            ->call('updatePassword')
            ->assertHasErrors('currentPassword');

        // Too short (< 8)
        Livewire::test(ChangePassword::class)
            ->set('currentPassword', 'old_password_123')
            ->set('newPassword', 'short')
            ->set('newPasswordConfirmation', 'short')
            ->call('updatePassword')
            ->assertHasErrors('newPassword');

        // Mismatched confirmation
        Livewire::test(ChangePassword::class)
            ->set('currentPassword', 'old_password_123')
            ->set('newPassword', 'new_password_123')
            ->set('newPasswordConfirmation', 'different_123')
            ->call('updatePassword')
            ->assertHasErrors('newPasswordConfirmation');

        // Same as current password
        Livewire::test(ChangePassword::class)
            ->set('currentPassword', 'old_password_123')
            ->set('newPassword', 'old_password_123')
            ->set('newPasswordConfirmation', 'old_password_123')
            ->call('updatePassword')
            ->assertHasErrors('newPassword');

        $this->assertTrue(Hash::check('old_password_123', $this->admin->fresh()->password));
    }

    public function test_change_password_is_rate_limited_after_five_failed_attempts(): void
    {
        $this->actingAs($this->admin);

        for ($i = 0; $i < 5; $i++) {
            Livewire::test(ChangePassword::class)
                ->set('currentPassword', 'wrong_password')
                ->set('newPassword', 'new_password_123')
                ->set('newPasswordConfirmation', 'new_password_123')
                ->call('updatePassword')
                ->assertHasErrors('currentPassword');
        }

        Livewire::test(ChangePassword::class)
            ->set('currentPassword', 'old_password_123')
            ->set('newPassword', 'new_password_123')
            ->set('newPasswordConfirmation', 'new_password_123')
            ->call('updatePassword')
            ->assertHasErrors('currentPassword')
            ->assertSee('Terlalu banyak percobaan gagal');

        $this->assertTrue(Hash::check('old_password_123', $this->admin->fresh()->password));
    }

    public function test_change_password_updates_password_regenerates_session_and_revokes_other_database_sessions(): void
    {
        config(['session.driver' => 'database']);

        $this->actingAs($this->admin);
        $oldSessionId = session()->getId();

        // Simulate another logged-in device session for the same admin
        DB::table('sessions')->insert([
            'id' => 'other-device-session-id',
            'user_id' => $this->admin->id,
            'ip_address' => '127.0.0.2',
            'user_agent' => 'OtherDevice/1.0',
            'payload' => base64_encode('test'),
            'last_activity' => time(),
        ]);

        // Also insert another user's session to ensure it is NOT deleted
        $otherUser = User::factory()->create(['username' => 'other_admin']);
        DB::table('sessions')->insert([
            'id' => 'other-user-session-id',
            'user_id' => $otherUser->id,
            'ip_address' => '127.0.0.3',
            'user_agent' => 'OtherUser/1.0',
            'payload' => base64_encode('test'),
            'last_activity' => time(),
        ]);

        Livewire::test(ChangePassword::class)
            ->set('currentPassword', 'old_password_123')
            ->set('newPassword', 'new_secure_pass_456')
            ->set('newPasswordConfirmation', 'new_secure_pass_456')
            ->call('updatePassword')
            ->assertHasNoErrors()
            ->assertSee('Password berhasil diperbarui.');

        $this->assertTrue(Hash::check('new_secure_pass_456', $this->admin->fresh()->password));
        $this->assertNotSame($oldSessionId, session()->getId());

        $this->assertDatabaseMissing('sessions', ['id' => 'other-device-session-id']);
        $this->assertDatabaseHas('sessions', ['id' => 'other-user-session-id']);
    }
}
