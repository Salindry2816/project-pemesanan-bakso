<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\TableType;
use App\Livewire\Admin\TableManager;
use App\Models\DiningTable;
use App\Models\Order;
use App\Models\User;
use App\Support\TableCode;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Features\SupportLockedProperties\CannotUpdateLockedPropertyException;
use Livewire\Livewire;
use Tests\TestCase;

class AdminTableTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_is_redirected_from_tables_page_to_login(): void
    {
        $response = $this->get(route('admin.tables'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_unauthenticated_livewire_actions_on_table_manager_are_forbidden(): void
    {
        $table = DiningTable::factory()->create([
            'code' => '2A',
            'floor' => 2,
            'type' => TableType::Fixed,
            'is_active' => true,
        ]);

        Livewire::test(TableManager::class)
            ->call('createTable')
            ->assertForbidden();

        Livewire::test(TableManager::class)
            ->call('toggleActive', $table->id)
            ->assertForbidden();

        Livewire::test(TableManager::class)
            ->call('deleteTable', $table->id)
            ->assertForbidden();

        $this->assertDatabaseHas('tables', [
            'id' => $table->id,
            'is_active' => true,
        ]);
    }

    public function test_locked_deleting_id_property_cannot_be_tampered_from_client(): void
    {
        $admin = User::factory()->create();
        $table = DiningTable::factory()->create(['code' => '2A', 'floor' => 2]);

        $this->expectException(CannotUpdateLockedPropertyException::class);

        Livewire::actingAs($admin)
            ->test(TableManager::class)
            ->set('deletingId', $table->id);
    }

    public function test_admin_can_add_tables_per_floor_and_next_code_after_2g_is_2h(): void
    {
        $admin = User::factory()->create();

        // Seed 2A-2G and BEBAS on floor 2
        foreach (TableCode::range(2, 7) as $code) {
            DiningTable::factory()->create([
                'code' => $code,
                'floor' => 2,
                'type' => TableType::Fixed,
                'capacity' => 4,
                'is_active' => true,
            ]);
        }

        DiningTable::factory()->freeTable()->create();

        // 1. Add next table on floor 2 -> must be 2H
        Livewire::actingAs($admin)
            ->test(TableManager::class)
            ->assertSee('2H')
            ->set('selectedFloor', '2')
            ->set('capacity', '6')
            ->call('createTable')
            ->assertHasNoErrors()
            ->assertSee('Meja 2H (Lantai 2) berhasil ditambahkan.');

        $this->assertDatabaseHas('tables', [
            'code' => '2H',
            'floor' => 2,
            'type' => TableType::Fixed->value,
            'capacity' => 6,
            'is_active' => true,
        ]);

        // 2. Add first table on floor 3 with empty (optional) capacity -> must be 3A with null capacity
        Livewire::actingAs($admin)
            ->test(TableManager::class)
            ->set('selectedFloor', '3')
            ->set('capacity', '')
            ->call('createTable')
            ->assertHasNoErrors()
            ->assertSee('Meja 3A (Lantai 3) berhasil ditambahkan.');

        $this->assertDatabaseHas('tables', [
            'code' => '3A',
            'floor' => 3,
            'type' => TableType::Fixed->value,
            'capacity' => null,
            'is_active' => true,
        ]);

        // 3. Invalid capacity (0, > 50, decimal) is rejected
        Livewire::actingAs($admin)
            ->test(TableManager::class)
            ->set('selectedFloor', '2')
            ->set('capacity', '0')
            ->call('createTable')
            ->assertHasErrors(['capacity'])
            ->set('capacity', '55')
            ->call('createTable')
            ->assertHasErrors(['capacity'])
            ->set('capacity', '4.5')
            ->call('createTable')
            ->assertHasErrors(['capacity']);
    }

    public function test_toggle_active_blocks_table_with_active_order_and_allows_when_order_is_finished_or_cancelled(): void
    {
        $admin = User::factory()->create();
        $table = DiningTable::factory()->create([
            'code' => '2A',
            'floor' => 2,
            'type' => TableType::Fixed,
            'is_active' => true,
        ]);

        $order = Order::factory()->create([
            'table_id' => $table->id,
            'type' => OrderType::DineIn,
            'status' => OrderStatus::Diterima,
        ]);

        // Verify page displays "Terisi" when active order exists
        $response = $this->actingAs($admin)->get(route('admin.tables'));
        $response->assertStatus(200);
        $response->assertSee('Terisi');

        // All 4 active statuses must block deactivation
        foreach ([OrderStatus::Diterima, OrderStatus::Diproses, OrderStatus::Disiapkan, OrderStatus::Siap] as $activeStatus) {
            $order->update(['status' => $activeStatus]);

            Livewire::actingAs($admin)
                ->test(TableManager::class)
                ->call('toggleActive', $table->id)
                ->assertSee("Meja {$table->code} tidak dapat dinonaktifkan karena sedang memiliki pesanan aktif.");

            $this->assertDatabaseHas('tables', [
                'id' => $table->id,
                'is_active' => true,
            ]);
        }

        // Once order is selesai, table can be deactivated
        $order->update(['status' => OrderStatus::Selesai]);

        Livewire::actingAs($admin)
            ->test(TableManager::class)
            ->call('toggleActive', $table->id)
            ->assertSee("Meja {$table->code} dinonaktifkan.");

        $this->assertDatabaseHas('tables', [
            'id' => $table->id,
            'is_active' => false,
        ]);

        // Reactivate, then test with dibatalkan order
        Livewire::actingAs($admin)
            ->test(TableManager::class)
            ->call('toggleActive', $table->id)
            ->assertSee("Meja {$table->code} diaktifkan.");

        $order->update(['status' => OrderStatus::Dibatalkan]);

        Livewire::actingAs($admin)
            ->test(TableManager::class)
            ->call('toggleActive', $table->id)
            ->assertSee("Meja {$table->code} dinonaktifkan.");

        $this->assertDatabaseHas('tables', [
            'id' => $table->id,
            'is_active' => false,
        ]);
    }

    public function test_server_rejects_deleting_table_with_order_history_and_allows_deleting_unused_table(): void
    {
        $admin = User::factory()->create();
        $usedTable = DiningTable::factory()->create(['code' => '2A', 'floor' => 2]);
        $unusedTable = DiningTable::factory()->create(['code' => '2B', 'floor' => 2]);

        Order::factory()->create([
            'table_id' => $usedTable->id,
            'type' => OrderType::DineIn,
            'status' => OrderStatus::Selesai,
        ]);

        // Direct server delete call on table with history must be rejected
        Livewire::actingAs($admin)
            ->test(TableManager::class)
            ->call('deleteTable', $usedTable->id)
            ->assertSee("Meja {$usedTable->code} tidak dapat dihapus karena sudah memiliki riwayat pesanan.");

        $this->assertDatabaseHas('tables', ['id' => $usedTable->id]);

        // Unused table can be deleted via modal confirmation flow
        Livewire::actingAs($admin)
            ->test(TableManager::class)
            ->call('confirmDelete', $unusedTable->id)
            ->assertSet('deletingId', $unusedTable->id)
            ->call('deleteTable')
            ->assertSee("Meja {$unusedTable->code} berhasil dihapus.");

        $this->assertDatabaseMissing('tables', ['id' => $unusedTable->id]);
    }

    public function test_free_table_bebas_is_locked_and_cannot_be_deactivated_or_deleted(): void
    {
        $admin = User::factory()->create();
        $bebas = DiningTable::factory()->freeTable()->create();

        Livewire::actingAs($admin)
            ->test(TableManager::class)
            ->assertSee('BEBAS')
            ->assertSee('Aktif (Terkunci)')
            ->call('toggleActive', $bebas->id)
            ->assertSee('Meja Bebas bersifat permanen dan tidak dapat dinonaktifkan.')
            ->call('confirmDelete', $bebas->id)
            ->assertSet('deletingId', null)
            ->assertSee('Meja Bebas bersifat permanen dan tidak dapat dihapus.')
            ->call('deleteTable', $bebas->id)
            ->assertSee('Meja Bebas bersifat permanen dan tidak dapat dihapus.');

        $this->assertDatabaseHas('tables', [
            'id' => $bebas->id,
            'code' => 'BEBAS',
            'is_active' => true,
        ]);
    }

    public function test_table_occupancy_badges_and_capacity_labels_render_correctly(): void
    {
        $admin = User::factory()->create();

        // 2A: occupied with active dine-in order and set capacity
        $table2A = DiningTable::factory()->create([
            'code' => '2A',
            'floor' => 2,
            'capacity' => 4,
            'is_active' => true,
        ]);

        Order::factory()->create([
            'table_id' => $table2A->id,
            'type' => OrderType::DineIn,
            'status' => OrderStatus::Diproses,
        ]);

        // 2B: available (completed order only) and null capacity
        $table2B = DiningTable::factory()->create([
            'code' => '2B',
            'floor' => 2,
            'capacity' => null,
            'is_active' => true,
        ]);

        Order::factory()->create([
            'table_id' => $table2B->id,
            'type' => OrderType::DineIn,
            'status' => OrderStatus::Selesai,
        ]);

        Livewire::actingAs($admin)
            ->test(TableManager::class)
            ->assertSeeHtml('bg-table-terisi')
            ->assertSeeHtml('bg-table-tersedia')
            ->assertSee('Terisi')
            ->assertSee('Tersedia')
            ->assertSee('4 kursi')
            ->assertSee('Kapasitas tidak diatur');
    }
}
