<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Enums\TableType;
use App\Livewire\Admin\Dashboard;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderStatusLog;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Livewire\Livewire;
use Tests\TestCase;

class AdminDashboardTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::factory()->create(['username' => 'admin_test']);
    }

    public function test_guest_is_redirected_from_dashboard_to_login(): void
    {
        $this->get(route('admin.dashboard'))
            ->assertRedirect(route('admin.login'));
    }

    public function test_dashboard_renders_wire_poll_and_stat_counts_including_selesai_hari_ini_from_logs(): void
    {
        $customer = Customer::factory()->create(['phone' => '6281234560001']);
        $table = DiningTable::factory()->create(['code' => '2A', 'floor' => 2, 'type' => TableType::Fixed]);

        Order::factory()->create([
            'order_number' => '20261113-0001',
            'customer_id' => $customer->id,
            'table_id' => $table->id,
            'status' => OrderStatus::Diterima,
        ]);

        Order::factory()->create([
            'order_number' => '20261113-0002',
            'customer_id' => $customer->id,
            'table_id' => $table->id,
            'status' => OrderStatus::Diproses,
        ]);

        Order::factory()->create([
            'order_number' => '20261113-0003',
            'customer_id' => $customer->id,
            'table_id' => $table->id,
            'status' => OrderStatus::Siap,
        ]);

        // Created yesterday, completed today -> MUST count in Selesai Hari Ini
        $completedToday = Order::factory()->create([
            'order_number' => '20261112-0099',
            'customer_id' => $customer->id,
            'table_id' => $table->id,
            'status' => OrderStatus::Selesai,
            'created_at' => now()->subDay(),
        ]);

        OrderStatusLog::query()->create([
            'order_id' => $completedToday->id,
            'status' => OrderStatus::Selesai,
            'changed_by' => $this->admin->id,
            'created_at' => now(),
        ]);

        // Completed yesterday -> MUST NOT count in Selesai Hari Ini
        $completedYesterday = Order::factory()->create([
            'order_number' => '20261112-0001',
            'customer_id' => $customer->id,
            'table_id' => $table->id,
            'status' => OrderStatus::Selesai,
            'created_at' => now()->subDay(),
        ]);

        OrderStatusLog::query()->create([
            'order_id' => $completedYesterday->id,
            'status' => OrderStatus::Selesai,
            'changed_by' => $this->admin->id,
            'created_at' => now()->subDay(),
        ]);

        $this->actingAs($this->admin);

        Livewire::test(Dashboard::class)
            ->assertSeeHtml('wire:poll.5s.visible')
            ->assertSee('Pesanan Baru')
            ->assertSee('Dalam Proses')
            ->assertSee('Siap Diantar')
            ->assertSee('Selesai Hari Ini')
            ->assertViewHas('pesananBaruCount', 1)
            ->assertViewHas('dalamProsesCount', 1)
            ->assertViewHas('siapDiantarCount', 1)
            ->assertViewHas('selesaiHariIniCount', 1);
    }

    public function test_dashboard_filters_by_status_and_search_with_eager_loading(): void
    {
        $customerA = Customer::factory()->create(['phone' => '6281234560001']);
        $customerB = Customer::factory()->create(['phone' => '6281234560002']);
        $table2A = DiningTable::factory()->create(['code' => '2A', 'floor' => 2, 'type' => TableType::Fixed]);

        $orderA = Order::factory()->create([
            'order_number' => '20261113-0001',
            'customer_id' => $customerA->id,
            'type' => OrderType::DineIn,
            'table_id' => $table2A->id,
            'payment_method' => PaymentMethod::Qris,
            'payment_status' => PaymentStatus::BelumBayar,
            'status' => OrderStatus::Diterima,
        ]);

        OrderItem::factory()->create([
            'order_id' => $orderA->id,
            'name_snapshot' => 'Bakso Komplit',
            'qty' => 2,
            'price_snapshot' => 18000,
            'line_total' => 36000,
        ]);

        $orderB = Order::factory()->create([
            'order_number' => '20261113-0002',
            'customer_id' => $customerB->id,
            'type' => OrderType::TakeAway,
            'table_id' => null,
            'status' => OrderStatus::Selesai,
        ]);

        $this->actingAs($this->admin);

        Livewire::test(Dashboard::class)
            ->assertSee('#0001')
            ->assertDontSee('#0002')
            ->call('setFilter', 'selesai')
            ->assertSee('#0002')
            ->assertDontSee('#0001')
            ->call('setFilter', 'semua')
            ->set('search', '2A')
            ->assertSee('#0001')
            ->assertDontSee('#0002');

        // Verify no N+1 queries when rendering multiple orders
        for ($i = 3; $i <= 10; $i++) {
            $o = Order::factory()->create([
                'order_number' => '20261113-000'.$i,
                'customer_id' => $customerA->id,
                'table_id' => $table2A->id,
                'status' => OrderStatus::Diterima,
            ]);
            OrderItem::factory()->create(['order_id' => $o->id]);
        }

        DB::flushQueryLog();
        DB::enableQueryLog();

        Livewire::test(Dashboard::class);

        $queries = DB::getQueryLog();
        DB::disableQueryLog();

        $this->assertLessThanOrEqual(12, count($queries));
    }
}
