<?php

namespace Tests\Feature;

use App\Models\Order;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

class OrderSequenceAndCheckoutTokenSchemaTest extends TestCase
{
    use RefreshDatabase;

    public function test_orders_checkout_token_column_is_nullable_and_unique(): void
    {
        $this->assertTrue(Schema::hasColumn('orders', 'checkout_token'));

        $firstNullOrder = Order::factory()->create([
            'order_number' => '20261113-0001',
            'checkout_token' => null,
        ]);

        $secondNullOrder = Order::factory()->create([
            'order_number' => '20261113-0002',
            'checkout_token' => null,
        ]);

        $this->assertNull($firstNullOrder->checkout_token);
        $this->assertNull($secondNullOrder->checkout_token);

        $token = str_repeat('a', 64);

        Order::factory()->create([
            'order_number' => '20261113-0003',
            'checkout_token' => $token,
        ]);

        $this->expectException(QueryException::class);

        Order::factory()->create([
            'order_number' => '20261113-0004',
            'checkout_token' => $token,
        ]);
    }

    public function test_order_sequences_table_has_primary_key_seq_date_and_zero_default(): void
    {
        $this->assertTrue(Schema::hasTable('order_sequences'));
        $this->assertTrue(Schema::hasColumns('order_sequences', ['seq_date', 'last_number']));

        DB::table('order_sequences')->insert([
            'seq_date' => '2026-11-13',
        ]);

        $row = DB::table('order_sequences')->where('seq_date', '2026-11-13')->first();
        $this->assertNotNull($row);
        $this->assertSame(0, (int) $row->last_number);

        $this->expectException(QueryException::class);

        DB::table('order_sequences')->insert([
            'seq_date' => '2026-11-13',
            'last_number' => 5,
        ]);
    }
}
