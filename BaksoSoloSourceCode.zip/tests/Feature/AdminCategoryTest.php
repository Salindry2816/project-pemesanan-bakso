<?php

namespace Tests\Feature;

use App\Livewire\Admin\CategoryManager;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use Tests\TestCase;

class AdminCategoryTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_is_redirected_from_categories_page_to_login(): void
    {
        $response = $this->get(route('admin.categories'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_unauthenticated_livewire_actions_on_category_manager_are_forbidden(): void
    {
        $category = MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);

        Livewire::test(CategoryManager::class)
            ->set('newName', 'Kategori Ilegal')
            ->call('createCategory')
            ->assertForbidden();

        Livewire::test(CategoryManager::class)
            ->call('deleteCategory', $category->id)
            ->assertForbidden();

        $this->assertDatabaseMissing('menu_categories', ['name' => 'Kategori Ilegal']);
        $this->assertDatabaseHas('menu_categories', ['id' => $category->id, 'name' => 'Bakso']);
    }

    public function test_admin_can_view_categories_page_and_create_category_with_trimmed_name(): void
    {
        $admin = User::factory()->create();

        $response = $this->actingAs($admin)->get(route('admin.categories'));
        $response->assertStatus(200);
        $response->assertSee('Kelola Kategori Menu');
        $response->assertSee('Kategori');

        Livewire::actingAs($admin)
            ->test(CategoryManager::class)
            ->set('newName', '   Bakso   Spesial   ')
            ->call('createCategory')
            ->assertHasNoErrors()
            ->assertSet('newName', '')
            ->assertSee('Kategori berhasil ditambahkan.');

        $this->assertDatabaseHas('menu_categories', [
            'name' => 'Bakso Spesial',
            'sort_order' => 1,
        ]);
    }

    public function test_category_name_validation_enforces_required_max_50_and_case_insensitive_uniqueness(): void
    {
        $admin = User::factory()->create();
        MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);
        $second = MenuCategory::factory()->create(['name' => 'Minuman', 'sort_order' => 2]);

        // 1. Empty / whitespace-only
        Livewire::actingAs($admin)
            ->test(CategoryManager::class)
            ->set('newName', '   ')
            ->call('createCategory')
            ->assertHasErrors(['newName'])
            ->assertSee('Nama kategori wajib diisi.');

        // 2. Exceeds 50 characters
        Livewire::actingAs($admin)
            ->test(CategoryManager::class)
            ->set('newName', str_repeat('A', 51))
            ->call('createCategory')
            ->assertHasErrors(['newName'])
            ->assertSee('Nama kategori maksimal 50 karakter.');

        // 3. Case-insensitive duplicate on create
        Livewire::actingAs($admin)
            ->test(CategoryManager::class)
            ->set('newName', '  bAkSo  ')
            ->call('createCategory')
            ->assertHasErrors(['newName'])
            ->assertSee('Nama kategori sudah digunakan.');

        // 4. Case-insensitive duplicate on update of another category
        Livewire::actingAs($admin)
            ->test(CategoryManager::class)
            ->call('startEdit', $second->id)
            ->set('editingName', 'BAKSO')
            ->call('updateCategory')
            ->assertHasErrors(['editingName'])
            ->assertSee('Nama kategori sudah digunakan.');
    }

    public function test_admin_can_update_category_name_including_same_category_casing(): void
    {
        $admin = User::factory()->create();
        $category = MenuCategory::factory()->create(['name' => 'bakso', 'sort_order' => 1]);

        Livewire::actingAs($admin)
            ->test(CategoryManager::class)
            ->call('startEdit', $category->id)
            ->set('editingName', '  Bakso Utama  ')
            ->call('updateCategory')
            ->assertHasNoErrors()
            ->assertSet('editingId', null)
            ->assertSee('Nama kategori berhasil diperbarui.');

        $this->assertDatabaseHas('menu_categories', [
            'id' => $category->id,
            'name' => 'Bakso Utama',
        ]);
    }

    public function test_admin_can_move_categories_up_and_down_repeatedly_and_after_deletion(): void
    {
        $admin = User::factory()->create();
        $cat1 = MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);
        $cat2 = MenuCategory::factory()->create(['name' => 'Paket', 'sort_order' => 2]);
        $cat3 = MenuCategory::factory()->create(['name' => 'Minuman', 'sort_order' => 3]);

        $component = Livewire::actingAs($admin)->test(CategoryManager::class);

        // Boundary check: moving top category up does nothing
        $component->call('moveUp', $cat1->id);
        $this->assertSame(
            [$cat1->id, $cat2->id, $cat3->id],
            MenuCategory::query()->orderBy('sort_order')->pluck('id')->all()
        );

        // Boundary check: moving bottom category down does nothing
        $component->call('moveDown', $cat3->id);
        $this->assertSame(
            [$cat1->id, $cat2->id, $cat3->id],
            MenuCategory::query()->orderBy('sort_order')->pluck('id')->all()
        );

        // Move Minuman (cat3) up twice -> should become [Minuman, Bakso, Paket]
        $component->call('moveUp', $cat3->id)
            ->call('moveUp', $cat3->id);

        $this->assertSame(
            [$cat3->id, $cat1->id, $cat2->id],
            MenuCategory::query()->orderBy('sort_order')->pluck('id')->all()
        );

        // Delete middle category (cat1 - Bakso) leaving a gap, then swap remaining [cat3, cat2]
        $component->call('confirmDelete', $cat1->id)
            ->call('deleteCategory');

        $this->assertDatabaseMissing('menu_categories', ['id' => $cat1->id]);

        $component->call('moveDown', $cat3->id);

        $this->assertSame(
            [$cat2->id, $cat3->id],
            MenuCategory::query()->orderBy('sort_order')->pluck('id')->all()
        );
    }

    public function test_server_rejects_deleting_category_that_still_has_menus(): void
    {
        $admin = User::factory()->create();
        $category = MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);
        Menu::factory()->create([
            'category_id' => $category->id,
            'name' => 'Bakso Komplit',
        ]);

        // Direct server call to deleteCategory(id) bypassing modal confirmation
        Livewire::actingAs($admin)
            ->test(CategoryManager::class)
            ->call('deleteCategory', $category->id)
            ->assertSee('Kategori tidak dapat dihapus karena masih memiliki menu. Pindahkan atau hapus menu terlebih dahulu.');

        $this->assertDatabaseHas('menu_categories', ['id' => $category->id]);
        $this->assertDatabaseHas('menus', ['category_id' => $category->id, 'name' => 'Bakso Komplit']);
    }
}
