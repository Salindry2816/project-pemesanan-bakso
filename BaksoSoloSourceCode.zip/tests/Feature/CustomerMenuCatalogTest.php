<?php

namespace Tests\Feature;

use App\Enums\TableType;
use App\Livewire\Customer\MenuCatalog;
use App\Models\BusinessProfile;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Services\CartService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Livewire\Features\SupportLockedProperties\CannotUpdateLockedPropertyException;
use Livewire\Livewire;
use Tests\TestCase;

class CustomerMenuCatalogTest extends TestCase
{
    use RefreshDatabase;

    private Customer $customer;

    private DiningTable $table;

    private MenuCategory $categoryMakanan;

    private MenuCategory $categoryMinuman;

    private MenuCategory $categoryKosong;

    private Menu $menuBakso;

    private Menu $menuEsTeh;

    private Menu $menuHabis;

    protected function setUp(): void
    {
        parent::setUp();
        $this->startSession();

        BusinessProfile::factory()->create([
            'name' => 'Bakso Solo Bu Susi',
            'tagline' => 'Kantin M Lt. 2 UNJ',
        ]);

        $this->customer = Customer::factory()->create([
            'phone' => '6281234567890',
        ]);

        $this->table = DiningTable::factory()->create([
            'code' => '2A',
            'floor' => 2,
            'type' => TableType::Fixed,
            'is_active' => true,
        ]);

        $this->categoryMakanan = MenuCategory::factory()->create([
            'name' => 'Makanan',
            'sort_order' => 1,
        ]);

        $this->categoryMinuman = MenuCategory::factory()->create([
            'name' => 'Minuman',
            'sort_order' => 2,
        ]);

        // Category with NO menus
        $this->categoryKosong = MenuCategory::factory()->create([
            'name' => 'Kategori Kosong',
            'sort_order' => 3,
        ]);

        $this->menuBakso = Menu::factory()->create([
            'category_id' => $this->categoryMakanan->id,
            'name' => 'Bakso Komplit',
            'description' => 'Tahu, urat, dan telur spesial',
            'price' => 18000,
            'is_available' => true,
            'sort_order' => 1,
        ]);

        $this->menuEsTeh = Menu::factory()->create([
            'category_id' => $this->categoryMinuman->id,
            'name' => 'Es Teh Manis',
            'description' => 'Segar dan manis alami',
            'price' => 5000,
            'is_available' => true,
            'sort_order' => 1,
        ]);

        $this->menuHabis = Menu::factory()->create([
            'category_id' => $this->categoryMakanan->id,
            'name' => 'Bakso Keju Lumer',
            'description' => 'Keju mozarella meleleh',
            'price' => 22000,
            'is_available' => false,
            'sort_order' => 2,
        ]);

        session([
            'customer_id' => $this->customer->id,
            'order_type' => 'dine_in',
            'table_id' => $this->table->id,
        ]);
    }

    public function test_customer_without_selected_table_is_redirected_to_table_selection(): void
    {
        // 1. Unidentified customer -> redirected to /
        session()->forget(['customer_id', 'order_type', 'table_id']);
        $resGuest = $this->get(route('customer.menu'));
        $resGuest->assertRedirect(route('customer.phone'));

        // 2. Identified but no table -> redirected to /pilih-meja
        $resNoTable = $this->withSession(['customer_id' => $this->customer->id])
            ->get(route('customer.menu'));
        $resNoTable->assertRedirect(route('customer.table'));
        $resNoTable->assertSessionHas('error', 'Silakan pilih meja atau bungkus terlebih dahulu.');
    }

    public function test_menu_catalog_renders_cards_and_prices_from_database(): void
    {
        $response = $this->get(route('customer.menu'));

        $response->assertOk();
        $response->assertSee('Menu Bakso');
        $response->assertSee('Bakso Komplit');
        $response->assertSee('Rp 18.000');
        $response->assertSee('Tahu, urat, dan telur spesial');
        $response->assertSee('Es Teh Manis');
        $response->assertSee('Rp 5.000');
        $response->assertSee('Meja 2A');
        $response->assertSee('Ganti meja');
    }

    public function test_chips_only_display_categories_that_have_at_least_one_menu(): void
    {
        $component = Livewire::test(MenuCatalog::class);

        $component->assertSee('Semua');
        $component->assertSee('Makanan');
        $component->assertSee('Minuman');

        // Category with no menus MUST NOT be displayed
        $component->assertDontSee('Kategori Kosong');
    }

    public function test_filtering_by_category(): void
    {
        $component = Livewire::test(MenuCatalog::class);

        // Initially "Semua": both Bakso and Es Teh are visible
        $component->assertSee('Bakso Komplit');
        $component->assertSee('Es Teh Manis');

        // Filter to Minuman
        $component->call('selectCategory', $this->categoryMinuman->id)
            ->assertSee('Es Teh Manis')
            ->assertDontSee('Bakso Komplit');

        // Filter to Makanan
        $component->call('selectCategory', $this->categoryMakanan->id)
            ->assertSee('Bakso Komplit')
            ->assertDontSee('Es Teh Manis');

        // Switch back to Semua
        $component->call('selectCategory', null)
            ->assertSee('Bakso Komplit')
            ->assertSee('Es Teh Manis');
    }

    public function test_unavailable_menu_displays_habis_badge_and_server_rejects_adding(): void
    {
        $component = Livewire::test(MenuCatalog::class);

        $component->assertSee('Bakso Keju Lumer');
        $component->assertSee('Habis');

        // Direct call to addToCart with unavailable menu ID
        $component->call('addToCart', $this->menuHabis->id);

        $component->assertSet('errorMessage', 'Menu Bakso Keju Lumer sedang tidak tersedia.');
        $this->assertSame(0, app(CartService::class)->count());
    }

    public function test_add_increment_and_decrement_actions_affect_cart_service(): void
    {
        $cart = app(CartService::class);
        $this->assertSame(0, $cart->count());

        $component = Livewire::test(MenuCatalog::class);

        // 1. Add Bakso (qty becomes 1)
        $component->call('addToCart', $this->menuBakso->id)
            ->assertDispatched('cart-updated');
        $this->assertSame(1, $cart->count());

        // 2. Increment Bakso (qty becomes 2)
        $component->call('incrementQty', $this->menuBakso->id);
        $this->assertSame(2, $cart->count());

        // 3. Decrement Bakso (qty becomes 1)
        $component->call('decrementQty', $this->menuBakso->id);
        $this->assertSame(1, $cart->count());

        // 4. Decrement Bakso at 1 removes item (qty becomes 0)
        $component->call('decrementQty', $this->menuBakso->id);
        $this->assertSame(0, $cart->count());
        $this->assertTrue($cart->isEmpty());
    }

    public function test_quantity_limit_of_twenty_is_enforced_in_component(): void
    {
        $cart = app(CartService::class);
        $cart->setQuantity($this->menuBakso->id, 20);

        $component = Livewire::test(MenuCatalog::class);

        // Incrementing when already 20 is rejected
        $component->call('incrementQty', $this->menuBakso->id);

        $component->assertSet('errorMessage', 'Jumlah pesanan untuk menu ini maksimal 20 porsi.');
        $this->assertSame(20, $cart->count());
    }

    public function test_prices_are_always_freshly_read_from_database_in_summary_bar(): void
    {
        $cart = app(CartService::class);
        $cart->add($this->menuBakso->id, 2); // 2 x 18.000 = 36.000

        $component = Livewire::test(MenuCatalog::class);
        $component->assertSee('Total Pesanan');
        $component->assertSee('Rp 36.000');

        // Admin updates price in database to 21.000
        $this->menuBakso->update(['price' => 21000]);

        $componentRefresh = Livewire::test(MenuCatalog::class);
        $componentRefresh->assertSee('Rp 42.000'); // 2 x 21.000 = 42.000
    }

    public function test_menu_deleted_by_admin_is_handled_gracefully_without_500(): void
    {
        $cart = app(CartService::class);
        $cart->add($this->menuBakso->id, 1);

        // Delete menu from database while customer has it in cart
        $this->menuBakso->delete();

        $response = $this->get(route('customer.menu'));
        $response->assertOk();

        // Attempting to add deleted menu ID
        $component = Livewire::test(MenuCatalog::class);
        $component->call('addToCart', 99999);
        $component->assertSet('errorMessage', 'Menu tidak ditemukan.');
    }

    public function test_no_n_plus_one_queries_when_rendering_catalog(): void
    {
        // Add more menus across categories
        Menu::factory()->count(10)->create([
            'category_id' => $this->categoryMakanan->id,
            'is_available' => true,
        ]);
        Menu::factory()->count(10)->create([
            'category_id' => $this->categoryMinuman->id,
            'is_available' => true,
        ]);

        DB::flushQueryLog();
        DB::enableQueryLog();

        Livewire::test(MenuCatalog::class);

        $queries = DB::getQueryLog();
        DB::disableQueryLog();

        // Query count is constant O(1), independent of menu count (categories query + menus join query)
        $this->assertLessThanOrEqual(5, count($queries));
    }

    public function test_locked_selected_category_id_property_cannot_be_tampered_from_client(): void
    {
        $this->expectException(CannotUpdateLockedPropertyException::class);

        Livewire::test(MenuCatalog::class)
            ->set('selectedCategoryId', 999);
    }

    public function test_menu_texts_with_html_are_properly_escaped(): void
    {
        Menu::factory()->create([
            'category_id' => $this->categoryMakanan->id,
            'name' => '<script>alert("xss-menu")</script>',
            'description' => '<img src=x onerror=alert(1)>',
            'price' => 15000,
            'is_available' => true,
        ]);

        $response = $this->get(route('customer.menu'));

        $response->assertOk();
        $response->assertDontSee('<script>alert("xss-menu")</script>', false);
        $response->assertDontSee('<img src=x onerror=alert(1)>', false);
        $response->assertSee('&lt;script&gt;alert(&quot;xss-menu&quot;)&lt;/script&gt;', false);
    }

    public function test_cart_badge_updates_reactively_on_cart_updated_event(): void
    {
        app(CartService::class)->clear();

        $badge = Livewire::test(\App\Livewire\Customer\CartBadge::class, ['position' => 'desktop']);
        // When empty, badge span is not rendered
        $badge->assertDontSeeHtml('<span');

        // Add item to cart and dispatch event
        app(CartService::class)->add($this->menuBakso->id, 3);
        $badge->dispatch('cart-updated');

        // Now badge span with count 3 is rendered
        $badge->assertSeeHtml('<span');
        $badge->assertSee('3');
    }
}
