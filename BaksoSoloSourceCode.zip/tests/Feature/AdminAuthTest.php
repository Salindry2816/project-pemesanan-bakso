<?php

namespace Tests\Feature;

use App\Livewire\Admin\Auth\Login;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Livewire\Livewire;
use Tests\TestCase;

class AdminAuthTest extends TestCase
{
    use RefreshDatabase;

    public function test_unauthenticated_user_accessing_admin_is_redirected_to_admin_login(): void
    {
        $response = $this->get('/admin');

        $response->assertRedirect(route('admin.login'));
    }

    public function test_authenticated_admin_accessing_login_page_is_redirected_to_admin_dashboard(): void
    {
        $admin = User::factory()->create();

        $response = $this->actingAs($admin)->get('/admin/login');

        $response->assertRedirect(route('admin.dashboard'));
    }

    public function test_login_page_renders_properly(): void
    {
        $response = $this->get('/admin/login');

        $response->assertStatus(200);
        $response->assertSee('Login Admin');
        $response->assertSee('Masukkan username dan password');
        $response->assertSee('untuk masuk ke dashboard.');
    }

    public function test_admin_can_login_with_valid_credentials_and_session_is_regenerated(): void
    {
        $plainPassword = 'test-secret-password-99';
        $admin = User::factory()->create([
            'username' => 'admin_test',
            'password' => Hash::make($plainPassword),
        ]);

        $this->startSession();
        $oldSessionId = session()->getId();

        $component = Livewire::test(Login::class)
            ->set('username', 'admin_test')
            ->set('password', $plainPassword)
            ->call('authenticate');

        $component->assertRedirect(route('admin.dashboard'));
        $this->assertAuthenticatedAs($admin);
        $this->assertNotSame($oldSessionId, session()->getId());

        // Dashboard renders empty state and 0 counters
        $dashboardResponse = $this->actingAs($admin)->get('/admin');
        $dashboardResponse->assertStatus(200);
        $dashboardResponse->assertSee('Pesanan Baru');
        $dashboardResponse->assertSee('Dalam Proses');
        $dashboardResponse->assertSee('Siap Diantar');
        $dashboardResponse->assertSee('Selesai');
        $dashboardResponse->assertSee('Belum ada pesanan');
    }

    public function test_failed_login_returns_identical_generic_error_for_wrong_username_and_wrong_password_and_does_not_leak_password(): void
    {
        $plainPassword = 'correct-password-123';
        $wrongPassword = 'wrong-password-xyz';

        User::factory()->create([
            'username' => 'existing_admin',
            'password' => Hash::make($plainPassword),
        ]);

        // 1. Non-existent username
        $unknownUserTest = Livewire::test(Login::class)
            ->set('username', 'non_existent_user')
            ->set('password', $wrongPassword)
            ->call('authenticate');

        $unknownUserTest->assertHasErrors(['username']);
        $unknownUserError = $unknownUserTest->errors()->first('username');

        // 2. Existing username but wrong password
        $wrongPassTest = Livewire::test(Login::class)
            ->set('username', 'existing_admin')
            ->set('password', $wrongPassword)
            ->call('authenticate');

        $wrongPassTest->assertHasErrors(['username']);
        $wrongPassError = $wrongPassTest->errors()->first('username');

        $this->assertSame('Username atau password yang Anda masukkan salah.', $unknownUserError);
        $this->assertSame($unknownUserError, $wrongPassError);
        $this->assertGuest();

        // Password must be reset and not leaked in rendered HTML
        $wrongPassTest->assertSet('password', '');
        $this->assertStringNotContainsString($wrongPassword, $wrongPassTest->html());
    }

    public function test_login_is_rate_limited_after_five_failed_attempts_for_same_username_and_ip(): void
    {
        RateLimiter::clear('throttled_admin|127.0.0.1');

        User::factory()->create([
            'username' => 'throttled_admin',
            'password' => Hash::make('valid-password'),
        ]);

        // 5 failed attempts (mixed case to verify lowercase normalization)
        for ($i = 1; $i <= 5; $i++) {
            Livewire::test(Login::class)
                ->set('username', $i % 2 === 0 ? 'THROTTLED_ADMIN' : 'throttled_admin')
                ->set('password', 'invalid-password')
                ->call('authenticate')
                ->assertHasErrors(['username']);
        }

        // 6th attempt must be blocked by throttle even with valid password
        $sixthAttempt = Livewire::test(Login::class)
            ->set('username', 'throttled_admin')
            ->set('password', 'valid-password')
            ->call('authenticate');

        $sixthAttempt->assertHasErrors(['username']);
        $errorMessage = $sixthAttempt->errors()->first('username');

        $this->assertStringContainsString('Terlalu banyak percobaan masuk. Silakan coba lagi dalam', $errorMessage);
        $this->assertGuest();
    }

    public function test_successful_login_clears_rate_limiter_counter(): void
    {
        RateLimiter::clear('reset_admin|127.0.0.1');

        User::factory()->create([
            'username' => 'reset_admin',
            'password' => Hash::make('valid-password'),
        ]);

        // 4 failed attempts
        for ($i = 1; $i <= 4; $i++) {
            Livewire::test(Login::class)
                ->set('username', 'reset_admin')
                ->set('password', 'invalid-password')
                ->call('authenticate')
                ->assertHasErrors(['username']);
        }

        // 1 successful attempt clears the counter
        Livewire::test(Login::class)
            ->set('username', 'reset_admin')
            ->set('password', 'valid-password')
            ->call('authenticate')
            ->assertRedirect(route('admin.dashboard'));

        $this->post(route('admin.logout'));
        $this->assertGuest();

        // Next 5 failed attempts should NOT be throttled (they get generic wrong-credentials message)
        for ($i = 1; $i <= 5; $i++) {
            $attempt = Livewire::test(Login::class)
                ->set('username', 'reset_admin')
                ->set('password', 'invalid-password')
                ->call('authenticate');

            $attempt->assertHasErrors(['username']);
            $this->assertSame(
                'Username atau password yang Anda masukkan salah.',
                $attempt->errors()->first('username')
            );
        }
    }

    public function test_admin_can_logout_and_session_is_invalidated(): void
    {
        $admin = User::factory()->create();

        $this->actingAs($admin);
        $this->startSession();
        $oldSessionId = session()->getId();

        $response = $this->post(route('admin.logout'));

        $response->assertRedirect(route('admin.login'));
        $this->assertGuest();
        $this->assertNotSame($oldSessionId, session()->getId());
    }
}
