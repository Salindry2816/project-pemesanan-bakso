<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\TableType;
use App\Livewire\Admin\TableManager;
use App\Livewire\Customer\TableSelection;
use App\Models\BusinessProfile;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Order;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Route;
use Livewire\Features\SupportLockedProperties\CannotUpdateLockedPropertyException;
use Livewire\Livewire;
use Tests\TestCase;

class CustomerTableSelectionTest extends TestCase
{
    use RefreshDatabase;

    private Customer $customer;

    private DiningTable $table2A;

    private DiningTable $freeTable;

    protected function setUp(): void
    {
        parent::setUp();
        $this->startSession();

        BusinessProfile::factory()->create([
            'name' => 'Bakso Solo Bu Susi',
            'tagline' => 'Kantin M Lt. 2 UNJ',
        ]);

        $this->customer = Customer::factory()->create([
            'phone' => '6281234567890',
        ]);

        session(['customer_id' => $this->customer->id]);

        $this->table2A = DiningTable::factory()->create([
            'code' => '2A',
            'floor' => 2,
            'type' => TableType::Fixed,
            'capacity' => 4,
            'is_active' => true,
        ]);

        $this->freeTable = DiningTable::factory()->freeTable()->create();
    }

    public function test_guest_without_phone_session_is_redirected_to_home(): void
    {
        session()->forget('customer_id');

        $response = $this->get(route('customer.table'));

        $response->assertRedirect(route('customer.phone'));
        $response->assertSessionHas('error', 'Masukkan nomor handphone kamu untuk melanjutkan pemesanan di Bakso Solo.');
    }

    public function test_identified_customer_can_view_table_selection_page(): void
    {
        $response = $this->get(route('customer.table'));

        $response->assertOk();
        $response->assertSee('Pilih Meja');
        $response->assertSee('Makan di Tempat');
        $response->assertSee('Bungkus (Take Away)');
        $response->assertSee('Meja Berkode — Lantai 2');
        $response->assertSee('2A');
        $response->assertSee('4 kursi');
        $response->assertSee('Tersedia');
        $response->assertSee('Meja Bebas (22)');
        $response->assertDontSee('22 kursi');
        $response->assertSee('Lihat Denah Meja (Lantai 2)');
    }

    public function test_floor_tabs_only_display_floors_with_active_coded_tables(): void
    {
        // When only floor 2 exists, tab bar is not rendered or only shows floor 2
        $component = Livewire::test(TableSelection::class);

        $component->assertDontSee('Lantai 1');
        $component->assertDontSee('Lantai 3');
        $component->assertDontSee('Lantai 4');

        // Now add a floor 3 active coded table
        DiningTable::factory()->create([
            'code' => '3A',
            'floor' => 3,
            'type' => TableType::Fixed,
            'capacity' => 4,
            'is_active' => true,
        ]);

        $componentWithTwoFloors = Livewire::test(TableSelection::class);

        $componentWithTwoFloors->assertSee('Lantai 2 (Lokasi Warung)');
        $componentWithTwoFloors->assertSee('Lantai 3');
        $componentWithTwoFloors->assertDontSee('Lantai 1');
        $componentWithTwoFloors->assertDontSee('Lantai 4');
    }

    public function test_customer_can_select_available_coded_table_and_submit(): void
    {
        Livewire::test(TableSelection::class)
            ->call('selectTable', $this->table2A->id)
            ->assertSet('selectedTableId', $this->table2A->id)
            ->assertSet('orderType', 'dine_in')
            ->call('submit')
            ->assertHasNoErrors()
            ->assertRedirect(url('/menu'));

        $this->assertEquals('dine_in', session('order_type'));
        $this->assertEquals($this->table2A->id, session('table_id'));
        $this->assertNull(session('location_note'));
    }

    public function test_customer_cannot_select_occupied_table(): void
    {
        $otherCustomer = Customer::factory()->create();

        // Make 2A occupied with an active order belonging to ANOTHER customer
        Order::factory()->create([
            'customer_id' => $otherCustomer->id,
            'table_id' => $this->table2A->id,
            'type' => OrderType::DineIn,
            'status' => OrderStatus::Diproses,
        ]);

        $this->assertTrue($this->table2A->fresh()->isOccupied());
        $this->assertTrue($this->table2A->fresh()->isOccupied($this->customer->id));

        Livewire::test(TableSelection::class)
            ->call('selectTable', $this->table2A->id)
            ->assertHasErrors(['table' => 'Meja 2A sedang terisi. Silakan pilih meja yang masih tersedia.']);
    }

    public function test_customer_cannot_select_inactive_table(): void
    {
        $this->table2A->update(['is_active' => false]);

        Livewire::test(TableSelection::class)
            ->call('selectTable', $this->table2A->id)
            ->assertHasErrors(['table' => 'Meja ini sedang tidak aktif. Silakan pilih meja lain.']);
    }

    public function test_customer_selecting_free_table_requires_location_note_between_3_and_100_chars(): void
    {
        // 1. Missing location note
        Livewire::test(TableSelection::class)
            ->call('selectTable', $this->freeTable->id)
            ->set('locationNote', '')
            ->call('submit')
            ->assertHasErrors(['locationNote' => 'Patokan lokasi duduk wajib diisi untuk Meja Bebas.']);

        // 2. Note too short (<3 chars)
        Livewire::test(TableSelection::class)
            ->call('selectTable', $this->freeTable->id)
            ->set('locationNote', 'AB')
            ->call('submit')
            ->assertHasErrors(['locationNote' => 'Patokan lokasi duduk minimal 3 karakter.']);

        // 3. Note too long (>100 chars)
        Livewire::test(TableSelection::class)
            ->call('selectTable', $this->freeTable->id)
            ->set('locationNote', str_repeat('a', 101))
            ->call('submit')
            ->assertHasErrors(['locationNote' => 'Patokan lokasi duduk maksimal 100 karakter.']);

        // 4. Valid note succeeds
        Livewire::test(TableSelection::class)
            ->call('selectTable', $this->freeTable->id)
            ->set('locationNote', 'Depan kasir kantin, baju biru dongker')
            ->call('submit')
            ->assertHasNoErrors()
            ->assertRedirect(url('/menu'));

        $this->assertEquals('dine_in', session('order_type'));
        $this->assertEquals($this->freeTable->id, session('table_id'));
        $this->assertEquals('Depan kasir kantin, baju biru dongker', session('location_note'));
    }

    public function test_customer_can_select_take_away(): void
    {
        Livewire::test(TableSelection::class)
            ->call('selectTakeAway')
            ->assertSet('orderType', 'take_away')
            ->assertSet('selectedTableId', null)
            ->call('submit')
            ->assertHasNoErrors()
            ->assertRedirect(url('/menu'));

        $this->assertEquals('take_away', session('order_type'));
        $this->assertNull(session('table_id'));
        $this->assertNull(session('location_note'));
    }

    public function test_floor_2_map_modal_displays_tenants_in_correct_order_without_tenant_4(): void
    {
        $component = Livewire::test(TableSelection::class)
            ->call('toggleFloorMap')
            ->assertSet('showFloorMap', true);

        // Verify correct tenant sequence and labels
        $component->assertSee('TANGGA');
        $component->assertSee('TENANT 1');
        $component->assertSee('TENANT 2');
        $component->assertSee('TENANT 3');
        $component->assertSee('BAKSO SOLO');
        $component->assertSee('TENANT 5');
        $component->assertSee('TENANT 6');
        $component->assertSee('KAMAR MANDI');
        $component->assertSee('TANGGA TURUNAN');

        // Strictly NO Tenant 4
        $component->assertDontSee('TENANT 4');
        $component->assertDontSee('Tenant 4');

        // Verify Meja Bebas (22) box is rendered in the map without "kursi"
        $component->assertSee('Meja Bebas (22)');
        $component->assertDontSee('22 kursi');
    }

    public function test_locked_selected_table_id_property_cannot_be_tampered_from_client(): void
    {
        $this->expectException(CannotUpdateLockedPropertyException::class);

        Livewire::test(TableSelection::class)
            ->set('selectedTableId', 9999);
    }

    public function test_ensure_table_selected_middleware_protects_routes_and_detects_occupied_tables(): void
    {
        Route::middleware(['web', 'customer.table-selected'])->get('/_test/table-protected', function () {
            return response('TABLE_OK', 200);
        });

        // 1. Unidentified customer -> redirected to /
        session()->forget('customer_id');
        $res1 = $this->get('/_test/table-protected');
        $res1->assertRedirect(route('customer.phone'));
        $res1->assertSessionHas('error', 'Masukkan nomor handphone kamu untuk melanjutkan pemesanan di Bakso Solo.');

        // 2. Customer identified, but order_type missing -> redirected to /pilih-meja
        $res2 = $this->withSession(['customer_id' => $this->customer->id])
            ->get('/_test/table-protected');
        $res2->assertRedirect(route('customer.table'));
        $res2->assertSessionHas('error', 'Silakan pilih meja atau bungkus terlebih dahulu.');

        // 3. Take away -> allowed
        $res3 = $this->withSession([
            'customer_id' => $this->customer->id,
            'order_type' => 'take_away',
        ])->get('/_test/table-protected');
        $res3->assertOk();
        $res3->assertSee('TABLE_OK');

        // 4. Dine in with no table_id -> redirected
        $res4 = $this->withSession([
            'customer_id' => $this->customer->id,
            'order_type' => 'dine_in',
        ])->get('/_test/table-protected');
        $res4->assertRedirect(route('customer.table'));
        $res4->assertSessionHas('error', 'Silakan pilih meja tempat kamu duduk.');

        // 5. Dine in with valid available table -> allowed
        $res5 = $this->withSession([
            'customer_id' => $this->customer->id,
            'order_type' => 'dine_in',
            'table_id' => $this->table2A->id,
        ])->get('/_test/table-protected');
        $res5->assertOk();
        $res5->assertSee('TABLE_OK');

        // 6. Dine in with table that became occupied in database -> cleared and redirected
        $otherCustomer = Customer::factory()->create();

        Order::factory()->create([
            'customer_id' => $otherCustomer->id,
            'table_id' => $this->table2A->id,
            'type' => OrderType::DineIn,
            'status' => OrderStatus::Diproses,
        ]);

        $res6 = $this->withSession([
            'customer_id' => $this->customer->id,
            'order_type' => 'dine_in',
            'table_id' => $this->table2A->id,
        ])->get('/_test/table-protected');
        $res6->assertRedirect(route('customer.table'));
        $res6->assertSessionHas('error', "Meja {$this->table2A->code} sedang terisi pesanan lain. Silakan pilih meja yang masih tersedia.");
        $this->assertNull(session('table_id'));

        // 7. Dine in with deactivated table -> cleared and redirected
        $this->table2A->update(['is_active' => false]);
        $res7 = $this->withSession([
            'customer_id' => $this->customer->id,
            'order_type' => 'dine_in',
            'table_id' => $this->table2A->id,
        ])->get('/_test/table-protected');
        $res7->assertRedirect(route('customer.table'));
        $res7->assertSessionHas('error', 'Meja yang kamu pilih sedang tidak aktif. Silakan pilih meja lain.');

        // 8. Free table missing location note -> redirected
        $res8 = $this->withSession([
            'customer_id' => $this->customer->id,
            'order_type' => 'dine_in',
            'table_id' => $this->freeTable->id,
            'location_note' => 'ab', // too short (<3)
        ])->get('/_test/table-protected');
        $res8->assertRedirect(route('customer.table'));
        $res8->assertSessionHas('error', 'Silakan isi patokan lokasi duduk kamu di Meja Bebas (3–100 karakter).');

        // 9. Free table with valid location note -> allowed
        $res9 = $this->withSession([
            'customer_id' => $this->customer->id,
            'order_type' => 'dine_in',
            'table_id' => $this->freeTable->id,
            'location_note' => 'Dekat kasir kantin, jaket hitam',
        ])->get('/_test/table-protected');
        $res9->assertOk();
        $res9->assertSee('TABLE_OK');
    }

    public function test_customer_with_active_order_at_table_can_order_again_while_others_and_admin_see_occupied(): void
    {
        Route::middleware(['web', 'customer.table-selected'])->get('/_test/own-order-table', function () {
            return response('OWN_TABLE_OK', 200);
        });

        // Customer A creates an active order at 2A
        Order::factory()->create([
            'customer_id' => $this->customer->id,
            'table_id' => $this->table2A->id,
            'type' => OrderType::DineIn,
            'status' => OrderStatus::Diproses,
        ]);

        // 1. Model-level checks
        $this->assertFalse($this->table2A->isOccupied($this->customer->id));
        $this->assertTrue($this->table2A->isOccupied()); // Admin / global check

        $otherCustomer = Customer::factory()->create();
        $this->assertTrue($this->table2A->isOccupied($otherCustomer->id));

        // 2. Customer A passes EnsureTableSelected middleware for 2A
        $resOwn = $this->withSession([
            'customer_id' => $this->customer->id,
            'order_type' => 'dine_in',
            'table_id' => $this->table2A->id,
        ])->get('/_test/own-order-table');
        $resOwn->assertOk();
        $resOwn->assertSee('OWN_TABLE_OK');

        // 3. Customer A does NOT see 2A as occupied in TableSelection and can re-select it
        Livewire::withQueryParams([])
            ->test(TableSelection::class)
            ->assertDontSee('bg-[#FBE3E3]')
            ->call('selectTable', $this->table2A->id)
            ->assertHasNoErrors();

        // 4. Another customer sees 2A as Terisi in TableSelection and cannot select it
        session()->forget(['table_id', 'order_type', 'location_note']);
        session(['customer_id' => $otherCustomer->id]);
        Livewire::test(TableSelection::class)
            ->assertSee('bg-[#FBE3E3]')
            ->call('selectTable', $this->table2A->id)
            ->assertHasErrors(['table' => 'Meja 2A sedang terisi. Silakan pilih meja yang masih tersedia.']);

        // 5. Admin sees 2A as Terisi in TableManager
        $admin = User::factory()->create();
        $this->actingAs($admin);
        Livewire::test(TableManager::class)
            ->assertSee('2A')
            ->assertSee('Terisi');
    }
}
