<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Enums\TableType;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderStatusLog;
use App\Models\User;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Schema;
use Tests\TestCase;

class DatabaseModelsTest extends TestCase
{
    use RefreshDatabase;

    public function test_infrastructure_tables_for_sessions_cache_and_jobs_exist(): void
    {
        $this->assertTrue(Schema::hasTable('sessions'));
        $this->assertTrue(Schema::hasTable('cache'));
        $this->assertTrue(Schema::hasTable('jobs'));
    }

    public function test_order_relationships_and_enum_casts_work_properly(): void
    {
        $admin = User::factory()->create(['username' => 'bu_susi']);
        $customer = Customer::factory()->create(['phone' => '6281234567890']);
        $table = DiningTable::factory()->create([
            'code' => '2A',
            'floor' => 2,
            'type' => TableType::Fixed,
        ]);
        $category = MenuCategory::factory()->create(['name' => 'Bakso']);
        $menu = Menu::factory()->create([
            'category_id' => $category->id,
            'name' => 'Bakso Komplit',
            'price' => 18000,
        ]);

        $order = Order::factory()->create([
            'order_number' => '20261110-0012',
            'customer_id' => $customer->id,
            'type' => OrderType::DineIn,
            'table_id' => $table->id,
            'subtotal' => 18000,
            'total' => 18000,
            'payment_method' => PaymentMethod::Qris,
            'payment_status' => PaymentStatus::BelumBayar,
            'status' => OrderStatus::Diterima,
        ]);

        $item = OrderItem::factory()->create([
            'order_id' => $order->id,
            'menu_id' => $menu->id,
            'name_snapshot' => $menu->name,
            'price_snapshot' => $menu->price,
            'qty' => 1,
            'line_total' => 18000,
        ]);

        $log = OrderStatusLog::create([
            'order_id' => $order->id,
            'status' => OrderStatus::Diterima,
            'changed_by' => $admin->id,
        ]);

        $order->refresh();

        $this->assertSame('#0012', $order->display_number);
        $this->assertTrue($order->customer->is($customer));
        $this->assertTrue($order->table->is($table));
        $this->assertCount(1, $order->items);
        $this->assertTrue($order->items->first()->is($item));
        $this->assertCount(1, $order->statusLogs);
        $this->assertTrue($order->statusLogs->first()->is($log));
        $this->assertTrue($log->changedByUser->is($admin));

        $this->assertSame(OrderType::DineIn, $order->type);
        $this->assertSame(PaymentMethod::Qris, $order->payment_method);
        $this->assertSame(PaymentStatus::BelumBayar, $order->payment_status);
        $this->assertSame(OrderStatus::Diterima, $order->status);
    }

    public function test_order_items_preserve_snapshot_and_set_menu_id_null_when_menu_is_deleted(): void
    {
        $category = MenuCategory::factory()->create(['name' => 'Bakso']);
        $menu = Menu::factory()->create([
            'category_id' => $category->id,
            'name' => 'Bakso Mercon',
            'price' => 22000,
        ]);

        $order = Order::factory()->create([
            'table_id' => DiningTable::factory()->state(['code' => '4A', 'floor' => 4]),
            'subtotal' => 44000,
            'total' => 44000,
        ]);

        $orderItem = OrderItem::create([
            'order_id' => $order->id,
            'menu_id' => $menu->id,
            'name_snapshot' => $menu->name,
            'price_snapshot' => $menu->price,
            'qty' => 2,
            'item_note' => 'Pedas banget',
            'line_total' => 44000,
        ]);

        // Update menu price & name; snapshot must remain unchanged
        $menu->update([
            'name' => 'Bakso Mercon Spesial',
            'price' => 25000,
        ]);

        $orderItem->refresh();
        $this->assertSame('Bakso Mercon', $orderItem->name_snapshot);
        $this->assertSame(22000, $orderItem->price_snapshot);
        $this->assertSame(44000, $orderItem->line_total);

        // Delete menu; order_items row must remain and menu_id becomes null
        $menu->delete();

        $orderItem->refresh();
        $this->assertNull($orderItem->menu_id);
        $this->assertSame('Bakso Mercon', $orderItem->name_snapshot);
        $this->assertSame(22000, $orderItem->price_snapshot);
    }

    public function test_unique_constraints_on_customers_phone_orders_order_number_and_tables_code(): void
    {
        Customer::factory()->create(['phone' => '628111111111']);
        $this->assertThrows(
            fn () => Customer::factory()->create(['phone' => '628111111111']),
            QueryException::class
        );

        $orderTable = DiningTable::factory()->create(['code' => '4Z', 'floor' => 4]);
        Order::factory()->create([
            'order_number' => '20261110-0001',
            'table_id' => $orderTable->id,
        ]);
        $this->assertThrows(
            fn () => Order::factory()->create([
                'order_number' => '20261110-0001',
                'table_id' => $orderTable->id,
            ]),
            QueryException::class
        );

        DiningTable::factory()->create(['code' => '2A']);
        $this->assertThrows(
            fn () => DiningTable::factory()->create(['code' => '2A']),
            QueryException::class
        );
    }

    public function test_dining_table_coded_scope_and_occupancy_ignore_free_table(): void
    {
        $codedTable = DiningTable::factory()->create([
            'code' => '2A',
            'floor' => 2,
            'type' => TableType::Fixed,
        ]);
        $freeTable = DiningTable::factory()->freeTable()->create();

        // Coded scope only returns fixed tables
        $codedCodes = DiningTable::query()->coded()->pluck('code')->all();
        $this->assertSame(['2A'], $codedCodes);

        // Active dine-in order on coded table makes it occupied
        Order::factory()->create([
            'table_id' => $codedTable->id,
            'type' => OrderType::DineIn,
            'status' => OrderStatus::Diproses,
        ]);
        $this->assertTrue($codedTable->isOccupied());

        // Active dine-in order on free table ("BEBAS") never makes it occupied
        Order::factory()->create([
            'table_id' => $freeTable->id,
            'type' => OrderType::DineIn,
            'location_note' => 'Dekat tangga, baju hitam',
            'status' => OrderStatus::Diterima,
        ]);
        $this->assertFalse($freeTable->isOccupied());
    }
}
