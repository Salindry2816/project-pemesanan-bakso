<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Enums\TableType;
use App\Livewire\Admin\OrderDetail;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\OrderStatusLog;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Features\SupportLockedProperties\CannotUpdateLockedPropertyException;
use Livewire\Livewire;
use Tests\TestCase;

class AdminOrderDetailTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    private Customer $customer;

    private DiningTable $table;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::factory()->create(['username' => 'bu_susi']);
        $this->customer = Customer::factory()->create(['phone' => '6281234560001']);
        $this->table = DiningTable::factory()->create(['code' => '2A', 'floor' => 2, 'type' => TableType::Fixed]);
    }

    public function test_guest_is_redirected_and_unauthenticated_actions_are_forbidden(): void
    {
        $order = Order::factory()->create([
            'order_number' => '20261113-0001',
            'customer_id' => $this->customer->id,
            'table_id' => $this->table->id,
        ]);

        $this->get(route('admin.orders.show', $order))
            ->assertRedirect(route('admin.login'));

        Livewire::test(OrderDetail::class, ['order' => $order])
            ->call('markAsPaid')
            ->assertForbidden();

        Livewire::test(OrderDetail::class, ['order' => $order])
            ->call('transitionStatus', OrderStatus::Diterima->value, OrderStatus::Diproses->value)
            ->assertForbidden();
    }

    public function test_mark_as_paid_is_idempotent_and_preserves_original_paid_at(): void
    {
        $order = Order::factory()->create([
            'order_number' => '20261113-0002',
            'customer_id' => $this->customer->id,
            'table_id' => $this->table->id,
            'payment_method' => PaymentMethod::Cash,
            'payment_status' => PaymentStatus::BelumBayar,
            'paid_at' => null,
        ]);

        $this->actingAs($this->admin);

        $component = Livewire::test(OrderDetail::class, ['order' => $order])
            ->call('markAsPaid')
            ->assertSee('Lunas');

        $order->refresh();
        $this->assertSame(PaymentStatus::Lunas, $order->payment_status);
        $this->assertNotNull($order->paid_at);
        $originalPaidAt = $order->paid_at->toDateTimeString();

        // Calling markAsPaid again keeps paid_at unchanged
        $this->travel(5)->minutes();
        $component->call('markAsPaid')
            ->assertSee('Pesanan sudah berstatus Lunas.');

        $order->refresh();
        $this->assertSame($originalPaidAt, $order->paid_at->toDateTimeString());
    }

    public function test_selesai_requires_lunas_and_expected_status_prevents_stale_transition(): void
    {
        $order = Order::factory()->create([
            'order_number' => '20261113-0003',
            'customer_id' => $this->customer->id,
            'table_id' => $this->table->id,
            'type' => OrderType::DineIn,
            'payment_status' => PaymentStatus::BelumBayar,
            'status' => OrderStatus::Diterima,
        ]);

        OrderItem::factory()->create([
            'order_id' => $order->id,
            'name_snapshot' => 'Bakso Urat',
            'qty' => 2,
            'price_snapshot' => 20000,
            'line_total' => 40000,
        ]);

        $this->actingAs($this->admin);

        $component = Livewire::test(OrderDetail::class, ['order' => $order]);

        // Advance step by step until Siap
        $component->call('transitionStatus', OrderStatus::Diterima->value, OrderStatus::Diproses->value);
        $component->call('transitionStatus', OrderStatus::Diproses->value, OrderStatus::Disiapkan->value);
        $component->call('transitionStatus', OrderStatus::Disiapkan->value, OrderStatus::Siap->value);

        $order->refresh();
        $this->assertSame(OrderStatus::Siap, $order->status);

        // Stale expectedStatus is rejected
        $component->call('transitionStatus', OrderStatus::Diproses->value, OrderStatus::Disiapkan->value)
            ->assertSee('Status pesanan sudah berubah');
        $this->assertSame(OrderStatus::Siap, $order->fresh()->status);

        // Selesai is blocked while BelumBayar
        $component->call('transitionStatus', OrderStatus::Siap->value, OrderStatus::Selesai->value)
            ->assertSee('harus berstatus Lunas');
        $this->assertSame(OrderStatus::Siap, $order->fresh()->status);

        // Mark as paid, then Selesai succeeds and records log
        $component->call('markAsPaid')
            ->call('transitionStatus', OrderStatus::Siap->value, OrderStatus::Selesai->value);

        $order->refresh();
        $this->assertSame(OrderStatus::Selesai, $order->status);
        $this->assertSame(
            4,
            OrderStatusLog::query()->where('order_id', $order->id)->where('changed_by', $this->admin->id)->count()
        );
    }

    public function test_admin_can_cancel_before_selesai_and_cannot_cancel_after_selesai(): void
    {
        $order = Order::factory()->create([
            'order_number' => '20261113-0004',
            'customer_id' => $this->customer->id,
            'table_id' => $this->table->id,
            'status' => OrderStatus::Diproses,
        ]);

        $this->actingAs($this->admin);

        Livewire::test(OrderDetail::class, ['order' => $order])
            ->call('transitionStatus', OrderStatus::Diproses->value, OrderStatus::Dibatalkan->value);

        $this->assertSame(OrderStatus::Dibatalkan, $order->fresh()->status);

        // Cancelled order cannot be marked as paid
        Livewire::test(OrderDetail::class, ['order' => $order->fresh()])
            ->call('markAsPaid')
            ->assertSee('tidak dapat ditandai lunas');

        $completedOrder = Order::factory()->create([
            'order_number' => '20261113-0005',
            'customer_id' => $this->customer->id,
            'table_id' => $this->table->id,
            'payment_status' => PaymentStatus::Lunas,
            'status' => OrderStatus::Selesai,
        ]);

        Livewire::test(OrderDetail::class, ['order' => $completedOrder])
            ->call('transitionStatus', OrderStatus::Selesai->value, OrderStatus::Dibatalkan->value)
            ->assertSee('Tidak dapat mengubah status');

        $this->assertSame(OrderStatus::Selesai, $completedOrder->fresh()->status);
    }

    public function test_locked_order_id_cannot_be_tampered_from_client(): void
    {
        $order = Order::factory()->create([
            'order_number' => '20261113-0006',
            'customer_id' => $this->customer->id,
            'table_id' => $this->table->id,
        ]);

        $this->actingAs($this->admin);

        $this->expectException(CannotUpdateLockedPropertyException::class);

        Livewire::test(OrderDetail::class, ['order' => $order])
            ->set('orderId', 999999);
    }
}
