<?php

namespace Tests\Feature;

use App\Models\BusinessProfile;
use App\Models\User;
use chillerlan\QRCode\Common\EccLevel;
use chillerlan\QRCode\QRCode;
use chillerlan\QRCode\QROptions;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminPrintQrTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    private BusinessProfile $profile;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::factory()->create(['username' => 'bu_susi']);

        $this->profile = BusinessProfile::forceCreate([
            'id' => 1,
            'name' => 'Bakso Solo',
            'tagline' => 'Warung Bu Susi',
            'description' => 'Bakso lezat khas Solo di Kantin M UNJ.',
            'location' => 'Kantin M, Lantai 2, UNJ',
            'phone' => '6285215355501',
            'whatsapp' => '6285215355501',
            'open_time' => '08.00',
            'close_time' => '17.00',
        ]);
    }

    public function test_guest_is_redirected_from_print_qr_page_to_login(): void
    {
        $response = $this->get(route('admin.qr'));
        $response->assertRedirect(route('admin.login'));
    }

    public function test_admin_can_view_print_qr_page_with_poster_content_and_svg(): void
    {
        config(['app.url' => 'https://bakso-solo.up.railway.app']);

        $response = $this->actingAs($this->admin)->get(route('admin.qr'));

        $response->assertStatus(200);
        $response->assertSee('Cetak QR Meja');
        $response->assertSee('Bakso Solo');
        $response->assertSee('Warung Bu Susi');
        $response->assertSee('Kantin M, Lantai 2, UNJ');
        $response->assertSee('Scan untuk pesan');
        $response->assertSee('Buka: 08.00 – 17.00');
        $response->assertSee('https://bakso-solo.up.railway.app');

        // Verify SVG QR is present in the DOM
        $response->assertSee('<svg', false);
        $response->assertSee('class="qr-svg qrcode"', false);
    }

    public function test_qr_code_encodes_exact_app_url_config_and_different_urls_produce_different_svg(): void
    {
        $options = new QROptions([
            'outputInterface' => \chillerlan\QRCode\Output\QROutputInterface::MARKUP_SVG,
            'eccLevel' => EccLevel::M,
            'outputBase64' => false,
            'svgAddXmlHeader' => false,
            'addQuietzone' => true,
        ]);

        $url1 = 'https://warung-bakso-pertama.id';
        config(['app.url' => $url1]);
        $response1 = $this->actingAs($this->admin)->get(route('admin.qr'));
        $svg1 = $response1->viewData('qrSvg');
        $expectedSvg1 = (new QRCode($options))->render($url1);

        // 1. Must exactly match the QR SVG rendered for url1
        $this->assertSame($expectedSvg1, $svg1);
        $response1->assertSee($expectedSvg1, false);

        // 2. Different APP_URL must produce a different QR SVG
        $url2 = 'https://warung-bakso-kedua.id/khusus';
        config(['app.url' => $url2]);
        $response2 = $this->actingAs($this->admin)->get(route('admin.qr'));
        $svg2 = $response2->viewData('qrSvg');
        $expectedSvg2 = (new QRCode($options))->render($url2);

        $this->assertSame($expectedSvg2, $svg2);
        $this->assertNotSame($svg1, $svg2);
    }

    public function test_app_url_warning_displayed_when_localhost_or_ip(): void
    {
        // 1. Localhost url must show warning
        config(['app.url' => 'http://localhost:8000']);

        $response = $this->actingAs($this->admin)->get(route('admin.qr'));
        $response->assertStatus(200);
        $response->assertSee('Ubah APP_URL ke domain final sebelum mencetak QR.');
        $response->assertSee('http://localhost:8000');

        // 2. 127.0.0.1 must show warning
        config(['app.url' => 'http://127.0.0.1']);

        $response = $this->actingAs($this->admin)->get(route('admin.qr'));
        $response->assertStatus(200);
        $response->assertSee('Ubah APP_URL ke domain final sebelum mencetak QR.');
    }

    public function test_app_url_warning_not_displayed_when_domain_is_valid_in_local(): void
    {
        config(['app.url' => 'http://bakso-solo.test']);

        $response = $this->actingAs($this->admin)->get(route('admin.qr'));
        $response->assertStatus(200);
        $response->assertDontSee('Ubah APP_URL ke domain final sebelum mencetak QR.');
    }

    public function test_production_environment_warns_if_app_url_is_not_https(): void
    {
        $this->app->detectEnvironment(fn () => 'production');
        config(['app.url' => 'http://bakso-solo.com']);

        $response = $this->actingAs($this->admin)->get(route('admin.qr'));
        $response->assertStatus(200);
        $response->assertSee('Ubah APP_URL ke domain final sebelum mencetak QR.');
    }

    public function test_production_environment_does_not_warn_when_https_domain(): void
    {
        $this->app->detectEnvironment(fn () => 'production');
        config(['app.url' => 'https://bakso-solo.up.railway.app']);

        $response = $this->actingAs($this->admin)->get(route('admin.qr'));
        $response->assertStatus(200);
        $response->assertDontSee('Ubah APP_URL ke domain final sebelum mencetak QR.');
    }

    public function test_missing_profile_does_not_throw_500_and_shows_warning(): void
    {
        BusinessProfile::query()->delete();

        $response = $this->actingAs($this->admin)->get(route('admin.qr'));

        $response->assertStatus(200);
        $response->assertSee('Profil usaha belum dibuat. Jalankan seeder awal untuk mengisi profil usaha.');
        $response->assertSee('Bakso Solo'); // fallback default
        $response->assertSee('Scan untuk pesan');
        $response->assertSee('<svg', false);
    }
}
