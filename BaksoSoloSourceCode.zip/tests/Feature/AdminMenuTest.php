<?php

namespace Tests\Feature;

use App\Livewire\Admin\MenuManager;
use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Livewire\Livewire;
use Tests\TestCase;

class AdminMenuTest extends TestCase
{
    use RefreshDatabase;

    private array $tempFiles = [];

    protected function tearDown(): void
    {
        foreach ($this->tempFiles as $file) {
            if (is_file($file)) {
                @unlink($file);
            }
        }

        parent::tearDown();
    }

    public function test_guest_is_redirected_from_menus_page_to_login(): void
    {
        $response = $this->get(route('admin.menus'));

        $response->assertRedirect(route('admin.login'));
    }

    public function test_unauthenticated_livewire_actions_on_menu_manager_are_forbidden(): void
    {
        $category = MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);
        $menu = Menu::factory()->create([
            'category_id' => $category->id,
            'name' => 'Bakso Urat',
            'price' => 17000,
            'is_available' => true,
        ]);

        Livewire::test(MenuManager::class)
            ->set('name', 'Menu Ilegal')
            ->set('categoryId', (string) $category->id)
            ->set('price', '15000')
            ->call('saveMenu')
            ->assertForbidden();

        Livewire::test(MenuManager::class)
            ->call('toggleAvailability', $menu->id)
            ->assertForbidden();

        Livewire::test(MenuManager::class)
            ->call('deleteMenu', $menu->id)
            ->assertForbidden();

        $this->assertDatabaseMissing('menus', ['name' => 'Menu Ilegal']);
        $this->assertDatabaseHas('menus', [
            'id' => $menu->id,
            'is_available' => true,
        ]);
    }

    public function test_locked_properties_cannot_be_tampered_from_client(): void
    {
        $admin = User::factory()->create();
        $category = MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);
        $menu = Menu::factory()->create([
            'category_id' => $category->id,
            'name' => 'Bakso Urat',
        ]);

        $this->expectException(\Livewire\Features\SupportLockedProperties\CannotUpdateLockedPropertyException::class);

        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->set('editingId', $menu->id);
    }

    public function test_admin_can_view_empty_state_and_filter_menus_by_category(): void
    {
        $admin = User::factory()->create();
        $catBakso = MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);
        $catMinuman = MenuCategory::factory()->create(['name' => 'Minuman', 'sort_order' => 2]);

        // Empty state first
        $emptyResponse = $this->actingAs($admin)->get(route('admin.menus'));
        $emptyResponse->assertStatus(200);
        $emptyResponse->assertSee('Belum ada menu. Tambahkan menu pertama.');
        $emptyResponse->assertSee('Kelola Kategori');
        $emptyResponse->assertSee(route('admin.categories'));

        // Populate menus
        Menu::factory()->create([
            'category_id' => $catBakso->id,
            'name' => 'Bakso Komplit',
            'price' => 18000,
            'sort_order' => 1,
        ]);
        Menu::factory()->create([
            'category_id' => $catMinuman->id,
            'name' => 'Es Teh Manis',
            'price' => 5000,
            'sort_order' => 1,
        ]);

        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->assertSee('Bakso Komplit')
            ->assertSee('Rp 18.000')
            ->assertSee('Es Teh Manis')
            ->assertSee('Rp 5.000')
            ->call('filterByCategory', $catBakso->id)
            ->assertSee('Bakso Komplit')
            ->assertDontSee('Es Teh Manis')
            ->call('filterByCategory', null)
            ->assertSee('Bakso Komplit')
            ->assertSee('Es Teh Manis');
    }

    public function test_admin_can_create_and_update_menu_with_jpg_png_webp_photos_and_old_photo_is_deleted(): void
    {
        $disk = config('filesystems.media_disk', 'public');
        Storage::fake($disk);

        $admin = User::factory()->create();
        $category = MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);

        Menu::factory()->create([
            'category_id' => $category->id,
            'name' => 'Bakso Awal',
            'sort_order' => 2,
        ]);

        // 1. Create menu with JPG photo -> sort_order should be 3 (last in category)
        $jpgPhoto = $this->createImageFile('jpeg', 'bakso-komplit.jpg');

        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->call('openCreateModal')
            ->set('name', '  Bakso   Komplit  ')
            ->set('categoryId', (string) $category->id)
            ->set('price', '18000')
            ->set('description', 'Bakso halus, urat, tahu, dan mie.')
            ->set('photo', $jpgPhoto)
            ->call('saveMenu')
            ->assertHasNoErrors()
            ->assertSet('showFormModal', false)
            ->assertSee('Menu baru berhasil ditambahkan.');

        $menu = Menu::query()->where('name', 'Bakso Komplit')->firstOrFail();
        $this->assertSame(18000, $menu->price);
        $this->assertSame(3, $menu->sort_order);
        $this->assertNotNull($menu->photo_path);
        $firstPhotoPath = $menu->photo_path;
        Storage::disk($disk)->assertExists($firstPhotoPath);

        // 2. Update menu and replace JPG with PNG photo -> old JPG must be deleted
        $pngPhoto = $this->createImageFile('png', 'bakso-komplit-baru.png');

        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->call('openEditModal', $menu->id)
            ->set('name', 'Bakso Komplit Spesial')
            ->set('price', '20000')
            ->set('photo', $pngPhoto)
            ->call('saveMenu')
            ->assertHasNoErrors();

        $menu->refresh();
        $this->assertSame('Bakso Komplit Spesial', $menu->name);
        $this->assertSame(20000, $menu->price);
        $this->assertNotNull($menu->photo_path);
        $this->assertNotSame($firstPhotoPath, $menu->photo_path);
        Storage::disk($disk)->assertMissing($firstPhotoPath);
        Storage::disk($disk)->assertExists($menu->photo_path);
        $secondPhotoPath = $menu->photo_path;

        // 3. Update menu and replace PNG with WebP photo -> old PNG must be deleted
        $webpPhoto = $this->createImageFile('webp', 'bakso.webp');

        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->call('openEditModal', $menu->id)
            ->set('photo', $webpPhoto)
            ->call('saveMenu')
            ->assertHasNoErrors();

        $menu->refresh();
        $this->assertNotNull($menu->photo_path);
        $this->assertStringEndsWith('.webp', $menu->photo_path);
        Storage::disk($disk)->assertMissing($secondPhotoPath);
        Storage::disk($disk)->assertExists($menu->photo_path);
        $thirdPhotoPath = $menu->photo_path;

        // 4. Remove photo explicitly via removePhoto button
        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->call('openEditModal', $menu->id)
            ->call('removePhoto')
            ->call('saveMenu')
            ->assertHasNoErrors();

        $menu->refresh();
        $this->assertNull($menu->photo_path);
        Storage::disk($disk)->assertMissing($thirdPhotoPath);
    }

    public function test_menu_validation_enforces_name_category_and_integer_price_rules(): void
    {
        $admin = User::factory()->create();
        $category = MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);

        $component = Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->call('openCreateModal');

        // Empty name & invalid category
        $component->set('name', '   ')
            ->set('categoryId', '9999')
            ->set('price', '18000')
            ->call('saveMenu')
            ->assertHasErrors(['name', 'categoryId']);

        // Price = 0
        $component->set('name', 'Bakso')
            ->set('categoryId', (string) $category->id)
            ->set('price', '0')
            ->call('saveMenu')
            ->assertHasErrors(['price'])
            ->assertSee('Harga menu harus lebih dari Rp 0.');

        // Negative price
        $component->set('price', '-5000')
            ->call('saveMenu')
            ->assertHasErrors(['price'])
            ->assertSee('Harga menu harus lebih dari Rp 0.');

        // Decimal price
        $component->set('price', '18000.50')
            ->call('saveMenu')
            ->assertHasErrors(['price'])
            ->assertSee('Harga menu harus berupa angka bulat rupiah');

        // Non-numeric price
        $component->set('price', '18rb')
            ->call('saveMenu')
            ->assertHasErrors(['price']);

        // Exceeds 1,000,000
        $component->set('price', '1500000')
            ->call('saveMenu')
            ->assertHasErrors(['price'])
            ->assertSee('Harga menu maksimal Rp 1.000.000.');
    }

    public function test_menu_upload_rejects_oversized_file_non_image_and_fake_extension(): void
    {
        $disk = config('filesystems.media_disk', 'public');
        Storage::fake($disk);

        $admin = User::factory()->create();
        $category = MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);

        // 1. Oversized file (> 2 MB)
        $oversizedFile = UploadedFile::fake()->create('huge.jpg', 2500, 'image/jpeg');

        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->call('openCreateModal')
            ->set('name', 'Bakso Besar')
            ->set('categoryId', (string) $category->id)
            ->set('price', '18000')
            ->set('photo', $oversizedFile)
            ->assertHasErrors(['photo'])
            ->call('saveMenu')
            ->assertHasErrors(['photo']);

        $this->assertDatabaseMissing('menus', ['name' => 'Bakso Besar']);

        // 2. Non-image text file with .jpg extension
        $fakeJpg = UploadedFile::fake()->createWithContent('fake.jpg', 'not an image content');

        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->call('openCreateModal')
            ->set('name', 'Bakso Palsu')
            ->set('categoryId', (string) $category->id)
            ->set('price', '18000')
            ->set('photo', $fakeJpg)
            ->assertHasErrors(['photo'])
            ->call('saveMenu')
            ->assertHasErrors(['photo']);

        $this->assertDatabaseMissing('menus', ['name' => 'Bakso Palsu']);
    }

    public function test_admin_can_toggle_menu_availability(): void
    {
        $admin = User::factory()->create();
        $category = MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);
        $menu = Menu::factory()->create([
            'category_id' => $category->id,
            'name' => 'Bakso Mercon',
            'is_available' => true,
        ]);

        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->call('toggleAvailability', $menu->id)
            ->assertSee('ditandai tidak tersedia');

        $this->assertDatabaseHas('menus', [
            'id' => $menu->id,
            'is_available' => false,
        ]);

        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->call('toggleAvailability', $menu->id)
            ->assertSee('ditandai tersedia');

        $this->assertDatabaseHas('menus', [
            'id' => $menu->id,
            'is_available' => true,
        ]);
    }

    public function test_deleting_menu_deletes_photo_and_preserves_order_items_snapshot(): void
    {
        $disk = config('filesystems.media_disk', 'public');
        Storage::fake($disk);

        $admin = User::factory()->create();
        $category = MenuCategory::factory()->create(['name' => 'Bakso', 'sort_order' => 1]);

        $photoFile = $this->createImageFile('png', 'bakso-keju.png');

        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->call('openCreateModal')
            ->set('name', 'Bakso Keju')
            ->set('categoryId', (string) $category->id)
            ->set('price', '22000')
            ->set('photo', $photoFile)
            ->call('saveMenu')
            ->assertHasNoErrors();

        $menu = Menu::query()->where('name', 'Bakso Keju')->firstOrFail();
        $photoPath = $menu->photo_path;
        $this->assertNotNull($photoPath);
        Storage::disk($disk)->assertExists($photoPath);

        // Create an historical order item referencing this menu
        $order = Order::factory()->create([
            'table_id' => DiningTable::factory()->state(['code' => '4Z', 'floor' => 4]),
        ]);
        $orderItem = OrderItem::factory()->create([
            'order_id' => $order->id,
            'menu_id' => $menu->id,
            'name_snapshot' => 'Bakso Keju',
            'price_snapshot' => 22000,
            'qty' => 2,
            'line_total' => 44000,
        ]);

        // Delete menu via modal confirmation flow
        Livewire::actingAs($admin)
            ->test(MenuManager::class)
            ->call('confirmDelete', $menu->id)
            ->call('deleteMenu')
            ->assertSee('Menu berhasil dihapus.');

        $this->assertDatabaseMissing('menus', ['id' => $menu->id]);
        Storage::disk($disk)->assertMissing($photoPath);

        // Historical order item must remain intact with menu_id = null
        $orderItem->refresh();
        $this->assertNull($orderItem->menu_id);
        $this->assertSame('Bakso Keju', $orderItem->name_snapshot);
        $this->assertSame(22000, $orderItem->price_snapshot);
        $this->assertSame(44000, $orderItem->line_total);
    }

    private function createImageFile(string $format, string $clientName): UploadedFile
    {
        $img = imagecreatetruecolor(300, 300);
        $color = imagecolorallocate($img, 120, 42, 37);
        imagefilledrectangle($img, 0, 0, 300, 300, $color);

        ob_start();
        match ($format) {
            'jpeg' => imagejpeg($img, null, 85),
            'png' => imagepng($img),
            'webp' => imagewebp($img, null, 85),
        };
        $bytes = (string) ob_get_clean();

        return UploadedFile::fake()->createWithContent($clientName, $bytes);
    }
}
