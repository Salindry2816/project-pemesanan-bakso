<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Enums\TableType;
use App\Livewire\Admin\OrderNotificationBell;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Order;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use Tests\TestCase;

class AdminOrderNotificationBellTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::factory()->create(['username' => 'admin_bell']);
    }

    public function test_bell_initializes_pending_count_and_dispatches_alert_only_when_new_order_arrives(): void
    {
        $customer = Customer::factory()->create(['phone' => '6281234560021']);
        $table = DiningTable::factory()->create(['code' => '2A', 'floor' => 2, 'type' => TableType::Fixed]);

        $existingOrder = Order::factory()->create([
            'order_number' => now()->format('Ymd').'-0001',
            'customer_id' => $customer->id,
            'type' => OrderType::DineIn,
            'table_id' => $table->id,
            'total' => 18000,
            'payment_method' => PaymentMethod::Cash,
            'payment_status' => PaymentStatus::BelumBayar,
            'status' => OrderStatus::Diterima,
        ]);

        // Processed/cancelled orders must not be counted in bell pending list
        Order::factory()->create([
            'order_number' => now()->format('Ymd').'-0002',
            'customer_id' => $customer->id,
            'type' => OrderType::TakeAway,
            'total' => 22000,
            'payment_method' => PaymentMethod::Qris,
            'payment_status' => PaymentStatus::Lunas,
            'status' => OrderStatus::Diproses,
        ]);

        $this->actingAs($this->admin);

        $component = Livewire::test(OrderNotificationBell::class)
            ->assertSet('pendingCount', 1)
            ->assertSet('lastSeenMaxId', $existingOrder->id)
            ->assertNotDispatched('new-order-alert');

        // Polling again with no new order does not fire alert
        $component->call('checkOrders')
            ->assertSet('pendingCount', 1)
            ->assertNotDispatched('new-order-alert');

        // Create a brand new pending order
        $newOrder = Order::factory()->create([
            'order_number' => now()->format('Ymd').'-0003',
            'customer_id' => $customer->id,
            'type' => OrderType::DineIn,
            'table_id' => $table->id,
            'total' => 35000,
            'payment_method' => PaymentMethod::Qris,
            'payment_status' => PaymentStatus::BelumBayar,
            'status' => OrderStatus::Diterima,
        ]);

        $component->call('checkOrders')
            ->assertSet('pendingCount', 2)
            ->assertSet('lastSeenMaxId', $newOrder->id)
            ->assertDispatched('new-order-alert');

        // Next poll without newer order should stay quiet
        $component->call('checkOrders')
            ->assertSet('pendingCount', 2)
            ->assertNotDispatched('new-order-alert');
    }
}
