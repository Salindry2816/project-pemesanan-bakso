<?php

namespace Tests\Feature;

use App\Enums\TableType;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Models\Order;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Symfony\Component\Process\Process;
use Tests\TestCase;

class OrderServiceConcurrencyTest extends TestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->truncateConcurrencyTables();
    }

    protected function tearDown(): void
    {
        $this->truncateConcurrencyTables();
        parent::tearDown();
    }

    protected function truncateConcurrencyTables(): void
    {
        static::ensureTestingDatabaseName((string) DB::connection()->getDatabaseName());

        DB::statement('SET FOREIGN_KEY_CHECKS=0');
        foreach ([
            'order_status_logs',
            'order_items',
            'orders',
            'order_sequences',
            'menus',
            'menu_categories',
            'tables',
            'customers',
        ] as $table) {
            DB::table($table)->truncate();
        }
        DB::statement('SET FOREIGN_KEY_CHECKS=1');
    }

    /**
     * @param  list<array<string, mixed>>  $payloads
     * @return list<array<string, mixed>>
     */
    protected function runParallelWorkers(array $payloads): array
    {
        $startAt = microtime(true) + 0.6;
        $workerPath = base_path('tests/Concurrency/race_worker.php');

        $env = [
            'DB_CONNECTION' => (string) config('database.default'),
            'DB_HOST' => (string) config('database.connections.mysql.host'),
            'DB_PORT' => (string) config('database.connections.mysql.port'),
            'DB_DATABASE' => (string) DB::connection()->getDatabaseName(),
            'DB_USERNAME' => (string) config('database.connections.mysql.username'),
            'DB_PASSWORD' => (string) config('database.connections.mysql.password'),
        ];

        $processes = [];
        foreach ($payloads as $payload) {
            $payload['start_at'] = $startAt;
            $process = new Process(
                [PHP_BINARY, $workerPath, json_encode($payload, JSON_THROW_ON_ERROR)],
                base_path(),
                $env,
                null,
                30,
            );
            $process->start();
            $processes[] = $process;
        }

        $results = [];
        foreach ($processes as $process) {
            $process->wait();
            $stdout = trim($process->getOutput());
            $this->assertTrue(
                $process->isSuccessful(),
                "Worker failed (exit {$process->getExitCode()}): {$stdout} {$process->getErrorOutput()}"
            );
            $decoded = json_decode($stdout, true, 512, JSON_THROW_ON_ERROR);
            $results[] = $decoded;
        }

        return $results;
    }

    public function test_twenty_concurrent_orders_produce_unique_gap_free_sequential_numbers(): void
    {
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);

        $payloads = [];
        for ($i = 0; $i < 20; $i++) {
            $customer = Customer::factory()->create();
            $payloads[] = [
                'customer_id' => $customer->id,
                'order_type' => 'take_away',
                'table_id' => null,
                'payment_method' => 'cash',
                'cart_lines' => [$menu->id => ['qty' => 1, 'item_note' => null]],
                'checkout_token' => Str::random(32),
            ];
        }

        $results = $this->runParallelWorkers($payloads);

        $succeeded = array_values(array_filter($results, static fn (array $r): bool => $r['ok'] === true));
        $this->assertCount(20, $succeeded);

        $orderNumbers = array_column($succeeded, 'order_number');
        sort($orderNumbers);

        $expectedPrefix = now()->format('Ymd').'-';
        $expected = array_map(
            static fn (int $n): string => sprintf('%s%04d', $expectedPrefix, $n),
            range(1, 20)
        );

        $this->assertSame($expected, $orderNumbers);
        $this->assertSame(20, Order::query()->count());
    }

    public function test_two_customers_racing_for_same_coded_table_allows_exactly_one(): void
    {
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);
        $table = DiningTable::factory()->create(['code' => '2A', 'floor' => 2, 'type' => TableType::Fixed]);

        $customer1 = Customer::factory()->create();
        $customer2 = Customer::factory()->create();

        $results = $this->runParallelWorkers([
            [
                'customer_id' => $customer1->id,
                'order_type' => 'dine_in',
                'table_id' => $table->id,
                'payment_method' => 'cash',
                'cart_lines' => [$menu->id => ['qty' => 1, 'item_note' => null]],
                'checkout_token' => Str::random(32),
            ],
            [
                'customer_id' => $customer2->id,
                'order_type' => 'dine_in',
                'table_id' => $table->id,
                'payment_method' => 'cash',
                'cart_lines' => [$menu->id => ['qty' => 1, 'item_note' => null]],
                'checkout_token' => Str::random(32),
            ],
        ]);

        $succeeded = array_values(array_filter($results, static fn (array $r): bool => $r['ok'] === true));
        $failed = array_values(array_filter($results, static fn (array $r): bool => $r['ok'] === false));

        $this->assertCount(1, $succeeded);
        $this->assertCount(1, $failed);
        $this->assertStringContainsString('sudah terisi', (string) $failed[0]['error']);
        $this->assertSame(1, Order::query()->where('table_id', $table->id)->count());
    }

    public function test_ten_concurrent_submits_with_same_checkout_token_create_exactly_one_order(): void
    {
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);
        $customer = Customer::factory()->create();
        $token = Str::random(32);

        $payloads = [];
        for ($i = 0; $i < 10; $i++) {
            $payloads[] = [
                'customer_id' => $customer->id,
                'order_type' => 'take_away',
                'table_id' => null,
                'payment_method' => 'cash',
                'cart_lines' => [$menu->id => ['qty' => 2, 'item_note' => null]],
                'checkout_token' => $token,
            ];
        }

        $results = $this->runParallelWorkers($payloads);

        $succeeded = array_values(array_filter($results, static fn (array $r): bool => $r['ok'] === true));
        $this->assertCount(10, $succeeded);

        $uniqueOrderIds = array_values(array_unique(array_column($succeeded, 'order_id')));
        $this->assertCount(1, $uniqueOrderIds);
        $this->assertSame(1, Order::query()->where('checkout_token', $token)->count());
    }

    public function test_one_customer_ten_concurrent_submits_respects_active_order_limit_of_three(): void
    {
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);
        $customer = Customer::factory()->create();

        $payloads = [];
        for ($i = 0; $i < 10; $i++) {
            $payloads[] = [
                'customer_id' => $customer->id,
                'order_type' => 'take_away',
                'table_id' => null,
                'payment_method' => 'cash',
                'cart_lines' => [$menu->id => ['qty' => 1, 'item_note' => null]],
                'checkout_token' => Str::random(32),
            ];
        }

        $results = $this->runParallelWorkers($payloads);

        $succeeded = array_values(array_filter($results, static fn (array $r): bool => $r['ok'] === true));
        $failed = array_values(array_filter($results, static fn (array $r): bool => $r['ok'] === false));

        $this->assertCount(3, $succeeded);
        $this->assertCount(7, $failed);
        foreach ($failed as $fail) {
            $this->assertStringContainsString('3 pesanan aktif', (string) $fail['error']);
        }
        $this->assertSame(3, Order::query()->where('customer_id', $customer->id)->count());
    }

    public function test_twelve_concurrent_mixed_coded_tables_and_take_away_all_succeed_with_unique_numbers(): void
    {
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create(['category_id' => $category->id, 'price' => 15000]);

        $payloads = [];
        for ($i = 0; $i < 6; $i++) {
            $customer = Customer::factory()->create();
            $table = DiningTable::factory()->create([
                'code' => '2'.chr(65 + $i),
                'floor' => 2,
                'type' => TableType::Fixed,
            ]);
            $payloads[] = [
                'customer_id' => $customer->id,
                'order_type' => 'dine_in',
                'table_id' => $table->id,
                'payment_method' => 'cash',
                'cart_lines' => [$menu->id => ['qty' => 1, 'item_note' => null]],
                'checkout_token' => Str::random(40),
            ];
        }

        for ($i = 0; $i < 6; $i++) {
            $customer = Customer::factory()->create();
            $payloads[] = [
                'customer_id' => $customer->id,
                'order_type' => 'take_away',
                'table_id' => null,
                'payment_method' => 'cash',
                'cart_lines' => [$menu->id => ['qty' => 2, 'item_note' => null]],
                'checkout_token' => Str::random(40),
            ];
        }

        $results = $this->runParallelWorkers($payloads);
        $succeeded = array_values(array_filter($results, static fn (array $r): bool => $r['ok'] === true));

        $this->assertCount(12, $succeeded);

        $orderNumbers = array_column($succeeded, 'order_number');
        sort($orderNumbers);

        $expectedPrefix = now()->format('Ymd').'-';
        $expected = array_map(
            static fn (int $n): string => sprintf('%s%04d', $expectedPrefix, $n),
            range(1, 12)
        );

        $this->assertSame($expected, $orderNumbers);
        $this->assertSame(12, Order::query()->count());
    }

    public function test_race_worker_refuses_to_run_on_database_without_test_suffix(): void
    {
        $workerPath = base_path('tests/Concurrency/race_worker.php');

        $process = new Process(
            [PHP_BINARY, $workerPath, '{}'],
            base_path(),
            [
                'DB_CONNECTION' => (string) config('database.default'),
                'DB_HOST' => (string) config('database.connections.mysql.host'),
                'DB_PORT' => (string) config('database.connections.mysql.port'),
                'DB_DATABASE' => 'umkm_bakso',
                'DB_USERNAME' => (string) config('database.connections.mysql.username'),
                'DB_PASSWORD' => (string) config('database.connections.mysql.password'),
            ],
            null,
            15,
        );

        $process->run();

        $this->assertFalse($process->isSuccessful());
        $this->assertStringContainsString('Refusing to run race worker on non-test database: umkm_bakso', $process->getErrorOutput());
    }

    public function test_customer_cancel_and_admin_transition_race_allows_exactly_one_winner(): void
    {
        $customer = Customer::factory()->create();
        $category = MenuCategory::factory()->create();
        $menu = Menu::factory()->create([
            'category_id' => $category->id,
            'price' => 18000,
            'is_available' => true,
        ]);
        $service = app(\App\Services\OrderService::class);

        $order = $service->createOrder(
            customerId: $customer->id,
            orderType: \App\Enums\OrderType::TakeAway,
            tableId: null,
            locationNote: null,
            orderNote: null,
            paymentMethod: \App\Enums\PaymentMethod::Cash,
            cartLines: [$menu->id => ['qty' => 1, 'item_note' => null]],
            checkoutToken: Str::random(40),
        );

        $results = $this->runParallelWorkers([
            [
                'action' => 'cancel_by_customer',
                'customer_id' => $customer->id,
                'order_number' => $order->order_number,
            ],
            [
                'action' => 'admin_transition_diproses',
                'order_id' => $order->id,
            ],
        ]);

        $succeeded = array_values(array_filter($results, static fn (array $r): bool => $r['ok'] === true));
        $failed = array_values(array_filter($results, static fn (array $r): bool => $r['ok'] === false));

        $this->assertCount(1, $succeeded);
        $this->assertCount(1, $failed);

        $winnerStatus = $succeeded[0]['status'];
        $freshOrder = $order->fresh(['statusLogs']);

        $this->assertSame($winnerStatus, $freshOrder->status->value);
        $this->assertContains($winnerStatus, [\App\Enums\OrderStatus::Dibatalkan->value, \App\Enums\OrderStatus::Diproses->value]);
        $this->assertSame(2, $freshOrder->statusLogs->count());
        $this->assertSame($winnerStatus, $freshOrder->statusLogs->last()->status->value);
    }
}
