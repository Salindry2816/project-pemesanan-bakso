<?php

namespace Tests\Feature;

use App\Livewire\Admin\BusinessProfileEditor;
use App\Models\BusinessProfile;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Livewire\Features\SupportLockedProperties\CannotUpdateLockedPropertyException;
use Livewire\Livewire;
use Tests\TestCase;

class AdminBusinessProfileTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    private BusinessProfile $profile;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::factory()->create(['username' => 'bu_susi']);

        $this->profile = BusinessProfile::forceCreate([
            'id' => 1,
            'name' => 'Bakso Solo',
            'tagline' => 'Warung Bu Susi',
            'description' => 'Bakso lezat khas Solo di Kantin M UNJ.',
            'location' => 'Kantin M, Lantai 2, UNJ',
            'phone' => '6285215355501',
            'whatsapp' => '6285215355501',
            'open_time' => '08.00',
            'close_time' => '17.00',
        ]);
    }

    public function test_guest_is_redirected_from_profile_page_to_login(): void
    {
        $response = $this->get(route('admin.profile'));
        $response->assertRedirect(route('admin.login'));
    }

    public function test_unauthenticated_livewire_actions_on_business_profile_editor_are_forbidden(): void
    {
        Livewire::test(BusinessProfileEditor::class)
            ->call('saveProfile')
            ->assertForbidden();

        Livewire::test(BusinessProfileEditor::class)
            ->call('removeLogo')
            ->assertForbidden();

        Livewire::test(BusinessProfileEditor::class)
            ->call('removeQris')
            ->assertForbidden();
    }

    public function test_admin_can_view_profile_page_and_update_text_fields(): void
    {
        $response = $this->actingAs($this->admin)->get(route('admin.profile'));
        $response->assertStatus(200);
        $response->assertSee('Profil Usaha');
        $response->assertSee('Bakso Solo');
        $response->assertSee('Warung Bu Susi');
        $response->assertSee('Pengaturan Warung');

        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->assertSet('name', 'Bakso Solo')
            ->assertSet('tagline', 'Warung Bu Susi')
            ->assertSet('open_time', '08.00')
            ->assertSet('close_time', '17.00')
            ->set('name', 'Bakso Solo Mas Bro')
            ->set('tagline', 'Spesial Urat & Tetelan')
            ->set('description', 'Deskripsi baru yang diperbarui.')
            ->set('location', 'Kantin M Lt 2 UNJ Rawamangun')
            ->set('open_time', '09.00')
            ->set('close_time', '18.00')
            ->call('saveProfile')
            ->assertHasNoErrors()
            ->assertSee('Profil usaha berhasil diperbarui.');

        $this->profile->refresh();
        $this->assertSame('Bakso Solo Mas Bro', $this->profile->name);
        $this->assertSame('Spesial Urat & Tetelan', $this->profile->tagline);
        $this->assertSame('Deskripsi baru yang diperbarui.', $this->profile->description);
        $this->assertSame('Kantin M Lt 2 UNJ Rawamangun', $this->profile->location);
        $this->assertSame('09.00', $this->profile->open_time);
        $this->assertSame('18.00', $this->profile->close_time);
    }

    public function test_invalid_time_format_is_rejected(): void
    {
        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('open_time', '24.00')
            ->call('saveProfile')
            ->assertHasErrors(['open_time'])
            ->set('open_time', '08.60')
            ->call('saveProfile')
            ->assertHasErrors(['open_time'])
            ->set('open_time', '8.00')
            ->call('saveProfile')
            ->assertHasErrors(['open_time'])
            ->set('open_time', 'pagi')
            ->call('saveProfile')
            ->assertHasErrors(['open_time']);
    }

    public function test_same_open_and_close_time_is_rejected(): void
    {
        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('open_time', '08.00')
            ->set('close_time', '08.00')
            ->call('saveProfile')
            ->assertHasErrors(['close_time'])
            ->assertSee('Jam buka dan jam tutup tidak boleh sama.');
    }

    public function test_whatsapp_and_phone_are_automatically_normalized_to_628(): void
    {
        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('phone', '081234567890')
            ->set('whatsapp', '+62 812-9876-5432')
            ->call('saveProfile')
            ->assertHasNoErrors();

        $this->profile->refresh();
        $this->assertSame('6281234567890', $this->profile->phone);
        $this->assertSame('6281298765432', $this->profile->whatsapp);
    }

    public function test_invalid_phone_and_whatsapp_are_rejected(): void
    {
        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('phone', '12345')
            ->call('saveProfile')
            ->assertHasErrors(['phone']);

        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('phone', '6285215355501')
            ->set('whatsapp', '021123456') // Not a mobile number
            ->call('saveProfile')
            ->assertHasErrors(['whatsapp'])
            ->assertSee('Format nomor WhatsApp tidak valid.');
    }

    public function test_logo_upload_validates_and_resizes_to_max_800px(): void
    {
        $disk = config('filesystems.media_disk', 'public');
        Storage::fake($disk);

        $largeLogo = $this->createImageFile(1200, 900, 'jpeg', 'large-logo.jpg');

        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('logo', $largeLogo)
            ->call('saveProfile')
            ->assertHasNoErrors()
            ->assertSee('Profil usaha berhasil diperbarui.');

        $this->profile->refresh();
        $this->assertNotNull($this->profile->logo_path);
        Storage::disk($disk)->assertExists($this->profile->logo_path);

        $binary = Storage::disk($disk)->get($this->profile->logo_path);
        $info = getimagesizefromstring($binary);
        $this->assertNotFalse($info);
        $this->assertSame(800, $info[0]);
        $this->assertSame(600, $info[1]);
    }

    public function test_qris_upload_validates_and_keeps_lossless_exact_dimensions(): void
    {
        $disk = config('filesystems.media_disk', 'public');
        Storage::fake($disk);

        $qrisImage = $this->createImageFile(500, 700, 'png', 'qris-warung.png');

        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('qris', $qrisImage)
            ->call('saveProfile')
            ->assertHasNoErrors()
            ->assertSee('Profil usaha berhasil diperbarui.');

        $this->profile->refresh();
        $this->assertNotNull($this->profile->qris_image_path);
        Storage::disk($disk)->assertExists($this->profile->qris_image_path);

        $binary = Storage::disk($disk)->get($this->profile->qris_image_path);
        $info = getimagesizefromstring($binary);
        $this->assertNotFalse($info);
        $this->assertSame(500, $info[0]);
        $this->assertSame(700, $info[1]);
    }

    public function test_oversized_upload_and_invalid_extension_are_rejected(): void
    {
        $disk = config('filesystems.media_disk', 'public');
        Storage::fake($disk);

        // 1. Oversized file (> 2 MB)
        $oversized = UploadedFile::fake()->create('huge.jpg', 2500, 'image/jpeg');

        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('logo', $oversized)
            ->assertHasErrors(['logo'])
            ->call('saveProfile')
            ->assertHasErrors(['logo']);

        // 2. Non-image file disguised as image
        $fakeImage = UploadedFile::fake()->createWithContent('exploit.jpg', '<?php echo "evil"; ?>');

        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('logo', $fakeImage)
            ->assertHasErrors(['logo'])
            ->call('saveProfile')
            ->assertHasErrors(['logo']);
    }

    public function test_replacing_image_deletes_old_file_from_storage(): void
    {
        $disk = config('filesystems.media_disk', 'public');
        Storage::fake($disk);

        $firstLogo = $this->createImageFile(400, 400, 'png', 'first-logo.png');

        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('logo', $firstLogo)
            ->call('saveProfile')
            ->assertHasNoErrors();

        $this->profile->refresh();
        $firstPath = $this->profile->logo_path;
        Storage::disk($disk)->assertExists($firstPath);

        $secondLogo = $this->createImageFile(300, 300, 'jpeg', 'second-logo.jpg');

        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('logo', $secondLogo)
            ->call('saveProfile')
            ->assertHasNoErrors();

        $this->profile->refresh();
        $secondPath = $this->profile->logo_path;

        $this->assertNotSame($firstPath, $secondPath);
        Storage::disk($disk)->assertMissing($firstPath);
        Storage::disk($disk)->assertExists($secondPath);
    }

    public function test_remove_logo_and_remove_qris_clear_storage_and_database(): void
    {
        $disk = config('filesystems.media_disk', 'public');
        Storage::fake($disk);

        $logo = $this->createImageFile(400, 400, 'png', 'logo.png');
        $qris = $this->createImageFile(400, 400, 'png', 'qris.png');

        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('logo', $logo)
            ->set('qris', $qris)
            ->call('saveProfile')
            ->assertHasNoErrors();

        $this->profile->refresh();
        $logoPath = $this->profile->logo_path;
        $qrisPath = $this->profile->qris_image_path;

        Storage::disk($disk)->assertExists($logoPath);
        Storage::disk($disk)->assertExists($qrisPath);

        // Remove logo
        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->call('removeLogo')
            ->assertSee('Logo warung berhasil dihapus.');

        $this->profile->refresh();
        $this->assertNull($this->profile->logo_path);
        Storage::disk($disk)->assertMissing($logoPath);

        // Remove QRIS
        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->call('removeQris')
            ->assertSee('Gambar QRIS berhasil dihapus.');

        $this->profile->refresh();
        $this->assertNull($this->profile->qris_image_path);
        Storage::disk($disk)->assertMissing($qrisPath);
    }

    public function test_locked_properties_cannot_be_tampered_from_client(): void
    {
        $this->expectException(CannotUpdateLockedPropertyException::class);

        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->set('profileId', 999);
    }

    public function test_missing_profile_shows_error_message_and_does_not_throw_500(): void
    {
        BusinessProfile::query()->delete();

        $response = $this->actingAs($this->admin)->get(route('admin.profile'));
        $response->assertStatus(200);
        $response->assertSee('Profil usaha belum dibuat. Jalankan seeder awal.');

        Livewire::actingAs($this->admin)
            ->test(BusinessProfileEditor::class)
            ->assertSee('Profil usaha belum dibuat. Jalankan seeder awal.')
            ->call('saveProfile')
            ->assertSee('Profil usaha belum dibuat. Jalankan seeder awal.');

        $this->assertSame(0, BusinessProfile::count());
    }

    private function createImageFile(int $width, int $height, string $format, string $clientName): UploadedFile
    {
        $img = imagecreatetruecolor($width, $height);
        $color = imagecolorallocate($img, 120, 42, 37);
        imagefilledrectangle($img, 0, 0, $width, $height, $color);

        ob_start();
        match ($format) {
            'jpeg' => imagejpeg($img, null, 85),
            'png' => imagepng($img),
            'webp' => imagewebp($img, null, 85),
        };
        $bytes = (string) ob_get_clean();

        return UploadedFile::fake()->createWithContent($clientName, $bytes);
    }
}
