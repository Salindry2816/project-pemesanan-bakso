<?php

namespace Tests\Feature;

use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\MenuCategory;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ViewRouteGuardsTest extends TestCase
{
    use RefreshDatabase;

    public function test_no_route_has_calls_remain_in_layout_and_admin_views(): void
    {
        $viewsToCheck = [
            'components/layouts/admin.blade.php',
            'components/layouts/customer.blade.php',
            'livewire/admin/category-manager.blade.php',
            'livewire/admin/menu-manager.blade.php',
            'livewire/admin/table-manager.blade.php',
        ];

        foreach ($viewsToCheck as $relPath) {
            $fullPath = resource_path("views/{$relPath}");
            $this->assertFileExists($fullPath);
            $content = file_get_contents($fullPath);
            $this->assertStringNotContainsString('Route::has', $content, "Route::has was found in {$relPath}");
        }
    }

    public function test_all_customer_layout_navigation_links_point_to_active_registered_routes(): void
    {
        $category = MenuCategory::create(['name' => 'Bakso', 'slug' => 'bakso', 'display_order' => 1]);
        $table = DiningTable::factory()->create(['code' => '01', 'floor' => 1, 'is_active' => true]);
        $customer = Customer::create(['phone' => '081234567890', 'is_active' => true]);

        session([
            'customer_id' => $customer->id,
            'order_type' => 'dine_in',
            'table_id' => $table->id,
            'table_type' => 'numbered',
        ]);

        $response = $this->get(route('customer.menu'));

        $response->assertOk();
        $response->assertSee(route('customer.table'));
        $response->assertSee(route('customer.menu'));
        $response->assertSee(route('customer.cart'));
        $response->assertSee(route('customer.profile'));
        $response->assertSee(route('customer.reset'));
    }
}
