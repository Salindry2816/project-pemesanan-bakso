<?php

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\TableType;
use App\Livewire\Admin\OrderList;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Order;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Livewire\Livewire;
use Tests\TestCase;

class AdminOrderListTest extends TestCase
{
    use RefreshDatabase;

    private User $admin;

    protected function setUp(): void
    {
        parent::setUp();

        $this->admin = User::factory()->create([
            'username' => 'admin_test',
            'password' => 'password123',
        ]);
    }

    public function test_guest_is_redirected_from_admin_order_list(): void
    {
        $this->get(route('admin.orders.index'))
            ->assertRedirect(route('admin.login'));
    }

    public function test_dashboard_has_semua_pesanan_button_and_sidebar_pesanan_stays_on_dashboard(): void
    {
        $this->actingAs($this->admin)
            ->get(route('admin.dashboard'))
            ->assertOk()
            ->assertSee('Semua Pesanan')
            ->assertSee(route('admin.orders.index'), false)
            ->assertSee('href="'.route('admin.dashboard').'"', false);
    }

    public function test_order_list_filters_by_status_date_and_normalized_phone_or_table_or_number(): void
    {
        $customer1 = Customer::factory()->create(['phone' => '628123450001']);
        $customer2 = Customer::factory()->create(['phone' => '628987650002']);

        $table2A = DiningTable::factory()->create([
            'code' => '2A',
            'floor' => 2,
            'type' => TableType::Fixed,
        ]);

        $orderTodaySelesai = Order::factory()->create([
            'order_number' => '20261113-0001',
            'customer_id' => $customer1->id,
            'type' => OrderType::DineIn,
            'table_id' => $table2A->id,
            'status' => OrderStatus::Selesai,
            'created_at' => now(),
        ]);

        $orderYesterdayDibatalkan = Order::factory()->create([
            'order_number' => '20261112-0002',
            'customer_id' => $customer2->id,
            'type' => OrderType::TakeAway,
            'table_id' => null,
            'status' => OrderStatus::Dibatalkan,
            'created_at' => now()->subDay(),
        ]);

        $this->actingAs($this->admin);

        // Status filter
        Livewire::test(OrderList::class)
            ->call('setFilter', 'selesai')
            ->assertSee($orderTodaySelesai->display_number)
            ->assertDontSee($orderYesterdayDibatalkan->display_number);

        // Date filter
        Livewire::test(OrderList::class)
            ->set('dateFrom', now()->subDay()->toDateString())
            ->set('dateTo', now()->subDay()->toDateString())
            ->assertSee($orderYesterdayDibatalkan->display_number)
            ->assertDontSee($orderTodaySelesai->display_number);

        // Search by 08... phone (normalized to 628...)
        Livewire::test(OrderList::class)
            ->set('search', '08123450001')
            ->assertSee($orderTodaySelesai->display_number)
            ->assertDontSee($orderYesterdayDibatalkan->display_number);

        // Search by table code
        Livewire::test(OrderList::class)
            ->set('search', '2A')
            ->assertSee($orderTodaySelesai->display_number)
            ->assertDontSee($orderYesterdayDibatalkan->display_number);

        // Search with wildcard '%' must be escaped and not match everything
        Livewire::test(OrderList::class)
            ->set('search', '%')
            ->assertSee('Tidak ada pesanan ditemukan');
    }

    public function test_order_list_paginates_and_preserves_filter_across_pages(): void
    {
        $customer = Customer::factory()->create(['phone' => '628111222333']);

        for ($i = 1; $i <= 16; $i++) {
            Order::factory()->create([
                'order_number' => sprintf('20261113-%04d', $i),
                'customer_id' => $customer->id,
                'status' => OrderStatus::Selesai,
                'created_at' => now()->subMinutes(20 - $i),
            ]);
        }

        Order::factory()->create([
            'order_number' => '20261113-0099',
            'customer_id' => $customer->id,
            'status' => OrderStatus::Dibatalkan,
            'created_at' => now()->subMinutes(30),
        ]);

        $this->actingAs($this->admin);

        $component = Livewire::test(OrderList::class)
            ->call('setFilter', 'selesai')
            ->assertSee('#0016')
            ->assertDontSee('#0001')
            ->assertDontSee('#0099');

        $component->call('nextPage')
            ->assertSet('statusFilter', 'selesai')
            ->assertSee('#0001')
            ->assertDontSee('#0099');
    }
}
