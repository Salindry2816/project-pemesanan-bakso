<?php

namespace Tests\Feature;

use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\TableType;
use App\Services\OrderService;
use Illuminate\Support\Facades\DB;
use App\Models\BusinessProfile;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Models\Order;
use App\Models\User;
use Database\Seeders\DatabaseSeeder;
use Database\Seeders\DemoSeeder;
use Database\Seeders\ProductionSeeder;
use Database\Seeders\WarungCatalogSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use RuntimeException;
use Tests\TestCase;

class SeederTest extends TestCase
{
    use RefreshDatabase;

    private function setAdminEnv(?string $username = null, ?string $password = null): array
    {
        $username ??= 'test_admin_'.Str::lower(Str::random(6));
        $password ??= Str::random(16);

        putenv("ADMIN_USERNAME={$username}");
        putenv("ADMIN_PASSWORD={$password}");
        $_ENV['ADMIN_USERNAME'] = $username;
        $_ENV['ADMIN_PASSWORD'] = $password;
        $_SERVER['ADMIN_USERNAME'] = $username;
        $_SERVER['ADMIN_PASSWORD'] = $password;

        return [$username, $password];
    }

    public function test_production_seeder_is_idempotent_creates_expected_records_and_no_dummy_data(): void
    {
        [$username] = $this->setAdminEnv();

        // Run twice via DatabaseSeeder to verify idempotency
        $this->seed(DatabaseSeeder::class);
        $this->seed(DatabaseSeeder::class);

        $this->assertSame(1, User::count());
        $this->assertDatabaseHas('users', ['username' => $username]);

        // 7 coded tables (2A..2G) + 1 free table ('BEBAS' capacity 22) = 8 tables
        $this->assertSame(8, DiningTable::count());
        $this->assertSame(7, DiningTable::coded()->count());
        $this->assertSame(
            ['2A', '2B', '2C', '2D', '2E', '2F', '2G'],
            DiningTable::coded()->orderBy('code')->pluck('code')->all()
        );

        $freeTable = DiningTable::where('code', 'BEBAS')->first();
        $this->assertNotNull($freeTable);
        $this->assertSame(TableType::Free, $freeTable->type);
        $this->assertSame(2, $freeTable->floor);
        $this->assertSame(22, $freeTable->capacity);

        // Categories: Bakso, Paket, Minuman
        $this->assertSame(3, MenuCategory::count());
        $this->assertSame(
            ['Bakso', 'Paket', 'Minuman'],
            MenuCategory::orderBy('sort_order')->pluck('name')->all()
        );

        // Single business profile row
        $this->assertSame(1, BusinessProfile::count());
        $profile = BusinessProfile::first();
        $this->assertSame('Bakso Solo', $profile->name);
        $this->assertSame('Warung Bu Susi', $profile->tagline);
        $this->assertSame('085215355501', $profile->whatsapp);

        // Must NOT create any menus, customers, or orders
        $this->assertSame(0, Menu::count());
        $this->assertSame(0, Customer::count());
        $this->assertSame(0, Order::count());
    }

    public function test_production_seeder_does_not_overwrite_existing_modified_records(): void
    {
        [$username] = $this->setAdminEnv();
        $updatedSecret = Str::random(18);

        $this->seed(ProductionSeeder::class);

        // Modify existing records
        $admin = User::where('username', $username)->firstOrFail();
        $admin->update([
            'name' => 'Ibu Susi Baru',
            'password' => Hash::make($updatedSecret),
        ]);

        $profile = BusinessProfile::findOrFail(1);
        $profile->update([
            'open_time' => '09.00',
        ]);

        $baksoCategory = MenuCategory::where('name', 'Bakso')->firstOrFail();
        $baksoCategory->update([
            'sort_order' => 99,
        ]);

        $table2A = DiningTable::where('code', '2A')->firstOrFail();
        $table2A->update([
            'is_active' => false,
        ]);

        // Re-run ProductionSeeder
        $this->seed(ProductionSeeder::class);

        // Counts must not increase for admin, profile, categories, and tables
        $this->assertSame(1, User::count());
        $this->assertSame(1, BusinessProfile::count());
        $this->assertSame(3, MenuCategory::count());
        $this->assertSame(8, DiningTable::count());

        // Modified values must NOT be reverted to defaults
        $admin->refresh();
        $this->assertSame('Ibu Susi Baru', $admin->name);
        $this->assertTrue(Hash::check($updatedSecret, $admin->password));

        $profile->refresh();
        $this->assertSame('09.00', $profile->open_time);

        $baksoCategory->refresh();
        $this->assertSame(99, $baksoCategory->sort_order);

        $table2A->refresh();
        $this->assertFalse($table2A->is_active);
    }

    public function test_production_seeder_fails_when_admin_env_is_missing(): void
    {
        $this->setAdminEnv('', '');

        $this->expectException(RuntimeException::class);

        $this->seed(ProductionSeeder::class);
    }

    public function test_demo_seeder_populates_sample_menus_and_orders_in_non_production(): void
    {
        Storage::fake('public');
        $this->setAdminEnv();

        $this->seed(ProductionSeeder::class);
        $this->seed(DemoSeeder::class);

        $this->assertSame(12, Menu::count());

        $baksoCategory = MenuCategory::where('name', 'Bakso')->firstOrFail();
        $paketCategory = MenuCategory::where('name', 'Paket')->firstOrFail();
        $minumanCategory = MenuCategory::where('name', 'Minuman')->firstOrFail();
        $tambahanCategory = MenuCategory::where('name', 'Tambahan')->firstOrFail();

        $this->assertSame(8, Menu::where('category_id', $baksoCategory->id)->count());
        $this->assertSame(1, Menu::where('category_id', $paketCategory->id)->count());
        $this->assertSame(2, Menu::where('category_id', $minumanCategory->id)->count());
        $this->assertSame(1, Menu::where('category_id', $tambahanCategory->id)->count());

        $this->assertDatabaseHas('menus', [
            'name' => 'Bakso + Indomie',
            'category_id' => $paketCategory->id,
            'price' => 22000,
            'photo_path' => 'menus/bakso-indomie.jpg',
        ]);
        $this->assertDatabaseHas('menus', [
            'name' => 'Es Teh / Teh Anget',
            'category_id' => $minumanCategory->id,
            'price' => 5000,
        ]);

        $profile = BusinessProfile::firstOrFail();
        $this->assertSame('logos/logo-bakso-ibu-susi.jpg', $profile->logo_path);
        $this->assertSame('qris/qris-bu-susi.png', $profile->qris_image_path);
        Storage::disk('public')->assertExists('logos/logo-bakso-ibu-susi.jpg');
        Storage::disk('public')->assertExists('qris/qris-bu-susi.png');
        Storage::disk('public')->assertExists('menus/bakso-komplit.jpg');

        $this->assertGreaterThan(0, Customer::count());
        $this->assertGreaterThan(0, Order::count());
    }

    public function test_demo_seeder_refuses_to_run_in_production_environment(): void
    {
        $originalEnv = $this->app['env'];
        $this->app['env'] = 'production';

        try {
            $this->expectException(RuntimeException::class);
            $this->expectExceptionMessage('DemoSeeder tidak boleh dijalankan di environment production.');
            app(DemoSeeder::class)->run();
        } finally {
            $this->app['env'] = $originalEnv;
        }
    }

    public function test_demo_seeder_syncs_order_sequence_so_12_subsequent_orders_do_not_collide(): void
    {
        Storage::fake('public');
        $this->setAdminEnv();

        $this->seed(ProductionSeeder::class);
        $this->assertDatabaseMissing('order_sequences', ['seq_date' => now()->toDateString()]);

        $this->seed(DemoSeeder::class);
        $this->assertDatabaseHas('order_sequences', [
            'seq_date' => now()->toDateString(),
            'last_number' => 12,
        ]);

        $orderService = app(OrderService::class);
        $menu = Menu::firstOrFail();
        $datePrefix = now()->format('Ymd');

        $createdNumbers = [];
        for ($i = 1; $i <= 12; $i++) {
            $customer = Customer::create([
                'phone' => '628990000' . str_pad((string) $i, 3, '0', STR_PAD_LEFT),
            ]);

            $order = $orderService->createOrder(
                customerId: $customer->id,
                orderType: OrderType::TakeAway,
                tableId: null,
                locationNote: null,
                orderNote: null,
                paymentMethod: PaymentMethod::Cash,
                cartLines: [$menu->id => ['menu_id' => $menu->id, 'qty' => 1, 'item_note' => null]],
                checkoutToken: OrderService::generateCheckoutToken(),
            );

            $createdNumbers[] = $order->order_number;
        }

        $this->assertSame("{$datePrefix}-0013", $createdNumbers[0]);
        $this->assertSame("{$datePrefix}-0024", $createdNumbers[11]);
        $this->assertSame(12, count(array_unique($createdNumbers)));

        // Re-running DemoSeeder must not rewind last_number below 24
        $this->seed(DemoSeeder::class);
        $this->assertSame(24, (int) DB::table('order_sequences')->where('seq_date', now()->toDateString())->value('last_number'));
    }

    public function test_warung_catalog_seeder_is_idempotent_and_preserves_custom_uploads(): void
    {
        Storage::fake('public');
        $this->setAdminEnv();

        $this->seed(ProductionSeeder::class);
        $this->seed(WarungCatalogSeeder::class);

        $this->assertSame(12, Menu::count());

        $profile = BusinessProfile::firstOrFail();
        $profile->update([
            'logo_path' => 'logos/custom.jpg',
            'qris_image_path' => 'qris/custom.png',
        ]);

        $menu = Menu::where('name', 'Bakso Komplit')->firstOrFail();
        $menu->update([
            'photo_path' => 'menus/custom-komplit.jpg',
            'is_available' => false,
        ]);

        // Re-run WarungCatalogSeeder and verify custom uploads/availability are kept
        $this->seed(WarungCatalogSeeder::class);

        $profile->refresh();
        $menu->refresh();

        $this->assertSame('logos/custom.jpg', $profile->logo_path);
        $this->assertSame('qris/custom.png', $profile->qris_image_path);
        $this->assertSame('menus/custom-komplit.jpg', $menu->photo_path);
        $this->assertFalse($menu->is_available);
    }
}
