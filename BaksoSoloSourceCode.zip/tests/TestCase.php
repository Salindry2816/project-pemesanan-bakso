<?php

namespace Tests;

use Illuminate\Foundation\Testing\TestCase as BaseTestCase;
use Illuminate\Support\Facades\DB;
use RuntimeException;

abstract class TestCase extends BaseTestCase
{
    protected function setUp(): void
    {
        parent::setUp();

        static::ensureTestingDatabaseName((string) DB::connection()->getDatabaseName());
    }

    public static function ensureTestingDatabaseName(string $databaseName): void
    {
        if (! str_ends_with($databaseName, '_test')) {
            throw new RuntimeException(
                "Test hanya boleh berjalan di database yang namanya berakhiran _test (aktif: '{$databaseName}')."
            );
        }
    }
}
