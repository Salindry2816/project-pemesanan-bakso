<?php

declare(strict_types=1);

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Exceptions\OrderCreationException;
use App\Models\Order;
use App\Services\OrderService;
use Illuminate\Contracts\Console\Kernel;
use Illuminate\Support\Facades\DB;

require __DIR__.'/../../vendor/autoload.php';

$app = require __DIR__.'/../../bootstrap/app.php';
$app->make(Kernel::class)->bootstrap();

$databaseName = (string) DB::connection()->getDatabaseName();
if (! str_ends_with($databaseName, '_test')) {
    fwrite(STDERR, "Refusing to run race worker on non-test database: {$databaseName}\n");
    exit(1);
}

$payload = json_decode((string) ($argv[1] ?? '{}'), true, 512, JSON_THROW_ON_ERROR);

$startAt = (float) ($payload['start_at'] ?? 0.0);
if ($startAt > 0.0) {
    $remainingUs = (int) (($startAt - microtime(true)) * 1_000_000);
    if ($remainingUs > 0) {
        usleep($remainingUs);
    }
}

try {
    $action = (string) ($payload['action'] ?? 'create');

    if ($action === 'cancel_by_customer') {
        /** @var OrderService $service */
        $service = app(OrderService::class);
        $order = $service->cancelOrderByCustomer(
            customerId: (int) $payload['customer_id'],
            orderNumber: (string) $payload['order_number'],
        );

        echo json_encode([
            'ok' => true,
            'status' => $order->status->value,
        ], JSON_THROW_ON_ERROR);
    } elseif ($action === 'admin_transition_diproses') {
        $won = DB::transaction(function () use ($payload): bool {
            $order = Order::query()->whereKey((int) $payload['order_id'])->lockForUpdate()->firstOrFail();
            if ($order->status !== OrderStatus::Diterima) {
                return false;
            }

            $order->update(['status' => OrderStatus::Diproses]);
            $order->statusLogs()->create([
                'status' => OrderStatus::Diproses,
                'changed_by' => (int) ($payload['admin_id'] ?? 0) ?: null,
                'created_at' => now(),
            ]);

            return true;
        }, 10);

        echo json_encode([
            'ok' => $won,
            'status' => $won ? OrderStatus::Diproses->value : 'already_changed',
        ], JSON_THROW_ON_ERROR);
    } else {
        /** @var OrderService $service */
        $service = app(OrderService::class);

        $order = $service->createOrder(
            customerId: (int) $payload['customer_id'],
            orderType: OrderType::from((string) $payload['order_type']),
            tableId: isset($payload['table_id']) ? (int) $payload['table_id'] : null,
            locationNote: $payload['location_note'] ?? null,
            orderNote: $payload['order_note'] ?? null,
            paymentMethod: PaymentMethod::from((string) ($payload['payment_method'] ?? 'cash')),
            cartLines: $payload['cart_lines'],
            checkoutToken: (string) $payload['checkout_token'],
            rateLimitIp: null,
            clearCart: false,
        );

        echo json_encode([
            'ok' => true,
            'order_id' => $order->id,
            'order_number' => $order->order_number,
            'retries' => $service->lastTransactionRetries,
        ], JSON_THROW_ON_ERROR);
    }
} catch (OrderCreationException $e) {
    echo json_encode([
        'ok' => false,
        'error' => $e->getMessage(),
        'retries' => isset($service) ? $service->lastTransactionRetries : 0,
    ], JSON_THROW_ON_ERROR);
} catch (Throwable $e) {
    echo json_encode([
        'ok' => false,
        'error' => get_class($e).': '.$e->getMessage(),
    ], JSON_THROW_ON_ERROR);
    exit(1);
}
