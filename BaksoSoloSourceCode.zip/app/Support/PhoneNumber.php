<?php

namespace App\Support;

use Illuminate\Validation\ValidationException;

final class PhoneNumber
{
    /**
     * Normalize an Indonesian phone or WhatsApp number to 628xxxxxxxxxx format.
     */
    public static function normalize(string $raw): string
    {
        $cleaned = preg_replace('/[\s\-\.\(\)]+/', '', trim($raw)) ?? '';

        if (str_starts_with($cleaned, '+62')) {
            $cleaned = '62'.substr($cleaned, 3);
        } elseif (str_starts_with($cleaned, '08')) {
            $cleaned = '62'.substr($cleaned, 1);
        } elseif (str_starts_with($cleaned, '8') && ctype_digit($cleaned)) {
            $cleaned = '62'.$cleaned;
        }

        return $cleaned;
    }

    /**
     * Check whether the phone number is a valid Indonesian mobile number (628...).
     */
    public static function isValid(string $raw): bool
    {
        $normalized = self::normalize($raw);

        return (bool) preg_match('/^628[1-9][0-9]{6,11}$/', $normalized);
    }

    /**
     * Normalize or throw a localized ValidationException.
     */
    public static function normalizeOrFail(string $raw, string $errorField = 'phone'): string
    {
        $normalized = self::normalize($raw);

        if (! self::isValid($normalized)) {
            throw ValidationException::withMessages([
                $errorField => 'Format nomor telepon tidak valid. Gunakan nomor aktif Indonesia (contoh: 081234567890).',
            ]);
        }

        return $normalized;
    }
}
