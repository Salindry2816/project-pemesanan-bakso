<?php

namespace App\Support;

use InvalidArgumentException;

class TableCode
{
    public const MIN_FLOOR = 1;
    public const MAX_FLOOR = 4;

    public static function validateFloor(int $floor): void
    {
        if ($floor < self::MIN_FLOOR || $floor > self::MAX_FLOOR) {
            throw new InvalidArgumentException("Nomor lantai harus antara 1 sampai 4 (diberikan: {$floor}).");
        }
    }

    /**
     * Generate a table code from floor (1-4) and zero-based index (0 -> A, 1 -> B, ...).
     */
    public static function fromIndex(int $floor, int $index): string
    {
        self::validateFloor($floor);

        if ($index < 0 || $index > 25) {
            throw new InvalidArgumentException("Indeks meja harus antara 0 sampai 25 (diberikan: {$index}).");
        }

        return $floor.chr(ord('A') + $index);
    }

    /**
     * Generate sequential table codes for a floor (e.g. floor 2, count 7 -> ['2A', ..., '2G']).
     *
     * @return list<string>
     */
    public static function range(int $floor, int $count): array
    {
        self::validateFloor($floor);

        if ($count < 0 || $count > 26) {
            throw new InvalidArgumentException("Jumlah meja harus antara 0 sampai 26 (diberikan: {$count}).");
        }

        $codes = [];
        for ($i = 0; $i < $count; $i++) {
            $codes[] = self::fromIndex($floor, $i);
        }

        return $codes;
    }

    /**
     * Check whether a value is a valid coded table format for floors 1-4 (e.g. "2A", "3B"),
     * ignoring free table records such as "BEBAS".
     */
    public static function isCodedTable(string $code, ?int $floor = null): bool
    {
        $normalized = strtoupper(trim($code));

        if (! preg_match('/^([1-4])([A-Z])$/', $normalized, $matches)) {
            return false;
        }

        if ($floor !== null && (int) $matches[1] !== $floor) {
            return false;
        }

        return true;
    }

    /**
     * Determine the next sequential table code for a given floor based on existing codes
     * or table items (automatically ignores non-coded/free records like "BEBAS").
     *
     * @param  iterable<mixed>  $existing
     */
    public static function nextForFloor(int $floor, iterable $existing = []): string
    {
        self::validateFloor($floor);

        $maxLetterIndex = -1;

        foreach ($existing as $item) {
            if (is_object($item)) {
                $type = $item->type ?? null;
                $typeValue = is_object($type) && property_exists($type, 'value') ? $type->value : $type;

                if ($typeValue === 'free') {
                    continue;
                }

                $code = (string) ($item->code ?? '');
            } elseif (is_array($item)) {
                $type = $item['type'] ?? null;
                $typeValue = is_object($type) && property_exists($type, 'value') ? $type->value : $type;

                if ($typeValue === 'free') {
                    continue;
                }

                $code = (string) ($item['code'] ?? '');
            } else {
                $code = (string) $item;
            }

            $normalized = strtoupper(trim($code));

            if (! self::isCodedTable($normalized, $floor)) {
                continue;
            }

            $letter = substr($normalized, 1, 1);
            $letterIndex = ord($letter) - ord('A');

            if ($letterIndex > $maxLetterIndex) {
                $maxLetterIndex = $letterIndex;
            }
        }

        $nextIndex = $maxLetterIndex + 1;

        if ($nextIndex > 25) {
            throw new InvalidArgumentException("Semua huruf meja untuk lantai {$floor} (A-Z) sudah terpakai.");
        }

        return self::fromIndex($floor, $nextIndex);
    }
}
