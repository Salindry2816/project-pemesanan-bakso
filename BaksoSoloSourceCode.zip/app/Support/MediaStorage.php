<?php

namespace App\Support;

use finfo;
use GdImage;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

/**
 * Shared image upload and storage helper.
 *
 * Railway / Production Build Requirement:
 * Requires PHP extensions: ext-gd (compiled with JPEG, PNG, and WebP support),
 * ext-exif, ext-fileinfo, and ext-mbstring (declared in composer.json).
 */
final class MediaStorage
{
    public const MAX_BYTES = 2 * 1024 * 1024; // 2 MB

    public const MAX_SIDE_PIXELS = 6000;

    public const MAX_TOTAL_PIXELS = 25_000_000;

    public const DEFAULT_MAX_DIMENSION = 800;

    /**
     * Return the configured disk name for uploaded media.
     */
    public static function disk(): string
    {
        return (string) config('filesystems.media_disk', 'public');
    }

    /**
     * Return the public URL for a stored relative media path.
     */
    public static function url(?string $path): ?string
    {
        if ($path === null || trim($path) === '') {
            return null;
        }

        $disk = self::disk();

        if ($disk === 'public' && config('filesystems.disks.public.driver') === 'local') {
            return '/storage/'.ltrim($path, '/');
        }

        return Storage::disk($disk)->url($path);
    }

    /**
     * Decode, apply EXIF orientation, proportionally resize (max 800px), re-encode via GD,
     * store with a random ULID filename, and delete the old file if replaced.
     */
    public static function storeImage(
        UploadedFile $file,
        string $directory,
        ?string $oldPath = null,
        int $maxDimension = self::DEFAULT_MAX_DIMENSION,
        string $errorField = 'photo',
    ): string {
        return self::processAndStore(
            file: $file,
            directory: $directory,
            oldPath: $oldPath,
            maxDimension: $maxDimension,
            lossless: false,
            errorField: $errorField,
        );
    }

    /**
     * Store QRIS image without resizing and without lossy compression, while still
     * decoding and re-encoding through GD to strip EXIF/payloads safely.
     */
    public static function storeQris(
        UploadedFile $file,
        string $directory = 'qris',
        ?string $oldPath = null,
        string $errorField = 'qris',
    ): string {
        return self::processAndStore(
            file: $file,
            directory: $directory,
            oldPath: $oldPath,
            maxDimension: null,
            lossless: true,
            errorField: $errorField,
        );
    }

    /**
     * Delete a file from the configured media disk if it exists.
     */
    public static function delete(?string $path): void
    {
        if ($path === null || trim($path) === '') {
            return;
        }

        $disk = Storage::disk(self::disk());

        if ($disk->exists($path)) {
            $disk->delete($path);
        }
    }

    /**
     * Validate actual file size, MIME content via finfo, image header via getimagesize,
     * and pixel dimension bounds before any GD memory allocation.
     *
     * @return array{realPath: string, mime: string, extension: string, width: int, height: int}
     */
    public static function validateUploadedFile(UploadedFile $file, string $errorField = 'photo'): array
    {
        $realPath = $file->getRealPath();

        if ($realPath === false || ! is_file($realPath)) {
            throw ValidationException::withMessages([
                $errorField => 'File gambar tidak dapat dibaca.',
            ]);
        }

        $fileSize = filesize($realPath);
        if ($fileSize === false || $fileSize <= 0 || $fileSize > self::MAX_BYTES) {
            throw ValidationException::withMessages([
                $errorField => 'Ukuran gambar maksimal 2 MB.',
            ]);
        }

        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $detectedMime = $finfo->file($realPath);

        $allowedMimes = [
            'image/jpeg' => 'jpg',
            'image/png' => 'png',
            'image/webp' => 'webp',
        ];

        if (! is_string($detectedMime) || ! isset($allowedMimes[$detectedMime])) {
            throw ValidationException::withMessages([
                $errorField => 'File yang diunggah harus berupa gambar berformat JPG, PNG, atau WebP yang valid.',
            ]);
        }

        $imageInfo = @getimagesize($realPath);
        if ($imageInfo === false || ! isset($imageInfo[0], $imageInfo[1], $imageInfo[2])) {
            throw ValidationException::withMessages([
                $errorField => 'File yang diunggah harus berupa gambar berformat JPG, PNG, atau WebP yang valid.',
            ]);
        }

        [$width, $height, $imageType] = $imageInfo;

        $validTypes = [
            'image/jpeg' => IMAGETYPE_JPEG,
            'image/png' => IMAGETYPE_PNG,
            'image/webp' => IMAGETYPE_WEBP,
        ];

        if ($width <= 0 || $height <= 0 || $validTypes[$detectedMime] !== $imageType) {
            throw ValidationException::withMessages([
                $errorField => 'File yang diunggah harus berupa gambar berformat JPG, PNG, atau WebP yang valid.',
            ]);
        }

        if (
            $width > self::MAX_SIDE_PIXELS
            || $height > self::MAX_SIDE_PIXELS
            || ($width * $height) > self::MAX_TOTAL_PIXELS
        ) {
            throw ValidationException::withMessages([
                $errorField => 'Dimensi gambar terlalu besar (maksimal 6000x6000 piksel).',
            ]);
        }

        return [
            'realPath' => $realPath,
            'mime' => $detectedMime,
            'extension' => $allowedMimes[$detectedMime],
            'width' => $width,
            'height' => $height,
        ];
    }

    private static function processAndStore(
        UploadedFile $file,
        string $directory,
        ?string $oldPath,
        ?int $maxDimension,
        bool $lossless,
        string $errorField,
    ): string {
        $validated = self::validateUploadedFile($file, $errorField);
        $realPath = $validated['realPath'];
        $detectedMime = $validated['mime'];
        $extension = $validated['extension'];

        $source = self::createGdImage($realPath, $detectedMime, $errorField);

        if ($detectedMime === 'image/jpeg') {
            $source = self::applyExifOrientation($source, $realPath);
        }

        $srcWidth = imagesx($source);
        $srcHeight = imagesy($source);

        $targetWidth = $srcWidth;
        $targetHeight = $srcHeight;

        if ($maxDimension !== null && $maxDimension > 0 && ($srcWidth > $maxDimension || $srcHeight > $maxDimension)) {
            $ratio = min($maxDimension / $srcWidth, $maxDimension / $srcHeight);
            $targetWidth = max(1, (int) round($srcWidth * $ratio));
            $targetHeight = max(1, (int) round($srcHeight * $ratio));
        }

        $canvas = imagecreatetruecolor($targetWidth, $targetHeight);
        if ($canvas === false) {
            throw ValidationException::withMessages([
                $errorField => 'Gagal memproses gambar.',
            ]);
        }

        if ($detectedMime === 'image/png' || $detectedMime === 'image/webp') {
            imagealphablending($canvas, false);
            imagesavealpha($canvas, true);
            $transparent = imagecolorallocatealpha($canvas, 0, 0, 0, 127);
            imagefilledrectangle($canvas, 0, 0, $targetWidth, $targetHeight, $transparent);
        } else {
            $white = imagecolorallocate($canvas, 255, 255, 255);
            imagefilledrectangle($canvas, 0, 0, $targetWidth, $targetHeight, $white);
        }

        if ($targetWidth === $srcWidth && $targetHeight === $srcHeight) {
            imagecopy($canvas, $source, 0, 0, 0, 0, $srcWidth, $srcHeight);
        } else {
            imagecopyresampled(
                $canvas,
                $source,
                0,
                0,
                0,
                0,
                $targetWidth,
                $targetHeight,
                $srcWidth,
                $srcHeight
            );
        }

        $encodedBinary = self::encodeGdImage($canvas, $detectedMime, $lossless, $errorField);

        $safeDirectory = preg_replace('/[^a-z0-9_-]/i', '', $directory) ?: 'uploads';
        $filename = Str::lower((string) Str::ulid()).'.'.$extension;
        $relativePath = $safeDirectory.'/'.$filename;

        $stored = Storage::disk(self::disk())->put($relativePath, $encodedBinary);

        if ($stored !== true) {
            throw ValidationException::withMessages([
                $errorField => 'Gagal menyimpan gambar ke media penyimpanan.',
            ]);
        }

        if ($oldPath !== null && $oldPath !== '' && $oldPath !== $relativePath) {
            self::delete($oldPath);
        }

        return $relativePath;
    }

    private static function createGdImage(string $realPath, string $mime, string $errorField): GdImage
    {
        $image = match ($mime) {
            'image/jpeg' => @imagecreatefromjpeg($realPath),
            'image/png' => @imagecreatefrompng($realPath),
            'image/webp' => @imagecreatefromwebp($realPath),
            default => false,
        };

        if (! $image instanceof GdImage) {
            throw ValidationException::withMessages([
                $errorField => 'File gambar rusak atau tidak dapat diproses.',
            ]);
        }

        if (! imageistruecolor($image)) {
            imagepalettetotruecolor($image);
        }

        return $image;
    }

    private static function applyExifOrientation(GdImage $image, string $realPath): GdImage
    {
        $orientation = self::readJpegOrientation($realPath);

        if ($orientation === null || $orientation === 1) {
            return $image;
        }

        return match ($orientation) {
            2 => self::flipImage($image, IMG_FLIP_HORIZONTAL),
            3 => imagerotate($image, 180, 0) ?: $image,
            4 => self::flipImage($image, IMG_FLIP_VERTICAL),
            5 => self::rotateAndFlip($image, 270, IMG_FLIP_HORIZONTAL),
            6 => imagerotate($image, 270, 0) ?: $image,
            7 => self::rotateAndFlip($image, 90, IMG_FLIP_HORIZONTAL),
            8 => imagerotate($image, 90, 0) ?: $image,
            default => $image,
        };
    }

    private static function flipImage(GdImage $image, int $mode): GdImage
    {
        imageflip($image, $mode);

        return $image;
    }

    private static function rotateAndFlip(GdImage $image, int $angle, int $flipMode): GdImage
    {
        $rotated = imagerotate($image, $angle, 0);
        if (! $rotated instanceof GdImage) {
            return $image;
        }

        imageflip($rotated, $flipMode);

        return $rotated;
    }

    private static function readJpegOrientation(string $realPath): ?int
    {
        if (function_exists('exif_read_data')) {
            $exif = @exif_read_data($realPath);
            if (is_array($exif) && isset($exif['Orientation']) && is_numeric($exif['Orientation'])) {
                return (int) $exif['Orientation'];
            }
        }

        return null;
    }

    private static function encodeGdImage(GdImage $canvas, string $mime, bool $lossless, string $errorField): string
    {
        ob_start();

        $success = match ($mime) {
            'image/jpeg' => imagejpeg($canvas, null, $lossless ? 100 : 85),
            'image/png' => imagepng($canvas, null, 9),
            'image/webp' => imagewebp(
                $canvas,
                null,
                $lossless && defined('IMG_WEBP_LOSSLESS') ? IMG_WEBP_LOSSLESS : ($lossless ? 100 : 85)
            ),
            default => false,
        };

        $binary = ob_get_clean();

        if (! $success || ! is_string($binary) || $binary === '') {
            throw ValidationException::withMessages([
                $errorField => 'Gagal menyimpan gambar.',
            ]);
        }

        return $binary;
    }
}
