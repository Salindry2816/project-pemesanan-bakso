<?php

namespace App\Http\Controllers\Customer;

use App\Http\Controllers\Controller;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ResetCustomerSessionController extends Controller
{
    /**
     * Clear customer session data and redirect to the phone entry page.
     */
    public function __invoke(Request $request): RedirectResponse
    {
        $request->session()->forget([
            'customer_id',
            'order_type',
            'table_id',
            'location_note',
            'cart',
            'order_note',
            'previous_customer_id',
        ]);

        $request->session()->regenerate();

        return redirect()->route('customer.phone')
            ->with('status', 'Sesi telah direset. Silakan masukkan nomor handphone baru.');
    }
}
