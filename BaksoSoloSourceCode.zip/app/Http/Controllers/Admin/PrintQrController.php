<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\BusinessProfile;
use chillerlan\QRCode\Common\EccLevel;
use chillerlan\QRCode\QRCode;
use chillerlan\QRCode\QROptions;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;

class PrintQrController extends Controller
{
    public function __invoke(Request $request): View
    {
        $profile = BusinessProfile::query()->find(1);

        $targetUrl = (string) config('app.url', '');
        if (trim($targetUrl) === '') {
            $targetUrl = url('/');
        }

        $host = parse_url($targetUrl, PHP_URL_HOST);
        if (! $host) {
            $host = parse_url('http://'.$targetUrl, PHP_URL_HOST) ?: '';
        }

        $isLocalHost = in_array(strtolower($host), ['localhost', '127.0.0.1', '::1'], true);
        $isNonHttpsProduction = app()->isProduction() && ! str_starts_with(strtolower($targetUrl), 'https://');
        $showAppUrlWarning = $isLocalHost || $isNonHttpsProduction;

        $options = new QROptions([
            'outputInterface' => \chillerlan\QRCode\Output\QROutputInterface::MARKUP_SVG,
            'eccLevel' => EccLevel::M,
            'outputBase64' => false,
            'svgAddXmlHeader' => false,
            'addQuietzone' => true,
        ]);

        $qrSvg = (new QRCode($options))->render($targetUrl);

        return view('admin.print-qr', [
            'profile' => $profile,
            'targetUrl' => $targetUrl,
            'showAppUrlWarning' => $showAppUrlWarning,
            'qrSvg' => $qrSvg,
        ]);
    }
}
