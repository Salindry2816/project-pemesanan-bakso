<?php

namespace App\Http\Middleware;

use App\Models\Customer;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Symfony\Component\HttpFoundation\Response;

class EnsureCustomerIdentified
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $customerId = $request->session()->get('customer_id');

        if (! $customerId) {
            return $this->unauthorizedResponse($request, 'Masukkan nomor handphone kamu untuk melanjutkan pemesanan di Bakso Solo.');
        }

        $customerExists = Customer::query()->whereKey($customerId)->exists();

        if (! $customerExists) {
            $request->session()->forget([
                'customer_id',
                'order_type',
                'table_id',
                'location_note',
                'cart',
                'order_note',
            ]);

            return $this->unauthorizedResponse($request, 'Sesi tidak valid. Silakan masukkan nomor handphone Anda kembali.');
        }

        return $next($request);
    }

    private function unauthorizedResponse(Request $request, string $message): Response
    {
        if ($request->expectsJson()) {
            return response()->json(['message' => $message], 401);
        }

        $targetUrl = Route::has('customer.phone') ? route('customer.phone') : url('/');

        return redirect()->to($targetUrl)->with('error', $message);
    }
}
