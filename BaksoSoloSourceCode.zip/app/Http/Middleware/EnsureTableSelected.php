<?php

namespace App\Http\Middleware;

use App\Enums\TableType;
use App\Models\Customer;
use App\Models\DiningTable;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Symfony\Component\HttpFoundation\Response;

class EnsureTableSelected
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        $customerId = $request->session()->get('customer_id');

        if (! $customerId || ! Customer::query()->whereKey($customerId)->exists()) {
            $request->session()->forget([
                'customer_id',
                'order_type',
                'table_id',
                'location_note',
                'cart',
                'order_note',
            ]);

            return $this->unauthorizedResponse($request, 'customer.phone', '/', 'Masukkan nomor handphone kamu untuk melanjutkan pemesanan di Bakso Solo.');
        }

        $orderType = $request->session()->get('order_type');

        if (! $orderType || ! in_array($orderType, ['dine_in', 'take_away'], true)) {
            return $this->unauthorizedResponse($request, 'customer.table', '/pilih-meja', 'Silakan pilih meja atau bungkus terlebih dahulu.');
        }

        if ($orderType === 'take_away') {
            return $next($request);
        }

        // Dine In verification
        $tableId = $request->session()->get('table_id');
        if (! $tableId) {
            return $this->unauthorizedResponse($request, 'customer.table', '/pilih-meja', 'Silakan pilih meja tempat kamu duduk.');
        }

        /** @var DiningTable|null $table */
        $table = DiningTable::query()->find($tableId);

        if (! $table || ! $table->is_active) {
            $request->session()->forget(['table_id', 'order_type', 'location_note']);

            return $this->unauthorizedResponse($request, 'customer.table', '/pilih-meja', 'Meja yang kamu pilih sedang tidak aktif. Silakan pilih meja lain.');
        }

        if ($table->type === TableType::Fixed && $table->isOccupied((int) $customerId)) {
            $request->session()->forget(['table_id', 'order_type', 'location_note']);

            return $this->unauthorizedResponse($request, 'customer.table', '/pilih-meja', "Meja {$table->code} sedang terisi pesanan lain. Silakan pilih meja yang masih tersedia.");
        }

        if ($table->type === TableType::Free) {
            $locationNote = trim((string) $request->session()->get('location_note'));
            $len = mb_strlen($locationNote);

            if ($len < 3 || $len > 100) {
                return $this->unauthorizedResponse($request, 'customer.table', '/pilih-meja', 'Silakan isi patokan lokasi duduk kamu di Meja Bebas (3–100 karakter).');
            }
        }

        return $next($request);
    }

    private function unauthorizedResponse(Request $request, string $routeName, string $fallbackUrl, string $message): Response
    {
        if ($request->expectsJson()) {
            return response()->json(['message' => $message], 403);
        }

        $targetUrl = Route::has($routeName) ? route($routeName) : url($fallbackUrl);

        return redirect()->to($targetUrl)->with('error', $message);
    }
}
