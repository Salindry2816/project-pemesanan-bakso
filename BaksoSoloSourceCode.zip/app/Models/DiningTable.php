<?php

namespace App\Models;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\TableType;
use Database\Factories\DiningTableFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable(['code', 'floor', 'type', 'capacity', 'is_active'])]
class DiningTable extends Model
{
    /** @use HasFactory<DiningTableFactory> */
    use HasFactory;

    protected $table = 'tables';

    protected function casts(): array
    {
        return [
            'floor' => 'integer',
            'type' => TableType::class,
            'capacity' => 'integer',
            'is_active' => 'boolean',
        ];
    }

    /**
     * @return HasMany<Order, $this>
     */
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class, 'table_id');
    }

    /**
     * Scope only coded (fixed) tables, ignoring free seating records.
     *
     * @param  Builder<self>  $query
     * @return Builder<self>
     */
    public function scopeCoded(Builder $query): Builder
    {
        return $query->where('type', TableType::Fixed);
    }

    /**
     * Scope only active tables.
     *
     * @param  Builder<self>  $query
     * @return Builder<self>
     */
    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    /**
     * Determine whether this table is currently occupied.
     * Free tables ("Meja Bebas") are never considered occupied (PRD section 7 & 11).
     */
    public function isOccupied(?int $exceptCustomerId = null, bool $lock = false): bool
    {
        if ($this->type === TableType::Free) {
            return false;
        }

        return $this->orders()
            ->where('type', OrderType::DineIn)
            ->whereIn('status', OrderStatus::activeValues())
            ->when($exceptCustomerId !== null, function (Builder $query) use ($exceptCustomerId): void {
                $query->where('customer_id', '!=', $exceptCustomerId);
            })
            ->when($lock, function (Builder $query): void {
                $query->lockForUpdate();
            })
            ->exists();
    }
}
