<?php

namespace App\Livewire\Customer;

use App\Models\Customer;
use App\Support\PhoneNumber;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Facades\Route;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.customer', ['title' => 'Masuk', 'showNav' => false])]
#[Title('Masuk – Pemesanan Bakso Solo')]
class PhoneEntry extends Component
{
    public string $phone = '';

    public function mount(): void
    {
        $customerId = session('customer_id');

        if ($customerId && Customer::query()->whereKey($customerId)->exists() && ! request()->has('ganti')) {
            $orderType = session('order_type');
            $tableId = session('table_id');
            $hasTable = $orderType === 'take_away' || ($orderType === 'dine_in' && $tableId);

            if ($hasTable) {
                $target = Route::has('customer.menu') ? route('customer.menu') : url('/menu');
                $this->redirect($target, navigate: false);

                return;
            }

            $target = Route::has('customer.table') ? route('customer.table') : url('/pilih-meja');
            $this->redirect($target, navigate: false);
        }
    }

    public function submit(): void
    {
        $this->resetErrorBag();

        $rawPhone = trim($this->phone);
        $normalizedCandidate = PhoneNumber::normalize($rawPhone);

        $ipFailKey = 'phone-entry:fail:ip:'.request()->ip();
        $phoneFailKey = 'phone-entry:fail:phone:'.($normalizedCandidate !== '' ? $normalizedCandidate : $rawPhone);
        $ipSuccessKey = 'phone-entry:success:ip:'.request()->ip();

        if (RateLimiter::tooManyAttempts($ipFailKey, 10)) {
            $seconds = RateLimiter::availableIn($ipFailKey);
            $this->addError('phone', "Terlalu banyak percobaan gagal dari perangkat ini. Silakan coba lagi dalam {$seconds} detik.");

            return;
        }

        if (RateLimiter::tooManyAttempts($phoneFailKey, 5)) {
            $seconds = RateLimiter::availableIn($phoneFailKey);
            $this->addError('phone', "Terlalu banyak percobaan untuk nomor ini. Silakan coba lagi dalam {$seconds} detik.");

            return;
        }

        if (RateLimiter::tooManyAttempts($ipSuccessKey, 120)) {
            $seconds = RateLimiter::availableIn($ipSuccessKey);
            $this->addError('phone', "Batas akses masuk tercapai untuk jaringan ini. Silakan coba lagi dalam {$seconds} detik.");

            return;
        }

        if ($rawPhone === '') {
            RateLimiter::hit($ipFailKey, 60);
            $this->addError('phone', 'Nomor handphone wajib diisi.');

            return;
        }

        if (! PhoneNumber::isValid($rawPhone)) {
            RateLimiter::hit($ipFailKey, 60);
            RateLimiter::hit($phoneFailKey, 60);
            $this->addError('phone', 'Format nomor handphone tidak valid. Gunakan nomor aktif Indonesia (contoh: 081234567890).');

            return;
        }

        $normalizedPhone = PhoneNumber::normalize($rawPhone);

        RateLimiter::hit($ipSuccessKey, 60);
        RateLimiter::clear($phoneFailKey);

        $customer = Customer::query()->firstOrCreate(
            ['phone' => $normalizedPhone]
        );

        $previousCustomerId = session('customer_id') ?? session('previous_customer_id');
        if ($previousCustomerId && (int) $previousCustomerId !== (int) $customer->id) {
            session()->forget(['cart', 'order_type', 'table_id', 'location_note', 'order_note']);
        }
        session()->forget('previous_customer_id');

        session()->regenerate();
        session()->put('customer_id', $customer->id);

        $orderType = session('order_type');
        $tableId = session('table_id');
        $hasTable = $orderType === 'take_away' || ($orderType === 'dine_in' && $tableId);

        if ($hasTable) {
            $target = Route::has('customer.menu') ? route('customer.menu') : url('/menu');
        } else {
            $target = Route::has('customer.table') ? route('customer.table') : url('/pilih-meja');
        }

        $this->redirect($target, navigate: false);
    }

    public function render(): View
    {
        try {
            $businessProfile = \App\Models\BusinessProfile::query()->find(1);
        } catch (\Throwable) {
            $businessProfile = null;
        }

        return view('livewire.customer.phone-entry', [
            'businessName' => $businessProfile?->name ?? 'Bakso Solo',
            'businessTagline' => $businessProfile?->tagline ?? 'Warung Bu Susi',
            'businessLogoUrl' => \App\Support\MediaStorage::url($businessProfile?->logo_path),
        ]);
    }
}
