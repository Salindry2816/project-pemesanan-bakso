<?php

namespace App\Livewire\Customer;

use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\MenuCategory;
use App\Services\CartService;
use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.customer', ['title' => 'Menu', 'activeNav' => 'menu'])]
#[Title('Menu – Bakso Solo')]
class MenuCatalog extends Component
{
    #[Locked]
    public ?int $selectedCategoryId = null;

    public ?string $errorMessage = null;

    public function selectCategory(?int $categoryId = null): void
    {
        $this->errorMessage = null;
        $this->selectedCategoryId = $categoryId;
    }

    public function addToCart(int $menuId, CartService $cart): void
    {
        $this->errorMessage = null;

        try {
            $cart->add($menuId, 1);
            $this->dispatch('cart-updated');
        } catch (\InvalidArgumentException $e) {
            $this->errorMessage = $e->getMessage();
        }
    }

    public function incrementQty(int $menuId, CartService $cart): void
    {
        $this->errorMessage = null;

        try {
            $cart->add($menuId, 1);
            $this->dispatch('cart-updated');
        } catch (\InvalidArgumentException $e) {
            $this->errorMessage = $e->getMessage();
        }
    }

    public function decrementQty(int $menuId, CartService $cart): void
    {
        $this->errorMessage = null;

        $lines = $cart->lines();
        $current = isset($lines[$menuId]) ? (int) $lines[$menuId]['qty'] : 0;

        try {
            if ($current <= 1) {
                $cart->remove($menuId);
            } else {
                $cart->setQuantity($menuId, $current - 1);
            }
            $this->dispatch('cart-updated');
        } catch (\InvalidArgumentException $e) {
            $this->errorMessage = $e->getMessage();
        }
    }

    public function render(CartService $cart): View
    {
        // 1. Categories with at least one menu (sorted by sort_order, name)
        $categories = MenuCategory::query()
            ->whereHas('menus')
            ->orderBy('sort_order')
            ->orderBy('name')
            ->get();

        // 2. Menus eager loaded with category (sorted by category.sort_order, menus.sort_order, menus.name)
        $menusQuery = Menu::query()
            ->select('menus.*')
            ->join('menu_categories', 'menus.category_id', '=', 'menu_categories.id')
            ->with('category')
            ->orderBy('menu_categories.sort_order')
            ->orderBy('menus.sort_order')
            ->orderBy('menus.name');

        if ($this->selectedCategoryId) {
            $menusQuery->where('menus.category_id', $this->selectedCategoryId);
        }

        $menus = $menusQuery->get();

        // 3. Cart lines and summary
        $cartLines = $cart->lines();
        $cartSummary = $cart->summary();
        $cartCount = $cart->count();

        // 4. Table badge info for header
        $orderType = session('order_type');
        $tableId = session('table_id');
        $tableBadge = null;

        if ($orderType === 'take_away') {
            $tableBadge = 'Bungkus';
        } elseif ($orderType === 'dine_in' && $tableId) {
            try {
                $tableModel = DiningTable::query()->find($tableId);
                $tableBadge = $tableModel ? ($tableModel->code === 'BEBAS' ? 'Meja Bebas' : 'Meja '.$tableModel->code) : null;
            } catch (\Throwable) {
                $tableBadge = null;
            }
        }

        return view('livewire.customer.menu-catalog', [
            'categories' => $categories,
            'menus' => $menus,
            'cartLines' => $cartLines,
            'cartSummary' => $cartSummary,
            'cartCount' => $cartCount,
            'tableBadge' => $tableBadge,
        ]);
    }
}
