<?php

namespace App\Livewire\Customer;

use App\Models\BusinessProfile;
use App\Support\MediaStorage;
use App\Support\PhoneNumber;
use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Component;

#[Layout('components.layouts.customer', ['title' => 'Profil', 'activeNav' => 'profil'])]
class Profile extends Component
{
    public function render(): View
    {
        /** @var BusinessProfile|null $profile */
        $profile = BusinessProfile::query()->find(1) ?? BusinessProfile::query()->first();

        $logoUrl = $profile && $profile->logo_path ? MediaStorage::url($profile->logo_path) : null;

        $normalizedWa = null;
        if ($profile && ! empty(trim((string) $profile->whatsapp))) {
            $normalizedWa = PhoneNumber::normalize($profile->whatsapp);
        }

        $businessName = $profile?->name ?? 'Bakso Solo';

        return view('livewire.customer.profile', [
            'profile' => $profile,
            'logoUrl' => $logoUrl,
            'normalizedWa' => $normalizedWa,
            'businessName' => $businessName,
        ])->title("Profil – {$businessName}");
    }
}
