<?php

namespace App\Livewire\Customer;

use App\Services\CartService;
use Illuminate\Contracts\View\View;
use Livewire\Attributes\On;
use Livewire\Component;

class CartBadge extends Component
{
    public string $position = 'desktop';

    #[On('cart-updated')]
    public function render(CartService $cart): View
    {
        return view('livewire.customer.cart-badge', [
            'count' => $cart->count(),
        ]);
    }
}
