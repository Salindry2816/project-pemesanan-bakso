<?php

namespace App\Livewire\Customer;

use App\Models\Order;
use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.customer', ['title' => 'Pesanan Saya', 'activeNav' => 'pesanan'])]
#[Title('Pesanan Saya – Bakso Solo')]
class OrderHistory extends Component
{
    public function render(): View
    {
        $customerId = (int) session('customer_id');

        $orders = $customerId > 0
            ? Order::query()
                ->where('customer_id', $customerId)
                ->with(['table', 'items'])
                ->latest('created_at')
                ->limit(20)
                ->get()
            : collect();

        return view('livewire.customer.order-history', [
            'orders' => $orders,
        ]);
    }
}
