<?php

namespace App\Livewire\Customer;

use App\Enums\OrderStatus;
use App\Exceptions\OrderCreationException;
use App\Models\BusinessProfile;
use App\Models\Order;
use App\Services\OrderService;
use App\Support\MediaStorage;
use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.customer', ['title' => 'Status Pesanan', 'activeNav' => 'pesanan'])]
#[Title('Status Pesanan – Bakso Solo')]
class OrderStatusDetail extends Component
{
    #[Locked]
    public string $orderNumber = '';

    public bool $showCancelDialog = false;

    public ?string $errorMessage = null;

    public ?string $statusMessage = null;

    public function mount(string $orderNumber): void
    {
        $this->orderNumber = $orderNumber;

        // Verify ownership immediately; identical 404 for non-existent or other customer's order
        $this->findOwnedOrder();
    }

    public function openCancelDialog(): void
    {
        $this->errorMessage = null;
        $this->statusMessage = null;

        $order = $this->findOwnedOrder();
        if ($order->status !== OrderStatus::Diterima) {
            $this->errorMessage = 'Pesanan tidak dapat dibatalkan karena sudah diproses atau diselesaikan.';

            return;
        }

        $this->showCancelDialog = true;
    }

    public function dismissCancelDialog(): void
    {
        $this->showCancelDialog = false;
    }

    public function cancelOrder(OrderService $orderService): void
    {
        $this->errorMessage = null;
        $this->statusMessage = null;

        try {
            $orderService->cancelOrderByCustomer((int) session('customer_id'), $this->orderNumber);
            $this->showCancelDialog = false;
            $this->statusMessage = 'Pesanan berhasil dibatalkan.';
        } catch (OrderCreationException $e) {
            $this->showCancelDialog = false;
            $this->errorMessage = $e->getMessage();
        }
    }

    protected function findOwnedOrder(): Order
    {
        $customerId = (int) session('customer_id');

        return Order::query()
            ->where('order_number', $this->orderNumber)
            ->where('customer_id', $customerId)
            ->with([
                'items:id,order_id,name_snapshot,price_snapshot,qty,item_note,line_total',
                'table:id,code,floor',
                'statusLogs' => fn ($query) => $query->select(['id', 'order_id', 'status', 'created_at'])->orderBy('created_at'),
            ])
            ->firstOrFail();
    }

    public function render(): View
    {
        $order = $this->findOwnedOrder();
        $qrisUrl = MediaStorage::url(BusinessProfile::query()->value('qris_image_path'));

        $steps = [
            OrderStatus::Diterima,
            OrderStatus::Diproses,
            OrderStatus::Disiapkan,
            OrderStatus::Siap,
        ];

        if ($order->status === OrderStatus::Selesai) {
            $steps[] = OrderStatus::Selesai;
        }

        $logsByStatus = [];
        foreach ($order->statusLogs as $log) {
            $key = $log->status->value;
            if (! isset($logsByStatus[$key])) {
                $logsByStatus[$key] = $log->created_at;
            }
        }

        $currentStepIndex = array_search($order->status, $steps, true);

        return view('livewire.customer.order-status-detail', [
            'order' => $order,
            'qrisUrl' => $qrisUrl,
            'steps' => $steps,
            'logsByStatus' => $logsByStatus,
            'currentStepIndex' => $currentStepIndex,
        ]);
    }
}
