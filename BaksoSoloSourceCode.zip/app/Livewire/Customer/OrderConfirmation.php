<?php

namespace App\Livewire\Customer;

use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\TableType;
use App\Exceptions\OrderCreationException;
use App\Models\BusinessProfile;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Services\CartService;
use App\Services\CartSummary;
use App\Services\OrderService;
use App\Support\MediaStorage;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Route;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.customer', ['title' => 'Konfirmasi Pesanan'])]
#[Title('Konfirmasi Pesanan – Bakso Solo')]
class OrderConfirmation extends Component
{
    public string $orderNote = '';

    public string $paymentMethod = 'cash';

    public ?string $errorMessage = null;

    public bool $showConfirmDialog = false;

    #[Locked]
    public string $checkoutToken = '';

    #[Locked]
    public ?int $tableId = null;

    #[Locked]
    public string $orderType = 'dine_in';

    #[Locked]
    public ?string $locationNote = null;

    protected ?DiningTable $cachedTable = null;

    protected ?Customer $cachedCustomer = null;

    public function mount(CartService $cartService): void
    {
        $this->orderType = (string) session('order_type', 'dine_in');
        $this->tableId = session('table_id');
        $this->locationNote = session('location_note');
        $this->orderNote = (string) session('order_note', '');
        $this->checkoutToken = OrderService::generateCheckoutToken();

        // 1. Guard against empty cart
        $summary = $cartService->summary();
        if (empty($summary->validLines)) {
            session()->flash('error', 'Keranjang belanja masih kosong. Silakan pilih menu terlebih dahulu.');
            $this->redirect(route('customer.menu'), navigate: false);

            return;
        }

        // 2. Guard against problem items in cart
        if ($summary->hasProblems) {
            session()->flash('error', 'Beberapa menu tidak tersedia, periksa keranjang.');
            $this->redirect(route('customer.cart'), navigate: false);

            return;
        }

        // 3. Guard against table becoming occupied or deactivated
        if ($this->tableId) {
            $table = $this->table;

            if (! $table || ! $table->is_active) {
                session()->forget(['table_id', 'order_type', 'location_note']);
                session()->flash('error', 'Meja yang kamu pilih sedang tidak aktif. Silakan pilih meja lain.');
                $this->redirect(route('customer.table'), navigate: false);

                return;
            }

            if ($table->type === TableType::Fixed && $table->isOccupied((int) session('customer_id'))) {
                session()->forget(['table_id', 'order_type', 'location_note']);
                session()->flash('error', "Meja {$table->code} sedang terisi pesanan lain. Silakan pilih meja yang masih tersedia.");
                $this->redirect(route('customer.table'), navigate: false);

                return;
            }
        }
    }

    public function updatedOrderNote(mixed $value): void
    {
        $this->saveOrderNote(app(CartService::class));
    }

    public function updatedPaymentMethod(string $value): void
    {
        $this->resetErrorBag('paymentMethod');
        $this->errorMessage = null;

        $method = PaymentMethod::tryFrom($value);
        if (! $method) {
            $this->paymentMethod = PaymentMethod::Cash->value;
            $this->addError('paymentMethod', 'Metode pembayaran tidak valid.');

            return;
        }

        if ($method === PaymentMethod::Qris && ! $this->isQrisAvailable()) {
            $this->paymentMethod = PaymentMethod::Cash->value;
            $this->addError('paymentMethod', 'Pembayaran QRIS belum tersedia karena kode QR belum diunggah.');
        }
    }

    public function isQrisAvailable(): bool
    {
        $qrisPath = BusinessProfile::query()->value('qris_image_path');

        return is_string($qrisPath) && trim($qrisPath) !== '';
    }

    public function saveOrderNote(CartService $cartService): void
    {
        // Re-check cart emptiness and problems
        $summary = $cartService->summary();
        if (empty($summary->validLines)) {
            session()->flash('error', 'Keranjang belanja masih kosong. Silakan pilih menu terlebih dahulu.');
            $this->redirect(route('customer.menu'), navigate: false);

            return;
        }

        if ($summary->hasProblems) {
            session()->flash('error', 'Beberapa menu tidak tersedia, periksa keranjang.');
            $this->redirect(route('customer.cart'), navigate: false);

            return;
        }

        $trimmed = trim($this->orderNote);

        if (mb_strlen($trimmed) > 200) {
            $this->addError('orderNote', 'Catatan pesanan maksimal 200 karakter.');

            return;
        }

        $this->resetErrorBag('orderNote');
        session(['order_note' => $trimmed === '' ? null : $trimmed]);
        $this->orderNote = $trimmed;
    }

    public function openConfirmDialog(CartService $cartService): void
    {
        $this->errorMessage = null;
        $this->resetErrorBag();

        $summary = $cartService->summary();
        if (empty($summary->validLines)) {
            session()->flash('error', 'Keranjang belanja masih kosong. Silakan pilih menu terlebih dahulu.');
            $this->redirect(route('customer.menu'), navigate: false);

            return;
        }

        if ($summary->hasProblems) {
            session()->flash('error', 'Beberapa menu tidak tersedia, periksa keranjang.');
            $this->redirect(route('customer.cart'), navigate: false);

            return;
        }

        $trimmedNote = trim($this->orderNote);
        if (mb_strlen($trimmedNote) > 200) {
            $this->addError('orderNote', 'Catatan pesanan maksimal 200 karakter.');

            return;
        }

        $method = PaymentMethod::tryFrom($this->paymentMethod);
        if (! $method) {
            $this->addError('paymentMethod', 'Metode pembayaran tidak valid.');

            return;
        }

        if ($method === PaymentMethod::Qris && ! $this->isQrisAvailable()) {
            $this->paymentMethod = PaymentMethod::Cash->value;
            $this->addError('paymentMethod', 'Pembayaran QRIS belum tersedia karena kode QR belum diunggah.');

            return;
        }

        $this->showConfirmDialog = true;
    }

    public function cancelConfirmDialog(): void
    {
        $this->showConfirmDialog = false;
    }

    public function placeOrder(CartService $cartService, OrderService $orderService): void
    {
        $this->errorMessage = null;
        $this->resetErrorBag();

        $summary = $cartService->summary();
        if (empty($summary->validLines)) {
            session()->flash('error', 'Keranjang belanja masih kosong. Silakan pilih menu terlebih dahulu.');
            $this->redirect(route('customer.menu'), navigate: false);

            return;
        }

        if ($summary->hasProblems) {
            session()->flash('error', 'Beberapa menu tidak tersedia, periksa keranjang.');
            $this->redirect(route('customer.cart'), navigate: false);

            return;
        }

        $trimmedNote = trim($this->orderNote);
        if (mb_strlen($trimmedNote) > 200) {
            $this->addError('orderNote', 'Catatan pesanan maksimal 200 karakter.');

            return;
        }

        $method = PaymentMethod::tryFrom($this->paymentMethod);
        if (! $method) {
            $this->addError('paymentMethod', 'Metode pembayaran tidak valid.');

            return;
        }

        $orderType = OrderType::tryFrom($this->orderType);
        if (! $orderType) {
            session()->flash('error', 'Jenis pesanan tidak valid. Silakan pilih meja kembali.');
            $this->redirect(route('customer.table'), navigate: false);

            return;
        }

        try {
            $order = $orderService->createOrder(
                customerId: (int) session('customer_id'),
                orderType: $orderType,
                tableId: $this->tableId,
                locationNote: $this->locationNote,
                orderNote: $trimmedNote === '' ? null : $trimmedNote,
                paymentMethod: $method,
                cartLines: $cartService->lines(),
                checkoutToken: $this->checkoutToken,
                rateLimitIp: request()->ip(),
            );
        } catch (OrderCreationException $e) {
            $this->showConfirmDialog = false;
            $this->errorMessage = $e->getMessage();

            return;
        }

        session()->forget('order_note');
        $this->dispatch('cart-updated');

        $this->redirect(
            route('customer.order.show', ['orderNumber' => $order->order_number]),
            navigate: false
        );
    }

    public function getTableProperty(): ?DiningTable
    {
        if ($this->tableId && $this->cachedTable === null) {
            $this->cachedTable = DiningTable::query()->find($this->tableId);
        }

        return $this->cachedTable;
    }

    public function getCustomerProperty(): ?Customer
    {
        $customerId = session('customer_id');
        if ($customerId && $this->cachedCustomer === null) {
            $this->cachedCustomer = Customer::query()->find($customerId);
        }

        return $this->cachedCustomer;
    }

    public function getMaskedPhoneProperty(): string
    {
        $customer = $this->customer;
        if (! $customer || ! $customer->phone) {
            return '';
        }

        $phone = (string) $customer->phone;
        if (str_starts_with($phone, '62')) {
            $phone = '0' . substr($phone, 2);
        }

        if (strlen($phone) <= 8) {
            return substr($phone, 0, 2) . '****' . substr($phone, -2);
        }

        return substr($phone, 0, 4) . '-****-' . substr($phone, -4);
    }

    public function render(CartService $cartService): View
    {
        $summary = $cartService->summary();
        $qrisUrl = MediaStorage::url(BusinessProfile::query()->value('qris_image_path'));

        return view('livewire.customer.order-confirmation', [
            'summary' => $summary,
            'table' => $this->table,
            'maskedPhone' => $this->maskedPhone,
            'qrisAvailable' => $qrisUrl !== null,
            'qrisUrl' => $qrisUrl,
        ]);
    }
}
