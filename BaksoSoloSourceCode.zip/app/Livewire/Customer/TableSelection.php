<?php

namespace App\Livewire\Customer;

use App\Enums\TableType;
use App\Models\Customer;
use App\Models\DiningTable;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Route;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.customer', ['title' => 'Pilih Meja'])]
#[Title('Pilih Meja – Bakso Solo')]
class TableSelection extends Component
{
    public string $orderType = 'dine_in'; // 'dine_in' | 'take_away'

    #[Locked]
    public ?int $selectedTableId = null;

    public string $locationNote = '';

    public int $selectedFloor = 2;

    public bool $showFloorMap = false;

    public function mount(): void
    {
        $customerId = session('customer_id');
        if (! $customerId || ! Customer::query()->whereKey($customerId)->exists()) {
            $target = Route::has('customer.phone') ? route('customer.phone') : url('/');
            session()->flash('error', 'Masukkan nomor handphone kamu untuk melanjutkan pemesanan di Bakso Solo.');
            $this->redirect($target, navigate: false);

            return;
        }

        $this->orderType = (string) session('order_type', 'dine_in');
        $this->selectedTableId = session('table_id');
        $this->locationNote = (string) session('location_note', '');

        // If customer previously selected a table, sync the floor tab
        if ($this->selectedTableId) {
            $table = DiningTable::query()->find($this->selectedTableId);
            if ($table && $table->floor) {
                $this->selectedFloor = $table->floor;
            }
        }
    }

    public function selectFloor(int $floor): void
    {
        $this->resetErrorBag();
        $this->selectedFloor = $floor;
    }

    public function selectTable(int $tableId): void
    {
        $this->resetErrorBag();

        /** @var DiningTable|null $table */
        $table = DiningTable::query()->find($tableId);

        if (! $table || ! $table->is_active) {
            $this->addError('table', 'Meja ini sedang tidak aktif. Silakan pilih meja lain.');

            return;
        }

        $customerId = (int) session('customer_id') ?: null;

        if ($table->type === TableType::Fixed && $table->isOccupied($customerId)) {
            $this->addError('table', "Meja {$table->code} sedang terisi. Silakan pilih meja yang masih tersedia.");

            return;
        }

        $this->orderType = 'dine_in';
        $this->selectedTableId = $table->id;

        if ($table->type === TableType::Fixed) {
            $this->locationNote = '';
        }
    }

    public function selectTakeAway(): void
    {
        $this->resetErrorBag();
        $this->orderType = 'take_away';
        $this->selectedTableId = null;
        $this->locationNote = '';
    }

    public function toggleFloorMap(): void
    {
        $this->showFloorMap = ! $this->showFloorMap;
    }

    public function closeFloorMap(): void
    {
        $this->showFloorMap = false;
    }

    public function submit(): void
    {
        $this->resetErrorBag();

        if ($this->orderType === 'take_away') {
            session([
                'order_type' => 'take_away',
                'table_id' => null,
                'location_note' => null,
            ]);

            $target = Route::has('customer.menu') ? route('customer.menu') : url('/menu');
            $this->redirect($target, navigate: false);

            return;
        }

        if (! $this->selectedTableId) {
            $this->addError('table', 'Silakan pilih nomor meja tempat kamu duduk.');

            return;
        }

        /** @var DiningTable|null $table */
        $table = DiningTable::query()->find($this->selectedTableId);

        if (! $table || ! $table->is_active) {
            $this->addError('table', 'Meja yang kamu pilih sedang tidak aktif.');

            return;
        }

        $customerId = (int) session('customer_id') ?: null;

        if ($table->type === TableType::Fixed) {
            if ($table->isOccupied($customerId)) {
                $this->addError('table', "Meja {$table->code} sedang terisi. Silakan pilih meja yang masih tersedia.");

                return;
            }

            session([
                'order_type' => 'dine_in',
                'table_id' => $table->id,
                'location_note' => null,
            ]);
        } else {
            // Free table ("Meja Bebas")
            $this->locationNote = trim($this->locationNote);

            $this->validate(
                [
                    'locationNote' => ['required', 'string', 'min:3', 'max:100'],
                ],
                [
                    'locationNote.required' => 'Patokan lokasi duduk wajib diisi untuk Meja Bebas.',
                    'locationNote.min' => 'Patokan lokasi duduk minimal 3 karakter.',
                    'locationNote.max' => 'Patokan lokasi duduk maksimal 100 karakter.',
                ]
            );

            session([
                'order_type' => 'dine_in',
                'table_id' => $table->id,
                'location_note' => $this->locationNote,
            ]);
        }

        $target = Route::has('customer.menu') ? route('customer.menu') : url('/menu');
        $this->redirect($target, navigate: false);
    }

    public function render(): View
    {
        // 1. Only floors with active coded tables
        $availableFloors = DiningTable::query()
            ->coded()
            ->active()
            ->select('floor')
            ->distinct()
            ->orderBy('floor')
            ->pluck('floor')
            ->all();

        if (! in_array($this->selectedFloor, $availableFloors, true) && ! empty($availableFloors)) {
            $this->selectedFloor = $availableFloors[0];
        }

        // 2. Active coded tables for current selected floor
        $tables = DiningTable::query()
            ->coded()
            ->active()
            ->where('floor', $this->selectedFloor)
            ->orderBy('code')
            ->get();

        // 3. Free table record
        $freeTable = DiningTable::query()
            ->where('type', TableType::Free)
            ->active()
            ->first();

        // 4. Floor 2 tables for map modal
        $floor2Tables = DiningTable::query()
            ->coded()
            ->active()
            ->where('floor', 2)
            ->orderBy('code')
            ->get();

        return view('livewire.customer.table-selection', [
            'availableFloors' => $availableFloors,
            'tables' => $tables,
            'freeTable' => $freeTable,
            'floor2Tables' => $floor2Tables,
            'currentCustomerId' => (int) session('customer_id') ?: null,
        ]);
    }
}
