<?php

namespace App\Livewire\Customer;

use App\Enums\TableType;
use App\Models\DiningTable;
use App\Services\CartService;
use App\Services\CartSummary;
use Illuminate\Contracts\View\View;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.customer', ['title' => 'Keranjang Pesanan'])]
#[Title('Keranjang Pesanan – Bakso Solo')]
class CartViewer extends Component
{
    /**
     * Item notes keyed by menu_id.
     *
     * @var array<int, string>
     */
    public array $notes = [];

    public ?string $errorMessage = null;

    public ?string $successMessage = null;

    public function mount(CartService $cartService): void
    {
        $this->syncNotesFromCart($cartService);
    }

    /**
     * Catch Livewire updates on $notes array (e.g. notes.5).
     */
    public function updatedNotes(mixed $value, string|int $key): void
    {
        $menuId = (int) $key;
        $this->saveNote($menuId);
    }

    public function incrementQty(int $menuId, ?CartService $cartService = null): void
    {
        $cartService ??= app(CartService::class);
        $cart = $cartService->lines();

        if ($menuId <= 0 || ! isset($cart[$menuId])) {
            $this->errorMessage = 'Menu tidak ada di dalam keranjang.';

            return;
        }

        $currentQty = (int) $cart[$menuId]['qty'];
        if ($currentQty >= CartService::MAX_QTY_PER_ITEM) {
            $this->errorMessage = 'Jumlah pesanan untuk menu ini maksimal 20 porsi.';

            return;
        }

        $this->errorMessage = null;
        $cartService->setQuantity($menuId, $currentQty + 1);
        $this->dispatch('cart-updated');
    }

    public function decrementQty(int $menuId, ?CartService $cartService = null): void
    {
        $cartService ??= app(CartService::class);
        $cart = $cartService->lines();

        if ($menuId <= 0 || ! isset($cart[$menuId])) {
            $this->errorMessage = 'Menu tidak ada di dalam keranjang.';

            return;
        }

        $currentQty = (int) $cart[$menuId]['qty'];
        if ($currentQty <= 1) {
            // Keep at 1. To remove, the customer clicks the "Hapus" button.
            return;
        }

        $this->errorMessage = null;
        $cartService->setQuantity($menuId, $currentQty - 1);
        $this->dispatch('cart-updated');
    }

    public function updateQty(int $menuId, int $qty, ?CartService $cartService = null): void
    {
        $cartService ??= app(CartService::class);
        $cart = $cartService->lines();

        if ($menuId <= 0 || ! isset($cart[$menuId])) {
            $this->errorMessage = 'Menu tidak ada di dalam keranjang.';

            return;
        }

        if ($qty <= 0) {
            $this->removeItem($menuId, $cartService);

            return;
        }

        if ($qty > CartService::MAX_QTY_PER_ITEM) {
            $this->errorMessage = 'Jumlah pesanan untuk menu ini maksimal 20 porsi.';

            return;
        }

        $this->errorMessage = null;
        $cartService->setQuantity($menuId, $qty);
        $this->dispatch('cart-updated');
    }

    public function removeItem(int $menuId, ?CartService $cartService = null): void
    {
        $cartService ??= app(CartService::class);
        $cart = $cartService->lines();

        if ($menuId <= 0 || ! isset($cart[$menuId])) {
            $this->errorMessage = 'Menu tidak ada di dalam keranjang.';

            return;
        }

        $this->errorMessage = null;
        $cartService->remove($menuId);
        unset($this->notes[$menuId]);
        $this->resetErrorBag("notes.{$menuId}");
        $this->dispatch('cart-updated');
    }

    public function saveNote(int $menuId, ?CartService $cartService = null): void
    {
        $cartService ??= app(CartService::class);
        $cart = $cartService->lines();

        if ($menuId <= 0 || ! isset($cart[$menuId])) {
            $this->errorMessage = 'Menu tidak ada di dalam keranjang.';

            return;
        }

        $rawNote = $this->notes[$menuId] ?? '';
        $trimmed = is_string($rawNote) ? trim($rawNote) : '';

        if (mb_strlen($trimmed) > CartService::MAX_NOTE_LENGTH) {
            $this->addError("notes.{$menuId}", 'Catatan maksimal 100 karakter.');

            return;
        }

        $this->resetErrorBag("notes.{$menuId}");

        try {
            $cartService->setItemNote($menuId, $trimmed === '' ? null : $trimmed);
            $this->dispatch('cart-updated');
        } catch (\InvalidArgumentException $e) {
            $this->addError("notes.{$menuId}", $e->getMessage());
        }
    }

    public function removeUnavailable(?CartService $cartService = null): void
    {
        $cartService ??= app(CartService::class);
        $cartService->removeUnavailable();
        $this->errorMessage = null;

        // Clean up notes array
        $currentMenuIds = array_keys($cartService->lines());
        foreach (array_keys($this->notes) as $id) {
            if (! in_array($id, $currentMenuIds, true)) {
                unset($this->notes[$id]);
                $this->resetErrorBag("notes.{$id}");
            }
        }

        $this->dispatch('cart-updated');
    }

    public function render(CartService $cartService): View
    {
        $summary = $cartService->summary();

        // Keep local notes array in sync with items in cart
        $this->syncNotesFromCart($cartService);

        // Fetch table info
        $orderType = (string) session('order_type', 'dine_in');
        $tableId = session('table_id');
        $locationNote = session('location_note');

        $table = null;
        if ($tableId) {
            $table = DiningTable::query()->find($tableId);
        }

        return view('livewire.customer.cart-viewer', [
            'summary' => $summary,
            'orderType' => $orderType,
            'table' => $table,
            'locationNote' => $locationNote,
        ]);
    }

    protected function syncNotesFromCart(CartService $cartService): void
    {
        $lines = $cartService->lines();
        foreach ($lines as $menuId => $line) {
            if (! array_key_exists($menuId, $this->notes)) {
                $this->notes[$menuId] = (string) ($line['item_note'] ?? '');
            }
        }
    }
}
