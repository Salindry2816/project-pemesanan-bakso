<?php

namespace App\Livewire\Admin;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\TableType;
use App\Models\DiningTable;
use App\Support\TableCode;
use Illuminate\Contracts\View\View;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.admin')]
#[Title('Kelola Meja')]
class TableManager extends Component
{
    public const FREE_TABLE_CODE = 'BEBAS';

    public string $selectedFloor = '2';

    public string $capacity = '4';

    #[Locked]
    public ?int $deletingId = null;

    public string $deletingCode = '';

    public ?string $statusMessage = null;

    public ?string $errorMessage = null;

    public function createTable(): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        $this->selectedFloor = trim($this->selectedFloor);
        $this->capacity = trim($this->capacity);

        $this->validate(
            [
                'selectedFloor' => ['required', 'integer', 'in:1,2,3,4'],
                'capacity' => ['nullable', 'regex:/^-?\d+$/'],
            ],
            [
                'selectedFloor.required' => 'Lantai meja wajib dipilih.',
                'selectedFloor.integer' => 'Lantai meja tidak valid.',
                'selectedFloor.in' => 'Lantai hanya tersedia untuk lantai 1 sampai 4.',
                'capacity.regex' => 'Kapasitas meja harus berupa angka bulat antara 1 sampai 50.',
            ]
        );

        $capacityInt = null;
        if ($this->capacity !== '') {
            $capacityInt = (int) $this->capacity;
            if ($capacityInt < 1 || $capacityInt > 50) {
                throw ValidationException::withMessages([
                    'capacity' => 'Kapasitas meja harus berupa angka bulat antara 1 sampai 50.',
                ]);
            }
        }

        $floorInt = (int) $this->selectedFloor;

        try {
            $createdTable = DB::transaction(function () use ($floorInt, $capacityInt): ?DiningTable {
                $existingCodes = DiningTable::query()
                    ->where('floor', $floorInt)
                    ->lockForUpdate()
                    ->pluck('code')
                    ->all();

                try {
                    $nextCode = TableCode::nextForFloor($floorInt, $existingCodes);
                } catch (\InvalidArgumentException) {
                    $this->errorMessage = "Semua kode meja untuk Lantai {$floorInt} ({$floorInt}A-{$floorInt}Z) sudah penuh.";

                    return null;
                }

                return DiningTable::query()->create([
                    'code' => $nextCode,
                    'floor' => $floorInt,
                    'type' => TableType::Fixed,
                    'capacity' => $capacityInt,
                    'is_active' => true,
                ]);
            });
        } catch (QueryException) {
            $this->errorMessage = 'Kode meja baru sedang dibuat bersamaan oleh proses lain. Silakan coba lagi.';

            return;
        }

        if ($createdTable !== null) {
            $this->statusMessage = "Meja {$createdTable->code} (Lantai {$createdTable->floor}) berhasil ditambahkan.";
        }
    }

    public function toggleActive(int $tableId): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        DB::transaction(function () use ($tableId): void {
            $table = DiningTable::query()->lockForUpdate()->find($tableId);
            if ($table === null) {
                return;
            }

            if ($this->isFreeTable($table)) {
                $this->errorMessage = 'Meja Bebas bersifat permanen dan tidak dapat dinonaktifkan.';

                return;
            }

            if ($table->is_active && $table->isOccupied()) {
                $this->errorMessage = "Meja {$table->code} tidak dapat dinonaktifkan karena sedang memiliki pesanan aktif.";

                return;
            }

            $table->update([
                'is_active' => ! $table->is_active,
            ]);

            $this->statusMessage = $table->is_active
                ? "Meja {$table->code} diaktifkan."
                : "Meja {$table->code} dinonaktifkan.";
        });
    }

    public function confirmDelete(int $tableId): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        $table = DiningTable::query()->findOrFail($tableId);

        if ($this->isFreeTable($table)) {
            $this->errorMessage = 'Meja Bebas bersifat permanen dan tidak dapat dihapus.';

            return;
        }

        if ($table->orders()->exists()) {
            $this->errorMessage = "Meja {$table->code} tidak dapat dihapus karena sudah memiliki riwayat pesanan. Gunakan fitur nonaktifkan meja.";

            return;
        }

        $this->deletingId = $table->id;
        $this->deletingCode = $table->code;
    }

    public function cancelDelete(): void
    {
        $this->reset(['deletingId', 'deletingCode']);
    }

    public function deleteTable(?int $tableId = null): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        $targetId = $tableId ?? $this->deletingId;
        if ($targetId === null) {
            return;
        }

        DB::transaction(function () use ($targetId): void {
            $table = DiningTable::query()->lockForUpdate()->find($targetId);

            if ($table === null) {
                return;
            }

            if ($this->isFreeTable($table)) {
                $this->errorMessage = 'Meja Bebas bersifat permanen dan tidak dapat dihapus.';

                return;
            }

            if ($table->orders()->exists()) {
                $this->errorMessage = "Meja {$table->code} tidak dapat dihapus karena sudah memiliki riwayat pesanan. Gunakan fitur nonaktifkan meja.";

                return;
            }

            $code = $table->code;
            $table->delete();
            $this->statusMessage = "Meja {$code} berhasil dihapus.";
        });

        $this->cancelDelete();
    }

    private function isFreeTable(DiningTable $table): bool
    {
        return $table->type === TableType::Free
            || strtoupper($table->code) === self::FREE_TABLE_CODE;
    }

    private function resetFeedback(): void
    {
        $this->statusMessage = null;
        $this->errorMessage = null;
    }

    private function ensureAuthenticated(): void
    {
        abort_unless(Auth::check(), 403);
    }

    public function render(): View
    {
        $freeTable = DiningTable::query()
            ->where('type', TableType::Free)
            ->orWhere('code', self::FREE_TABLE_CODE)
            ->first();

        $codedTables = DiningTable::query()
            ->coded()
            ->withCount('orders')
            ->withExists([
                'orders as is_currently_occupied' => fn ($query) => $query
                    ->where('type', OrderType::DineIn)
                    ->whereIn('status', OrderStatus::activeValues()),
            ])
            ->orderBy('floor')
            ->orderBy('code')
            ->get();

        $selectedFloorInt = (int) $this->selectedFloor;
        if ($selectedFloorInt < TableCode::MIN_FLOOR || $selectedFloorInt > TableCode::MAX_FLOOR) {
            $selectedFloorInt = 2;
        }

        $existingCodesForFloor = $codedTables
            ->where('floor', $selectedFloorInt)
            ->pluck('code')
            ->all();

        try {
            $nextCodePreview = TableCode::nextForFloor($selectedFloorInt, $existingCodesForFloor);
        } catch (\InvalidArgumentException) {
            $nextCodePreview = null;
        }

        return view('livewire.admin.table-manager', [
            'freeTable' => $freeTable,
            'tablesByFloor' => $codedTables->groupBy('floor'),
            'nextCodePreview' => $nextCodePreview,
        ]);
    }
}
