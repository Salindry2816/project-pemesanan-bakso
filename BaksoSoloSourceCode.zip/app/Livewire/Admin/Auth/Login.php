<?php

namespace App\Livewire\Admin\Auth;

use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.guest-admin')]
#[Title('Login Admin')]
class Login extends Component
{
    public string $username = '';

    public string $password = '';

    public function authenticate(): void
    {
        $this->validate(
            [
                'username' => ['required', 'string'],
                'password' => ['required', 'string'],
            ],
            [
                'username.required' => 'Username wajib diisi.',
                'password.required' => 'Password wajib diisi.',
            ]
        );

        $throttleKey = $this->throttleKey();

        if (RateLimiter::tooManyAttempts($throttleKey, 5)) {
            $seconds = RateLimiter::availableIn($throttleKey);

            throw ValidationException::withMessages([
                'username' => "Terlalu banyak percobaan masuk. Silakan coba lagi dalam {$seconds} detik.",
            ]);
        }

        if (! Auth::attempt(['username' => $this->username, 'password' => $this->password])) {
            RateLimiter::hit($throttleKey, 60);
            $this->reset('password');

            throw ValidationException::withMessages([
                'username' => 'Username atau password yang Anda masukkan salah.',
            ]);
        }

        RateLimiter::clear($throttleKey);

        session()->regenerate();

        $this->redirectIntended(default: route('admin.dashboard'), navigate: false);
    }

    protected function throttleKey(): string
    {
        return Str::transliterate(Str::lower(trim($this->username)).'|'.request()->ip());
    }

    public function render(): View
    {
        return view('livewire.admin.auth.login');
    }
}
