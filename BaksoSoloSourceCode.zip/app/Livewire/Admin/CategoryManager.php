<?php

namespace App\Livewire\Admin;

use App\Models\MenuCategory;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.admin')]
#[Title('Kelola Kategori')]
class CategoryManager extends Component
{
    public string $newName = '';

    public ?int $editingId = null;

    public string $editingName = '';

    public ?int $deletingId = null;

    public string $deletingName = '';

    public ?string $statusMessage = null;

    public ?string $errorMessage = null;

    public function createCategory(): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        $this->newName = $this->normalizeName($this->newName);
        $this->validateCategoryName($this->newName, 'newName');

        DB::transaction(function (): void {
            $maxOrder = (int) MenuCategory::query()->lockForUpdate()->max('sort_order');

            MenuCategory::query()->create([
                'name' => $this->newName,
                'sort_order' => $maxOrder + 1,
            ]);
        });

        $this->reset('newName');
        $this->statusMessage = 'Kategori berhasil ditambahkan.';
    }

    public function startEdit(int $categoryId): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();
        $this->resetValidation();

        $category = MenuCategory::query()->findOrFail($categoryId);
        $this->editingId = $category->id;
        $this->editingName = $category->name;
    }

    public function cancelEdit(): void
    {
        $this->reset(['editingId', 'editingName']);
        $this->resetValidation();
    }

    public function updateCategory(): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        if ($this->editingId === null) {
            return;
        }

        $category = MenuCategory::query()->findOrFail($this->editingId);
        $this->editingName = $this->normalizeName($this->editingName);
        $this->validateCategoryName($this->editingName, 'editingName', $category->id);

        $category->update([
            'name' => $this->editingName,
        ]);

        $this->reset(['editingId', 'editingName']);
        $this->statusMessage = 'Nama kategori berhasil diperbarui.';
    }

    public function moveUp(int $categoryId): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();
        $this->swapCategoryOrder($categoryId, -1);
    }

    public function moveDown(int $categoryId): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();
        $this->swapCategoryOrder($categoryId, 1);
    }

    public function confirmDelete(int $categoryId): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        $category = MenuCategory::query()->findOrFail($categoryId);
        $this->deletingId = $category->id;
        $this->deletingName = $category->name;
    }

    public function cancelDelete(): void
    {
        $this->reset(['deletingId', 'deletingName']);
    }

    public function deleteCategory(?int $categoryId = null): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        $targetId = $categoryId ?? $this->deletingId;
        if ($targetId === null) {
            return;
        }

        $deleted = DB::transaction(function () use ($targetId): bool {
            $category = MenuCategory::query()->lockForUpdate()->find($targetId);

            if ($category === null) {
                return false;
            }

            if ($category->menus()->exists()) {
                $this->errorMessage = 'Kategori tidak dapat dihapus karena masih memiliki menu. Pindahkan atau hapus menu terlebih dahulu.';

                return false;
            }

            $category->delete();

            return true;
        });

        $this->cancelDelete();

        if ($deleted) {
            if ($this->editingId === $targetId) {
                $this->cancelEdit();
            }

            $this->statusMessage = 'Kategori berhasil dihapus.';
        }
    }

    private function swapCategoryOrder(int $categoryId, int $offset): void
    {
        DB::transaction(function () use ($categoryId, $offset): void {
            $categories = MenuCategory::query()
                ->orderBy('sort_order')
                ->orderBy('id')
                ->lockForUpdate()
                ->get()
                ->values();

            $currentIndex = $categories->search(fn (MenuCategory $cat): bool => $cat->id === $categoryId);
            if ($currentIndex === false) {
                return;
            }

            $targetIndex = $currentIndex + $offset;
            if ($targetIndex < 0 || $targetIndex >= $categories->count()) {
                return;
            }

            $orderedIds = $categories->pluck('id')->all();
            [$orderedIds[$currentIndex], $orderedIds[$targetIndex]] = [$orderedIds[$targetIndex], $orderedIds[$currentIndex]];

            foreach ($orderedIds as $index => $id) {
                MenuCategory::query()
                    ->whereKey($id)
                    ->update(['sort_order' => $index + 1]);
            }
        });
    }

    private function validateCategoryName(string $name, string $field, ?int $ignoreId = null): void
    {
        $this->validate(
            [
                $field => ['required', 'string', 'max:50'],
            ],
            [
                "{$field}.required" => 'Nama kategori wajib diisi.',
                "{$field}.string" => 'Nama kategori harus berupa teks.',
                "{$field}.max" => 'Nama kategori maksimal 50 karakter.',
            ]
        );

        $exists = MenuCategory::query()
            ->whereRaw('LOWER(name) = ?', [mb_strtolower($name)])
            ->when($ignoreId !== null, fn ($query) => $query->whereKeyNot($ignoreId))
            ->exists();

        if ($exists) {
            throw ValidationException::withMessages([
                $field => 'Nama kategori sudah digunakan.',
            ]);
        }
    }

    private function normalizeName(string $value): string
    {
        return trim(preg_replace('/\s+/u', ' ', $value) ?? '');
    }

    private function resetFeedback(): void
    {
        $this->statusMessage = null;
        $this->errorMessage = null;
    }

    private function ensureAuthenticated(): void
    {
        abort_unless(Auth::check(), 403);
    }

    public function render(): View
    {
        $categories = MenuCategory::query()
            ->withCount('menus')
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        return view('livewire.admin.category-manager', [
            'categories' => $categories,
        ]);
    }
}
