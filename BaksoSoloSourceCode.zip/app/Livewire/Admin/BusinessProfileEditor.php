<?php

namespace App\Livewire\Admin;

use App\Models\BusinessProfile;
use App\Support\MediaStorage;
use App\Support\PhoneNumber;
use Illuminate\Contracts\View\View;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithFileUploads;

#[Layout('components.layouts.admin')]
#[Title('Profil Usaha')]
class BusinessProfileEditor extends Component
{
    use WithFileUploads;

    #[Locked]
    public ?int $profileId = null;

    #[Locked]
    public ?string $existingLogoPath = null;

    #[Locked]
    public ?string $existingQrisPath = null;

    public string $name = '';

    public string $tagline = '';

    public string $description = '';

    public string $location = '';

    public string $phone = '';

    public string $whatsapp = '';

    public string $open_time = '08.00';

    public string $close_time = '17.00';

    public mixed $logo = null;

    public mixed $qris = null;

    public ?string $logoUploadError = null;

    public ?string $qrisUploadError = null;

    public ?string $statusMessage = null;

    public ?string $errorMessage = null;

    public ?string $profileMissingError = null;

    public function mount(): void
    {
        $this->loadProfile();
    }

    public function updatedLogo(): void
    {
        $this->logoUploadError = null;
        $this->resetErrorBag('logo');
        if ($this->logo instanceof UploadedFile) {
            try {
                MediaStorage::validateUploadedFile($this->logo, 'logo');
            } catch (ValidationException $e) {
                $this->logo = null;
                $this->logoUploadError = $e->errors()['logo'][0] ?? 'File logo tidak valid.';

                throw $e;
            }
        }
    }

    public function updatedQris(): void
    {
        $this->qrisUploadError = null;
        $this->resetErrorBag('qris');
        if ($this->qris instanceof UploadedFile) {
            try {
                MediaStorage::validateUploadedFile($this->qris, 'qris');
            } catch (ValidationException $e) {
                $this->qris = null;
                $this->qrisUploadError = $e->errors()['qris'][0] ?? 'File QRIS tidak valid.';

                throw $e;
            }
        }
    }

    public function _uploadErrored($name, $errorsInJson, $isMultiple): void
    {
        $this->dispatch('upload:errored', name: $name)->self();

        $message = 'File yang diunggah harus berupa gambar berformat JPG, PNG, atau WebP dengan ukuran maksimal 2 MB.';

        if ($name === 'logo') {
            $this->logoUploadError = $message;
        } elseif ($name === 'qris') {
            $this->qrisUploadError = $message;
        }

        throw ValidationException::withMessages([$name => $message]);
    }

    public function removeLogo(): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();
        $this->logoUploadError = null;

        $profile = BusinessProfile::query()->find(1);
        if (! $profile) {
            $this->profileMissingError = 'Profil usaha belum dibuat. Jalankan seeder awal.';

            return;
        }

        if ($this->existingLogoPath !== null) {
            MediaStorage::delete($this->existingLogoPath);
            $profile->update(['logo_path' => null]);
            $this->existingLogoPath = null;
        }

        $this->logo = null;
        $this->resetErrorBag('logo');
        $this->statusMessage = 'Logo warung berhasil dihapus.';
    }

    public function removeQris(): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();
        $this->qrisUploadError = null;

        $profile = BusinessProfile::query()->find(1);
        if (! $profile) {
            $this->profileMissingError = 'Profil usaha belum dibuat. Jalankan seeder awal.';

            return;
        }

        if ($this->existingQrisPath !== null) {
            MediaStorage::delete($this->existingQrisPath);
            $profile->update(['qris_image_path' => null]);
            $this->existingQrisPath = null;
        }

        $this->qris = null;
        $this->resetErrorBag('qris');
        $this->statusMessage = 'Gambar QRIS berhasil dihapus.';
    }

    public function saveProfile(): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        if ($this->logoUploadError !== null) {
            throw ValidationException::withMessages([
                'logo' => $this->logoUploadError,
            ]);
        }

        if ($this->qrisUploadError !== null) {
            throw ValidationException::withMessages([
                'qris' => $this->qrisUploadError,
            ]);
        }

        $profile = BusinessProfile::query()->find(1);
        if (! $profile) {
            $this->profileMissingError = 'Profil usaha belum dibuat. Jalankan seeder awal.';

            return;
        }

        $this->name = trim(preg_replace('/\s+/u', ' ', $this->name) ?? '');
        $this->tagline = trim(preg_replace('/\s+/u', ' ', $this->tagline) ?? '');
        $this->description = trim($this->description);
        $this->location = trim(preg_replace('/\s+/u', ' ', $this->location) ?? '');
        $this->phone = trim($this->phone);
        $this->whatsapp = trim($this->whatsapp);

        $this->open_time = str_replace(':', '.', trim($this->open_time));
        $this->close_time = str_replace(':', '.', trim($this->close_time));

        $this->validate(
            [
                'name' => ['required', 'string', 'max:100'],
                'tagline' => ['nullable', 'string', 'max:100'],
                'description' => ['nullable', 'string', 'max:1000'],
                'location' => ['nullable', 'string', 'max:255'],
                'open_time' => ['required', 'regex:/^(?:[01]\d|2[0-3])\.[0-5]\d$/'],
                'close_time' => ['required', 'regex:/^(?:[01]\d|2[0-3])\.[0-5]\d$/'],
            ],
            [
                'name.required' => 'Nama warung wajib diisi.',
                'name.max' => 'Nama warung maksimal 100 karakter.',
                'tagline.max' => 'Tagline warung maksimal 100 karakter.',
                'description.max' => 'Deskripsi warung maksimal 1000 karakter.',
                'location.max' => 'Lokasi warung maksimal 255 karakter.',
                'open_time.required' => 'Jam buka wajib diisi.',
                'open_time.regex' => 'Format jam buka tidak valid (gunakan format HH.MM contoh: 08.00).',
                'close_time.required' => 'Jam tutup wajib diisi.',
                'close_time.regex' => 'Format jam tutup tidak valid (gunakan format HH.MM contoh: 17.00).',
            ]
        );

        if ($this->open_time === $this->close_time) {
            throw ValidationException::withMessages([
                'close_time' => 'Jam buka dan jam tutup tidak boleh sama.',
            ]);
        }

        $normalizedPhone = null;
        if ($this->phone !== '') {
            try {
                $normalizedPhone = PhoneNumber::normalizeOrFail($this->phone, 'phone');
                $this->phone = $normalizedPhone;
            } catch (ValidationException $e) {
                throw $e;
            }
        }

        $normalizedWhatsapp = null;
        if ($this->whatsapp !== '') {
            try {
                $normalizedWhatsapp = PhoneNumber::normalizeOrFail($this->whatsapp, 'whatsapp');
                $this->whatsapp = $normalizedWhatsapp;
            } catch (ValidationException) {
                throw ValidationException::withMessages([
                    'whatsapp' => 'Format nomor WhatsApp tidak valid. Gunakan nomor aktif Indonesia (contoh: 081234567890).',
                ]);
            }
        }

        if ($this->logo instanceof UploadedFile) {
            MediaStorage::validateUploadedFile($this->logo, 'logo');
        }

        if ($this->qris instanceof UploadedFile) {
            MediaStorage::validateUploadedFile($this->qris, 'qris');
        }

        $newLogoPath = $this->existingLogoPath;
        if ($this->logo instanceof UploadedFile) {
            $newLogoPath = MediaStorage::storeImage(
                file: $this->logo,
                directory: 'profile',
                oldPath: $this->existingLogoPath,
                maxDimension: 800,
                errorField: 'logo',
            );
        }

        $newQrisPath = $this->existingQrisPath;
        if ($this->qris instanceof UploadedFile) {
            $newQrisPath = MediaStorage::storeQris(
                file: $this->qris,
                directory: 'qris',
                oldPath: $this->existingQrisPath,
                errorField: 'qris',
            );
        }

        $profile->update([
            'name' => $this->name,
            'tagline' => $this->tagline !== '' ? $this->tagline : null,
            'description' => $this->description !== '' ? $this->description : null,
            'location' => $this->location !== '' ? $this->location : null,
            'phone' => $normalizedPhone,
            'whatsapp' => $normalizedWhatsapp,
            'open_time' => $this->open_time,
            'close_time' => $this->close_time,
            'logo_path' => $newLogoPath,
            'qris_image_path' => $newQrisPath,
        ]);

        $this->existingLogoPath = $newLogoPath;
        $this->existingQrisPath = $newQrisPath;
        $this->logo = null;
        $this->qris = null;
        $this->statusMessage = 'Profil usaha berhasil diperbarui.';
    }

    private function loadProfile(): void
    {
        $profile = BusinessProfile::query()->find(1);

        if (! $profile) {
            $this->profileMissingError = 'Profil usaha belum dibuat. Jalankan seeder awal.';

            return;
        }

        $this->profileId = $profile->id;
        $this->name = (string) $profile->name;
        $this->tagline = (string) ($profile->tagline ?? '');
        $this->description = (string) ($profile->description ?? '');
        $this->location = (string) ($profile->location ?? '');
        $this->phone = (string) ($profile->phone ?? '');
        $this->whatsapp = (string) ($profile->whatsapp ?? '');
        $this->open_time = (string) ($profile->open_time ?? '08.00');
        $this->close_time = (string) ($profile->close_time ?? '17.00');
        $this->existingLogoPath = $profile->logo_path;
        $this->existingQrisPath = $profile->qris_image_path;
    }

    private function resetFeedback(): void
    {
        $this->statusMessage = null;
        $this->errorMessage = null;
    }

    private function ensureAuthenticated(): void
    {
        if (! Auth::check()) {
            abort(403, 'Aksi ini memerlukan login admin.');
        }
    }

    public function render(): View
    {
        return view('livewire.admin.business-profile-editor', [
            'existingLogoUrl' => MediaStorage::url($this->existingLogoPath),
            'existingQrisUrl' => MediaStorage::url($this->existingQrisPath),
        ]);
    }
}
