<?php

namespace App\Livewire\Admin;

use App\Enums\OrderStatus;
use App\Enums\PaymentStatus;
use App\Models\Order;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.admin')]
#[Title('Detail Pesanan')]
class OrderDetail extends Component
{
    #[Locked]
    public int $orderId;

    public ?string $statusMessage = null;

    public ?string $errorMessage = null;

    public function mount(Order $order): void
    {
        $this->orderId = $order->id;
    }

    public function markAsPaid(): void
    {
        abort_unless(auth()->check(), 403);

        $this->statusMessage = null;
        $this->errorMessage = null;

        DB::transaction(function (): void {
            $order = Order::query()->whereKey($this->orderId)->lockForUpdate()->firstOrFail();

            if ($order->status === OrderStatus::Dibatalkan) {
                $this->errorMessage = 'Pesanan yang sudah dibatalkan tidak dapat ditandai lunas.';

                return;
            }

            if ($order->payment_status === PaymentStatus::Lunas) {
                $this->statusMessage = 'Pesanan sudah berstatus Lunas.';

                return;
            }

            $order->update([
                'payment_status' => PaymentStatus::Lunas,
                'paid_at' => now(),
            ]);

            $this->statusMessage = 'Pembayaran berhasil ditandai Lunas.';
        });
    }

    public function transitionStatus(string $expectedStatus, string $targetStatus): void
    {
        abort_unless(auth()->check(), 403);

        $this->statusMessage = null;
        $this->errorMessage = null;

        $expected = OrderStatus::tryFrom($expectedStatus);
        $target = OrderStatus::tryFrom($targetStatus);

        if ($expected === null || $target === null) {
            $this->errorMessage = 'Status tujuan tidak valid.';

            return;
        }

        DB::transaction(function () use ($expected, $target): void {
            $order = Order::query()->whereKey($this->orderId)->lockForUpdate()->firstOrFail();

            if ($order->status !== $expected) {
                $this->errorMessage = 'Status pesanan sudah berubah oleh proses lain. Data terbaru telah dimuat.';

                return;
            }

            if (! $order->status->canTransitionTo($target)) {
                $this->errorMessage = "Tidak dapat mengubah status dari {$order->status->label()} ke {$target->label()}.";

                return;
            }

            if ($target === OrderStatus::Selesai && $order->payment_status !== PaymentStatus::Lunas) {
                $this->errorMessage = 'Pesanan hanya dapat diselesaikan setelah pembayaran ditandai Lunas.';

                return;
            }

            $order->update([
                'status' => $target,
            ]);

            $order->statusLogs()->create([
                'status' => $target,
                'changed_by' => auth()->id(),
                'created_at' => now(),
            ]);

            $this->statusMessage = "Status pesanan diperbarui menjadi {$target->label()}.";
        });
    }

    public function render(): View
    {
        $order = Order::query()
            ->with(['customer', 'table', 'items', 'statusLogs.changedByUser'])
            ->findOrFail($this->orderId);

        $nextStatus = $order->status->next();
        $canCancel = $order->status->canTransitionTo(OrderStatus::Dibatalkan);

        return view('livewire.admin.order-detail', [
            'order' => $order,
            'nextStatus' => $nextStatus,
            'canCancel' => $canCancel,
        ]);
    }
}
