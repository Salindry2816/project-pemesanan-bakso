<?php

namespace App\Livewire\Admin;

use App\Models\Menu;
use App\Models\MenuCategory;
use App\Support\MediaStorage;
use Illuminate\Contracts\View\View;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Locked;
use Livewire\Attributes\Title;
use Livewire\Component;
use Livewire\WithFileUploads;

#[Layout('components.layouts.admin')]
#[Title('Kelola Menu')]
class MenuManager extends Component
{
    use WithFileUploads;

    public ?int $selectedCategoryId = null;

    public bool $showFormModal = false;

    #[Locked]
    public ?int $editingId = null;

    public string $name = '';

    public string $categoryId = '';

    public string $price = '';

    public string $description = '';

    public bool $isAvailable = true;

    public mixed $photo = null;

    #[Locked]
    public ?string $existingPhotoPath = null;

    public bool $removeExistingPhoto = false;

    public ?string $photoUploadError = null;

    #[Locked]
    public ?int $deletingId = null;

    public string $deletingName = '';

    public ?string $statusMessage = null;

    public ?string $errorMessage = null;

    public function filterByCategory(?int $categoryId = null): void
    {
        $this->selectedCategoryId = $categoryId;
    }

    public function openCreateModal(): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();
        $this->resetForm();

        $defaultCategory = $this->selectedCategoryId
            ?? MenuCategory::query()->orderBy('sort_order')->orderBy('id')->value('id');

        $this->categoryId = $defaultCategory !== null ? (string) $defaultCategory : '';
        $this->showFormModal = true;
    }

    public function openEditModal(int $menuId): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();
        $this->resetForm();

        $menu = Menu::query()->findOrFail($menuId);

        $this->editingId = $menu->id;
        $this->name = $menu->name;
        $this->categoryId = (string) $menu->category_id;
        $this->price = (string) $menu->price;
        $this->description = (string) ($menu->description ?? '');
        $this->isAvailable = (bool) $menu->is_available;
        $this->existingPhotoPath = $menu->photo_path;
        $this->showFormModal = true;
    }

    public function closeFormModal(): void
    {
        $this->showFormModal = false;
        $this->resetForm();
    }

    public function updatedPhoto(): void
    {
        $this->photoUploadError = null;
        $this->removeExistingPhoto = false;
        $this->resetErrorBag('photo');

        if ($this->photo instanceof UploadedFile) {
            try {
                MediaStorage::validateUploadedFile($this->photo, 'photo');
            } catch (ValidationException $e) {
                $this->photo = null;
                $this->photoUploadError = $e->errors()['photo'][0] ?? 'File foto tidak valid.';

                throw $e;
            }
        }
    }

    public function _uploadErrored($name, $errorsInJson, $isMultiple): void
    {
        $this->dispatch('upload:errored', name: $name)->self();

        $message = 'File foto tidak valid. Gunakan gambar JPG, PNG, atau WebP dengan ukuran maksimal 2 MB.';

        if ($name === 'photo') {
            $this->photoUploadError = $message;
        }

        throw ValidationException::withMessages([$name => $message]);
    }

    public function removePhoto(): void
    {
        $this->ensureAuthenticated();
        $this->photo = null;
        $this->photoUploadError = null;
        $this->resetErrorBag('photo');

        if ($this->existingPhotoPath !== null) {
            $this->removeExistingPhoto = true;
        }
    }

    public function saveMenu(): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        $this->name = trim(preg_replace('/\s+/u', ' ', $this->name) ?? '');
        $this->description = trim($this->description);
        $this->price = trim((string) $this->price);

        $this->validate(
            [
                'name' => ['required', 'string', 'max:100'],
                'categoryId' => ['required', 'integer', 'exists:menu_categories,id'],
                'price' => ['required', 'regex:/^-?\d+$/'],
                'description' => ['nullable', 'string', 'max:255'],
                'isAvailable' => ['boolean'],
            ],
            [
                'name.required' => 'Nama menu wajib diisi.',
                'name.max' => 'Nama menu maksimal 100 karakter.',
                'categoryId.required' => 'Kategori menu wajib dipilih.',
                'categoryId.integer' => 'Kategori menu tidak valid.',
                'categoryId.exists' => 'Kategori menu yang dipilih tidak ditemukan.',
                'price.required' => 'Harga menu wajib diisi.',
                'price.regex' => 'Harga menu harus berupa angka bulat rupiah (tanpa desimal atau huruf).',
                'description.max' => 'Deskripsi menu maksimal 255 karakter.',
            ]
        );

        $priceInt = (int) $this->price;
        if ($priceInt <= 0) {
            throw ValidationException::withMessages([
                'price' => 'Harga menu harus lebih dari Rp 0.',
            ]);
        }

        if ($priceInt > 1_000_000) {
            throw ValidationException::withMessages([
                'price' => 'Harga menu maksimal Rp 1.000.000.',
            ]);
        }

        if ($this->photoUploadError !== null) {
            throw ValidationException::withMessages([
                'photo' => $this->photoUploadError,
            ]);
        }

        $categoryIdInt = (int) $this->categoryId;
        $existingMenu = $this->editingId !== null
            ? Menu::query()->findOrFail($this->editingId)
            : null;

        $oldPhotoPath = $existingMenu?->photo_path;
        $newPhotoPath = $oldPhotoPath;

        if ($this->photo instanceof UploadedFile) {
            // MediaStorage saves the new image first and only deletes $oldPhotoPath after write succeeds
            $newPhotoPath = MediaStorage::storeImage(
                file: $this->photo,
                directory: 'menus',
                oldPath: $oldPhotoPath,
                maxDimension: MediaStorage::DEFAULT_MAX_DIMENSION,
                errorField: 'photo',
            );
        } elseif ($this->removeExistingPhoto && $oldPhotoPath !== null) {
            $newPhotoPath = null;
        }

        DB::transaction(function () use ($existingMenu, $categoryIdInt, $priceInt, $newPhotoPath): void {
            if ($existingMenu === null) {
                $maxSortOrder = (int) Menu::query()
                    ->where('category_id', $categoryIdInt)
                    ->lockForUpdate()
                    ->max('sort_order');

                Menu::query()->create([
                    'category_id' => $categoryIdInt,
                    'name' => $this->name,
                    'description' => $this->description !== '' ? $this->description : null,
                    'price' => $priceInt,
                    'photo_path' => $newPhotoPath,
                    'is_available' => $this->isAvailable,
                    'sort_order' => $maxSortOrder + 1,
                ]);
            } else {
                $sortOrder = $existingMenu->sort_order;
                if ($existingMenu->category_id !== $categoryIdInt) {
                    $maxSortOrder = (int) Menu::query()
                        ->where('category_id', $categoryIdInt)
                        ->lockForUpdate()
                        ->max('sort_order');
                    $sortOrder = $maxSortOrder + 1;
                }

                $existingMenu->update([
                    'category_id' => $categoryIdInt,
                    'name' => $this->name,
                    'description' => $this->description !== '' ? $this->description : null,
                    'price' => $priceInt,
                    'photo_path' => $newPhotoPath,
                    'is_available' => $this->isAvailable,
                    'sort_order' => $sortOrder,
                ]);
            }
        });

        if ($this->removeExistingPhoto && ! ($this->photo instanceof UploadedFile) && $oldPhotoPath !== null) {
            MediaStorage::delete($oldPhotoPath);
        }

        $isEdit = $existingMenu !== null;
        $this->closeFormModal();
        $this->statusMessage = $isEdit
            ? 'Menu berhasil diperbarui.'
            : 'Menu baru berhasil ditambahkan.';
    }

    public function toggleAvailability(int $menuId): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        $menu = Menu::query()->findOrFail($menuId);
        $menu->update([
            'is_available' => ! $menu->is_available,
        ]);

        $this->statusMessage = $menu->is_available
            ? "Menu \"{$menu->name}\" ditandai tersedia."
            : "Menu \"{$menu->name}\" ditandai tidak tersedia.";
    }

    public function confirmDelete(int $menuId): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        $menu = Menu::query()->findOrFail($menuId);
        $this->deletingId = $menu->id;
        $this->deletingName = $menu->name;
    }

    public function cancelDelete(): void
    {
        $this->reset(['deletingId', 'deletingName']);
    }

    public function deleteMenu(?int $menuId = null): void
    {
        $this->ensureAuthenticated();
        $this->resetFeedback();

        $targetId = $menuId ?? $this->deletingId;
        if ($targetId === null) {
            return;
        }

        $photoToDelete = null;

        $deleted = DB::transaction(function () use ($targetId, &$photoToDelete): bool {
            $menu = Menu::query()->lockForUpdate()->find($targetId);
            if ($menu === null) {
                return false;
            }

            $photoToDelete = $menu->photo_path;
            $menu->delete();

            return true;
        });

        $this->cancelDelete();

        if ($deleted) {
            if ($photoToDelete !== null) {
                MediaStorage::delete($photoToDelete);
            }

            $this->statusMessage = 'Menu berhasil dihapus.';
        }
    }

    private function resetForm(): void
    {
        $this->reset([
            'editingId',
            'name',
            'categoryId',
            'price',
            'description',
            'photo',
            'existingPhotoPath',
            'removeExistingPhoto',
            'photoUploadError',
        ]);
        $this->isAvailable = true;
        $this->resetValidation();
    }

    private function resetFeedback(): void
    {
        $this->statusMessage = null;
        $this->errorMessage = null;
    }

    private function ensureAuthenticated(): void
    {
        abort_unless(Auth::check(), 403);
    }

    public function render(): View
    {
        $categories = MenuCategory::query()
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        $menus = Menu::query()
            ->with('category')
            ->select('menus.*')
            ->join('menu_categories', 'menu_categories.id', '=', 'menus.category_id')
            ->when(
                $this->selectedCategoryId !== null,
                fn ($query) => $query->where('menus.category_id', $this->selectedCategoryId)
            )
            ->orderBy('menu_categories.sort_order')
            ->orderBy('menu_categories.id')
            ->orderBy('menus.sort_order')
            ->orderBy('menus.name')
            ->get();

        return view('livewire.admin.menu-manager', [
            'categories' => $categories,
            'menus' => $menus,
        ]);
    }
}
