<?php

namespace App\Livewire\Admin;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Models\Order;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Collection;
use Livewire\Attributes\Locked;
use Livewire\Component;

class OrderNotificationBell extends Component
{
    #[Locked]
    public int $lastSeenMaxId = 0;

    public int $pendingCount = 0;

    /**
     * @var array<int, array{id: int, display_number: string, location: string, total_formatted: string, time: string, url: string}>
     */
    public array $recentOrders = [];

    public function mount(): void
    {
        $maxId = $this->loadSnapshot();
        $this->lastSeenMaxId = $maxId;
    }

    public function checkOrders(): void
    {
        $maxId = $this->loadSnapshot();

        if ($maxId > $this->lastSeenMaxId) {
            $this->lastSeenMaxId = $maxId;
            $latest = $this->recentOrders[0] ?? null;

            if ($latest !== null) {
                $this->dispatch('new-order-alert', $latest);
            }
        }
    }

    public function render(): View
    {
        return view('livewire.admin.order-notification-bell');
    }

    private function loadSnapshot(): int
    {
        if (! auth()->check()) {
            $this->pendingCount = 0;
            $this->recentOrders = [];

            return 0;
        }

        try {
            $baseQuery = Order::query()->where('status', OrderStatus::Diterima->value);

            $this->pendingCount = (int) (clone $baseQuery)->count();
            $maxId = (int) ((clone $baseQuery)->max('id') ?? 0);

            /** @var Collection<int, Order> $orders */
            $orders = (clone $baseQuery)
                ->with('table:id,code')
                ->orderByDesc('id')
                ->limit(5)
                ->get(['id', 'order_number', 'type', 'table_id', 'location_note', 'total', 'created_at']);

            $this->recentOrders = $orders->map(function (Order $order): array {
                $location = $order->type === OrderType::TakeAway
                    ? 'Bungkus'
                    : ($order->table?->code === 'BEBAS'
                        ? 'Meja Bebas'
                        : ('Meja ' . ($order->table?->code ?? '-')));

                return [
                    'id' => $order->id,
                    'display_number' => $order->display_number,
                    'location' => $location,
                    'total_formatted' => 'Rp ' . number_format($order->total, 0, ',', '.'),
                    'time' => $order->created_at?->format('H:i') ?? '-',
                    'url' => route('admin.orders.show', $order),
                ];
            })->values()->all();

            return $maxId;
        } catch (\Throwable) {
            $this->pendingCount = 0;
            $this->recentOrders = [];

            return 0;
        }
    }
}
