<?php

namespace App\Livewire\Admin;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Models\OrderStatusLog;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Builder;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.admin')]
#[Title('Dashboard')]
class Dashboard extends Component
{
    public string $statusFilter = 'aktif';

    public string $search = '';

    public function setFilter(string $filter): void
    {
        $allowed = array_merge(
            ['aktif', 'semua'],
            array_map(static fn (OrderStatus $s): string => $s->value, OrderStatus::cases())
        );

        $this->statusFilter = in_array($filter, $allowed, true) ? $filter : 'aktif';
    }

    public function render(): View
    {
        $pesananBaruCount = Order::query()
            ->where('status', OrderStatus::Diterima)
            ->count();

        $dalamProsesCount = Order::query()
            ->whereIn('status', [OrderStatus::Diproses->value, OrderStatus::Disiapkan->value])
            ->count();

        $siapDiantarCount = Order::query()
            ->where('status', OrderStatus::Siap)
            ->count();

        $selesaiHariIniCount = OrderStatusLog::query()
            ->where('status', OrderStatus::Selesai)
            ->whereBetween('created_at', [now()->startOfDay(), now()->endOfDay()])
            ->distinct('order_id')
            ->count('order_id');

        $searchTerm = trim($this->search);

        $orders = Order::query()
            ->with(['customer', 'table', 'items'])
            ->when($this->statusFilter === 'aktif', function (Builder $query): void {
                $query->whereIn('status', OrderStatus::activeValues());
            })
            ->when($this->statusFilter !== 'aktif' && $this->statusFilter !== 'semua', function (Builder $query): void {
                $status = OrderStatus::tryFrom($this->statusFilter);
                if ($status !== null) {
                    $query->where('status', $status->value);
                }
            })
            ->when($searchTerm !== '', function (Builder $query) use ($searchTerm): void {
                $query->where(function (Builder $sub) use ($searchTerm): void {
                    $sub->where('order_number', 'like', "%{$searchTerm}%")
                        ->orWhereHas('customer', function (Builder $customerQuery) use ($searchTerm): void {
                            $customerQuery->where('phone', 'like', "%{$searchTerm}%");
                        })
                        ->orWhereHas('table', function (Builder $tableQuery) use ($searchTerm): void {
                            $tableQuery->where('code', 'like', "%{$searchTerm}%");
                        });
                });
            })
            ->latest('created_at')
            ->limit(50)
            ->get();

        return view('livewire.admin.dashboard', [
            'pesananBaruCount' => $pesananBaruCount,
            'dalamProsesCount' => $dalamProsesCount,
            'siapDiantarCount' => $siapDiantarCount,
            'selesaiHariIniCount' => $selesaiHariIniCount,
            'orders' => $orders,
        ]);
    }
}
