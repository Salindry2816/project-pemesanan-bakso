<?php

namespace App\Livewire\Admin;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Support\PhoneNumber;
use Carbon\Carbon;
use Illuminate\Contracts\View\View;
use Illuminate\Database\Eloquent\Builder;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Attributes\Url;
use Livewire\Component;
use Livewire\WithPagination;

#[Layout('components.layouts.admin')]
#[Title('Semua Pesanan')]
class OrderList extends Component
{
    use WithPagination;

    #[Url(except: 'semua')]
    public string $statusFilter = 'semua';

    #[Url(except: '')]
    public string $dateFrom = '';

    #[Url(except: '')]
    public string $dateTo = '';

    #[Url(except: '')]
    public string $search = '';

    public function updatedStatusFilter(): void
    {
        $this->resetPage();
    }

    public function updatedDateFrom(): void
    {
        $this->resetPage();
    }

    public function updatedDateTo(): void
    {
        $this->resetPage();
    }

    public function updatedSearch(): void
    {
        $this->resetPage();
    }

    public function setFilter(string $filter): void
    {
        $allowed = array_merge(
            ['semua', 'aktif'],
            array_map(static fn (OrderStatus $s): string => $s->value, OrderStatus::cases())
        );

        $this->statusFilter = in_array($filter, $allowed, true) ? $filter : 'semua';
        $this->resetPage();
    }

    public function resetFilters(): void
    {
        $this->statusFilter = 'semua';
        $this->dateFrom = '';
        $this->dateTo = '';
        $this->search = '';
        $this->resetPage();
    }

    public function render(): View
    {
        $searchTerm = trim($this->search);
        $fromDate = $this->parseDate($this->dateFrom);
        $toDate = $this->parseDate($this->dateTo);

        $orders = Order::query()
            ->with(['customer', 'table', 'items'])
            ->when($this->statusFilter === 'aktif', function (Builder $query): void {
                $query->whereIn('status', OrderStatus::activeValues());
            })
            ->when($this->statusFilter !== 'aktif' && $this->statusFilter !== 'semua', function (Builder $query): void {
                $status = OrderStatus::tryFrom($this->statusFilter);
                if ($status !== null) {
                    $query->where('status', $status->value);
                }
            })
            ->when($fromDate !== null, function (Builder $query) use ($fromDate): void {
                $query->where('created_at', '>=', $fromDate->copy()->startOfDay());
            })
            ->when($toDate !== null, function (Builder $query) use ($toDate): void {
                $query->where('created_at', '<=', $toDate->copy()->endOfDay());
            })
            ->when($searchTerm !== '', function (Builder $query) use ($searchTerm): void {
                $escaped = addcslashes($searchTerm, '%_\\');
                $normalizedPhone = PhoneNumber::normalize($searchTerm);
                $escapedPhone = addcslashes($normalizedPhone, '%_\\');

                $query->where(function (Builder $sub) use ($escaped, $escapedPhone): void {
                    $sub->where('order_number', 'like', "%{$escaped}%")
                        ->orWhereHas('customer', function (Builder $customerQuery) use ($escapedPhone): void {
                            $customerQuery->where('phone', 'like', "%{$escapedPhone}%");
                        })
                        ->orWhereHas('table', function (Builder $tableQuery) use ($escaped): void {
                            $tableQuery->where('code', 'like', "%{$escaped}%");
                        });
                });
            })
            ->latest('created_at')
            ->paginate(15);

        return view('livewire.admin.order-list', [
            'orders' => $orders,
        ]);
    }

    private function parseDate(string $value): ?Carbon
    {
        $trimmed = trim($value);
        if ($trimmed === '') {
            return null;
        }

        try {
            $parsed = Carbon::createFromFormat('Y-m-d', $trimmed);

            return $parsed !== false && $parsed->format('Y-m-d') === $trimmed ? $parsed : null;
        } catch (\Throwable) {
            return null;
        }
    }
}
