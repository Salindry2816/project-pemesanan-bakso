<?php

namespace App\Livewire\Admin;

use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\RateLimiter;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;

#[Layout('components.layouts.admin')]
#[Title('Ganti Password')]
class ChangePassword extends Component
{
    public string $currentPassword = '';

    public string $newPassword = '';

    public string $newPasswordConfirmation = '';

    public ?string $statusMessage = null;

    public function updatePassword(): void
    {
        abort_unless(auth()->check(), 403);

        $this->statusMessage = null;

        /** @var User $admin */
        $admin = auth()->user();
        $throttleKey = 'admin-change-password:'.$admin->id.'|'.request()->ip();

        if (RateLimiter::tooManyAttempts($throttleKey, 5)) {
            $seconds = RateLimiter::availableIn($throttleKey);
            $this->addError('currentPassword', "Terlalu banyak percobaan gagal. Coba lagi dalam {$seconds} detik.");

            return;
        }

        $this->validate([
            'currentPassword' => ['required', 'string'],
            'newPassword' => ['required', 'string', 'min:8'],
            'newPasswordConfirmation' => ['required', 'string', 'same:newPassword'],
        ], [
            'currentPassword.required' => 'Password saat ini wajib diisi.',
            'newPassword.required' => 'Password baru wajib diisi.',
            'newPassword.min' => 'Password baru minimal 8 karakter.',
            'newPasswordConfirmation.required' => 'Konfirmasi password baru wajib diisi.',
            'newPasswordConfirmation.same' => 'Konfirmasi password baru tidak cocok.',
        ]);

        if (! Hash::check($this->currentPassword, $admin->password)) {
            RateLimiter::hit($throttleKey, 60);
            $this->addError('currentPassword', 'Password saat ini tidak sesuai.');

            return;
        }

        if (Hash::check($this->newPassword, $admin->password)) {
            $this->addError('newPassword', 'Password baru tidak boleh sama dengan password saat ini.');

            return;
        }

        RateLimiter::clear($throttleKey);

        $admin->forceFill([
            'password' => $this->newPassword,
        ])->save();

        session()->regenerate(true);

        if (config('session.driver') === 'database') {
            DB::table((string) config('session.table', 'sessions'))
                ->where('user_id', $admin->id)
                ->where('id', '!=', session()->getId())
                ->delete();
        }

        $this->reset(['currentPassword', 'newPassword', 'newPasswordConfirmation']);
        $this->resetErrorBag();
        $this->statusMessage = 'Password berhasil diperbarui.';
    }

    public function render(): View
    {
        return view('livewire.admin.change-password');
    }
}
