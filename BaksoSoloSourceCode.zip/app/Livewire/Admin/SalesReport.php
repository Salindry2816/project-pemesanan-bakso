<?php

namespace App\Livewire\Admin;

use App\Enums\OrderStatus;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Models\Order;
use App\Models\OrderItem;
use Carbon\Carbon;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Livewire\Attributes\Layout;
use Livewire\Attributes\Title;
use Livewire\Component;
use Symfony\Component\HttpFoundation\StreamedResponse;

#[Layout('components.layouts.admin', ['title' => 'Laporan Penjualan', 'activeMenu' => 'laporan'])]
#[Title('Laporan Penjualan – Admin Bakso Solo')]
class SalesReport extends Component
{
    public string $periodMode = 'daily';

    public string $selectedMonth = '';

    public int $selectedYear = 0;

    public function mount(): void
    {
        $now = now();
        $this->selectedMonth = $now->format('Y-m');
        $this->selectedYear = (int) $now->format('Y');
    }

    public function setPeriodMode(string $mode): void
    {
        if (! in_array($mode, ['daily', 'monthly'], true)) {
            return;
        }

        $this->periodMode = $mode;
    }

    public function updatedSelectedMonth(): void
    {
        if (! preg_match('/^\d{4}-\d{2}$/', $this->selectedMonth)) {
            $this->selectedMonth = now()->format('Y-m');
        }
    }

    public function updatedSelectedYear(): void
    {
        if ($this->selectedYear < 2020 || $this->selectedYear > 2100) {
            $this->selectedYear = (int) now()->format('Y');
        }
    }

    public function exportCsv(): StreamedResponse
    {
        $report = $this->buildReportData();
        $suffix = $this->periodMode === 'daily'
            ? $this->selectedMonth
            : (string) $this->selectedYear;
        $filename = "laporan-penjualan-bakso-solo-{$this->periodMode}-{$suffix}.csv";

        return response()->streamDownload(function () use ($report): void {
            $out = fopen('php://output', 'w');
            if ($out === false) {
                return;
            }

            // UTF-8 BOM for clean Excel rendering in Indonesia
            fwrite($out, "\xEF\xBB\xBF");

            fputcsv($out, ['Laporan Penjualan Bakso Solo - ' . $report['periodLabel']]);
            fputcsv($out, ['Total Pendapatan Lunas (Rp)', $report['totalRevenue']]);
            fputcsv($out, ['Transaksi Lunas', $report['paidTransactionsCount']]);
            fputcsv($out, ['Total Semua Pesanan', $report['totalOrdersCount']]);
            fputcsv($out, []);
            fputcsv($out, ['Periode', 'Transaksi Lunas', 'Total Pendapatan (Rp)']);

            foreach ($report['rows'] as $row) {
                fputcsv($out, [
                    $this->sanitizeCsvCell((string) $row['label']),
                    $row['count'],
                    $row['revenue'],
                ]);
            }

            fputcsv($out, []);
            fputcsv($out, ['Menu Paling Laris', 'Porsi Terjual', 'Total Pendapatan (Rp)']);
            foreach ($report['topMenus'] as $menu) {
                fputcsv($out, [
                    $this->sanitizeCsvCell((string) $menu['menu_name']),
                    $menu['total_qty'],
                    $menu['total_revenue'],
                ]);
            }

            fclose($out);
        }, $filename, [
            'Content-Type' => 'text/csv; charset=UTF-8',
        ]);
    }

    public function render(): View
    {
        $report = $this->buildReportData();

        $this->dispatch('sales-chart-updated', [
            'labels' => $report['chartLabels'],
            'revenues' => $report['chartRevenues'],
            'counts' => $report['chartCounts'],
            'mode' => $this->periodMode,
            'title' => $report['periodLabel'],
        ]);

        return view('livewire.admin.sales-report', $report);
    }

    /**
     * @return array<string, mixed>
     */
    private function buildReportData(): array
    {
        [$start, $end, $periodLabel] = $this->resolveWindow();

        // Automatic live highlights (Hari Ini & Bulan Ini)
        $todayStart = now()->startOfDay();
        $todayEnd = now()->endOfDay();
        $monthStart = now()->startOfMonth();
        $monthEnd = now()->endOfMonth();

        $todayStats = $this->aggregatePaidOrders($todayStart, $todayEnd);
        $thisMonthStats = $this->aggregatePaidOrders($monthStart, $monthEnd);

        // Selected period orders (paid, excluding cancelled)
        $paidOrders = Order::query()
            ->where('payment_status', PaymentStatus::Lunas->value)
            ->where('status', '!=', OrderStatus::Dibatalkan->value)
            ->whereBetween(DB::raw('COALESCE(paid_at, created_at)'), [$start, $end])
            ->get(['id', 'total', 'payment_method', 'paid_at', 'created_at']);

        // All orders created in selected period (for order count & status breakdown)
        $allOrdersInWindow = Order::query()
            ->whereBetween('created_at', [$start, $end])
            ->get(['id', 'status', 'payment_status']);

        $totalRevenue = (int) $paidOrders->sum('total');
        $paidTransactionsCount = $paidOrders->count();
        $totalOrdersCount = $allOrdersInWindow->count();
        $cancelledOrdersCount = $allOrdersInWindow
            ->where('status', OrderStatus::Dibatalkan)
            ->count();
        $unpaidOrdersCount = $allOrdersInWindow
            ->where('status', '!=', OrderStatus::Dibatalkan)
            ->where('payment_status', PaymentStatus::BelumBayar)
            ->count();
        $averageOrderValue = $paidTransactionsCount > 0
            ? (int) round($totalRevenue / $paidTransactionsCount)
            : 0;

        // Cash vs QRIS breakdown
        $cashOrders = $paidOrders->where('payment_method', PaymentMethod::Cash);
        $qrisOrders = $paidOrders->where('payment_method', PaymentMethod::Qris);

        $paymentBreakdown = [
            'cash' => [
                'count' => $cashOrders->count(),
                'revenue' => (int) $cashOrders->sum('total'),
            ],
            'qris' => [
                'count' => $qrisOrders->count(),
                'revenue' => (int) $qrisOrders->sum('total'),
            ],
        ];

        // Build continuous time-series buckets for chart & table
        [$chartLabels, $chartRevenues, $chartCounts, $rows] = $this->buildSeries(
            $paidOrders,
            $start,
            $end
        );

        // Top selling menus from paid non-cancelled orders in window
        $topMenusRaw = OrderItem::query()
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            ->where('orders.payment_status', PaymentStatus::Lunas->value)
            ->where('orders.status', '!=', OrderStatus::Dibatalkan->value)
            ->whereBetween(DB::raw('COALESCE(orders.paid_at, orders.created_at)'), [$start, $end])
            ->selectRaw('order_items.name_snapshot as menu_name, SUM(order_items.qty) as total_qty, SUM(order_items.line_total) as total_revenue')
            ->groupBy('order_items.name_snapshot')
            ->orderByDesc('total_qty')
            ->orderByDesc('total_revenue')
            ->limit(10)
            ->get();

        $maxTopQty = max(1, (int) ($topMenusRaw->max('total_qty') ?? 1));
        $topMenus = $topMenusRaw->map(fn ($row) => [
            'menu_name' => (string) $row->menu_name,
            'total_qty' => (int) $row->total_qty,
            'total_revenue' => (int) $row->total_revenue,
            'percent' => (int) round(((int) $row->total_qty / $maxTopQty) * 100),
        ])->values()->all();

        $yearOptions = range(max(2024, (int) now()->format('Y') - 2), (int) now()->format('Y') + 1);

        return [
            'periodLabel' => $periodLabel,
            'todayRevenue' => $todayStats['revenue'],
            'todayTransactions' => $todayStats['count'],
            'thisMonthRevenue' => $thisMonthStats['revenue'],
            'thisMonthTransactions' => $thisMonthStats['count'],
            'totalRevenue' => $totalRevenue,
            'paidTransactionsCount' => $paidTransactionsCount,
            'totalOrdersCount' => $totalOrdersCount,
            'cancelledOrdersCount' => $cancelledOrdersCount,
            'unpaidOrdersCount' => $unpaidOrdersCount,
            'averageOrderValue' => $averageOrderValue,
            'paymentBreakdown' => $paymentBreakdown,
            'chartLabels' => $chartLabels,
            'chartRevenues' => $chartRevenues,
            'chartCounts' => $chartCounts,
            'rows' => $rows,
            'topMenus' => $topMenus,
            'yearOptions' => $yearOptions,
        ];
    }

    /**
     * @return array{0: Carbon, 1: Carbon, 2: string}
     */
    private function resolveWindow(): array
    {
        if ($this->periodMode === 'monthly') {
            $year = ($this->selectedYear >= 2020 && $this->selectedYear <= 2100)
                ? $this->selectedYear
                : (int) now()->format('Y');

            $start = Carbon::create($year, 1, 1)->startOfYear();
            $end = Carbon::create($year, 12, 31)->endOfYear();

            return [$start, $end, "Rekap Bulanan Tahun {$year}"];
        }

        $monthString = preg_match('/^\d{4}-\d{2}$/', $this->selectedMonth)
            ? $this->selectedMonth
            : now()->format('Y-m');

        $anchor = Carbon::createFromFormat('Y-m', $monthString)?->startOfMonth() ?? now()->startOfMonth();
        $monthNames = [
            1 => 'Januari', 2 => 'Februari', 3 => 'Maret', 4 => 'April',
            5 => 'Mei', 6 => 'Juni', 7 => 'Juli', 8 => 'Agustus',
            9 => 'September', 10 => 'Oktober', 11 => 'November', 12 => 'Desember',
        ];
        $label = 'Rekap Harian ' . ($monthNames[(int) $anchor->format('n')] ?? $anchor->format('F')) . ' ' . $anchor->format('Y');

        return [$anchor->copy()->startOfMonth(), $anchor->copy()->endOfMonth(), $label];
    }

    /**
     * @return array{revenue: int, count: int}
     */
    private function aggregatePaidOrders(Carbon $start, Carbon $end): array
    {
        $row = Order::query()
            ->where('payment_status', PaymentStatus::Lunas->value)
            ->where('status', '!=', OrderStatus::Dibatalkan->value)
            ->whereBetween(DB::raw('COALESCE(paid_at, created_at)'), [$start, $end])
            ->selectRaw('COALESCE(SUM(total), 0) as revenue, COUNT(*) as tx_count')
            ->first();

        return [
            'revenue' => (int) ($row?->revenue ?? 0),
            'count' => (int) ($row?->tx_count ?? 0),
        ];
    }

    /**
     * @param  Collection<int, Order>  $paidOrders
     * @return array{0: array<int, string>, 1: array<int, int>, 2: array<int, int>, 3: array<int, array{label: string, count: int, revenue: int}>}
     */
    private function buildSeries(Collection $paidOrders, Carbon $start, Carbon $end): array
    {
        $labels = [];
        $revenues = [];
        $counts = [];
        $rows = [];

        if ($this->periodMode === 'monthly') {
            $monthLabels = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des'];
            $grouped = $paidOrders->groupBy(fn (Order $o) => (int) ($o->paid_at ?? $o->created_at)->format('n'));

            for ($m = 1; $m <= 12; $m++) {
                /** @var Collection<int, Order> $bucket */
                $bucket = $grouped->get($m, collect());
                $rev = (int) $bucket->sum('total');
                $cnt = $bucket->count();
                $lbl = $monthLabels[$m - 1];

                $labels[] = $lbl;
                $revenues[] = $rev;
                $counts[] = $cnt;
                $rows[] = [
                    'label' => $lbl . ' ' . $start->format('Y'),
                    'count' => $cnt,
                    'revenue' => $rev,
                ];
            }

            return [$labels, $revenues, $counts, $rows];
        }

        $grouped = $paidOrders->groupBy(fn (Order $o) => ($o->paid_at ?? $o->created_at)->format('Y-m-d'));
        $cursor = $start->copy();
        while ($cursor->lte($end)) {
            $key = $cursor->format('Y-m-d');
            /** @var Collection<int, Order> $bucket */
            $bucket = $grouped->get($key, collect());
            $rev = (int) $bucket->sum('total');
            $cnt = $bucket->count();

            $labels[] = $cursor->format('d');
            $revenues[] = $rev;
            $counts[] = $cnt;
            $rows[] = [
                'label' => $cursor->format('d M Y'),
                'count' => $cnt,
                'revenue' => $rev,
            ];

            $cursor->addDay();
        }

        return [$labels, $revenues, $counts, $rows];
    }

    private function sanitizeCsvCell(string $value): string
    {
        $trimmed = ltrim($value);
        if ($trimmed !== '' && in_array($trimmed[0], ['=', '+', '-', '@', "\t", "\r"], true)) {
            return "'" . $value;
        }

        return $value;
    }
}
