<?php

namespace App\Enums;

enum TableType: string
{
    case Fixed = 'fixed';
    case Free = 'free';

    public function label(): string
    {
        return match ($this) {
            self::Fixed => 'Meja Berkode',
            self::Free => 'Meja Bebas',
        };
    }
}
