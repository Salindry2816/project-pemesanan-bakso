<?php

namespace App\Enums;

enum OrderStatus: string
{
    case Diterima = 'diterima';
    case Diproses = 'diproses';
    case Disiapkan = 'disiapkan';
    case Siap = 'siap';
    case Selesai = 'selesai';
    case Dibatalkan = 'dibatalkan';

    public function label(): string
    {
        return match ($this) {
            self::Diterima => 'Diterima',
            self::Diproses => 'Diproses',
            self::Disiapkan => 'Disiapkan',
            self::Siap => 'Siap Diantar',
            self::Selesai => 'Selesai',
            self::Dibatalkan => 'Dibatalkan',
        };
    }

    public function customerTimelineLabel(): string
    {
        return match ($this) {
            self::Diterima => 'Pesanan diterima',
            self::Diproses => 'Sedang diproses',
            self::Disiapkan => 'Sedang disiapkan',
            self::Siap => 'Siap diambil',
            self::Selesai => 'Selesai',
            self::Dibatalkan => 'Dibatalkan',
        };
    }

    public function badgeColor(): string
    {
        return match ($this) {
            self::Diterima => '#2F8FE0',
            self::Diproses => '#064E34',
            self::Disiapkan => '#E8A21A',
            self::Siap => '#5A9158',
            self::Selesai => '#6B7280',
            self::Dibatalkan => '#C62828',
        };
    }

    public function badgeClass(): string
    {
        return match ($this) {
            self::Diterima => 'bg-status-diterima text-white',
            self::Diproses => 'bg-status-diproses text-white',
            self::Disiapkan => 'bg-status-disiapkan text-white',
            self::Siap => 'bg-status-siap text-white',
            self::Selesai => 'bg-status-selesai text-white',
            self::Dibatalkan => 'bg-status-dibatalkan text-white',
        };
    }

    public function next(): ?self
    {
        return match ($this) {
            self::Diterima => self::Diproses,
            self::Diproses => self::Disiapkan,
            self::Disiapkan => self::Siap,
            self::Siap => self::Selesai,
            self::Selesai, self::Dibatalkan => null,
        };
    }

    public function canTransitionTo(self $target): bool
    {
        if ($target === self::Dibatalkan) {
            return $this !== self::Selesai && $this !== self::Dibatalkan;
        }

        return $this->next() === $target;
    }

    public function isActive(): bool
    {
        return ! in_array($this, [self::Selesai, self::Dibatalkan], true);
    }

    /**
     * @return list<string>
     */
    public static function activeValues(): array
    {
        return array_map(
            static fn (self $status): string => $status->value,
            array_values(array_filter(
                self::cases(),
                static fn (self $status): bool => $status->isActive()
            ))
        );
    }
}
