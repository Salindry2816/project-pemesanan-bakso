<?php

namespace App\Services;

use App\Enums\OrderStatus;
use App\Enums\OrderType;
use App\Enums\PaymentMethod;
use App\Enums\PaymentStatus;
use App\Enums\TableType;
use App\Exceptions\OrderCreationException;
use App\Models\BusinessProfile;
use App\Models\Customer;
use App\Models\DiningTable;
use App\Models\Menu;
use App\Models\Order;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;

class OrderService
{
    public const MAX_ACTIVE_ORDERS = 3;

    public const MAX_ORDER_NOTE_LENGTH = 200;

    public const MAX_LOCATION_NOTE_LENGTH = 100;

    public const MIN_LOCATION_NOTE_LENGTH = 3;

    public int $lastTransactionRetries = 0;

    public function __construct(
        protected ?CartService $cartService = null
    ) {}

    public static function generateCheckoutToken(): string
    {
        return Str::random(40);
    }

    /**
     * Create an order atomically with customer/table locking, daily sequence numbering,
     * checkout_token idempotency, active order limit enforcement, and snapshot creation.
     *
     * @param  array<int|string, array{qty: int, item_note?: ?string}>  $cartLines
     *
     * @throws OrderCreationException
     */
    public function createOrder(
        int $customerId,
        OrderType $orderType,
        ?int $tableId,
        ?string $locationNote,
        ?string $orderNote,
        PaymentMethod $paymentMethod,
        array $cartLines,
        string $checkoutToken,
        ?string $rateLimitIp = null,
        bool $clearCart = true,
    ): Order {
        $normalizedToken = trim($checkoutToken);
        if ($normalizedToken === '' || mb_strlen($normalizedToken) > 64) {
            throw new OrderCreationException('Token checkout tidak valid.');
        }

        $this->lastTransactionRetries = 0;

        // Fast idempotency check before rate limiting or acquiring locks
        $existingOrder = Order::query()->where('checkout_token', $normalizedToken)->first();
        if ($existingOrder !== null) {
            if ((int) $existingOrder->customer_id !== $customerId) {
                throw new OrderCreationException('Permintaan checkout tidak valid. Silakan muat ulang halaman.');
            }

            if ($clearCart && $this->cartService !== null) {
                $this->cartService->clear();
            }

            return $existingOrder->loadMissing(['items', 'table', 'statusLogs']);
        }

        $this->checkRateLimits($customerId, $rateLimitIp);

        try {
            $this->validateInputs($orderType, $tableId, $orderNote, $paymentMethod, $cartLines);
            $normalizedOrderNote = $this->normalizeOptionalNote($orderNote);

            // Ensure today's sequence row exists before locking inside the transaction
            // to avoid InnoDB gap-lock / insert-intention deadlocks under high concurrency.
            DB::table('order_sequences')->insertOrIgnore([
                'seq_date' => now()->toDateString(),
                'last_number' => 0,
            ]);

            $attempts = 0;

            try {
                $order = DB::transaction(function () use (
                    &$attempts,
                    $customerId,
                    $orderType,
                    $tableId,
                    $locationNote,
                    $normalizedOrderNote,
                    $paymentMethod,
                    $cartLines,
                    $normalizedToken,
                ): Order {
                    $attempts++;
                    // 1. Lock customer first (fixed lock order: customer -> table -> order_sequences)
                    $customer = Customer::query()->whereKey($customerId)->lockForUpdate()->first();
                    if (! $customer) {
                        throw new OrderCreationException('Data pelanggan tidak ditemukan.');
                    }

                    // 2. Re-check checkout_token idempotency after acquiring customer lock
                    $existing = Order::query()->where('checkout_token', $normalizedToken)->first();
                    if ($existing !== null) {
                        if ((int) $existing->customer_id !== $customerId) {
                            throw new OrderCreationException('Permintaan checkout tidak valid. Silakan muat ulang halaman.');
                        }

                        return $existing->loadMissing(['items', 'table', 'statusLogs']);
                    }

                    // 3. Validate & lock table (if dine-in)
                    [$table, $normalizedLocationNote] = $this->lockAndValidateTable(
                        $customerId,
                        $orderType,
                        $tableId,
                        $locationNote,
                    );

                    // 4. Enforce active order limit inside transaction (serialized per customer by step 1 lock)
                    $activeOrderCount = Order::query()
                        ->where('customer_id', $customerId)
                        ->whereIn('status', OrderStatus::activeValues())
                        ->count();

                    if ($activeOrderCount >= self::MAX_ACTIVE_ORDERS) {
                        throw new OrderCreationException(
                            'Anda sudah memiliki 3 pesanan aktif. Tunggu hingga salah satu pesanan selesai.'
                        );
                    }

                    // 5. Re-validate cart items & compute totals from fresh DB prices
                    [$subtotal, $orderItemsData] = $this->buildOrderItems($cartLines);

                    // 6. Generate gap-free daily order number via order_sequences row lock
                    $orderNumber = $this->nextDailyOrderNumber();

                    // 7. Create order, item snapshots, and initial status log
                    $order = Order::query()->create([
                        'order_number' => $orderNumber,
                        'checkout_token' => $normalizedToken,
                        'customer_id' => $customer->id,
                        'type' => $orderType,
                        'table_id' => $table?->id,
                        'location_note' => $normalizedLocationNote,
                        'note' => $normalizedOrderNote,
                        'subtotal' => $subtotal,
                        'total' => $subtotal,
                        'payment_method' => $paymentMethod,
                        'payment_status' => PaymentStatus::BelumBayar,
                        'status' => OrderStatus::Diterima,
                        'paid_at' => null,
                    ]);

                    $order->items()->createMany($orderItemsData);

                    $order->statusLogs()->create([
                        'status' => OrderStatus::Diterima,
                        'changed_by' => null,
                        'created_at' => now(),
                    ]);

                    return $order->load(['items', 'table', 'statusLogs']);
                }, 10);

                $this->lastTransactionRetries = max(0, $attempts - 1);
            } catch (QueryException $e) {
                if ($this->isDuplicateCheckoutTokenException($e)) {
                    $existing = Order::query()->where('checkout_token', $normalizedToken)->first();
                    if ($existing !== null && (int) $existing->customer_id === $customerId) {
                        if ($clearCart && $this->cartService !== null) {
                            $this->cartService->clear();
                        }

                        return $existing->loadMissing(['items', 'table', 'statusLogs']);
                    }
                }

                throw $e;
            }
        } catch (OrderCreationException $e) {
            $this->recordFailedAttempt($customerId, $rateLimitIp);

            throw $e;
        }

        $this->recordSuccessfulAttempt($customerId, $rateLimitIp);

        if ($clearCart && $this->cartService !== null) {
            $this->cartService->clear();
        }

        return $order;
    }

    protected function checkRateLimits(int $customerId, ?string $rateLimitIp): void
    {
        if ($rateLimitIp === null || $rateLimitIp === '') {
            return;
        }

        $customerFailKey = "order-create:fail:customer:{$customerId}";
        $ipFailKey = "order-create:fail:ip:{$rateLimitIp}";
        $ipSuccessKey = "order-create:success:ip:{$rateLimitIp}";

        if (RateLimiter::tooManyAttempts($customerFailKey, 10)) {
            $seconds = RateLimiter::availableIn($customerFailKey);

            throw new OrderCreationException("Terlalu banyak percobaan gagal. Silakan coba lagi dalam {$seconds} detik.");
        }

        if (RateLimiter::tooManyAttempts($ipFailKey, 20)) {
            $seconds = RateLimiter::availableIn($ipFailKey);

            throw new OrderCreationException("Terlalu banyak percobaan gagal dari perangkat ini. Silakan coba lagi dalam {$seconds} detik.");
        }

        if (RateLimiter::tooManyAttempts($ipSuccessKey, 60)) {
            $seconds = RateLimiter::availableIn($ipSuccessKey);

            throw new OrderCreationException("Batas pembuatan pesanan tercapai untuk jaringan ini. Silakan coba lagi dalam {$seconds} detik.");
        }
    }

    protected function recordFailedAttempt(int $customerId, ?string $rateLimitIp): void
    {
        if ($rateLimitIp === null || $rateLimitIp === '') {
            return;
        }

        RateLimiter::hit("order-create:fail:customer:{$customerId}", 60);
        RateLimiter::hit("order-create:fail:ip:{$rateLimitIp}", 60);
    }

    protected function recordSuccessfulAttempt(int $customerId, ?string $rateLimitIp): void
    {
        if ($rateLimitIp === null || $rateLimitIp === '') {
            return;
        }

        RateLimiter::clear("order-create:fail:customer:{$customerId}");
        RateLimiter::hit("order-create:success:ip:{$rateLimitIp}", 60);
    }

    /**
     * @param  array<int|string, array{qty: int, item_note?: ?string}>  $cartLines
     */
    protected function validateInputs(
        OrderType $orderType,
        ?int $tableId,
        ?string $orderNote,
        PaymentMethod $paymentMethod,
        array $cartLines,
    ): void {
        if ($cartLines === []) {
            throw new OrderCreationException('Keranjang belanja masih kosong.');
        }

        if (count($cartLines) > CartService::MAX_DISTINCT_ITEMS) {
            throw new OrderCreationException('Jumlah jenis menu melebihi batas maksimal keranjang.');
        }

        foreach ($cartLines as $line) {
            $qty = (int) ($line['qty'] ?? 0);
            if ($qty < 1 || $qty > CartService::MAX_QTY_PER_ITEM) {
                throw new OrderCreationException('Jumlah tiap menu harus antara 1 sampai 20 porsi.');
            }

            $itemNote = trim((string) ($line['item_note'] ?? ''));
            if (mb_strlen($itemNote) > CartService::MAX_NOTE_LENGTH) {
                throw new OrderCreationException('Catatan per menu maksimal 100 karakter.');
            }
        }

        $trimmedOrderNote = trim((string) $orderNote);
        if (mb_strlen($trimmedOrderNote) > self::MAX_ORDER_NOTE_LENGTH) {
            throw new OrderCreationException('Catatan pesanan maksimal 200 karakter.');
        }

        if ($orderType === OrderType::DineIn && $tableId === null) {
            throw new OrderCreationException('Silakan pilih meja terlebih dahulu.');
        }

        if ($paymentMethod === PaymentMethod::Qris) {
            $qrisPath = BusinessProfile::query()->value('qris_image_path');
            if (! is_string($qrisPath) || trim($qrisPath) === '') {
                throw new OrderCreationException('Pembayaran QRIS sedang tidak tersedia karena kode QR belum diunggah.');
            }
        }
    }

    protected function normalizeOptionalNote(?string $note): ?string
    {
        $trimmed = trim((string) $note);

        return $trimmed === '' ? null : $trimmed;
    }

    /**
     * @return array{0: ?DiningTable, 1: ?string}
     */
    protected function lockAndValidateTable(
        int $customerId,
        OrderType $orderType,
        ?int $tableId,
        ?string $locationNote,
    ): array {
        if ($orderType === OrderType::TakeAway) {
            return [null, null];
        }

        $table = DiningTable::query()->whereKey($tableId)->lockForUpdate()->first();
        if (! $table || ! $table->is_active) {
            throw new OrderCreationException('Meja tidak ditemukan atau sedang nonaktif.');
        }

        if ($table->type === TableType::Fixed) {
            if ($table->isOccupied($customerId, lock: true)) {
                throw new OrderCreationException('Meja yang dipilih sudah terisi oleh pelanggan lain.');
            }

            return [$table, null];
        }

        $normalizedLocationNote = trim((string) $locationNote);
        $length = mb_strlen($normalizedLocationNote);
        if ($length < self::MIN_LOCATION_NOTE_LENGTH || $length > self::MAX_LOCATION_NOTE_LENGTH) {
            throw new OrderCreationException('Catatan lokasi untuk Meja Bebas wajib diisi (3–100 karakter).');
        }

        return [$table, $normalizedLocationNote];
    }

    /**
     * @param  array<int|string, array{qty: int, item_note?: ?string}>  $cartLines
     * @return array{0: int, 1: list<array{menu_id: int, name_snapshot: string, price_snapshot: int, qty: int, item_note: ?string, line_total: int}>}
     */
    protected function buildOrderItems(array $cartLines): array
    {
        $menuIds = array_map('intval', array_keys($cartLines));
        $menus = Menu::query()->whereIn('id', $menuIds)->get()->keyBy('id');

        $subtotal = 0;
        $orderItemsData = [];

        foreach ($cartLines as $menuId => $line) {
            $menuId = (int) $menuId;
            $qty = (int) $line['qty'];
            $itemNote = $this->normalizeOptionalNote($line['item_note'] ?? null);

            /** @var Menu|null $menu */
            $menu = $menus->get($menuId);
            if (! $menu) {
                throw new OrderCreationException('Salah satu menu di keranjang sudah dihapus.');
            }

            if (! $menu->is_available) {
                throw new OrderCreationException("Menu {$menu->name} sedang habis.");
            }

            $lineTotal = $menu->price * $qty;
            $subtotal += $lineTotal;

            $orderItemsData[] = [
                'menu_id' => $menu->id,
                'name_snapshot' => $menu->name,
                'price_snapshot' => $menu->price,
                'qty' => $qty,
                'item_note' => $itemNote,
                'line_total' => $lineTotal,
            ];
        }

        return [$subtotal, $orderItemsData];
    }

    protected function nextDailyOrderNumber(): string
    {
        $now = now();
        $seqDate = $now->toDateString();
        $datePrefix = $now->format('Ymd');

        $sequence = DB::table('order_sequences')
            ->where('seq_date', $seqDate)
            ->lockForUpdate()
            ->first();

        if (! $sequence) {
            DB::table('order_sequences')->insertOrIgnore([
                'seq_date' => $seqDate,
                'last_number' => 0,
            ]);

            $sequence = DB::table('order_sequences')
                ->where('seq_date', $seqDate)
                ->lockForUpdate()
                ->first();
        }

        $nextNumber = ((int) ($sequence->last_number ?? 0)) + 1;

        DB::table('order_sequences')
            ->where('seq_date', $seqDate)
            ->update(['last_number' => $nextNumber]);

        return sprintf('%s-%04d', $datePrefix, $nextNumber);
    }

    public function cancelOrderByCustomer(int $customerId, string $orderNumber): Order
    {
        return DB::transaction(function () use ($customerId, $orderNumber): Order {
            $order = Order::query()
                ->where('order_number', $orderNumber)
                ->where('customer_id', $customerId)
                ->lockForUpdate()
                ->first();

            if (! $order) {
                throw new OrderCreationException('Pesanan tidak ditemukan.');
            }

            if ($order->status !== OrderStatus::Diterima) {
                throw new OrderCreationException(
                    'Pesanan tidak dapat dibatalkan karena sudah diproses atau diselesaikan.'
                );
            }

            $order->update([
                'status' => OrderStatus::Dibatalkan,
            ]);

            $order->statusLogs()->create([
                'status' => OrderStatus::Dibatalkan,
                'changed_by' => null,
                'created_at' => now(),
            ]);

            return $order->load(['items', 'table', 'statusLogs']);
        }, 10);
    }

    protected function isDuplicateCheckoutTokenException(QueryException $e): bool
    {
        $sqlState = $e->errorInfo[0] ?? null;
        $driverCode = $e->errorInfo[1] ?? null;

        return $sqlState === '23000'
            && (int) $driverCode === 1062
            && str_contains($e->getMessage(), 'checkout_token');
    }
}
