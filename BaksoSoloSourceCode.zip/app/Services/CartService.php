<?php

namespace App\Services;

use App\Models\Menu;
use Illuminate\Contracts\Session\Session;
use InvalidArgumentException;

class CartService
{
    public const MAX_QTY_PER_ITEM = 20;

    public const MAX_DISTINCT_ITEMS = 30;

    public const MAX_NOTE_LENGTH = 100;

    public const SESSION_KEY = 'cart';

    public function __construct(
        protected ?Session $session = null
    ) {}

    protected function session(): Session
    {
        if ($this->session !== null) {
            return $this->session;
        }

        if (request()->hasSession()) {
            return request()->session();
        }

        return app('session.store');
    }

    /**
     * @return array<int, array{qty: int, item_note: ?string}>
     */
    public function lines(): array
    {
        return $this->getCart();
    }

    /**
     * Total quantity of all items in the cart.
     */
    public function count(): int
    {
        $cart = $this->getCart();
        $total = 0;
        foreach ($cart as $item) {
            $total += (int) $item['qty'];
        }

        return $total;
    }

    /**
     * Number of distinct menu items in the cart.
     */
    public function distinctCount(): int
    {
        return count($this->getCart());
    }

    /**
     * Check if the cart is completely empty.
     */
    public function isEmpty(): bool
    {
        return $this->distinctCount() === 0;
    }

    /**
     * Add quantity of a menu item to the cart.
     *
     * @throws InvalidArgumentException
     */
    public function add(int $menuId, int $qty = 1): int
    {
        if ($qty < 1) {
            throw new InvalidArgumentException('Jumlah pesanan minimal 1 porsi.');
        }

        if ($qty > self::MAX_QTY_PER_ITEM) {
            throw new InvalidArgumentException('Jumlah pesanan untuk satu menu maksimal 20 porsi.');
        }

        $cart = $this->getCart();

        if (! isset($cart[$menuId]) && count($cart) >= self::MAX_DISTINCT_ITEMS) {
            throw new InvalidArgumentException('Keranjang belanja maksimal berisi 30 jenis menu berbeda.');
        }

        /** @var Menu|null $menu */
        $menu = Menu::query()->find($menuId);

        if (! $menu) {
            throw new InvalidArgumentException('Menu tidak ditemukan.');
        }

        if (! $menu->is_available) {
            throw new InvalidArgumentException("Menu {$menu->name} sedang tidak tersedia.");
        }

        $currentQty = isset($cart[$menuId]) ? (int) $cart[$menuId]['qty'] : 0;
        $newQty = $currentQty + $qty;

        if ($newQty > self::MAX_QTY_PER_ITEM) {
            throw new InvalidArgumentException('Jumlah pesanan untuk menu ini maksimal 20 porsi.');
        }

        $cart[$menuId] = [
            'qty' => $newQty,
            'item_note' => $cart[$menuId]['item_note'] ?? null,
        ];

        $this->saveCart($cart);

        return $newQty;
    }

    /**
     * Set explicit quantity for a menu item.
     * Setting quantity to 0 removes the item.
     *
     * @throws InvalidArgumentException
     */
    public function setQuantity(int $menuId, int $qty): void
    {
        if ($qty === 0) {
            $this->remove($menuId);

            return;
        }

        if ($qty < 0) {
            throw new InvalidArgumentException('Jumlah pesanan tidak boleh negatif.');
        }

        if ($qty > self::MAX_QTY_PER_ITEM) {
            throw new InvalidArgumentException('Jumlah pesanan untuk satu menu maksimal 20 porsi.');
        }

        $cart = $this->getCart();

        if (! isset($cart[$menuId])) {
            if (count($cart) >= self::MAX_DISTINCT_ITEMS) {
                throw new InvalidArgumentException('Keranjang belanja maksimal berisi 30 jenis menu berbeda.');
            }

            /** @var Menu|null $menu */
            $menu = Menu::query()->find($menuId);

            if (! $menu) {
                throw new InvalidArgumentException('Menu tidak ditemukan.');
            }

            if (! $menu->is_available) {
                throw new InvalidArgumentException("Menu {$menu->name} sedang tidak tersedia.");
            }

            $cart[$menuId] = [
                'qty' => $qty,
                'item_note' => null,
            ];
        } else {
            $cart[$menuId]['qty'] = $qty;
        }

        $this->saveCart($cart);
    }

    /**
     * Remove a menu item from the cart.
     */
    public function remove(int $menuId): void
    {
        $cart = $this->getCart();
        if (isset($cart[$menuId])) {
            unset($cart[$menuId]);
            $this->saveCart($cart);
        }
    }

    /**
     * Set custom note for an item in the cart.
     * Max 100 characters. Rejects longer strings with localized error.
     *
     * @throws InvalidArgumentException
     */
    public function setItemNote(int $menuId, ?string $note): void
    {
        $cart = $this->getCart();

        if (! isset($cart[$menuId])) {
            throw new InvalidArgumentException('Menu tidak ada di dalam keranjang.');
        }

        if ($note === null) {
            $cart[$menuId]['item_note'] = null;
        } else {
            $trimmed = trim($note);
            if ($trimmed === '') {
                $cart[$menuId]['item_note'] = null;
            } else {
                if (mb_strlen($trimmed) > self::MAX_NOTE_LENGTH) {
                    throw new InvalidArgumentException('Catatan menu maksimal 100 karakter.');
                }
                $cart[$menuId]['item_note'] = $trimmed;
            }
        }

        $this->saveCart($cart);
    }

    /**
     * Clear the cart from session.
     * Does NOT touch order_note or any other session keys.
     */
    public function clear(): void
    {
        $this->session()->forget(self::SESSION_KEY);
    }

    /**
     * Build cart summary with live prices and validation against database.
     * Prices are NEVER taken from client or stored in session.
     * Uses eager loading (single DB query) to prevent N+1.
     */
    public function summary(): CartSummary
    {
        $cart = $this->getCart();

        if (empty($cart)) {
            return new CartSummary([], [], 0, false);
        }

        $menuIds = array_keys($cart);

        // Single eager-loaded query to avoid N+1 queries
        $menus = Menu::query()
            ->with('category')
            ->whereIn('id', $menuIds)
            ->get()
            ->keyBy('id');

        $validLines = [];
        $problemLines = [];
        $total = 0;

        foreach ($cart as $menuId => $item) {
            $qty = (int) $item['qty'];
            $note = $item['item_note'] ?? null;

            if (! $menus->has($menuId)) {
                $problemLines[] = [
                    'menu_id' => $menuId,
                    'menu' => null,
                    'qty' => $qty,
                    'item_note' => $note,
                    'reason' => 'Menu sudah tidak ada atau telah dihapus',
                ];

                continue;
            }

            /** @var Menu $menu */
            $menu = $menus->get($menuId);

            if (! $menu->is_available) {
                $problemLines[] = [
                    'menu_id' => $menuId,
                    'menu' => $menu,
                    'qty' => $qty,
                    'item_note' => $note,
                    'reason' => "Menu {$menu->name} sedang tidak tersedia",
                ];

                continue;
            }

            $unitPrice = (int) $menu->price;
            $lineTotal = $unitPrice * $qty;
            $total += $lineTotal;

            $validLines[] = [
                'menu_id' => $menuId,
                'menu' => $menu,
                'qty' => $qty,
                'item_note' => $note,
                'unit_price' => $unitPrice,
                'line_total' => $lineTotal,
            ];
        }

        $hasProblems = count($problemLines) > 0;

        return new CartSummary($validLines, $problemLines, $total, $hasProblems);
    }

    /**
     * Explicit cleanup method to discard unavailable or deleted items from session.
     * Must be called explicitly, never silently inside summary().
     */
    public function removeUnavailable(): int
    {
        $summary = $this->summary();

        if (! $summary->hasProblems) {
            return 0;
        }

        $cart = $this->getCart();
        $removed = 0;

        foreach ($summary->problemLines as $problem) {
            if (isset($cart[$problem['menu_id']])) {
                unset($cart[$problem['menu_id']]);
                $removed++;
            }
        }

        $this->saveCart($cart);

        return $removed;
    }

    /**
     * Read and normalize cart from session.
     * Defensive against tampered or corrupted session data.
     *
     * @return array<int, array{qty: int, item_note: ?string}>
     */
    protected function getCart(): array
    {
        $raw = $this->session()->get(self::SESSION_KEY);

        if (! is_array($raw)) {
            return [];
        }

        $normalized = [];

        foreach ($raw as $key => $value) {
            $menuId = filter_var($key, FILTER_VALIDATE_INT);
            if ($menuId === false || $menuId <= 0) {
                continue;
            }

            // Scalar value support (backward compatibility if qty was stored as integer)
            if (is_int($value) || (is_string($value) && ctype_digit($value))) {
                $qty = (int) $value;
                if ($qty <= 0) {
                    continue;
                }
                $qty = min($qty, self::MAX_QTY_PER_ITEM);
                $normalized[$menuId] = [
                    'qty' => $qty,
                    'item_note' => null,
                ];

                continue;
            }

            if (is_array($value)) {
                $qty = filter_var($value['qty'] ?? null, FILTER_VALIDATE_INT);
                if ($qty === false || $qty <= 0) {
                    continue;
                }
                $qty = min($qty, self::MAX_QTY_PER_ITEM);

                $note = isset($value['item_note']) ? trim((string) $value['item_note']) : null;
                if ($note === '') {
                    $note = null;
                } elseif ($note !== null && mb_strlen($note) > self::MAX_NOTE_LENGTH) {
                    $note = mb_substr($note, 0, self::MAX_NOTE_LENGTH);
                }

                $normalized[$menuId] = [
                    'qty' => $qty,
                    'item_note' => $note,
                ];
            }
        }

        return $normalized;
    }

    /**
     * @param  array<int, array{qty: int, item_note: ?string}>  $cart
     */
    protected function saveCart(array $cart): void
    {
        $this->session()->put(self::SESSION_KEY, $cart);
    }
}
