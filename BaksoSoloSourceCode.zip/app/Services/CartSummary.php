<?php

namespace App\Services;

use App\Models\Menu;

class CartSummary
{
    /**
     * @param  array<int, array{menu_id: int, menu: Menu, qty: int, item_note: ?string, unit_price: int, line_total: int}>  $validLines
     * @param  array<int, array{menu_id: int, menu: ?Menu, qty: int, item_note: ?string, reason: string}>  $problemLines
     */
    public function __construct(
        public readonly array $validLines,
        public readonly array $problemLines,
        public readonly int $total,
        public readonly bool $hasProblems,
    ) {}

    /**
     * @return array{valid_lines: array<int, array{menu_id: int, menu: Menu, qty: int, item_note: ?string, unit_price: int, line_total: int}>, problem_lines: array<int, array{menu_id: int, menu: ?Menu, qty: int, item_note: ?string, reason: string}>, total: int, has_problems: bool}
     */
    public function toArray(): array
    {
        return [
            'valid_lines' => $this->validLines,
            'problem_lines' => $this->problemLines,
            'total' => $this->total,
            'has_problems' => $this->hasProblems,
        ];
    }
}
