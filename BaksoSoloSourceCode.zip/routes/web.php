<?php

use App\Http\Controllers\Admin\LogoutController;
use App\Http\Controllers\Admin\PrintQrController;
use App\Http\Controllers\Customer\ResetCustomerSessionController;
use App\Livewire\Admin\Auth\Login;
use App\Livewire\Admin\BusinessProfileEditor;
use App\Livewire\Admin\CategoryManager;
use App\Livewire\Admin\ChangePassword;
use App\Livewire\Admin\Dashboard;
use App\Livewire\Admin\MenuManager;
use App\Livewire\Admin\OrderDetail;
use App\Livewire\Admin\OrderList;
use App\Livewire\Admin\SalesReport;
use App\Livewire\Admin\TableManager;
use App\Livewire\Customer\CartViewer;
use App\Livewire\Customer\MenuCatalog;
use App\Livewire\Customer\OrderConfirmation;
use App\Livewire\Customer\OrderHistory;
use App\Livewire\Customer\OrderStatusDetail;
use App\Livewire\Customer\PhoneEntry;
use App\Livewire\Customer\Profile;
use App\Livewire\Customer\TableSelection;
use Illuminate\Support\Facades\Route;

Route::get('/', PhoneEntry::class)->name('customer.phone');
Route::post('/ganti-nomor', ResetCustomerSessionController::class)->name('customer.reset');
Route::get('/pilih-meja', TableSelection::class)
    ->middleware('customer.identified')
    ->name('customer.table');
Route::get('/menu', MenuCatalog::class)
    ->middleware('customer.table-selected')
    ->name('customer.menu');
Route::get('/keranjang', CartViewer::class)
    ->middleware('customer.table-selected')
    ->name('customer.cart');
Route::get('/konfirmasi', OrderConfirmation::class)
    ->middleware('customer.table-selected')
    ->name('customer.confirm');
Route::get('/pesanan', OrderHistory::class)
    ->middleware('customer.identified')
    ->name('customer.orders');
Route::get('/pesanan/{orderNumber}', OrderStatusDetail::class)
    ->middleware('customer.identified')
    ->name('customer.order.show');
Route::get('/profil', Profile::class)
    ->middleware('customer.identified')
    ->name('customer.profile');

if (app()->isLocal()) {
    Route::get('/_tokens', function () {
        return view('pages.design-tokens');
    })->name('design.tokens');
}

Route::prefix('admin')->name('admin.')->group(function (): void {
    Route::middleware('guest')->group(function (): void {
        Route::get('/login', Login::class)->name('login');
    });

    Route::middleware('auth')->group(function (): void {
        Route::get('/', Dashboard::class)->name('dashboard');
        Route::get('/pesanan', OrderList::class)->name('orders.index');
        Route::get('/pesanan/{order}', OrderDetail::class)->name('orders.show');
        Route::get('/laporan', SalesReport::class)->name('reports');
        Route::get('/menu', MenuManager::class)->name('menus');
        Route::get('/kategori', CategoryManager::class)->name('categories');
        Route::get('/meja', TableManager::class)->name('tables');
        Route::get('/profil', BusinessProfileEditor::class)->name('profile');
        Route::get('/password', ChangePassword::class)->name('password');
        Route::get('/qr', PrintQrController::class)->name('qr');
        Route::post('/logout', LogoutController::class)->name('logout');
    });
});
